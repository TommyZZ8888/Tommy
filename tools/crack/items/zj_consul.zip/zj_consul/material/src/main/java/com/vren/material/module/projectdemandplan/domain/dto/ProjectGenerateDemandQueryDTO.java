package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.ArrayList;

@Data
public class ProjectGenerateDemandQueryDTO  {
    @ApiModelProperty("项目id")
    @NotBlank(message = "项目id不能为空")
    private String projectId;

    @ApiModelProperty("产品需求计划idList")
    private String[] idList;

}
