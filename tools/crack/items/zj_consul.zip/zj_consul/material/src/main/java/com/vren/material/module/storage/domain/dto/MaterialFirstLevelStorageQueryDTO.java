package com.vren.material.module.storage.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialFirstLevelStorageQueryDTO extends PageParam {

    @ApiModelProperty("归属")
    private String ascription;

    @ApiModelProperty("物资类型")
    private Integer materialType;
    @ApiModelProperty("物资名称")
    private String  materialName;

    @ApiModelProperty("入库状态(默认false)")
    private Integer warehousingState;

    @ApiModelProperty("入库开始时间")
    private Date storageStartDate;
    @ApiModelProperty("入库结束时间")
    private Date storageEndDate;
    @ApiModelProperty("入库方式")
    private Integer warehousingMethod;


}
