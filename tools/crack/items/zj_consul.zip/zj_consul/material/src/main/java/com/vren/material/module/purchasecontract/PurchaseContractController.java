package com.vren.material.module.purchasecontract;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.productmanagement.domain.dto.ProjectIdDTO;
import com.vren.material.module.purchasecontract.domain.dto.*;
import com.vren.material.module.purchasecontract.domain.vo.*;
import com.vren.material.module.purchaseplan.domain.vo.PurchasePlanDetailVO;
import com.vren.material.module.purchaseplan.domain.vo.SelectVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/purchaseContract")
@Api(tags = {"采购合同清单"})
@OperateLog
public class PurchaseContractController {

    @Autowired
    private PurchaseContractService purchaseContractService;

    @RequestMapping(value = "/getProjectInPurchasePlan", method = RequestMethod.POST)
    @ApiOperation("查询采购计划里面所有的项目")
    public ResponseResult<List<ProjectInPurchasePlanVO>> getProjectInPurchasePlan() {
        return ResponseResult.success("操作成功",purchaseContractService.getProjectInPurchasePlan());
    }


    @RequestMapping(value = "/generateContractList", method = RequestMethod.POST)
    @ApiOperation("生成合同清单")
    public ResponseResult<Boolean> generateContractList(@RequestBody @Valid GenerateContractListDTO dto) {
        purchaseContractService.generateContractList(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/selectContractList", method = RequestMethod.POST)
    @ApiOperation("查询合同清单")
    public ResponseResult<PageResult<ContractListVO>> getContractListById(@RequestBody QueryContractListDTO dto){
        return  ResponseResult.success("获取成功",purchaseContractService.getContractList(dto));
    }

    @RequestMapping(value = "/deleteRelationContractList", method = RequestMethod.POST)
    @ApiOperation("删除采购计划与合同清单的关联")
    public ResponseResult<Boolean> deleteRelationContractList(@RequestBody @Valid GetOneOrDeleteDTO dto){
        purchaseContractService.deleteRelationContractList(dto);
        return  ResponseResult.success("获取成功",true);
    }

    @RequestMapping(value = "/selectContractListById", method = RequestMethod.POST)
    @ApiOperation("根据id查询合同清单")
    public ResponseResult<ContractListVO> getContractListById(@RequestBody @Valid GetOneOrDeleteDTO dto){
        return  ResponseResult.success("获取成功",purchaseContractService.getContractListById(dto));
    }

    @RequestMapping(value = "/deleteContractList", method = RequestMethod.POST)
    @ApiOperation("删除合同清单")
    public ResponseResult<Boolean> deleteContractList(@RequestBody @Valid GetOneOrDeleteDTO dto){
        purchaseContractService.deleteContractList(dto);
        return  ResponseResult.success("获取成功",true);
    }



    @RequestMapping(value = "/editContractList", method = RequestMethod.POST)
    @ApiOperation("编辑合同清单")
    public ResponseResult<Boolean> editContractList(@RequestBody EditContractListDTO dto){
        purchaseContractService.editContractList(dto);
        return  ResponseResult.success("获取成功",true);
    }



    @RequestMapping(value = "/selectPurchaseStatesRecord", method = RequestMethod.POST)
    @ApiOperation("查询合同清单的采购状态变化情况")
    public ResponseResult<List<PurchaseStatusRecordVO>> getPurchaseStatesRecord(@RequestBody GetPurchaseStatusRecordDTO dto){
        return  ResponseResult.success("获取成功", purchaseContractService.getPurchaseStatesRecord(dto));
    }





    //*****************************************子界面****************************************************************


//    @NoNeedLogin
//    @RequestMapping(value = "/selectPurchaseStatesRecord", method = RequestMethod.POST)
//    @ApiOperation("查询采购计划详情（修改到货数量）")
//    public ResponseResult<List<PurchaseStatusRecordVO>> getPurchaseStatesRecord(@RequestBody GetPurchaseStatusRecordDTO dto){
//        return  ResponseResult.success("获取成功", purchaseContractService.getPurchaseStatesRecord(dto));
//    }

    /*****************************************项目需求计划需要的接口*************************************************/

    @RequestMapping(value = "/getContractNoAndId", method = RequestMethod.POST)
    @ApiOperation("查询所有的合同编号和id")
    public ResponseResult<List<ContractNoAndIdVO>> getContractNoAndId(){
        return  ResponseResult.success("获取成功", purchaseContractService.getContractNoAndId());
    }


    @RequestMapping(value = "/getProjectIdAndNameInContract", method = RequestMethod.POST)
    @ApiOperation("查询所有合同清单下面的项目id和项目名称")
    public ResponseResult<List<ProjectIdAndNameVO>> getProjectIdAndNameInContract(@RequestBody @Valid GetOneOrDeleteDTO dto){
        return  ResponseResult.success("获取成功", purchaseContractService.getProjectIdAndNameInContract(dto));
    }

    @RequestMapping(value = "/getMaterialTypeByProjectId", method = RequestMethod.POST)
    @ApiOperation("选择项目后，根据项目id查询下面的物资类型")
    public ResponseResult<List<SelectVO>> getMaterialTypeByProjectId(@RequestBody ProjectIdDTO dto){
        return  ResponseResult.success("获取成功", purchaseContractService.getMaterialTypeByProjectId(dto));
    }

    @RequestMapping(value = "/getPurchasePlanDetail", method = RequestMethod.POST)
    @ApiOperation("选择项目、物资类型后，查询所有的物资详情")
    public ResponseResult<List<PurchasePlanDetailVO>> getPurchasePlanDetail(@RequestBody PurchasePlanDetailDTO dto){
        return  ResponseResult.success("获取成功", purchaseContractService.getPurchasePlanDetail(dto));
    }

    @RequestMapping(value = "/getPurchasePlanNumberInSelect", method = RequestMethod.POST)
    @ApiOperation("根据选择的项目和物资类型和物资类型回显")
    public ResponseResult<List<PurchasePlanNumberInSelectVO>> getPurchasePlanNumberInSelect(@RequestBody PurchasePlanNumberInSelectDTO dto){
        return  ResponseResult.success("获取成功", purchaseContractService.getPurchasePlanNumberInSelect(dto));
    }

    @RequestMapping(value = "/export", method = RequestMethod.POST)
    @ApiOperation("导出")
    public void export(HttpServletResponse response, @RequestBody ExportDTO dto){
        purchaseContractService.export(response,dto);
    }


    @RequestMapping(value = "/importPurchaseContractDetail", method = RequestMethod.POST)
    @ApiOperation("导入")
    public ResponseResult<Boolean> importPurchaseContractDetail(MultipartFile file,ImportPurchaseContractDetailDTO dto){
        try {
            purchaseContractService.importPurchaseContractDetail(file,dto);
            return ResponseResult.success("导入成功",true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }




}
