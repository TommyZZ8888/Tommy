package com.vren.material.module.materialrenturn.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GenerateSpareRecordDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("余料名称")
    private String remainingMaterialName;

    @ApiModelProperty("余料编号")
    private String remainingMaterialNo;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("余料重量")
    @ConversionNumber
    private Long remainingMaterialWeight;

    @ApiModelProperty("余料数量")
    @ConversionNumber
    private Long remainingMaterialCount;

    @ApiModelProperty("执行标准")
    private String executiveStandard;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("附件")
    private String attachmentPath;

}
