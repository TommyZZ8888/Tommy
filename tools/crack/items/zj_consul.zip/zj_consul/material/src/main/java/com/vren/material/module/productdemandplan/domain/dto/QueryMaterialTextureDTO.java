package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryMaterialTextureDTO extends PageParam {
    @ApiModelProperty("代号")
    private String code;

    @ApiModelProperty("材料")
    private String material;

}
