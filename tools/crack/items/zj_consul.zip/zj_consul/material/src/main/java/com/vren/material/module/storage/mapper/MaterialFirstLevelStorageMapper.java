package com.vren.material.module.storage.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialrenturn.domain.entity.MaterialReturn;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MaterialFirstLevelStorageMapper extends MPJBaseMapper<MaterialFirstLevelStorage> {
    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<MaterialFirstLevelStorage> entities);
}
