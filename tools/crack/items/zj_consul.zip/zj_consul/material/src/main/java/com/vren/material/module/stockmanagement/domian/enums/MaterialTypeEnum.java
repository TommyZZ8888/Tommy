package com.vren.material.module.stockmanagement.domian.enums;

/**
 * @author 耿让
 */

public enum
MaterialTypeEnum {

    BOARD(1,"板材"),
    PROFILE(2,"型材"),
    FORGE_PIECE(3,"辅材"),
    PURCHASED_PARTS(4,"外购件"),
    FORGING(5,"锻材"),
    WELDING_MATERIALS(6,"焊材"),
    PAINT(7,"油漆"),
    SPARE_PARTS(8,"备品/备件"),
    SURPLUS_MATERIALS(9,"余料");

    MaterialTypeEnum(Integer code, String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
