package com.vren.material.module.materialcheckout.domain.enums;

public enum TaxMethod {
    GENERAL_TAXATION(0,"一般计税"),
    SIMPLE_TAXATION(1,"简易计税");
    private Integer code;
    private String name;
    TaxMethod(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
