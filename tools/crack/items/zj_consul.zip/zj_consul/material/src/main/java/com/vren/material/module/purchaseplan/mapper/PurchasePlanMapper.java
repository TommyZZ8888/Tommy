package com.vren.material.module.purchaseplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 */
@Mapper
public interface PurchasePlanMapper extends MPJBaseMapper<PurchasePlan> {


}
