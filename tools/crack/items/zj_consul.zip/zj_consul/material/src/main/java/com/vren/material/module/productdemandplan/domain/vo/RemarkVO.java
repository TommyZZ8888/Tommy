package com.vren.material.module.productdemandplan.domain.vo;

import lombok.Data;

@Data
public class RemarkVO {
    private Integer seq;
    private String content;
}
