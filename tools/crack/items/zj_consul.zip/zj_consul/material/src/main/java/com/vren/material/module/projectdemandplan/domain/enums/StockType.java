package com.vren.material.module.projectdemandplan.domain.enums;

public enum StockType {
    SURPLUS_MATERIAL (1,"余料"),
    STOCK(2,"库存")

    ;
    StockType (Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
