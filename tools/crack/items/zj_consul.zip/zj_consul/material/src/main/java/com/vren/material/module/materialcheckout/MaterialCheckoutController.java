package com.vren.material.module.materialcheckout;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.materialcheckout.domain.dto.*;
import com.vren.material.module.materialcheckout.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/materialcheckout")
@Api(tags = {"材料出库记录"})
@OperateLog
public class MaterialCheckoutController {
    @Autowired
    private MaterialCheckoutService materialCheckoutService;

    @RequestMapping(value = "/addMaterialCheckout", method = RequestMethod.POST)
    @ApiOperation("新增或修改领料单")
    public ResponseResult<Boolean> addOrEditMaterialCheckout(@RequestBody @Valid MaterialCheckoutRecordAddDTO dto) {
        materialCheckoutService.addOrEditMaterialCheckout(dto);
        return ResponseResult.success("操作成功");
    }



    @RequestMapping(value = "/getTaxMethodVOList", method = RequestMethod.POST)
    @ApiOperation("获得计税方法下拉框")
    public ResponseResult<List<TaxMethodVO>> getTaxMethodVOList() {

        return ResponseResult.success("操作成功",materialCheckoutService.getTaxMethodVOList());
    }

    @RequestMapping(value = "/getMaterialCheckoutList", method = RequestMethod.POST)
    @ApiOperation("获得领料单列表数据")
    public ResponseResult<PageResult<MaterialCheckoutRecordVO>> getMaterialCheckoutList(@RequestBody @Valid MaterialCheckoutRecordQueryDTO dto) {

        return ResponseResult.success("操作成功",materialCheckoutService.getMaterialCheckoutList(dto));
    }
    @RequestMapping(value = "/deleteMaterialCheckout", method = RequestMethod.POST)
    @ApiOperation("删除领料单")
    public ResponseResult<Boolean> deleteMaterialCheckout(@RequestBody @Valid MaterialCheckoutRecordDeleteDTO dto) {
        materialCheckoutService.deleteMaterialCheckout(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/getMaterialCheckoutDataList", method = RequestMethod.POST)
    @ApiOperation("获得库存回显数据")
    public ResponseResult<MaterialCheckoutDataVO> getMaterialCheckoutDataList(@RequestBody @Valid MaterialCheckoutDataDTO dto) {

        return ResponseResult.success("操作成功",materialCheckoutService.getMaterialCheckoutDataList(dto));
    }
    @RequestMapping(value = "/materialCheckout", method = RequestMethod.POST)
    @ApiOperation("领料单点出库(按钮)")
    public ResponseResult<Boolean> materialCheckout(@RequestBody @Valid MaterialCheckoutDTO dto) {
        materialCheckoutService.materialCheckout(dto);
        return ResponseResult.success("出库成功");
    }
/***************************************************************************************************************************/
    @RequestMapping(value = "/getMaterialNameList", method = RequestMethod.POST)
    @ApiOperation("获得物资编号下拉框")
    public ResponseResult<List<MaterialNumberVO>> getMaterialNameList(@RequestBody @Valid MaterialCheckoutRecordQueryDTO dto) {

        return ResponseResult.success("操作成功",materialCheckoutService.getMaterialNameList(dto));
    }
    @RequestMapping(value = "/getMaterialCheckoutDetailList", method = RequestMethod.POST)
    @ApiOperation("获得领料单列表明细数据")
    public ResponseResult<PageResult<MaterialCheckoutDetailVO>> getMaterialCheckoutDetailList(@RequestBody @Valid MaterialCheckoutDetailQueryDTO dto) {

        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutDetailList(dto));
    }
    @RequestMapping(value = "/getMaterialCheckoutDetailById", method = RequestMethod.POST)
    @ApiOperation("获得单个领料单明细数据")
    public ResponseResult<MaterialCheckoutDetailVO> getMaterialCheckoutDetailById(@RequestBody @Valid MaterialCheckoutDetailDTO dto) {

        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutDetailById(dto));
    }


    @RequestMapping(value = "/addMaterialCheckoutDetail", method = RequestMethod.POST)
    @ApiOperation("新增或修改领料单明细")
    public ResponseResult<Boolean> generateMaterialCheckoutDetail(@RequestBody @Valid MaterialCheckoutDetailAddDTO dto) {
        materialCheckoutService.addMaterialCheckoutDetail(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/deleteMaterialCheckoutDetail", method = RequestMethod.POST)
    @ApiOperation("删除领料单明细")
    public ResponseResult<Boolean> deleteMaterialCheckoutDetail(@RequestBody @Valid MaterialCheckoutDetailDeleteDTO dto) {
        materialCheckoutService.deleteMaterialCheckoutDetail(dto);
        return ResponseResult.success("操作成功");
    }
}
