package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ProjectDemandPlanUpdateDTO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目名称对应的id")
    @NotBlank(message ="项目id不能为空" )
    private String projectId;

    @ApiModelProperty("需求类型")
    @NotNull(message = "需求类型不能为空")
    private Integer demandType;

    @ApiModelProperty("计划编号")
    private String planNo;

    @ApiModelProperty("编制说明")
    private String preparationDescription;

    @ApiModelProperty("附件路径")
    private String attachmentPath;
    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;
}
