package com.vren.material.module.stockmanagement.domian.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class MaterialStockVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目表id")
    private String projectId;

    @ApiModelProperty("项目名称：根据项目表id获得")
    private String projectName;

    @ApiModelProperty("物资类型:1板材、2型材（型材、管材、棒材）、3辅材（五金等）、4外购件、5锻材、6焊材、7油漆、8备品/备件、9余料")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ApiModelProperty("税前单价")
//    @ConversionNumber
    private Long preTaxPrice;

    @ApiModelProperty("预警值")
    private Integer warningStatus;

    @ApiModelProperty("锁库数量")
    @ConversionNumber
    private Integer lockNumber;

    @ApiModelProperty("重量")
//    @ConversionNumber
    private Long weight;

    @ApiModelProperty("库存状态 1锁库、2未锁库")
    private Integer stockStatus;

    @ApiModelProperty("库存状态")
    private String stockStatusText;

    @ApiModelProperty("入库时间")
    private Date stockInTime;

}
