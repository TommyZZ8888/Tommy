package com.vren.material.module.materialrenturn.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class MaterialReturnVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("材料类型")
    private Integer materialType;

    @ApiModelProperty("材料类型")
    private String materialTypeText;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("生产公司")
    private String productionCompany;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("退库重量")
    @ConversionNumber
    private Long returnWeight;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long returnCount;

    @ApiModelProperty("执行标准（技术标准）")
    private String executiveStandards;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("面积")
    @ConversionNumber
    private Long area;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("创建时间（回库时间）")
    private Date createTime;

    @ApiModelProperty("退库类型")
    private String returnType;

}
