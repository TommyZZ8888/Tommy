package com.vren.material.module.storage.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.storage.domain.entity.MaterialStorageNotice;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MaterialStorageNoticeMapper extends MPJBaseMapper<MaterialStorageNotice> {
}
