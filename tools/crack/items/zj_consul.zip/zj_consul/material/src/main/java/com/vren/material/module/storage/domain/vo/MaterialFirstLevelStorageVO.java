package com.vren.material.module.storage.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialFirstLevelStorageVO {
    @ApiModelProperty("材料名称")
    private String materialName;
    @ApiModelProperty("归属(项目名称/设备类型)")
    private String ascription;
    @ApiModelProperty("归属描述")
    private String ascriptionText;
    @ApiModelProperty("物资类型")
    private Integer materialType;
    @ApiModelProperty("物资类型描述")
    private String materialTypeText;
    @ApiModelProperty("材料编号")
    private String materialNumber;
    @ApiModelProperty("合同编号")
    private String contractNo;
    @ApiModelProperty("项目名称")
    private String projectName;
    @ApiModelProperty("设备类型")
    private String deviceDrop;
    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("牌号")
    private  String brand;

    @ApiModelProperty("材质")
    private String texture;


    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("金额")
    private  Long money;


    @ApiModelProperty("入库日期")
    private Date storageDate;


    @ApiModelProperty("入库状态(默认 0 )")
    private Integer warehousingState;

    @ApiModelProperty("入库状态描述")
    private String warehousingStateText;
    //页面上没有的字段

    private String id;

    @ApiModelProperty("项目表id")
    private String projectId;



    @ApiModelProperty("库存表id")
    private  String materialStockId;

    @ApiModelProperty("物资入库通知单表ID")
    private String materialStorageNoticeId;

    @ApiModelProperty("生产厂家")
    private String manufacturer;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ConversionNumber
    @ApiModelProperty("单价")
    private Long univalence;

    @ApiModelProperty("生产日期")
    private Date manufactureDate;

    @ApiModelProperty("有效期")
    private Date validityTerm;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("焊材,型号")
    private String model;
    @ApiModelProperty("油漆,面积")
    private String area;
    @ApiModelProperty("油漆,颜色")
    private String colour;

    @ConversionNumber
    @ApiModelProperty("实际入库数量")
    private Long actualStockAmount;

    @ConversionNumber
    @ApiModelProperty("税前单价")
    private Long  preTaxPrice;

    @ConversionNumber
    @ApiModelProperty("税额")
    private Long tax;

    @ConversionNumber
    @ApiModelProperty("含税单价")
    private Long unitPriceIncludingTax;

    @ConversionNumber
    @ApiModelProperty("含税总额")
    private Long totalAmountIncludingTax;

    @ConversionNumber
    @ApiModelProperty("税前总额")
    private Long totalAmountBeforeTax;



    @ApiModelProperty("true 已有通知单id(有,复选框置灰)  false 没有")
    private Boolean noticeState;


    @ApiModelProperty("入库方式 (0,手动录入 1 ,扫码录入)")
    private Integer warehousingMethod;
    @ApiModelProperty("入库方式 (0,手动录入 1 ,扫码录入 ")
    private String warehousingMethodText;
    @ApiModelProperty("发票入库 (0,否  1 是)")
    private Integer invoiceWarehousing;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;
}
