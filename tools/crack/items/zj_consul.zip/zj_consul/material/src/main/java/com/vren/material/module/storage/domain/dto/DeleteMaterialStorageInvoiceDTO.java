package com.vren.material.module.storage.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class DeleteMaterialStorageInvoiceDTO {
    @ApiModelProperty("物资入库发票id")
    private String id;
}
