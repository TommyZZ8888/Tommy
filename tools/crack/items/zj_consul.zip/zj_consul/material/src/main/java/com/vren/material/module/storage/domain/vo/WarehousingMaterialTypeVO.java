package com.vren.material.module.storage.domain.vo;

import lombok.Data;

@Data
public class WarehousingMaterialTypeVO {
    private Integer code;
    private String value;
}
