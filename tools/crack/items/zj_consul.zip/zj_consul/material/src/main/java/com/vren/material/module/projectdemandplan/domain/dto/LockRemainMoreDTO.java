package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class LockRemainMoreDTO {

    @ApiModelProperty("锁余料的数据")
    private List<MaterialRemainDTO> list;
}
