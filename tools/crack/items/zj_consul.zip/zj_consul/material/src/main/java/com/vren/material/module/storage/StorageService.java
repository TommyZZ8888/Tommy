package com.vren.material.module.storage;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.module.basedb.dictdata.DictDataService;
import com.vren.common.module.basedb.dictdata.domain.entity.DictDataEntity;
import com.vren.common.module.material.entity.MaterialFirstLevelStorageFeignVO;
import com.vren.common.module.material.entity.MaterialNoticeVO;
import com.vren.common.module.project.ProjectFeign;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.quality.QualityService;
import com.vren.material.module.purchasecontract.domain.entity.ContractList;
import com.vren.material.module.purchasecontract.mapper.ContractListMapper;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.dto.QueryOneDTO;
import com.vren.material.module.stockmanagement.MaterialStockMapper;
import com.vren.material.module.stockmanagement.domian.dto.MaterialStockDTO;
import com.vren.material.module.storage.domain.dto.*;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import com.vren.material.module.storage.domain.entity.MaterialStorageInvoice;
import com.vren.material.module.storage.domain.entity.MaterialStorageInvoiceDetail;
import com.vren.material.module.storage.domain.entity.MaterialStorageNotice;
import com.vren.material.module.storage.domain.enums.WarehousingMaterialType;
import com.vren.material.module.storage.domain.enums.WarehousingMethod;
import com.vren.material.module.storage.domain.enums.WarehousingState;
import com.vren.material.module.storage.domain.vo.*;
import com.vren.material.module.storage.mapper.MaterialFirstLevelStorageMapper;
import com.vren.material.module.storage.mapper.MaterialStorageInvoiceDetailMapper;
import com.vren.material.module.storage.mapper.MaterialStorageInvoiceMapper;
import com.vren.material.module.storage.mapper.MaterialStorageNoticeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class StorageService {
    @Autowired
    private MaterialFirstLevelStorageMapper materialFirstLevelStorageMapper;
    @Autowired
    private MaterialStorageNoticeMapper materialStorageNoticeMapper;
    @Autowired
    private ContractListMapper contractListMapper;
    @Autowired
    private DictDataService dictDataService;
    @Autowired
    private MaterialStorageInvoiceMapper materialStorageInvoiceMapper;
    @Autowired
    private MaterialStorageInvoiceDetailMapper materialStorageInvoiceDetailMapper;
    @Autowired
    private ProjectFeign projectFeign;
    @Autowired
    private MaterialStockMapper materialStockMapper;
    @Autowired
    private QualityService qualityService;

    @Autowired
    private PurchasePlanService purchasePlanService;
    public PageResult<MaterialFirstLevelStorageVO> getDataList(MaterialFirstLevelStorageQueryDTO dto) {
        MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
        SearchUtil.timeRangeSearch(wrapper, MaterialFirstLevelStorage::getStorageDate, dto.getStorageStartDate(), dto.getStorageEndDate());
        wrapper.selectAll(MaterialFirstLevelStorage.class)
                .like(!CommonUtil.isNull(dto.getAscription()),MaterialFirstLevelStorage::getAscription,dto.getAscription())
                .eq(!CommonUtil.isNull(dto.getWarehousingMethod()),MaterialFirstLevelStorage::getWarehousingMethod,dto.getWarehousingMethod())
                .eq(!CommonUtil.isNull(dto.getWarehousingState()),MaterialFirstLevelStorage::getWarehousingState,dto.getWarehousingState())
                .like(!CommonUtil.isNull(dto.getMaterialName()),MaterialFirstLevelStorage::getMaterialName,dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getMaterialType()),MaterialFirstLevelStorage::getMaterialType,dto.getMaterialType())
                .orderByDesc(MaterialFirstLevelStorage::getCreateTime);
        List<MaterialFirstLevelStorageVO> materialFirstLevelStorageVOS = materialFirstLevelStorageMapper.selectJoinList(MaterialFirstLevelStorageVO.class, wrapper);
        List<MaterialFirstLevelStorageVO> collect = materialFirstLevelStorageVOS.stream()
                .peek(item -> item.setWarehousingMethodText(EnumUtil.getValue(WarehousingMethod.class, item.getWarehousingMethod())))
                .peek(item -> item.setWarehousingStateText(EnumUtil.getValue(WarehousingState.class, item.getWarehousingState())))
                .peek(item -> item.setMaterialTypeText(EnumUtil.getValue(WarehousingMaterialType.class, item.getMaterialType())))
                .peek(item->{ if(!CommonUtil.isNull(item.getProjectId())){
                    ResponseResult<ProjectVO> result = projectFeign.getById(item.getProjectId());
                    ProjectVO data = result.getData();
                    item.setAscriptionText(data.getProjectName());
                }})
                .peek(item->{
                    List<DictDataEntity> deviceSpotType = dictDataService.getDicDataForPage("DeviceSpotType");
                    for (DictDataEntity dictDataEntity : deviceSpotType) {
                        if(!CommonUtil.isNull(item.getAscription())&&item.getAscription().equals(dictDataEntity.getKeyId())){
                            item.setAscriptionText(dictDataEntity.getDicText());
                        }
                    }
                })
                .peek(item->item.setNoticeState(false))
                .peek(item->{if(!CommonUtil.isNull(item.getMaterialStorageNoticeId())){item.setNoticeState(true);}})
                .peek(item->{
                    item.setUnitPriceIncludingTax(item.getTax()+ item.getPreTaxPrice());
                    item.setTotalAmountBeforeTax(item.getPreTaxPrice()* item.getCount()/100);
                    item.setTotalAmountIncludingTax(item.getUnitPriceIncludingTax()* item.getCount()/100);

                })
        .collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect,dto);
    }


    public void addMaterialStorageNotice(GenerateMaterialStorageNoticeDTO dto) {

        List<String> collect = dto.getIds();
        List<MaterialFirstLevelStorage> list = materialFirstLevelStorageMapper.selectBatchIds(collect);

        Map<String, List<MaterialFirstLevelStorage>> noticeCollect  = list.stream().collect(Collectors.groupingBy(key -> {
            String format = String.format("%d", key.getMaterialType());
            return format;
        }));
        if(noticeCollect.size()>1){
            throw new ErrorException("选择的材料类型不一致,无法生成通知单");
        }
        Long sumCount = list.stream().mapToLong(MaterialFirstLevelStorage::getCount).sum();
        dto.setCount(sumCount);

        MaterialStorageNotice copy = BeanUtil.copy(dto, MaterialStorageNotice.class);
        materialStorageNoticeMapper.insert(copy);
        List<MaterialFirstLevelStorage> collectUpdate = list.stream().peek(item -> item.setMaterialStorageNoticeId(copy.getId())).collect(Collectors.toList());
        for (MaterialFirstLevelStorage materialFirstLevelStorage : collectUpdate) {
            materialFirstLevelStorageMapper.updateById(materialFirstLevelStorage);
        }

    }

    public void addOrUpdateMaterialFirstLevelStorage(MaterialFirstLevelStorageUpdateDTO dto) {
        if(CommonUtil.isNull(dto.getId())){
            MaterialFirstLevelStorage copy = BeanUtil.copy(dto, MaterialFirstLevelStorage.class);
            /*判断物资编号*/
            QueryWrapper<MaterialFirstLevelStorage> queryWrapper = new QueryWrapper<>();
            queryWrapper.select("1").eq(!CommonUtil.isNull(dto.getMaterialNumber()), "material_number", dto.getMaterialNumber()).last("limit 1");
            if (materialFirstLevelStorageMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("物资编号已存在");
            }
            copy.setInvoiceWarehousing(0);
            if(CommonUtil.isNull(dto.getCount())){
                copy.setActualStockAmount(0L);
            }else{  copy.setActualStockAmount(dto.getCount());}
            copy.setCreateTime(new Date());

            materialFirstLevelStorageMapper.insert(copy);
            return;
        }
        MaterialFirstLevelStorage copy = BeanUtil.copy(dto, MaterialFirstLevelStorage.class);
        copy.setUpdateTime(new Date());
        materialFirstLevelStorageMapper.updateById(copy);
    }

    public void deleteMaterialFirstLevelStorage(DeleteMaterialFirstLevelStorageDTO dto) {
        materialFirstLevelStorageMapper.deleteById(dto.getId());
    }



    public void addOrUpdateMaterialStorageInvoice(MaterialStorageInvoiceUpdateDTO dto) {
        if(CommonUtil.isNull(dto.getId())){
            MaterialStorageInvoice copy = BeanUtil.copy(dto, MaterialStorageInvoice.class);
            List<MaterialStorageInvoiceDetailDTO> dtoList = dto.getList();
            List<MaterialStorageInvoiceDetail> details = BeanUtil.copyList(dtoList, MaterialStorageInvoiceDetail.class);
            materialStorageInvoiceMapper.insert(copy);

            List<MaterialStorageInvoiceDetail> collect = details.stream().peek(item -> item.setMaterialStorageInvoiceId(copy.getId())).collect(Collectors.toList());

            Map<String, List<MaterialStorageInvoiceDetail>> map = collect.stream().collect(Collectors.groupingBy(MaterialStorageInvoiceDetail::getMaterialFirstLevelStorageId));
            for (String s : map.keySet()) {
                List<MaterialStorageInvoiceDetail> materialStorageInvoiceDetails = map.get(s);
                //填的数据总和
                Long sum = materialStorageInvoiceDetails.stream().mapToLong(MaterialStorageInvoiceDetail::getCount).sum();
                //实际的数据上限
                Long actualStockAmount = materialFirstLevelStorageMapper.selectById(s).getActualStockAmount();
                if(sum>actualStockAmount){
                    throw new ErrorException("填写的数量总和超过了"+actualStockAmount/100);
                }else{
                    for (MaterialStorageInvoiceDetail materialStorageInvoiceDetail : materialStorageInvoiceDetails) {
                        materialStorageInvoiceDetailMapper.insert(materialStorageInvoiceDetail);
                        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(materialStorageInvoiceDetail.getMaterialFirstLevelStorageId());
                        materialFirstLevelStorage.setInvoiceWarehousing(1);
                        materialFirstLevelStorage.setInvoiceQuantity(materialStorageInvoiceDetail.getCount());
                        materialFirstLevelStorageMapper.updateById(materialFirstLevelStorage);
                    }
                }

            }

            return;
        }
        MaterialStorageInvoice copy = BeanUtil.copy(dto, MaterialStorageInvoice.class);
/**/   List<MaterialStorageInvoiceDetailDTO> dtoList = dto.getList();
        List<MaterialStorageInvoiceDetail> details = BeanUtil.copyList(dtoList, MaterialStorageInvoiceDetail.class);
        List<MaterialStorageInvoiceDetail> collect = details.stream().peek(item -> item.setMaterialStorageInvoiceId(dto.getId())).collect(Collectors.toList());
        Map<String, List<MaterialStorageInvoiceDetail>> map = collect.stream().collect(Collectors.groupingBy(MaterialStorageInvoiceDetail::getMaterialFirstLevelStorageId));
        for (String s : map.keySet()) {
            List<MaterialStorageInvoiceDetail> materialStorageInvoiceDetails = map.get(s);
            //填的数据总和
            Long sum = materialStorageInvoiceDetails.stream().mapToLong(MaterialStorageInvoiceDetail::getCount).sum();
            //实际的数据上限
            Long actualStockAmount = materialFirstLevelStorageMapper.selectById(s).getActualStockAmount();
            if(sum>actualStockAmount){
                throw new ErrorException("填写的数量总和超过了"+actualStockAmount/100);
            }else{
                for (MaterialStorageInvoiceDetail materialStorageInvoiceDetail : materialStorageInvoiceDetails) {
                    if(CommonUtil.isNull(materialStorageInvoiceDetail.getId())){
                        materialStorageInvoiceDetailMapper.insert(materialStorageInvoiceDetail);
                    }else{
                        materialStorageInvoiceDetailMapper.updateById(materialStorageInvoiceDetail);
                        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(materialStorageInvoiceDetail.getMaterialFirstLevelStorageId());
                        materialFirstLevelStorage.setInvoiceQuantity(materialStorageInvoiceDetail.getCount());
                        materialFirstLevelStorageMapper.updateById(materialFirstLevelStorage);
                    }
                }
            }

        }
        /**/
        materialStorageInvoiceMapper.updateById(copy);
    }

    public void deleteMaterialStorageInvoice(DeleteMaterialStorageInvoiceDTO dto) {
        int result = materialStorageInvoiceMapper.deleteById(dto.getId());
        if(result>0){
            UpdateWrapper<MaterialStorageInvoiceDetail> wrapper = new UpdateWrapper<>();
            wrapper.eq("material_storage_invoice_id",dto.getId())
                    .set("material_storage_invoice_id",null);
            MaterialStorageInvoiceDetail materialStorageInvoiceDetail = new MaterialStorageInvoiceDetail();
            materialStorageInvoiceDetailMapper.update(materialStorageInvoiceDetail,wrapper);}

    }

    public List<WarehousingMaterialTypeVO> getWarehousingMaterialType() {
        ArrayList<WarehousingMaterialTypeVO> list = new ArrayList<>();
        for (WarehousingMaterialType statue : WarehousingMaterialType.values()) {
            WarehousingMaterialTypeVO warehousingMaterialTypeVO = new WarehousingMaterialTypeVO();
            warehousingMaterialTypeVO.setCode(statue.getCode());
            warehousingMaterialTypeVO.setValue(statue.getName());
            list.add(warehousingMaterialTypeVO);
        }
        return list;
    }

    public List<WarehousingMethodVO> getWarehousingMethod() {
        ArrayList<WarehousingMethodVO> list = new ArrayList<>();
        for (WarehousingMethod statue : WarehousingMethod.values()) {
            WarehousingMethodVO warehousingMethodVO = new WarehousingMethodVO();
            warehousingMethodVO.setCode(statue.getCode());
            warehousingMethodVO.setValue(statue.getName());
            list.add( warehousingMethodVO);
        }
        return list;
    }

    public List<WarehousingStateVO> getWarehousingState() {
        ArrayList<WarehousingStateVO> list = new ArrayList<>();
        for (WarehousingState statue : WarehousingState.values()) {
            WarehousingStateVO warehousingStateVO = new WarehousingStateVO();
            warehousingStateVO.setCode(statue.getCode());
            warehousingStateVO.setValue(statue.getName());
            list.add(warehousingStateVO);
        }
        return list;
    }

    public PageResult<MaterialStorageInvoiceVO> getMaterialStorageInvoiceList(MaterialStorageInvoiceQueryDTO dto) {
        MPJLambdaWrapper<MaterialStorageInvoice> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStorageInvoice.class)
                .like(!CommonUtil.isNull(dto.getInvoiceNo()),MaterialStorageInvoice::getInvoiceNo,dto.getInvoiceNo())
                .like(!CommonUtil.isNull(dto.getInvoiceName()),MaterialStorageInvoice::getInvoiceName,dto.getInvoiceName());
        List<MaterialStorageInvoice> materialStorageInvoices = materialStorageInvoiceMapper.selectList(wrapper);
        List<MaterialStorageInvoiceVO> materialStorageInvoiceVOS = BeanUtil.copyList(materialStorageInvoices, MaterialStorageInvoiceVO.class);
        List<MaterialStorageInvoiceVO> collect = materialStorageInvoiceVOS.stream().peek(item -> {
            MPJLambdaWrapper<MaterialStorageInvoiceDetail> mpjLambdaWrapper = new MPJLambdaWrapper<>();
            mpjLambdaWrapper.selectAll(MaterialStorageInvoiceDetail.class)
                    .selectAll(MaterialStorageInvoice.class)
                    .leftJoin(MaterialStorageInvoice.class, MaterialStorageInvoice::getId, MaterialStorageInvoiceDetail::getMaterialStorageInvoiceId)
                    .eq(MaterialStorageInvoice::getId, item.getId());
            List<MaterialStorageInvoiceDetail> materialStorageInvoiceDetails = materialStorageInvoiceDetailMapper.selectList(mpjLambdaWrapper);
            List<MaterialStorageInvoiceEasyVO> easyVOList = materialStorageInvoiceDetails.stream().map(x -> {
                MaterialStorageInvoiceEasyVO materialStorageInvoiceEasyVO = new MaterialStorageInvoiceEasyVO();
                MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(x.getMaterialFirstLevelStorageId());
                materialStorageInvoiceEasyVO = BeanUtil.copy(materialFirstLevelStorage, MaterialStorageInvoiceEasyVO.class);
                materialStorageInvoiceEasyVO.setCount(x.getCount());
                return materialStorageInvoiceEasyVO;
            }).collect(Collectors.toList());

            item.setList(easyVOList);
        }).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect,dto);
    }

    public List<DeviceDataVO> getDeviceDropList() {

        List<DictDataEntity> dicDataForPage =dictDataService.getDicDataForPage("DeviceSpotType");

        List<DeviceDataVO> collect = dicDataForPage.stream().map(item -> {
            DeviceDataVO deviceDataVO = new DeviceDataVO();
            deviceDataVO.setKeyId(item.getKeyId());
            deviceDataVO.setSpotType(item.getDicText());
            return deviceDataVO;
        }).collect(Collectors.toList());
        return collect;
    }

    public MaterialFirstLevelStorageVO getMaterialFirstLevelStorageById(MaterialFirstLevelStorageDTO dto) {

        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(dto.getId());
        MaterialFirstLevelStorageVO copy = BeanUtil.copy(materialFirstLevelStorage, MaterialFirstLevelStorageVO.class);
        copy.setMaterialTypeText(EnumUtil.getValue(WarehousingMaterialType.class,copy.getMaterialType()));
        if(!CommonUtil.isNull(copy.getProjectId())){
            ResponseResult<ProjectVO> result = projectFeign.getById(copy.getProjectId());
            ProjectVO data = result.getData();
            copy.setProjectName(data.getProjectName());
        }
        List<DictDataEntity> deviceSpotType = dictDataService.getDicDataForPage("DeviceSpotType");
        for (DictDataEntity dictDataEntity : deviceSpotType) {
            if(!CommonUtil.isNull(copy.getAscription())&&copy.getAscription().equals(dictDataEntity.getKeyId())){
                copy.setDeviceDrop(dictDataEntity.getDicText());
            }
        }
        //合同编号对应的合同清单id查询出来的
        copy.setContractNo(materialFirstLevelStorage.getContractListId());
        return copy ;
    }

    public MaterialStorageInvoiceViewVO getMaterialStorageInvoiceById(MaterialStorageInvoiceQueryViewDTO dto) {

        MaterialStorageInvoice materialStorageInvoice = materialStorageInvoiceMapper.selectById(dto.getId());

        MPJLambdaWrapper<MaterialStorageInvoiceDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStorageInvoiceDetail.class)
                .eq(!CommonUtil.isNull(dto.getId()),MaterialStorageInvoiceDetail::getMaterialStorageInvoiceId,dto.getId());
        List<MaterialStorageInvoiceDetail> materialStorageInvoiceDetails = materialStorageInvoiceDetailMapper.selectList(wrapper);
        List<MaterialStorageInvoiceDetailVO> detailVOS = BeanUtil.copyList(materialStorageInvoiceDetails, MaterialStorageInvoiceDetailVO.class);
        List<MaterialStorageInvoiceDetailVO> collect = detailVOS.stream().map(x -> {
            MaterialStorageInvoiceDetailVO materialStorageInvoiceDetailVO = new MaterialStorageInvoiceDetailVO();
            MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(x.getMaterialFirstLevelStorageId());
            materialStorageInvoiceDetailVO = BeanUtil.copy(materialFirstLevelStorage, MaterialStorageInvoiceDetailVO.class);
            materialStorageInvoiceDetailVO.setCount(x.getCount());
            materialStorageInvoiceDetailVO.setMaterialFirstLevelStorageId(x.getMaterialFirstLevelStorageId());
            materialStorageInvoiceDetailVO.setId(x.getId());
            return materialStorageInvoiceDetailVO;
        }).collect(Collectors.toList());
        MaterialStorageInvoiceViewVO copy = BeanUtil.copy(materialStorageInvoice, MaterialStorageInvoiceViewVO.class);
        copy.setList(collect);
        return copy;
    }

    public List<MaterialNoticeVO> getMaterialStorageNoticeDetailList() {
        List<MaterialStorageNotice> materialStorageNotices = materialStorageNoticeMapper.selectList(null);
        List<MaterialNoticeVO> materialNoticeVOS = BeanUtil.copyList(materialStorageNotices, MaterialNoticeVO.class);
        List<MaterialNoticeVO> collect = materialNoticeVOS.stream().peek(item -> {
            MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(MaterialFirstLevelStorage.class)
                    .eq(MaterialFirstLevelStorage::getMaterialStorageNoticeId,item.getId());
            List<MaterialFirstLevelStorage> list = materialFirstLevelStorageMapper.selectList(wrapper);
            List<MaterialFirstLevelStorageFeignVO> materialFirstLevelStorageFeignVOS = BeanUtil.copyList(list, MaterialFirstLevelStorageFeignVO.class);
            item.setList(materialFirstLevelStorageFeignVOS);
        }).collect(Collectors.toList());
        return collect;
    }

    public List<ContractNoVO> getContractNo() {
        List<ContractList> contractLists = contractListMapper.selectList(null);

        return BeanUtil.copyList(contractLists,ContractNoVO.class);
    }

    public PageResult<MaterialFirstLevelStorageVO> getMaterialFirstLevelStorageListByContractNo(MaterialQueryDTO dto) {
        MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialFirstLevelStorage.class)
                .eq(MaterialFirstLevelStorage::getContractListId,dto.getContractListId());
        List<MaterialFirstLevelStorage> list = materialFirstLevelStorageMapper.selectList(wrapper);
        List<MaterialFirstLevelStorageVO> materialFirstLevelStorageVOS = BeanUtil.copyList(list, MaterialFirstLevelStorageVO.class);
        return PageUtil.convert2PageResult(materialFirstLevelStorageVOS,dto);
    }


    public List<MaterialCodeVO> getMaterialCode(MaterialCodeQueryDTO dto) {
        MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialFirstLevelStorage.class)
                        .eq(MaterialFirstLevelStorage::getContractListId,dto.getContractListId());
        List<MaterialFirstLevelStorage> list = materialFirstLevelStorageMapper.selectList(wrapper);
        List<MaterialCodeVO> collect = list.stream().map(item -> {
            MaterialCodeVO materialCodeVO = new MaterialCodeVO();
            materialCodeVO.setId(item.getId());
            materialCodeVO.setMaterialCode(item.getMaterialName()==null?"":item.getMaterialName() + item.getMaterialNumber()==null?"":item.getMaterialNumber());
            return materialCodeVO;
        }).collect(Collectors.toList());
        return collect;

    }

    public MaterialStockDTO getMaterialStockById(MaterialFirstLevelStorageDTO dto) {
        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(dto.getId());
        MaterialStockDTO copy = BeanUtil.copy(materialFirstLevelStorage, MaterialStockDTO.class);
        if(!CommonUtil.isNull(copy)){
        copy.setMaterialStorageId(dto.getId());
        if(!CommonUtil.isNull(materialFirstLevelStorage.getColour())){
            copy.setColor(materialFirstLevelStorage.getColour());
        }

        if(!CommonUtil.isNull(materialFirstLevelStorage.getSpecification())){
            copy.setStandards(materialFirstLevelStorage.getSpecification());
        }}
        return copy;
    }

    public void batchInsertMaterialFirstLevelStorage(BatchInsertMaterialFirstLevelStorageDTO dto) {
        List<MaterialFirstLevelStorageSingleDto> list = dto.getList();

        List<MaterialFirstLevelStorageSingleDto> collect = list.stream().peek(item -> {
            QueryOneDTO queryOneDTO = new QueryOneDTO();
            queryOneDTO.setId(item.getPurchasePlanId());
            item.setProjectId(purchasePlanService.getPurchasePlanById(queryOneDTO).getProjectId());
            item.setAscription(item.getAscriptionText()==null?"":item.getAscriptionText());
            item.setMaterialNumber(item.getWarehousingNo());
            item.setColour(item.getColor()==null?"":item.getColor());
            item.setSpecification(item.getSize()==null?"":item.getSize());
            item.setMeasuringUnit(item.getUseMaterialUnit()==null?"":item.getUseMaterialUnit());
            item.setWeight(item.getPurchaseWeight()==null?0L:item.getPurchaseWeight());
            item.setWarehousingMethod(1);
            item.setCreateTime(new Date());


        }).collect(Collectors.toList());
        /*判断物资编号*/
        Iterator<MaterialFirstLevelStorageSingleDto> iterator = collect.iterator();
        while (iterator.hasNext()) {
            MaterialFirstLevelStorageSingleDto next = iterator.next();
            MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(MaterialFirstLevelStorage.class)
                    .eq(MaterialFirstLevelStorage::getMaterialNumber, next.getMaterialNumber());
            MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectOne(wrapper);
            if (!CommonUtil.isNull(materialFirstLevelStorage)) {
                materialFirstLevelStorage.setCount(materialFirstLevelStorage.getCount() + next.getCount());
                materialFirstLevelStorage.setUpdateTime(new Date());
                materialFirstLevelStorageMapper.updateById(materialFirstLevelStorage);
                if (materialFirstLevelStorage.getMaterialNumber().equals(next.getMaterialNumber())) {
                    iterator.remove();
                }

            }


        }
        if (CommonUtil.listIsNotEmpty(collect)) {
            List<MaterialFirstLevelStorage> materialFirstLevelStorages = BeanUtil.copyList(collect, MaterialFirstLevelStorage.class);
            materialFirstLevelStorageMapper.insertBatchSomeColumn(materialFirstLevelStorages);
        }
    }

    public MaterialFirstLevelStorage getByMaterialNumber(String warehousingNo) {
        MPJLambdaWrapper<MaterialFirstLevelStorage> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialFirstLevelStorage.class)
                .eq(MaterialFirstLevelStorage::getMaterialNumber,warehousingNo);
        return materialFirstLevelStorageMapper.selectOne(wrapper);
    }
}
