package com.vren.material.module.productdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class ProductDemandPlanDetailsExportCopyVO {

    @ExcelProperty("序号")
    @ApiModelProperty("自增序号")
    private Integer autoincrementId;

    @ExcelIgnore
    @ApiModelProperty("物资类型（按照物资类型分sheet）")
    private String materialType;

    @ExcelIgnore
    @ApiModelProperty("产品ID（通过产品信息表id，获得产品需求计划下面的制造编号和计划编号）")
    private String productInformationId;

    @ExcelProperty("件号")
    @ApiModelProperty("件号")
    private String partNo;

    @ExcelProperty("材料名称")
    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("材质")
    @ExcelProperty("材质")
    private String material;

    @ExcelProperty("规格")
    @ApiModelProperty("规格")
    private String specification;

    @ExcelProperty("数量")
    @ApiModelProperty("数量")
    @ConversionNumber
    private Double countExport;

    @ExcelProperty("重量(KG)")
    @ApiModelProperty("重量")
    @ConversionNumber
    private Double weightExport;


    @ExcelProperty("执行标准")
    @ApiModelProperty("执行标准")
    private String enforceStandards;



    @ExcelProperty(value = "交货时间",converter = DateConverter.class)
    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ExcelProperty("交货地点")
    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;
}
