package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class WeldingMaterialsVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("技术标准")
    private String technicalStandards;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;


    @ApiModelProperty("备注")
    private String remarks;

    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("材料类型")
    private Integer materialType;
    @ApiModelProperty("材料类型描述")
    private String materialTypeText;
    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;
}
