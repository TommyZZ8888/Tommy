package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author szp
 * @date 2023/2/3
 * @param
 * @return {@link null}
 * 头信息:
 * 0: "序号",
 *     1: "件号",
 *     2: "材料名称",
 *     3: "厚 度",
 *     4: "宽度",
 *     5: "长 度",
 *     6: "材质",
 *     7: "数量(块)",
 *     8: "重量（KG）",
 *     9: "执行标准",
 *     10: "交货时间",
 *     11: "交货地点",
 *     12: "备注",
 *     13: "规格",
 *     14: "标书价",
 *     15: "用料类型",
 *     16: "单位",
 *     17: "备件数量"*/
@Data
public class BoardImportVO {

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;

    private String partNo;

    private String materialName;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long thickness;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long width;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long length;


    private String texture;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long count;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long  weight;


    @ApiModelProperty("执行标准")
    private String enforceStandards;

    private String deliveryTime;


    private String deliveryLocation;

    @ExcelProperty(index = 12)
    private String remarks;

    //新增的导出列的字段
    @ExcelProperty(index = 13)
    private String specification;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long bidPrice;


    private String ingredientsType;

    private String unit;
    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

}
