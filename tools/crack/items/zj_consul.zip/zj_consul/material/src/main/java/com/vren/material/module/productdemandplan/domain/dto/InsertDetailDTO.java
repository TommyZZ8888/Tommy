package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class InsertDetailDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("产品需求计划id")
    private String productDemandPlanId;

    @ApiModelProperty("产品信息ID")
    private String productInformationId;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("件号")
    @NotBlank(message = "件号不能为空")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("材料")
    private String material;

    @ApiModelProperty("材质表里面的code")
    private String code;

    @ApiModelProperty("用料类型（计算用）")
    private String ingredientsType;

    @ApiModelProperty("比重（计算用）")
    @ConversionNumber
    private Long proportion;


    @ApiModelProperty("第一尺寸String")
    private String firstSizeString;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;


    @ApiModelProperty("第二尺寸（如果物资类型是锻件、外购件和辅材，第二尺寸代表重量）")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("第四尺寸/外购标准")
    private String fourthSizeOutsourcingStandards;

    @ApiModelProperty("用料单位(手动填写)")
    private String useMaterialUnit;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("备件数量")
    @ConversionNumber
    private Long sparePartsQuantity;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long demandProposalPrice;

    @ApiModelProperty("交货时间")
    @DateTimeFormat(pattern = "YYYY-MM-DD")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;

}
