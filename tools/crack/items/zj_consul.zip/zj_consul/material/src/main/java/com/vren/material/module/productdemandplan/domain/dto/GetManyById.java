package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class GetManyById {
    @ApiModelProperty("keyId")
    @NotBlank(message = "keyId不能为空")
    private String keyId;
}
