package com.vren.material.module.materialcheckout.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialCheckoutDetailQueryDTO extends PageParam {
    @NotBlank(message = "入库通知单id不为空")
    @ApiModelProperty("入库通知单id")
    private String id;
    @ApiModelProperty("材料类型")
    private Integer materialType;
}
