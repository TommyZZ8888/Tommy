package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
@Data
@TableName("project_demand_plan")
public class ProjectDemandPlan {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("需求类型")
    private Integer demandType;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("计划编号")
    private String planNo;

    @ApiModelProperty("编制说明")
    private String preparationDescription;

    @ConversionNumber
    @ApiModelProperty("需求标书总价")
    private Long demandBidPriceTotal;

    @ApiModelProperty("编制人")
    private String compiler;

    @ApiModelProperty("编制时间")
    private  Date compileTime;

    @ApiModelProperty("校对人")
    private String proofreader;

    @ApiModelProperty("校对时间")
    private Date proofreadingTime;

    @ApiModelProperty("审核人")
    private String reviewer;

    @ApiModelProperty("审核时间")
    private Date reviewTime;

    @ApiModelProperty("批准人")
    private String checker;

    @ApiModelProperty("批准时间")
    private Date checkTime;

    @ApiModelProperty("附件路径")
    private String attachmentPath;
    @ApiModelProperty("产品计划需求表id字符串")
    private String idListString;
    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;
}