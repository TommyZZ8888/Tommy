package com.vren.material.module.storage.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
@Data
public class MaterialCodeQueryDTO {
    @NotBlank(message = "合同清单id不能为空")
    @ApiModelProperty("合同清单id")
    private  String contractListId;
}
