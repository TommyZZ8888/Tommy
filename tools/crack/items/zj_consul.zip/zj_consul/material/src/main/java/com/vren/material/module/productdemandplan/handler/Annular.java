package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class Annular implements ComputerHandler{
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        //第四尺寸不需要倍数缩小
        if (CommonUtil.isNull(data.getFirstSize())||CommonUtil.isNull(data.getSecondSize())||CommonUtil.isNull(data.getThirdSize())||CommonUtil.isNull(data.getFourthSizeOutsourcingStandards())||CommonUtil.isNull(data.getProportion())){
            throw new RuntimeException(data.getMaterialName()+"的第一尺寸、第二尺寸、第三尺寸、第四尺寸和比重不能为空");
        }
        double width = 0.0;
        double length = 0.0;
        //扇角
        double fanAngle = 0.0;
        double area = 0.0;
        //小弓高
        double smallArchHeight = 0.0;
        double weight = 0.0;

        //扇角的计算
        fanAngle = 2*Math.PI/ Integer.parseInt(data.getFourthSizeOutsourcingStandards())/ Math.PI * 180;
        //小弓高的计算
        smallArchHeight = data.getSecondSize().doubleValue()/100 / 2 * ( 1-Math.cos( fanAngle /2 / 180 *Math.PI  ) );
        //小弓高四舍五入，保留一位小数
        BigDecimal bigDecimal = new BigDecimal(smallArchHeight);
        smallArchHeight = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();

        if (Integer.parseInt(data.getFourthSizeOutsourcingStandards()) == 1){
            //拼数为1
            //计算长度
            length = ( data.getFirstSize().doubleValue()/100 + 10 ) * data.getCount().doubleValue()/100;
            //计算宽度
            width = data.getFirstSize().doubleValue()/100 + 0;
        }else {
            //拼数不为1
            //计算长度
            length = smallArchHeight + ( data.getFirstSize().doubleValue()/100 - data.getSecondSize().doubleValue()/100 ) / 2 * Double.parseDouble(data.getFourthSizeOutsourcingStandards()) * data.getCount().doubleValue()/100
                    + ( smallArchHeight - data.getFirstSize().doubleValue()/100 / 2 * ( 1 - Math.cos( Math.asin( data.getSecondSize().doubleValue()/100 * Math.sin( fanAngle / 2 * Math.PI / 180 ) / (data.getFirstSize().doubleValue()/100) ) ) ) +2 ) * ( Double.parseDouble(data.getFourthSizeOutsourcingStandards()) * data.getCount().doubleValue()/100 -1 );
            BigDecimal decimal = new BigDecimal(length);
            length = decimal.setScale(1,BigDecimal.ROUND_HALF_UP).doubleValue();
            //计算宽度
            width = data.getFirstSize().doubleValue()/100 * Math.sin( fanAngle / 2 * Math.PI /180 ) + 0 ;
            width = (int) Math.ceil(width);
        }

        //宽度向上取整

        //面积的计算
        area = length * width /  1000000 ;
        //重量的计算
        weight =  area * data.getThirdSize().doubleValue()/100 * data.getProportion().doubleValue()/100;

        //规格  δ 厚度 X 长度 X 宽度
        String specification = "δ" + data.getThirdSize()/100 + "X" + length + "X" + (int)width;


        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (weight > 0) {
            productDemandPlanDetails.setWeight((long) (weight * 100));
        } else {
            productDemandPlanDetails.setWeight(0L);
        }
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            //长度
            String firstSize = specification.substring(specification.indexOf("X")+1, specification.lastIndexOf("X"));
            //宽度
            String secondSize = specification.substring(specification.lastIndexOf("X")+1);
            //厚度
            String thirdSize = specification.substring(1,specification.indexOf("X"));
            vo.setFirstSizeExport(Double.parseDouble(firstSize));
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
            vo.setThirdSizeExport(Double.parseDouble(thirdSize));
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            //长度
            String firstSize = specification.substring(specification.indexOf("X")+1, specification.lastIndexOf("X"));
            //宽度
            String secondSize = specification.substring(specification.lastIndexOf("X")+1);
            //厚度
            String thirdSize = specification.substring(1,specification.indexOf("X"));
            vo.setFirstSizeExport(Double.parseDouble(firstSize));
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
            vo.setThirdSizeExport(Double.parseDouble(thirdSize));
        }
    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        if (specification!=null) {
            //长度
            String length = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            //宽度
            String width = specification.substring(specification.lastIndexOf("X") + 1);
            //厚度
            String thickness = specification.substring(1, specification.indexOf("X"));
            map.put("width", width);
            map.put("length", width);
            map.put("thickness",  width);
        }
        return map;
    }
}
