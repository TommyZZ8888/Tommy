package com.vren.material.module.storage.domain.vo;

import lombok.Data;

@Data
public class WarehousingMethodVO {
    private Integer code;
    private String value;
}
