package com.vren.material.module.storage.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


import java.util.Date;
@Data
@TableName("material_storage_notice")
public class MaterialStorageNotice {
    @ApiModelProperty("材料入库通知单表id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;
    @ApiModelProperty("制造编号")
    private String manufacturingNo;

    @ApiModelProperty("检验物资类型")
    private Integer inspectionMaterialType;

    @ApiModelProperty("名称")
    private String materialName;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("标记")
    private String sign;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ApiModelProperty("供货状态")
    private Integer supplyStatus;

    @ApiModelProperty("生产厂家")
    private String manufacturer;

    @ApiModelProperty("出厂日期")
    private Date productionDate;

    @ApiModelProperty("生产令号")
    private String productionOrderNo;

    @ApiModelProperty("标准")
    private String standard;

    @ApiModelProperty("合格证号")
    private String certificateNo;

    @ApiModelProperty("检验编号")
    private String inspectionNo;


    @ApiModelProperty("采购员")
    private String buyer;

    @ApiModelProperty("日期")
    private Date date;

    @ApiModelProperty("检验结果")
    private String inspectionResult;

    @ApiModelProperty("仓库管理员")
    private String warehouseKeeper;

    @ApiModelProperty("材料检验员")
    private String materialInspector;

    @ApiModelProperty("审批结果")
    private String approvalResult;

    @ApiModelProperty("材料责任工程师")
    private String materialResponsibleEngineer;

    @ApiModelProperty("检验责任工程师")
    private String inspectionResponsibleEngineer;

    @ApiModelProperty("检验时间")
    private Date inspectionTime;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("附件材料到货附件")
    private String attachmentPath;

    @ApiModelProperty("处理意见")
    private Integer handingOpinion;
    @ConversionNumber
    @ApiModelProperty("不合格数")
    private Long unqualifiedQuantity;
    @ApiModelProperty("审批状态")
    private Integer approalStatus;
}