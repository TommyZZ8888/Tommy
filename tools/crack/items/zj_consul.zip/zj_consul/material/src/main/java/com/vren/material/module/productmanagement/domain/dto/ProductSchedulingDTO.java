package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductSchedulingDTO {

    @ApiModelProperty("产品需求计划id")
    private String id;

    @ApiModelProperty("1:排产状态  0:非排产状态")
    private Integer code;
}
