package com.vren.material.module.stocktransfer;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.stocktransfer.domain.dto.GenerateStockTransferDTO;
import com.vren.material.module.stocktransfer.domain.dto.GetStockTransferDTO;
import com.vren.material.module.stocktransfer.domain.dto.IncomingCompanySelectDTO;
import com.vren.material.module.stocktransfer.domain.vo.IncomingCompanySelectVO;
import com.vren.material.module.stocktransfer.domain.vo.StockTransferDetailVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/stockTransfer")
@Api(tags = {"调拨管理"})
@OperateLog
public class StockTransferController {

    @Autowired
    private StockTransferService stockTransferService;

    @RequestMapping(value = "/generateStockTransfer", method = RequestMethod.POST)
    @ApiOperation("生成调拨单")
    public ResponseResult<Boolean> generateStockTransfer (@RequestBody GenerateStockTransferDTO dto){
        return  ResponseResult.success("获取成功",stockTransferService.generateStockTransfer(dto));
    }


    @RequestMapping(value = "/incomingCompanySelect", method = RequestMethod.POST)
    @ApiOperation("拨入项目下拉框")
    public ResponseResult<List<IncomingCompanySelectVO>> incomingCompanySelect (@RequestBody @Valid IncomingCompanySelectDTO dto){
        return  ResponseResult.success("获取成功",stockTransferService.incomingCompanySelect(dto));
    }

    @RequestMapping(value = "/getStockTransfer", method = RequestMethod.POST)
    @ApiOperation("查询调拨单")
    public ResponseResult<PageResult<StockTransferDetailVO>> getStockTransfer (@RequestBody GetStockTransferDTO dto){
        return  ResponseResult.success("获取成功",stockTransferService.getStockTransfer(dto));
    }


}
