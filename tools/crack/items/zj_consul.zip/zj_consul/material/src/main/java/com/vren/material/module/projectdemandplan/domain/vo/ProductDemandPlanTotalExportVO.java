package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 * 产品需求计划汇总导出VO
 */
@Data
public class ProductDemandPlanTotalExportVO {


    @ExcelProperty("序号")
    @ApiModelProperty("自增序号")
    private Integer autoincrementId;

    @ExcelIgnore
    @ApiModelProperty("物资类型")
    private String materialType;
    @ExcelIgnore
    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ExcelProperty("件号")
    @ApiModelProperty("件号")
    private String partNo;

    @ExcelProperty("材料名称")
    @ApiModelProperty("材料名称")
    private String materialName;

    @ExcelIgnore
    @ApiModelProperty("材质表id(根据材质表id获取材质名称)")
    private String texture;

    @ExcelProperty("材质")
    @ApiModelProperty("材质")
    private String material;

    @ExcelProperty("厚度")
    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Double firstSizeExport;

    @ExcelProperty("宽度")
    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Double secondSizeExport;

    @ExcelProperty("长度")
    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Double thirdSizeExport;

    @ExcelIgnore
    @ApiModelProperty("规格")
    private String specification;

    @ExcelIgnore
    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ExcelIgnore
    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ExcelIgnore
    @ApiModelProperty("重量")
    @ConversionNumber
    private Long weight;

    @ExcelProperty("数量")
    @ApiModelProperty("数量")
    @ConversionNumber
    private Double countExport;

    @ExcelProperty("重量(KG)")
    @ApiModelProperty("重量")
    @ConversionNumber
    private Double weightExport;


    @ExcelProperty("执行标准")
    @ApiModelProperty("执行标准")
    private String enforceStandards;


    @ExcelProperty(value = "交货时间",converter = DateConverter.class)
    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ExcelProperty("交货地点")
    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;
}
