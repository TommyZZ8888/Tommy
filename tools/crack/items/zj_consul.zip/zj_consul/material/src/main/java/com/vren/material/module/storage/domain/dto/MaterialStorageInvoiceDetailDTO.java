package com.vren.material.module.storage.domain.dto;



import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialStorageInvoiceDetailDTO {
    @ApiModelProperty("细节表id")
    private String id ;
    @ApiModelProperty("一级入库表id")
    private String materialFirstLevelStorageId;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

}
