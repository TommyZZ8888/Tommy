package com.vren.material.module.purchaseplan;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelFillCellMergeStrategy;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.module.productdemandplan.ProductDemandPlanService;
import com.vren.material.module.productdemandplan.domain.vo.MaterialTextureVO;
import com.vren.material.module.projectdemandplan.ProjectDemandPlanService;
import com.vren.material.module.projectdemandplan.domain.dto.PurchaseCount;
import com.vren.material.module.projectdemandplan.domain.entity.PaintDemandPlan;
import com.vren.material.module.projectdemandplan.domain.entity.ProductDemandPlanTotal;
import com.vren.material.module.projectdemandplan.domain.entity.ProjectDemandPlan;
import com.vren.material.module.projectdemandplan.domain.entity.WeldingMaterialDemandPlan;
import com.vren.material.module.projectdemandplan.domain.enums.DemandType;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.purchasecontract.domain.dto.QueryContractListDTO;
import com.vren.material.module.purchasecontract.domain.vo.ProjectIdAndNameVO;
import com.vren.material.module.purchasecontract.domain.vo.ProjectInPurchasePlanVO;
import com.vren.material.module.purchaseplan.domain.dto.*;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsPaint;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsProductTotal;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsWeldingMaterials;
import com.vren.material.module.purchaseplan.domain.enums.ArrivalStatusEnum;
import com.vren.material.module.purchaseplan.domain.enums.PlanTypeEnum;
import com.vren.material.module.purchaseplan.domain.enums.PurchaseStateEnum;
import com.vren.material.module.purchaseplan.domain.vo.*;
import com.vren.material.module.purchaseplan.mapper.PurchasePlanDetailsPaintMapper;
import com.vren.material.module.purchaseplan.mapper.PurchasePlanDetailsProductTotalMapper;
import com.vren.material.module.purchaseplan.mapper.PurchasePlanDetailsWeldingMaterialsMapper;
import com.vren.material.module.purchaseplan.mapper.PurchasePlanMapper;
import com.vren.material.module.stockmanagement.StockManagementService;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.storage.StorageService;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class PurchasePlanService {

    @Autowired
    private StorageService storageService;

    @Autowired
    private PurchasePlanMapper purchasePlanMapper;

    @Autowired
    private ProjectDemandPlanService projectDemandPlanService;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private PurchasePlanDetailsPaintMapper purchasePlanDetailsPaintMapper;

    @Autowired
    private PurchasePlanDetailsWeldingMaterialsMapper purchasePlanDetailsWeldingMaterialsMapper;

    @Autowired
    private PurchasePlanDetailsProductTotalMapper purchasePlanDetailsProductTotalMapper;


    @Autowired
    private UserService userService;

    @Autowired
    private ProductDemandPlanService productDemandPlanService;

    @Autowired
    private StockManagementService stockManagementService;


    /**
     * 生成采购计划，关联多个项目需求计划
     * 表格使用项目需求计划那边的表格
     * 一个项目需求计划只有purchase_plan一张表
     *
     * @param dto
     */
    @Transactional(rollbackFor = Exception.class)
    public void generatePurchasePlan(GeneratePurchasePlanDTO dto) {
        //2023/03/02 采购计划，按批次生成  dto中的projectId格式未   projectId-批次



//        //根据项目id判断是否已经生成过采购计划
//        MPJLambdaWrapper<PurchasePlan> purchasePlanMPJLambdaWrapper = new MPJLambdaWrapper<>();
//        //查询项目id和对应的材料类型
//        purchasePlanMPJLambdaWrapper.select(PurchasePlan::getProjectId)
//                .eq(!CommonUtil.isNull(dto.getProjectId()), PurchasePlan::getProjectId, dto.getProjectId());
//        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(purchasePlanMPJLambdaWrapper);
//        if (CommonUtil.listIsNotEmpty(purchasePlans)) {
//            throw new RuntimeException("该项目已生成采购计划，不可重复生成！");
//        }
        //将projectId和批次拆分
        String[] split = dto.getProjectId().split("-");
        String projectId =  split[0];
        String batch = split[1];
        for (MaterialType materialType : MaterialType.values()) {
            //新增的实体
            PurchasePlan purchasePlan = new PurchasePlan();
            //项目名称
            purchasePlan.setProjectName(projectService.getById(projectId).getProjectName());
            //单位名称
            purchasePlan.setUnitName("中建五洲工程装备有限公司");
            //项目id
            purchasePlan.setProjectId(projectId);
            purchasePlan.setBatch(batch);
            //物资类型
            purchasePlan.setMaterialType(materialType.getCode());
            //根据项目id查询项目需求计划
            List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanService.selectByProjectId(projectId,batch);
            if (!CommonUtil.listIsNotEmpty(projectDemandPlans)) {
                throw new RuntimeException("该项目下没有对应的项目需求计划！");
            }
            List<String> ProjectDemandPlanIds = projectDemandPlans.stream().map(ProjectDemandPlan::getId).collect(Collectors.toList());
            //采购数量、重量和采购标书价
            HashMap<String, PurchaseCount> purchaseCountHashMap = projectDemandPlanService.purchaseCount(ProjectDemandPlanIds);
            //按照需求类型分组
            Map<Integer, List<ProjectDemandPlan>> map = projectDemandPlans.stream().filter(item -> !CommonUtil.isNull(item.getDemandType())).collect(Collectors.groupingBy(ProjectDemandPlan::getDemandType));
            if (map.get(DemandType.WELDING_MATERIALS.getCode()) != null) {
                if (materialType.getCode().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                    if (purchaseCountHashMap.get(materialType.getName()) != null) {
                        PurchaseCount purchaseCount = purchaseCountHashMap.get(materialType.getName());
                        purchasePlan.setTotalWeight(purchaseCount.getPurchaseWeight());
                    }
                    //新增焊材采购计划
                    int insert = purchasePlanMapper.insert(purchasePlan);
                    log.info("新增采购计划：{}", insert);
                    //项目下面的焊材需求计划
                    //根据项目需求计划id，查询关联的焊材需求计划

                    String projectDemandPlanId = map.get(1).get(0).getId();
                    List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = projectDemandPlanService.selectWeldByProjectDemandPlanId(projectDemandPlanId);
                    ArrayList<PurchasePlanDetailsWeldingMaterials> list = new ArrayList<>();
                    if (weldingMaterialDemandPlans.size() > 0) {
                        for (WeldingMaterialDemandPlan weld : weldingMaterialDemandPlans) {
                            PurchasePlanDetailsWeldingMaterials purchasePlanDetailsWeldingMaterials = new PurchasePlanDetailsWeldingMaterials();
                            purchasePlanDetailsWeldingMaterials.setPurchasePlanId(purchasePlan.getId());
                            //焊材需求计划表id
                            purchasePlanDetailsWeldingMaterials.setWeldingMaterialDemandPlanId(weld.getId());
                            purchasePlanDetailsWeldingMaterials.setFigureNo("图号");
                            purchasePlanDetailsWeldingMaterials.setMaterialName(weld.getMaterialName());
                            purchasePlanDetailsWeldingMaterials.setMaterialType(MaterialType.WELDING_MATERIALS.getCode());
                            purchasePlanDetailsWeldingMaterials.setModel(weld.getModel());
                            purchasePlanDetailsWeldingMaterials.setBrand(weld.getBrand());
                            purchasePlanDetailsWeldingMaterials.setSize(weld.getSize());
                            purchasePlanDetailsWeldingMaterials.setUseMaterialUnit(weld.getUnit());
                            //采购数量：需求数量减去锁库数量
                            Integer purchaseNumber = (int) (weld.getCount() - weld.getStockAmount());
                            purchasePlanDetailsWeldingMaterials.setPurchaseAmount(purchaseNumber);
//                            if (weld.getCount() > 0) {
//                                purchasePlanDetailsWeldingMaterials.setPurchaseWeight((purchaseNumber / weld.getCount()) * weld.getWeight());
//                            }
                            purchasePlanDetailsWeldingMaterials.setTechnicalStandard(weld.getTechnicalStandards());
                            purchasePlanDetailsWeldingMaterials.setRemarks(weld.getRemarks());
                            purchasePlanDetailsWeldingMaterials.setArrivalAmount(0);
                            purchasePlanDetailsWeldingMaterials.setProposalPrice(weld.getBidPrice());
                            purchasePlanDetailsWeldingMaterials.setPurchaseWeight(weld.getWeight());
                            purchasePlanDetailsWeldingMaterials.setPurchaseAmount(Math.toIntExact(weld.getCount()));

                            // 2023/1/29 交货时间和交货地点
                            purchasePlanDetailsWeldingMaterials.setDeliveryTime(weld.getDeliveryTime());
                            purchasePlanDetailsWeldingMaterials.setDeliveryLocation(weld.getDeliveryLocation());
                            // 2023/1/30 最低价、最高价和平均价（从库存表中查出近三个月相同的材料） 焊材按照型号、牌号和规格
                            List<MaterialStock> materialStocks =  stockManagementService.selectWeldInThreeMonth(weld.getModel(),weld.getBrand(),weld.getSize());
                            if (CommonUtil.listIsNotEmpty(materialStocks)){
                                //存在相同的材料
                                //最低价
                                Long min = materialStocks.stream().min(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                                Long high = materialStocks.stream().max(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                                double avg = materialStocks.stream().mapToLong(MaterialStock::getUnivalence).average().getAsDouble();
                                purchasePlanDetailsWeldingMaterials.setLowestMarketPrice(min);
                                purchasePlanDetailsWeldingMaterials.setHighestMarketPrice(high);
                                purchasePlanDetailsWeldingMaterials.setMarketWeightedAverage((long) avg);
                            }

                            list.add(purchasePlanDetailsWeldingMaterials);
                        }
                        //批量新增焊材采购计划
                        Integer integer = purchasePlanDetailsWeldingMaterialsMapper.insertBatchSomeColumn(list);
                        log.info("新增焊材采购计划{}条", integer);
                    }
                }
            }
            if (materialType.getCode().equals(MaterialType.PAINT.getCode())) {
                if (map.get(DemandType.PAINT.getCode()) != null) {
                    //新增油漆采购计划
                    if (purchaseCountHashMap.get(materialType.getName()) != null) {
                        PurchaseCount purchaseCount = purchaseCountHashMap.get(materialType.getName());
                        purchasePlan.setTotalAmount(purchaseCount.getPurchaseNum());
                    }
                    int insert = purchasePlanMapper.insert(purchasePlan);
                    log.info("新增采购计划：{}", insert);
                    //项目下面的油漆需求计划
                    //根据项目需求计划id，查询关联的油漆需求计划

                    String projectDemandPlanId = map.get(2).get(0).getId();
                    List<PaintDemandPlan> paintDemandPlans = projectDemandPlanService.selectPaintByProjectDemandPlanId(projectDemandPlanId);
                    ArrayList<PurchasePlanDetailsPaint> list = new ArrayList<>();
                    for (PaintDemandPlan paint : paintDemandPlans) {
                        PurchasePlanDetailsPaint purchasePlanDetailsPaint = new PurchasePlanDetailsPaint();
                        //采购计划表id
                        purchasePlanDetailsPaint.setPurchasePlanId(purchasePlan.getId());
//                        //油漆需求id
                        purchasePlanDetailsPaint.setPaintDemandPlanId(paint.getId());
//                        //图号 ->  件号
                        purchasePlanDetailsPaint.setFigureNo(paint.getPartNo());
//                        //材料名称
                        purchasePlanDetailsPaint.setMaterialName(paint.getMaterialName());
                        //物资类型
                        purchasePlanDetailsPaint.setMaterialType(MaterialType.PAINT.getCode());
//                        //颜色
                        purchasePlanDetailsPaint.setColor(paint.getColour());
//                        //规格
                        purchasePlanDetailsPaint.setSize(paint.getSize());
                        //采购数量
                        Integer purchaseNumber = (int) (paint.getCount() - paint.getStockAmount());
                        purchasePlanDetailsPaint.setPurchaseAmount(purchaseNumber);
                        if (paint.getArea() > 0) {
                            purchasePlanDetailsPaint.setPurchaseArea((purchaseNumber / paint.getCount()) * paint.getArea());
                        }
                        //用料单位
                        purchasePlanDetailsPaint.setUseMaterialUnit("件");
//                        //采购面积
                        purchasePlanDetailsPaint.setPurchaseArea(paint.getArea());
//                        //技术标准
                        purchasePlanDetailsPaint.setExecutiveStandards(paint.getExecutiveStandards());
////                        //备注
                        purchasePlanDetailsPaint.setRemarks(paint.getRemarks());
                        //到货数量
                        purchasePlanDetailsPaint.setArrivalAmount(0);
//                        //标书价
                        purchasePlanDetailsPaint.setProposalPrice(paint.getBidPrice());

                        // 2023/1/29 交货时间和交货地点
                        purchasePlanDetailsPaint.setDeliveryTime(paint.getDeliveryTime());
                        purchasePlanDetailsPaint.setDeliveryLocation(paint.getDeliveryLocation());
                        // 2023/1/30 最低价、最高价和平均价（从库存表中查出近三个月相同的材料） 油漆按照颜色和规格
                        List<MaterialStock> materialStocks =  stockManagementService.selectPaintInThreeMonth(paint.getSize(),paint.getColour());
                        if (CommonUtil.listIsNotEmpty(materialStocks)){
                            //存在相同的材料
                            //最低价
                            Long min = materialStocks.stream().min(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                            Long high = materialStocks.stream().max(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                            double avg = materialStocks.stream().mapToLong(MaterialStock::getUnivalence).average().getAsDouble();
                            purchasePlanDetailsPaint.setLowestMarketPrice(min);
                            purchasePlanDetailsPaint.setHighestMarketPrice(high);
                            purchasePlanDetailsPaint.setMarketWeightedAverage((long) avg);
                        }

                        list.add(purchasePlanDetailsPaint);
                    }
                    //批量新增油漆采购计划
                    if (CommonUtil.listIsNotEmpty(list)){

                        purchasePlanDetailsPaintMapper.insertBatchSomeColumn(list);
                    }
                }
            }
            if (map.get(DemandType.BOARD.getCode()) != null && DemandType.BOARD.getName().equals(materialType.getName())) {
                insertPurchaseDetail(purchaseCountHashMap, materialType, purchasePlan, map.get(DemandType.BOARD.getCode()).get(0).getId());
            }
            if (map.get(DemandType.PROFILE.getCode()) != null && DemandType.PROFILE.getName().equals(materialType.getName())) {
                insertPurchaseDetail(purchaseCountHashMap, materialType, purchasePlan, map.get(DemandType.PROFILE.getCode()).get(0).getId());
            }
            if (map.get(DemandType.FORGE_PIECE.getCode()) != null && DemandType.FORGE_PIECE.getName().equals(materialType.getName())) {
                insertPurchaseDetail(purchaseCountHashMap, materialType, purchasePlan, map.get(DemandType.FORGE_PIECE.getCode()).get(0).getId());
            }
            if (map.get(DemandType.PURCHASED_PARTS.getCode()) != null && DemandType.PURCHASED_PARTS.getName().equals(materialType.getName())) {
                insertPurchaseDetail(purchaseCountHashMap, materialType, purchasePlan, map.get(DemandType.PURCHASED_PARTS.getCode()).get(0).getId());
            }
            if (map.get(DemandType.AUXILIARY_MATERIALS.getCode()) != null && DemandType.AUXILIARY_MATERIALS.getName().equals(materialType.getName())) {
                insertPurchaseDetail(purchaseCountHashMap, materialType, purchasePlan, map.get(DemandType.AUXILIARY_MATERIALS.getCode()).get(0).getId());
            }
        }
    }

    public void insertPurchaseDetail(HashMap<String, PurchaseCount> purchaseCountHashMap, MaterialType materialType, PurchasePlan purchasePlan, String projectDemandPlanId) {

        if (purchaseCountHashMap.get(materialType.getName()) != null) {
            PurchaseCount purchaseCount = purchaseCountHashMap.get(materialType.getName());
            purchasePlan.setTotalWeight(purchaseCount.getPurchaseWeight());
            purchasePlan.setTotalAmount(purchaseCount.getPurchaseNum());
        }
        //新增产品采购计划，剩余的五种类型
        int insert = purchasePlanMapper.insert(purchasePlan);
        List<ProductDemandPlanTotal> productDemandPlanTotals = projectDemandPlanService.selectProductDemandByProjectDemandPlanId(projectDemandPlanId);
        ArrayList<PurchasePlanDetailsProductTotal> list = new ArrayList<>();
        if (productDemandPlanTotals.size() > 0) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                PurchasePlanDetailsProductTotal productTotal = new PurchasePlanDetailsProductTotal();
                productTotal.setPurchasePlanId(purchasePlan.getId());
                productTotal.setProductDemandPlanTotalId(productDemandPlanTotal.getId());
                productTotal.setMaterialName(productDemandPlanTotal.getMaterialName());
                productTotal.setMaterialType(productDemandPlanTotal.getMaterialType());
                productTotal.setTexture(productDemandPlanTotal.getTexture());
                productTotal.setSize(productDemandPlanTotal.getSpecification());
                productTotal.setUseMaterialUnit(productDemandPlanTotal.getUnit());
                //采购数量
                Integer purchaseNumber = Math.toIntExact((productDemandPlanTotal.getCount() - productDemandPlanTotal.getStockAmount()));
                productTotal.setPurchaseAmount(purchaseNumber);
                if (productDemandPlanTotal.getCount() > 0) {
                    productTotal.setPurchaseWeight((purchaseNumber / productDemandPlanTotal.getCount()) * productDemandPlanTotal.getWeight());
                }
                productTotal.setExecutiveStandards(productDemandPlanTotal.getEnforceStandards());
                productTotal.setArrivalAmount(0);
                productTotal.setProposalPrice(productDemandPlanTotal.getBidPrice());

                // 2023/1/29 交货时间和交货地点
                productTotal.setDeliveryTime(productDemandPlanTotal.getDeliveryTime());
                productTotal.setDeliveryLocation(productDemandPlanTotal.getDeliveryLocation());

                // 2023/1/30 最低价、最高价和平均价（从库存表中查出近三个月相同的材料） 产品按照规格和材质
                List<MaterialStock> materialStocks =  stockManagementService.selectProductTotalInThreeMonth(productDemandPlanTotal.getSpecification(),productDemandPlanTotal.getTexture());
                if (CommonUtil.listIsNotEmpty(materialStocks)){
                    //存在相同的材料
                    //最低价
                    Long min = materialStocks.stream().min(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                    Long high = materialStocks.stream().max(Comparator.comparing(MaterialStock::getUnivalence)).get().getUnivalence();
                    double avg = materialStocks.stream().mapToLong(MaterialStock::getUnivalence).average().getAsDouble();
                    productTotal.setLowestMarketPrice(min);
                    productTotal.setHighestMarketPrice(high);
                    productTotal.setMarketWeightedAverage((long) avg);
                }
                // 2023/02/08 采购计划详情新增用料类型字段，采购合同那边需要根据用料类型 获得 厚度、宽度和长度
                productTotal.setIngredientsType(productDemandPlanTotal.getIngredientsType());
                list.add(productTotal);
            }
            purchasePlanDetailsProductTotalMapper.insertBatchSomeColumn(list);
        }
    }

    public PageResult<PurchasePlanDateVO> getPurchasePlan(QueryPurchasePlanDTO dto) {
        Page<PurchasePlanDateVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 根据采购计划编号、项目名称和采购状态查询,创建时间
         */
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .like(!CommonUtil.isNull(dto.getPurchasePlanNumber()), PurchasePlan::getPurchasePlanNumber, dto.getPurchasePlanNumber())
                .like(!CommonUtil.isNull(dto.getProjectName()), PurchasePlan::getProjectName, dto.getProjectName())
                .eq(!CommonUtil.isNull(dto.getPurchaseStatus()), PurchasePlan::getPurchaseStatus, dto.getPurchaseStatus())
                .orderByDesc(PurchasePlan::getCreateTime)
                .eq(PurchasePlan::getIsDeleted,false);
        SearchUtil.timeRangeSearch(wrapper, PurchasePlan::getCreateTime, dto.getTimeStart(), dto.getTimeEnd());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        List<PurchasePlanVO> purchasePlanVOS = BeanUtil.copyList(purchasePlans, PurchasePlanVO.class);
        purchasePlanVOS.forEach(item -> {
            //设置物资类型
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            //设置采购状态
            item.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class, item.getPurchaseStatus()));
            //设置计划类型
            item.setScheduleTypeText(EnumUtil.getValue(PlanTypeEnum.class, item.getScheduleType()));
            //设置到货状态
            item.setArrivalStatusText(EnumUtil.getValue(ArrivalStatusEnum.class, item.getArrivalStatus()));
        });
        //根据项目id分组
        Map<String, List<PurchasePlanVO>> collect = purchasePlanVOS.stream().collect(Collectors.groupingBy(PurchasePlanVO::getProjectId));
        ArrayList<PurchasePlanDateVO> purchasePlanDateVOS = new ArrayList<>();
        for (String item : collect.keySet()) {
            Map<String, List<PurchasePlanVO>> listMap = collect.get(item).stream().filter(o -> !CommonUtil.isNull(o.getBatch())).collect(Collectors.groupingBy(PurchasePlanVO::getBatch));
            for (String p: listMap.keySet()) {
                PurchasePlanDateVO purchasePlanDateVO = new PurchasePlanDateVO();
                purchasePlanDateVO.setPurchasePlanVOS(listMap.get(p));
                purchasePlanDateVO.setProjectId(item);
                PurchasePlanVO purchasePlanVO = listMap.get(p).get(0);
                purchasePlanDateVO.setCreateTime(purchasePlanVO.getCreateTime());
                purchasePlanDateVO.setBatch(purchasePlanVO.getBatch());
                purchasePlanDateVO.setProjectIdAndBatch(purchasePlanVO.getProjectId()+"-"+purchasePlanVO.getBatch());
                //设置项目信息
                ProjectVO projectVO = projectService.getById(purchasePlanVO.getProjectId());
                BeanUtil.copyProperties(projectVO, purchasePlanDateVO);
                purchasePlanDateVOS.add(purchasePlanDateVO);
            }
        }
        //根据创建时间排序
        List<PurchasePlanDateVO> dateVOS = purchasePlanDateVOS.stream()
                .sorted(Comparator.comparing(PurchasePlanDateVO::getCreateTime, Comparator.reverseOrder()))
                .collect(Collectors.toList());
        return PageUtil.convert2PageResult(dateVOS, dto);
    }

    public List<SelectVO> purchaseStatusSelect() {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        for (PurchaseStateEnum item : PurchaseStateEnum.values()) {
            SelectVO build = SelectVO.builder().code(item.getCode()).name(item.getName()).build();
            selectVOS.add(build);
        }
        return selectVOS;
    }

    public List<SelectVO> planTypeSelect() {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        for (PlanTypeEnum item : PlanTypeEnum.values()) {
            SelectVO build = SelectVO.builder().code(item.getCode()).name(item.getName()).build();
            selectVOS.add(build);
        }
        return selectVOS;
    }

    public List<SelectVO> arrivalStatusSelect() {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        for (ArrivalStatusEnum item : ArrivalStatusEnum.values()) {
            SelectVO build = SelectVO.builder().code(item.getCode()).name(item.getName()).build();
            selectVOS.add(build);
        }
        return selectVOS;
    }


    public void editPurchasePlan(UpdatePurchasePlanDTO dto) {
        PurchasePlan copy = BeanUtil.copy(dto, PurchasePlan.class);
        purchasePlanMapper.updateById(copy);
    }

    public PurchasePlanVO getPurchasePlanById(QueryOneDTO dto) {
        PurchasePlan purchasePlan = purchasePlanMapper.selectById(dto.getId());
        PurchasePlanVO purchasePlanVO = BeanUtil.copy(purchasePlan, PurchasePlanVO.class);
        purchasePlanVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, purchasePlanVO.getMaterialType()));
        purchasePlanVO.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class, purchasePlanVO.getPurchaseStatus()));
        purchasePlanVO.setScheduleTypeText(EnumUtil.getValue(PlanTypeEnum.class, purchasePlanVO.getScheduleType()));
        purchasePlanVO.setArrivalStatusText(EnumUtil.getValue(ArrivalStatusEnum.class, purchasePlanVO.getArrivalStatus()));

        return purchasePlanVO;
    }

    public PageResult<PurchasePlanDetailVO> getPurchasePlanDetails(QueryOneDTO dto) {
        Page<PurchasePlanDetailVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 根据采购计划id查询，不同类型查询不同的表
         */
        //根据采购计划id查出相应的物资类型
        Integer materialType = getPurchasePlanById(dto).getMaterialType();
        if (materialType.equals(MaterialType.PAINT.getCode())) {
            //如果是油漆类型
            MPJLambdaWrapper<PurchasePlanDetailsPaint> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsPaint.class)
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsPaint::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsPaint::getPurchasePlanId, dto.getId())
                    .eq(PurchasePlanDetailsPaint::getIsDeleted,"0");
            IPage<PurchasePlanDetailVO> purchasePlanDetailVOIPage = purchasePlanDetailsPaintMapper.selectJoinPage(page, PurchasePlanDetailVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        } else if (materialType.equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //如果是焊材类型
            MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsWeldingMaterials::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsWeldingMaterials::getPurchasePlanId, dto.getId())
                    .eq(PurchasePlanDetailsWeldingMaterials::getIsDeleted,"0");
            IPage<PurchasePlanDetailVO> purchasePlanDetailVOIPage = purchasePlanDetailsWeldingMaterialsMapper.selectJoinPage(page, PurchasePlanDetailVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        } else {
            //产品类型
            MPJLambdaWrapper<PurchasePlanDetailsProductTotal> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsProductTotal::getPurchasePlanId, dto.getId())
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsProductTotal::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(materialType), PurchasePlanDetailsProductTotal::getMaterialType, materialType)
                    .eq(PurchasePlanDetailsProductTotal::getIsDeleted,"0");
            IPage<PurchasePlanDetailVO> purchasePlanDetailVOIPage = purchasePlanDetailsProductTotalMapper.selectJoinPage(page, PurchasePlanDetailVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
                //通过材质id设置材料名称
                MaterialTextureVO materialTexture = productDemandPlanService.getMaterialTexture(item.getTexture());
                if (materialTexture != null) {
                    item.setTextureText(materialTexture.getMaterial());
                }
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        }

    }


    public void accountExport(HttpServletResponse response, QueryPurchasePlanDTO dto) {
        /**
         *  模板见《中建五洲物资计划管理台账.docx》
         *      根据采购状态和时间查询
         */
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .like(!CommonUtil.isNull(dto.getPurchasePlanNumber()), PurchasePlan::getPurchasePlanNumber, dto.getPurchasePlanNumber())
                .like(!CommonUtil.isNull(dto.getProjectName()), PurchasePlan::getProjectName, dto.getProjectName())
                .eq(!CommonUtil.isNull(dto.getPurchaseStatus()), PurchasePlan::getPurchaseStatus, dto.getPurchaseStatus());
        SearchUtil.timeRangeSearch(wrapper, PurchasePlan::getCreateTime, dto.getTimeStart(), dto.getTimeEnd());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        //导出的数据
        List<AccountExportVO> accountExportVOS = BeanUtil.copyList(purchasePlans, AccountExportVO.class);
        AtomicInteger atomicInteger = new AtomicInteger();
        accountExportVOS.stream().forEach(item -> {
            //设置项目名称
            item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            //设置自增id
            item.setSerialNo(atomicInteger.incrementAndGet());
            //设置物资类型
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            //设置采购状态
            if (item.getPurchaseStatus() != null) {
                item.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class, item.getPurchaseStatus()));
            }
            //设置需求计划编号
            //根据项目id和物资类型，查询对应的项目需求计划
            ProjectDemandPlan projectDemandPlan = null;
            if (item.getMaterialType().equals(MaterialType.PAINT.getCode())) {
                //油漆  2
                projectDemandPlan = projectDemandPlanService.selectByProjectIdAndDemandType(item.getProjectId(), 2);
            } else if (item.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                //焊材 1
                projectDemandPlan = projectDemandPlanService.selectByProjectIdAndDemandType(item.getProjectId(), 1);
            } else {
                //产品 3
                projectDemandPlan = projectDemandPlanService.selectByProjectIdAndDemandType(item.getProjectId(), 3);
            }
            if (projectDemandPlan != null) {
                if (projectDemandPlan.getPlanNo() != null) {
                    item.setPlanNo(projectDemandPlan.getPlanNo());
                }
            }
            //需求计划提交人
            if (projectDemandPlan != null) {
                if (projectDemandPlan.getCompiler() != null) {
                    item.setProjectDemandPlanSubmitter(projectDemandPlan.getCompiler());
                }
            }
        });
        //导出
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/purchaseAccount.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("中建五洲物资管计划台账", response, resourceAsStream);
        HashMap<String, Object> map = new HashMap<>();
        map.put("param", "CSCECWZ-GM-B10203");
        excelExportService.fill(map, "管理台账");
        excelExportService.fill(new FillWrapper("list", accountExportVOS), "管理台账");
        excelExportService.export();
    }

    @Transactional(rollbackFor = Exception.class)
    public void deletePurchasePlan(DeletePurchasePlanDTO dto) {
        //2023/02/20  采购计划删除的时候，判断是否存在采购合同，存在的话，不让删除
        QueryWrapper<PurchasePlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1").eq("project_id",dto.getProjectId()).isNotNull("contract_list_id");
        if (purchasePlanMapper.selectCount(queryWrapper)>0){
            //存在采购合同
            throw new RuntimeException("该采购计划的采购合同已生成，不可删除");
        }

        //删除采购计划详情
        //根据项目id查询所有的采购计划id
        MPJLambdaWrapper<PurchasePlan> purchasePlanMPJLambdaWrapper = new MPJLambdaWrapper<>();
        purchasePlanMPJLambdaWrapper.select(PurchasePlan::getId)
                .eq(PurchasePlan::getProjectId, dto.getProjectId());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(purchasePlanMPJLambdaWrapper);
        List<String> collect = purchasePlans.stream().map(PurchasePlan::getId).collect(Collectors.toList());
        //删除采购计划
        UpdateWrapper<PurchasePlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("project_id", dto.getProjectId());
        purchasePlanMapper.delete(wrapper);
        //删除焊材
        UpdateWrapper<PurchasePlanDetailsWeldingMaterials> weldWrapper = new UpdateWrapper<>();
        weldWrapper.in("purchase_plan_id", collect).set("is_deleted","1");
        purchasePlanDetailsWeldingMaterialsMapper.update(new PurchasePlanDetailsWeldingMaterials(),weldWrapper);
        //删除油漆
        UpdateWrapper<PurchasePlanDetailsPaint> paintMPJLambdaWrapper = new UpdateWrapper<>();
        paintMPJLambdaWrapper.in("purchase_plan_id", collect).set("is_deleted","1");
        purchasePlanDetailsPaintMapper.update(new PurchasePlanDetailsPaint(),paintMPJLambdaWrapper);
        //删除产品
        UpdateWrapper<PurchasePlanDetailsProductTotal> productTotalMPJLambdaWrapper = new UpdateWrapper<>();
        productTotalMPJLambdaWrapper.in("purchase_plan_id", collect).set("is_deleted","1");
        purchasePlanDetailsProductTotalMapper.update(new PurchasePlanDetailsProductTotal(),productTotalMPJLambdaWrapper);
    }
    @Transactional(rollbackFor = Exception.class)
    public void editPurchasePlanDetail(UpdatePurchasePlanDetailDTO dto) {
        /**
         * 更新采购计划详情
         *  根据id和物资类型判断是在哪个表里面进行更新操作
         *  采购计划这边只有编辑市场最高价和市场最低价，没有编辑税前单价和税额
         */
        if (dto.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //编辑焊材
            PurchasePlanDetailsWeldingMaterials copy = BeanUtil.copy(dto, PurchasePlanDetailsWeldingMaterials.class);
            if (!CommonUtil.isNull(dto.getWarehousingNo())){
                QueryWrapper<PurchasePlanDetailsWeldingMaterials> queryWrapper = new QueryWrapper<>();
                queryWrapper.select("1")
                        .eq(!CommonUtil.isNull(dto.getWarehousingNo()), "warehousing_no", dto.getWarehousingNo())
                        .notIn("id", dto.getId())
                        .last("limit 1");
                if (purchasePlanDetailsWeldingMaterialsMapper.selectCount(queryWrapper) > 0) {
                    throw new RuntimeException("入库编号不能重复");
                }
            }
            purchasePlanDetailsWeldingMaterialsMapper.updateById(copy);
        } else if (dto.getMaterialType().equals(MaterialType.PAINT.getCode())) {
            //编辑油漆
            PurchasePlanDetailsPaint copy = BeanUtil.copy(dto, PurchasePlanDetailsPaint.class);
            if (!CommonUtil.isNull(dto.getWarehousingNo())){
                QueryWrapper<PurchasePlanDetailsPaint> queryWrapper = new QueryWrapper<>();
                queryWrapper.select("1")
                        .eq(!CommonUtil.isNull(dto.getWarehousingNo()), "warehousing_no", dto.getWarehousingNo())
                        .notIn("id", dto.getId())
                        .last("limit 1");
                if (purchasePlanDetailsPaintMapper.selectCount(queryWrapper) > 0) {
                    throw new RuntimeException("入库编号不能重复");
                }
            }
            purchasePlanDetailsPaintMapper.updateById(copy);
        } else {
            //编辑产品
            PurchasePlanDetailsProductTotal copy = BeanUtil.copy(dto, PurchasePlanDetailsProductTotal.class);
            if (!CommonUtil.isNull(dto.getWarehousingNo())){
                QueryWrapper<PurchasePlanDetailsProductTotal> queryWrapper = new QueryWrapper<>();
                queryWrapper.select("1")
                        .eq(!CommonUtil.isNull(dto.getWarehousingNo()), "warehousing_no", dto.getWarehousingNo())
                        .notIn("id", dto.getId())
                        .last("limit 1");
                if (purchasePlanDetailsProductTotalMapper.selectCount(queryWrapper) > 0) {
                    throw new RuntimeException("入库编号不能重复");
                }
            }
            purchasePlanDetailsProductTotalMapper.updateById(copy);
        }
    }

    public void deletePurchasePlanDetail(DeletePurchasePlaDetailDTO dto) {
        /**
         * 根据物资类型删除采购计划详情
         */
        if (dto.getMaterialType().equals(MaterialType.PAINT.getCode())) {
            //油漆
            //2023/02/15 采用逻辑删除
            UpdateWrapper<PurchasePlanDetailsPaint> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq(!CommonUtil.isNull(dto.getId()),"id",dto.getId())
                    .set("is_deleted","1");
            purchasePlanDetailsPaintMapper.update(new PurchasePlanDetailsPaint(),updateWrapper);
        } else if (dto.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //焊材
            //2023/02/15 采用逻辑删除
            UpdateWrapper<PurchasePlanDetailsWeldingMaterials> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq(!CommonUtil.isNull(dto.getId()),"id",dto.getId())
                    .set("is_deleted","1");
            purchasePlanDetailsWeldingMaterialsMapper.update(new PurchasePlanDetailsWeldingMaterials(),updateWrapper);
        } else {
            //产品
            //2023/02/15 采用逻辑删除
            UpdateWrapper<PurchasePlanDetailsProductTotal> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq(!CommonUtil.isNull(dto.getId()),"id",dto.getId())
                    .set("is_deleted","1");
            purchasePlanDetailsProductTotalMapper.update(new PurchasePlanDetailsProductTotal(),updateWrapper);
        }
    }
    @Transactional(rollbackFor = Exception.class)
    public PurchasePlanDetailVO getPurchasePlanDetailById(DeletePurchasePlaDetailDTO dto) {
        /**
         *  根据id和物资类型查询采购计划详情
         */
        if (dto.getMaterialType().equals(MaterialType.PAINT.getCode())) {
            //油漆
            PurchasePlanDetailsPaint purchasePlanDetailsPaint = purchasePlanDetailsPaintMapper.selectById(dto.getId());
            PurchasePlanDetailVO purchasePlanDetailVO = BeanUtil.copy(purchasePlanDetailsPaint, PurchasePlanDetailVO.class);
            purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, purchasePlanDetailVO.getMaterialType()));
            return purchasePlanDetailVO;
        } else if (dto.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //焊材
            PurchasePlanDetailsWeldingMaterials purchasePlanDetailsWeldingMaterials = purchasePlanDetailsWeldingMaterialsMapper.selectById(dto.getId());
            PurchasePlanDetailVO purchasePlanDetailVO = BeanUtil.copy(purchasePlanDetailsWeldingMaterials, PurchasePlanDetailVO.class);
            purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, purchasePlanDetailVO.getMaterialType()));
            return purchasePlanDetailVO;
        } else {
            //产品
            PurchasePlanDetailsProductTotal purchasePlanDetailsProductTotal = purchasePlanDetailsProductTotalMapper.selectById(dto.getId());
            PurchasePlanDetailVO purchasePlanDetailVO = BeanUtil.copy(purchasePlanDetailsProductTotal, PurchasePlanDetailVO.class);
            purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, purchasePlanDetailVO.getMaterialType()));
            MaterialTextureVO materialTexture = productDemandPlanService.getMaterialTexture(purchasePlanDetailVO.getTexture());
            if (materialTexture != null) {
                purchasePlanDetailVO.setTextureText(materialTexture.getMaterial());
            }
            return purchasePlanDetailVO;
        }
    }
    @Transactional(rollbackFor = Exception.class)
    public void purchasePlanExport(HttpServletResponse response, PurchasePlanExportDTO dto) {
        /**
         *  根据id查询采购计划
         */
        PurchasePlan purchasePlan = purchasePlanMapper.selectById(dto.getId());
        Integer materialType = purchasePlan.getMaterialType();
        //根据物资类型判断数据
        List<PurchasePlanExportVO> list;
        if (materialType.equals(MaterialType.PAINT.getCode())) {
            //油漆：查询油漆采购计划表
            MPJLambdaWrapper<PurchasePlanDetailsPaint> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsPaint.class)
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsPaint::getPurchasePlanId, dto.getId());
            List<PurchasePlanDetailsPaint> paints = purchasePlanDetailsPaintMapper.selectList(wrapper);
            list = BeanUtil.copyList(paints, PurchasePlanExportVO.class);
        } else if (materialType.equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //焊材
            MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsWeldingMaterials::getPurchasePlanId, dto.getId());
            List<PurchasePlanDetailsWeldingMaterials> welds = purchasePlanDetailsWeldingMaterialsMapper.selectList(wrapper);
            list = BeanUtil.copyList(welds, PurchasePlanExportVO.class);
        } else {
            //产品
            MPJLambdaWrapper<PurchasePlanDetailsProductTotal> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsProductTotal::getPurchasePlanId, dto.getId())
                    .eq(!CommonUtil.isNull(materialType), PurchasePlanDetailsProductTotal::getMaterialType, materialType);
            List<PurchasePlanDetailsProductTotal> totals = purchasePlanDetailsProductTotalMapper.selectList(wrapper);
            list = BeanUtil.copyList(totals, PurchasePlanExportVO.class);
        }

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            item.setSerialNo(atomicInteger.incrementAndGet());
            BeanUtil.copyProperties(purchasePlan, item);
        });

        HashMap<String, Object> map = new HashMap<>();
        map.put("unitName", purchasePlan.getUnitName());
        map.put("projectName", purchasePlan.getProjectName());
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY-MM-dd");
        String format = simpleDateFormat.format(purchasePlan.getCreateTime());
        map.put("createTime", format);
        map.put("formNo", purchasePlan.getFormNo());
        map.put("purchaseDescription", purchasePlan.getPurchaseDescription());
        map.put("purchasePlanCompiler", purchasePlan.getPurchasePlanCompiler());
        map.put("reviewer", purchasePlan.getReviewer());
        map.put("approver", purchasePlan.getApprover());
        map.put("weight", purchasePlan.getTotalWeight());
        map.put("total", purchasePlan.getTotalAmount());
        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("计划"), 6, List.of(12, 17)));
//        writeHandlers.add(new MyMergeHandler(List.of("油漆"), 4 + list.size(), List.of(new Cell RangeAddress(4 + list.size(), 4 + list.size(), 1, 10))));
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/purchasePlan.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("计划", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        excelExportService.fill(map, "计划");
        excelExportService.fill(new FillWrapper("list", list), "计划");

        /**
         * 编制说明
         */
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("preparationDescription", purchasePlan.getPreparationDescription());
        hashMap.put("purchasePlanNumber", purchasePlan.getPurchasePlanNumber());
        excelExportService.fill(hashMap, "编制说明");
        /**
         * 封面
         */
        HashMap<String, Object> data = new HashMap<>();
        //项目编号
        String projectNo = projectService.getById(purchasePlan.getProjectId()).getProjectNo();
        data.put("projectNo", projectNo);
        data.put("purchasePlanNumber", purchasePlan.getPurchasePlanNumber());
        data.put("projectName", purchasePlan.getProjectName());
        //项目需求计划编号:根据项目id和物资类型查询计划编号
        String planNo = projectDemandPlanService.selectPlanNoByProjectId(purchasePlan.getProjectId(), materialType);
        data.put("planNo", planNo);
        data.put("purchasePlanCompiler", purchasePlan.getPurchasePlanCompiler());
        data.put("reviewer", purchasePlan.getReviewer());
        data.put("approver", purchasePlan.getApprover());
        excelExportService.fill(data, "封面");
        excelExportService.export();
    }

    /***
     *  根据项目id和物资类型判断合同清单id是否为空
     * @param projectIds 项目id集合
     * @param materialType  物资类型
     * @return 是否为空
     */
    public boolean isRelatedToContractList(List<String> projectIds, Integer materialType) {
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        //将id分割出来

        wrapper.select(PurchasePlan::getContractListId, PurchasePlan::getProjectId)
                .eq(!CommonUtil.isNull(materialType), PurchasePlan::getMaterialType, materialType)
                .in(CommonUtil.listIsNotEmpty(projectIds), PurchasePlan::getProjectId, projectIds);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        for (PurchasePlan item : purchasePlans) {
            if (item.getContractListId() != null) {
                String projectName = projectService.getById(item.getProjectId()).getProjectName();
                throw new RuntimeException(projectName + ",该项目下的【" + EnumUtil.getValue(MaterialType.class, materialType) + "】已经存在合同清单中");
            }
        }
        return true;
    }

    /**
     * 更新关联的合同清单id
     *
     * @param projectIds   项目id（多个）
     * @param materialType 物资类型
     */
    public void updateContractList(List<String> projectIds, Integer materialType, String contractListId) {
        UpdateWrapper<PurchasePlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("material_type", materialType)
                .in("project_id", projectIds);
        PurchasePlan purchasePlan = new PurchasePlan();
        purchasePlan.setContractListId(contractListId);
        MPJLambdaWrapper<PurchasePlan> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(PurchasePlan.class)
                .eq(!CommonUtil.isNull(materialType),PurchasePlan::getMaterialType,materialType)
                .in(CommonUtil.listIsNotEmpty(projectIds),PurchasePlan::getProjectId,projectIds);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(queryWrapper);
        for (PurchasePlan purchase:purchasePlans) {
            purchase.setContractListId(contractListId);
            //根据采购计划表的id  和  物资类型  更新入库编号
            if (MaterialType.WELDING_MATERIALS.getCode().equals(materialType)){
                //焊材
                MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> weldWrapper = new MPJLambdaWrapper<>();
                weldWrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                        .eq(PurchasePlanDetailsWeldingMaterials::getPurchasePlanId,purchase.getId())
                        .isNull(PurchasePlanDetailsWeldingMaterials::getWarehousingNo);
                List<PurchasePlanDetailsWeldingMaterials> weldingMaterials = purchasePlanDetailsWeldingMaterialsMapper.selectList(weldWrapper);
                for (PurchasePlanDetailsWeldingMaterials weld:weldingMaterials) {
                    //更新计划编号
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                    String warehousingNo = "R"+ "HC" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    //判断入库编号是否已经存在
                    QueryWrapper<PurchasePlanDetailsWeldingMaterials> weldingMaterialsQueryWrapper = new QueryWrapper<>();
                    weldingMaterialsQueryWrapper.select("1").eq(!CommonUtil.isNull(warehousingNo),"warehousing_no",warehousingNo).last("limit 1");
                    //数据库已经存在编号，重新生成入库编号
                    while (purchasePlanDetailsWeldingMaterialsMapper.selectCount(weldingMaterialsQueryWrapper) > 0){
                        warehousingNo = "R"+ "HC" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    }
                    weld.setWarehousingNo(warehousingNo);
                    purchasePlanDetailsWeldingMaterialsMapper.updateById(weld);
                }
            }else if (MaterialType.PAINT.getCode().equals(materialType)){
                //油漆
                MPJLambdaWrapper<PurchasePlanDetailsPaint> paintWrapper = new MPJLambdaWrapper<>();
                paintWrapper.selectAll(PurchasePlanDetailsPaint.class)
                        .eq(PurchasePlanDetailsPaint::getPurchasePlanId,purchase.getId())
                        .isNull(PurchasePlanDetailsPaint::getWarehousingNo);
                List<PurchasePlanDetailsPaint> paintList = purchasePlanDetailsPaintMapper.selectList(paintWrapper);
                for (PurchasePlanDetailsPaint paint:paintList) {
                    //更新计划编号
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                    String warehousingNo = "R"+ "YQ" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    //判断入库编号是否已经存在
                    QueryWrapper<PurchasePlanDetailsPaint> paintMaterialsQueryWrapper = new QueryWrapper<>();
                    paintMaterialsQueryWrapper.select("1").eq(!CommonUtil.isNull(warehousingNo),"warehousing_no",warehousingNo).last("limit 1");
                    //数据库已经存在编号，重新生成入库编号
                    while (purchasePlanDetailsPaintMapper.selectCount(paintMaterialsQueryWrapper) > 0){
                        warehousingNo = "R"+ "YQ" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    }
                    paint.setWarehousingNo(warehousingNo);
                    purchasePlanDetailsPaintMapper.updateById(paint);
                }
            }else {
                String no = "";
                //产品
                switch (EnumUtil.getEnumByCode(MaterialType.class,materialType)){
                    case BOARD:
                        no = "BC";
                        break;
                    case PROFILE:
                        no = "XC";
                        break;
                    case FORGE_PIECE:
                        no = "DJ";
                        break;
                    case PURCHASED_PARTS:
                        no = "WG";
                        break;
                    case AUXILIARY_MATERIALS:
                        no = "FC";
                        break;
                    default:
                        no = "BH";
                        break;
                }
                //产品
                MPJLambdaWrapper<PurchasePlanDetailsProductTotal> productWrapper = new MPJLambdaWrapper<>();
                productWrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                        .eq(PurchasePlanDetailsProductTotal::getPurchasePlanId,purchase.getId())
                        .isNull(PurchasePlanDetailsProductTotal::getWarehousingNo);
                List<PurchasePlanDetailsProductTotal> productTotals = purchasePlanDetailsProductTotalMapper.selectList(productWrapper);
                for (PurchasePlanDetailsProductTotal product:productTotals) {
                    //更新计划编号
                    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                    String warehousingNo = "R"+ no + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    //判断入库编号是否已经存在
                    QueryWrapper<PurchasePlanDetailsProductTotal> productTotalQueryWrapper = new QueryWrapper<>();
                    productTotalQueryWrapper.select("1").eq(!CommonUtil.isNull(warehousingNo),"warehousing_no",warehousingNo).last("limit 1");
                    //数据库已经存在编号，重新生成入库编号
                    while (purchasePlanDetailsProductTotalMapper.selectCount(productTotalQueryWrapper) > 0){
                        warehousingNo = "R"+ "YQ" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000 );
                    }
                    product.setWarehousingNo(warehousingNo);
                    purchasePlanDetailsProductTotalMapper.updateById(product);
                }
            }
        }
        purchasePlanMapper.update(purchasePlan, wrapper);
    }

    /**
     * 根据合同清单id和查询条件查询
     *
     * @param collect 合同清单id集合
     * @param dto     查询条件
     * @return 采购计划返回的集合
     */
    public List<PurchasePlan> getPurchasePlanInContractList(List<String> collect, QueryContractListDTO dto) {
        //2023/03/15 查询条件新增项目需求计划编号
        List<ProjectDemandPlan> list = null;
        if (!CommonUtil.isNull(dto.getDemandPlanNumber())) {
            //在项目需求计划中根据项目需求计划编号查询 项目id和需求类型
            list = projectDemandPlanService.getProjectAndDemandType(dto.getDemandPlanNumber());
        }

        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .in(collect.size() > 0, PurchasePlan::getContractListId, collect)
                .like(!CommonUtil.isNull(dto.getPurchasePlanNumber()), PurchasePlan::getPurchasePlanNumber, dto.getPurchasePlanNumber())
                .like(!CommonUtil.isNull(dto.getProjectName()), PurchasePlan::getProjectName, dto.getProjectName());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(list)) {
            List<ProjectDemandPlan> finalList = list;
            List<PurchasePlan> purchasePlanList = purchasePlans.stream().filter(
                    item -> {
                        assert finalList != null;
                        AtomicBoolean flag = new AtomicBoolean(false);
                        finalList.forEach(l->{
                            if (l.getProjectId().equals(item.getProjectId())&&EnumUtil.getValue(MaterialType.class,item.getMaterialType()).equals(EnumUtil.getValue(DemandType.class,l.getDemandType()))){
                                flag.set(true);
                            }
                        });
                       return flag.get();
                    }).collect(Collectors.toList());
            return purchasePlanList;
        }
        return purchasePlans;
    }

    /**
     * 更新关联的合同清单id
     *
     * @param id 采购计划id
     */
    public void updateRelationContractList(String id) {
        UpdateWrapper<PurchasePlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", id)
                .set("contract_list_id", null);
        PurchasePlan purchasePlan = new PurchasePlan();
        purchasePlanMapper.update(purchasePlan, wrapper);
    }

    public void updateByContractListId(String id) {
        UpdateWrapper<PurchasePlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("contract_list_id", id)
                .set("contract_list_id", null);
        purchasePlanMapper.update(new PurchasePlan(), wrapper);
    }

    /**
     * 根据id查询合同清单id
     *
     * @param id 采购计划id
     * @return 合同清单id
     */
    public String selectContractListById(String id) {
        PurchasePlan purchasePlan = purchasePlanMapper.selectById(id);
        return purchasePlan.getContractListId() == null ? null : purchasePlan.getContractListId();
    }

    /**
     * 判断合同清单下是否还存在关联采购计划
     *
     * @param contractListId 合同清单id
     * @return true：存在，false：不存在
     */
    public boolean isExistRelateToContractList(String contractListId) {
        QueryWrapper<PurchasePlan> wrapper = new QueryWrapper<>();
        wrapper.eq("contract_list_id", contractListId);
        Long count = purchasePlanMapper.selectCount(wrapper);
        return count > 0;
    }

    /**
     * 根据项目id和物资类型，查询是否存在采购计划
     *
     * @param projectIds
     * @param materialType
     * @return
     */
    public boolean isExistPurchasePlan(List<String> projectIds, Integer materialType) {
        for (String item : projectIds) {
            QueryWrapper<PurchasePlan> wrapper = new QueryWrapper<>();
            wrapper.select("1")
                    .eq("project_id", item)
                    .eq("material_type", materialType)
                    .last("limit 1");
            Long count = purchasePlanMapper.selectCount(wrapper);
            if (count == 0) {
                String projectName = projectService.getById(item).getProjectName();
                throw new RuntimeException(projectName + "下没有【" + EnumUtil.getValue(MaterialType.class, materialType) + "】类型的采购计划！");
            }
        }
        return true;
    }

    /**
     * 查询所有合同清单id不为空的项目id和项目名称
     *
     * @return
     */
    public List<ProjectIdAndNameVO> getProjectIdAndNameInContract(String id) {
//        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
//        wrapper.select(PurchasePlan::getProjectId,PurchasePlan::getProjectName)
//                .isNotNull(PurchasePlan::getContractListId);
        QueryWrapper<PurchasePlan> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("DISTINCT  project_id", "project_name")
                .eq("contract_list_id",id);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(queryWrapper);
        return BeanUtil.copyList(purchasePlans, ProjectIdAndNameVO.class);
    }

    /**
     * 根据项目id查询物资合同清单写的物资类型
     *
     * @param projectId
     * @return
     */
    public List<SelectVO> getMaterialTypeByProjectId(String projectId) {
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(PurchasePlan::getMaterialType)
                .eq(!CommonUtil.isNull(projectId), PurchasePlan::getProjectId, projectId)
                .isNotNull(PurchasePlan::getContractListId);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        List<Integer> materialTypes = purchasePlans.stream().map(PurchasePlan::getMaterialType).distinct().collect(Collectors.toList());
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        for (Integer code : materialTypes) {
            SelectVO selectVO = SelectVO.builder().code(code).name(EnumUtil.getValue(MaterialType.class, code)).build();
            selectVOS.add(selectVO);
        }
        return selectVOS;
    }

    /**
     * 根据项目id和物资类型，查找采购计划详情
     *
     * @param projectId
     * @param materialType
     * @return
     */
    public List<PurchasePlanDetailVO> getPurchasePlanDetail(String projectId, Integer materialType) {
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
//        wrapper.select(PurchasePlan::getId)
//                .eq(!CommonUtil.isNull(projectId),PurchasePlan::getProjectId,projectId)
//                .eq(!CommonUtil.isNull(materialType),PurchasePlan::getMaterialType,materialType);
        QueryWrapper<PurchasePlan> queryWrapper = new QueryWrapper<>();
        if (CommonUtil.isNull(projectId) || CommonUtil.isNull(materialType)) {
            throw new RuntimeException("项目和物资类型尚未选择");
        }
        //2023/03/02  领料从采购合同获取数据时，从材料名称后面加上批次，用来区分相同名称，不同批次的材料
        queryWrapper.select("id", "contract_list_id","batch")
                .eq(!CommonUtil.isNull(projectId), "project_id", projectId)
                .eq(!CommonUtil.isNull(materialType), "material_type", materialType)
                .isNotNull("contract_list_id");
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(queryWrapper);
        //采购计划id
//        String purchasePlanId = purchasePlan.getId();
//        List<String> purchasePlanIds = purchasePlans.stream().map(PurchasePlan::getId).collect(Collectors.toList());
        Map<String, List<PurchasePlan>> collect = purchasePlans.stream().collect(Collectors.groupingBy(PurchasePlan::getId));
        ArrayList<String> purchasePlanIds = new ArrayList<>(collect.keySet());
//        String contractListId = purchasePlan.getContractListId();
        String contractListId = purchasePlans.get(0).getContractListId();
        if (!CommonUtil.listIsNotEmpty(purchasePlanIds)) {
            throw new RuntimeException("该项目的材料类型下没有采购计划！");
        }
        //根据物资类型，判断产品、油漆、焊材，到不同的表中的查询采购计划详情
        if (materialType.equals(MaterialType.PAINT.getCode())) {
            //油漆
            MPJLambdaWrapper<PurchasePlanDetailsPaint> paintMPJLambdaWrapper = new MPJLambdaWrapper<>();
            paintMPJLambdaWrapper.selectAll(PurchasePlanDetailsPaint.class)
                    .in(PurchasePlanDetailsPaint::getPurchasePlanId, purchasePlanIds);
            List<PurchasePlanDetailsPaint> paints = purchasePlanDetailsPaintMapper.selectList(paintMPJLambdaWrapper);
            List<PurchasePlanDetailVO> purchasePlanDetailVOS = BeanUtil.copyList(paints, PurchasePlanDetailVO.class);
            purchasePlanDetailVOS.forEach(item -> {
                item.setContractListId(contractListId);
                item.setMaterialName(item.getMaterialName()+"-"+collect.get(item.getPurchasePlanId()).get(0).getBatch());
                //2023/02/13  添加尚未入库数量
                initQualityNotInStock(item,item.getWarehousingNo());
            });
            return purchasePlanDetailVOS;
        } else if (materialType.equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //焊材
            MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> materialsMPJLambdaWrapper = new MPJLambdaWrapper<>();
            materialsMPJLambdaWrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                    .in(PurchasePlanDetailsWeldingMaterials::getPurchasePlanId, purchasePlanIds);
            List<PurchasePlanDetailsWeldingMaterials> weldingMaterials = purchasePlanDetailsWeldingMaterialsMapper.selectList(materialsMPJLambdaWrapper);
            List<PurchasePlanDetailVO> purchasePlanDetailVOS = BeanUtil.copyList(weldingMaterials, PurchasePlanDetailVO.class);
            purchasePlanDetailVOS.forEach(item -> {
                item.setContractListId(contractListId);
                item.setMaterialName(item.getMaterialName()+"-"+collect.get(item.getPurchasePlanId()).get(0).getBatch());
                //2023/02/13  添加尚未入库数量
                initQualityNotInStock(item,item.getWarehousingNo());
            });
            return purchasePlanDetailVOS;
        } else {
            //产品
            MPJLambdaWrapper<PurchasePlanDetailsProductTotal> productTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
            productTotalMPJLambdaWrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                    .in(PurchasePlanDetailsProductTotal::getPurchasePlanId, purchasePlanIds)
                    .eq(PurchasePlanDetailsProductTotal::getMaterialType, materialType);
            List<PurchasePlanDetailsProductTotal> productTotals = purchasePlanDetailsProductTotalMapper.selectList(productTotalMPJLambdaWrapper);
            List<PurchasePlanDetailVO> purchasePlanDetailVOS = BeanUtil.copyList(productTotals, PurchasePlanDetailVO.class);
            purchasePlanDetailVOS.forEach(item -> {
                item.setContractListId(contractListId);
                item.setMaterialName(item.getMaterialName()+"-"+collect.get(item.getPurchasePlanId()).get(0).getBatch());
                //2023/02/13  添加尚未入库数量
                initQualityNotInStock(item,item.getWarehousingNo());
            });
            return purchasePlanDetailVOS;
        }
    }

    public Long generateMarketUnitPriceTax(MarketUnitPriceTaxDTO dto) {
        //根据规格和材质在库存中查询最新的 税前单价和税额之和
        return stockManagementService.getLatestPrice(dto.getSpecification(),dto.getTexture());
    }

    public List<ProjectNameInDemandPlanVO> getProjectNameInDemandPlan() {
        //2023/03/02  id格式:项目id-批次  projectName格式：项目名称[批次]
        List<ProjectNameInDemandPlanVO> list=   projectDemandPlanService.getProject();
        //2023/03/02   已经生成过采购计划的，从下拉框中筛选出来
        //从采购计划中查询项目id和批次
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(null);
        //根据项目id和批次筛选
        List<String> collect = purchasePlans.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                new TreeSet<>(Comparator.comparing(o -> o.getProjectId() + ";" + o.getBatch()))), ArrayList::new)).stream()
                .map(c -> c.getProjectId() + "-" + c.getBatch()).collect(Collectors.toList());
        log.info("需要过滤的项目需求计划：{}",collect);
        return  list.stream().filter(item -> !collect.contains(item.getProjectId())).collect(Collectors.toList());
    }

    public PageResult<PriceControlVO> getPriceControl(QueryOneDTO dto) {
        Page<PriceControlVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 根据采购计划id查询，不同类型查询不同的表
         */
        //根据采购计划id查出相应的物资类型
        Integer materialType = getPurchasePlanById(dto).getMaterialType();
        if (materialType.equals(MaterialType.PAINT.getCode())) {
            //如果是油漆类型
            MPJLambdaWrapper<PurchasePlanDetailsPaint> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsPaint.class)
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsPaint::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsPaint::getPurchasePlanId, dto.getId());
            IPage<PriceControlVO> purchasePlanDetailVOIPage = purchasePlanDetailsPaintMapper.selectJoinPage(page, PriceControlVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().stream().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        } else if (materialType.equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //如果是焊材类型
            MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsWeldingMaterials::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsWeldingMaterials::getPurchasePlanId, dto.getId());
            IPage<PriceControlVO> purchasePlanDetailVOIPage = purchasePlanDetailsWeldingMaterialsMapper.selectJoinPage(page, PriceControlVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().stream().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        } else {
            //产品类型
            MPJLambdaWrapper<PurchasePlanDetailsProductTotal> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                    .eq(!CommonUtil.isNull(dto.getId()), PurchasePlanDetailsProductTotal::getPurchasePlanId, dto.getId())
                    .like(!CommonUtil.isNull(dto.getMaterialName()), PurchasePlanDetailsProductTotal::getMaterialName, dto.getMaterialName())
                    .eq(!CommonUtil.isNull(materialType), PurchasePlanDetailsProductTotal::getMaterialType, materialType);
            IPage<PriceControlVO> purchasePlanDetailVOIPage = purchasePlanDetailsProductTotalMapper.selectJoinPage(page, PriceControlVO.class, wrapper);
            purchasePlanDetailVOIPage.getRecords().stream().forEach(item -> {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
                //通过材质id设置材料名称
                MaterialTextureVO materialTexture = productDemandPlanService.getMaterialTexture(item.getTexture());
                if (materialTexture != null) {
                    item.setTextureText(materialTexture.getMaterial());
                }
            });
            return PageUtil.convert2PageResult(purchasePlanDetailVOIPage);
        }
    }

    public List<String> getPurchasePlanNumberInSelect(List<String> projectIds, Integer materialType) {
        //项目id格式：0e4c8a49db6d782e00c9ce77743acae6-第1批次 将项目id拆分开来
        ArrayList<String> list = new ArrayList<>();
        projectIds.forEach(
                item -> {
                    String[] split = item.split("-");
                    list.add(split[0]);
                }
        );
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .in(CommonUtil.listIsNotEmpty(list),PurchasePlan::getProjectId,list)
                .eq(!CommonUtil.isNull(materialType),PurchasePlan::getMaterialType,materialType);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
//        ArrayList<String> list = new ArrayList<>();
//        for (PurchasePlan purchasePlan:purchasePlans){
//            if (!CommonUtil.isNull(purchasePlan.getPurchasePlanNumber())){
//                list.add(purchasePlan.getPurchasePlanNumber());
//            }
//        }
        return purchasePlans.stream().filter(o -> !CommonUtil.isNull(o.getPurchasePlanNumber())).map(PurchasePlan::getPurchasePlanNumber).collect(Collectors.toList());
    }

    public List<ProjectInPurchasePlanVO> getProjectInPurchasePlan() {
        //2023/03/02 已经生成过采购合同的，从下拉框中筛选出来
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .isNull(PurchasePlan::getContractListId);
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(wrapper);
        ArrayList<ProjectInPurchasePlanVO> list = new ArrayList<>();
        ArrayList<PurchasePlan> collect = purchasePlans.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                new TreeSet<>(Comparator.comparing(o -> o.getProjectId() + ";" + o.getBatch()))
        ), ArrayList::new));
        collect.forEach(
                item -> {
                    ProjectInPurchasePlanVO build = ProjectInPurchasePlanVO.builder().projectId(item.getProjectId() + "-" + item.getBatch())
                            .projectName(projectService.getById(item.getProjectId()).getProjectName() + "-" + item.getBatch()).build();
                    list.add(build);
                }
        );

        return list;
    }

    public PurchasePlan getByContractListIdAndProjectId(String contractListId, String projectId,String batch){
        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(PurchasePlan::getId)
                .eq(!CommonUtil.isNull(contractListId),PurchasePlan::getContractListId,contractListId)
                .eq(!CommonUtil.isNull(projectId),PurchasePlan::getProjectId,projectId)
                .eq(!CommonUtil.isNull(batch),PurchasePlan::getBatch,batch);
        return purchasePlanMapper.selectOne(wrapper);
    }

    public List<PurchasePlanDetailsProductTotal> getProductTotal(String contractListId, String projectId,String batch) {
        PurchasePlan purchasePlan = getByContractListIdAndProjectId(contractListId,projectId,batch);
        MPJLambdaWrapper<PurchasePlanDetailsProductTotal> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                .eq(PurchasePlanDetailsProductTotal::getPurchasePlanId,purchasePlan.getId());
        return purchasePlanDetailsProductTotalMapper.selectList(lambdaWrapper);
    }

    public List<PurchasePlanDetailsWeldingMaterials> getWeld(String contractListId, String projectId,String batch) {
        PurchasePlan purchasePlan = getByContractListIdAndProjectId(contractListId,projectId,batch);
        MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                .eq(PurchasePlanDetailsWeldingMaterials::getPurchasePlanId,purchasePlan.getId());
        return purchasePlanDetailsWeldingMaterialsMapper.selectList(lambdaWrapper);
    }

    public void batchUpdateProductTotal(List<PurchasePlanDetailsProductTotal> productTotals) {
        //根据入库编号更新
        for (PurchasePlanDetailsProductTotal total:productTotals
             ) {
            if (!CommonUtil.isNull(total.getTotalPriceIncludingTax())&&!CommonUtil.isNull(total.getTotalPriceExcludingTax())){
                total.setTax(total.getTotalPriceIncludingTax()-total.getTotalPriceExcludingTax());
            }
            QueryWrapper<PurchasePlanDetailsProductTotal> wrapper = new QueryWrapper<>();
            wrapper.eq("warehousing_no",total.getWarehousingNo());
            purchasePlanDetailsProductTotalMapper.update(total,wrapper);
        }
    }

    public void batchUpdateWeld(List<PurchasePlanDetailsWeldingMaterials> welds) {
        //根据入库编号更新焊材数据
        for (PurchasePlanDetailsWeldingMaterials weld:welds
             ) {
            //2023/02/20  总税额
            weld.setTax(weld.getTotalPriceIncludingTax()-weld.getTotalPriceExcludingTax());
            QueryWrapper<PurchasePlanDetailsWeldingMaterials> wrapper = new QueryWrapper<>();
            wrapper.eq("warehousing_no",weld.getWarehousingNo());
            purchasePlanDetailsWeldingMaterialsMapper.update(weld,wrapper);
        }
    }

    public List<PurchasePlanDetailsPaint> getPaint(String contractListId, String projectId,String batch) {
        PurchasePlan purchasePlan = getByContractListIdAndProjectId(contractListId,projectId,batch);
        MPJLambdaWrapper<PurchasePlanDetailsPaint> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlanDetailsPaint.class)
                .eq(PurchasePlanDetailsPaint::getPurchasePlanId,purchasePlan.getId());
        return purchasePlanDetailsPaintMapper.selectList(wrapper);
    }

    public void batchUpdatePaint(List<PurchasePlanDetailsPaint> paints) {
        //根据入库编号更新油漆数据
        for (PurchasePlanDetailsPaint paint:paints
             ) {
            QueryWrapper<PurchasePlanDetailsPaint> wrapper = new QueryWrapper<>();
            wrapper.eq("warehousing_no",paint.getWarehousingNo());
            purchasePlanDetailsPaintMapper.update(paint,wrapper);
        }
    }

    public void initQualityNotInStock(PurchasePlanDetailVO purchasePlanDetailVO,String warehousingNo){
        //从一级入库表 根据物资编号查
        MaterialFirstLevelStorage storage = storageService.getByMaterialNumber(warehousingNo);
        if (!CommonUtil.isNull(storage)){
            purchasePlanDetailVO.setQualityNotInStock((purchasePlanDetailVO.getPurchaseAmount()-storage.getCount())/100);
        }
    }


    public PurchasePlanDetailVO getPurchaseDetailByWarehousingNo(WarehousingNoDTO dto) {
        //根据入库编号解析物资类型
        String warehousingNo = dto.getWarehousingNo();
        String substring = warehousingNo.substring(1, 3);
        PurchasePlanDetailVO purchasePlanDetailVO = null;
        switch (substring){
            case "HC":
                //焊材
                MPJLambdaWrapper<PurchasePlanDetailsWeldingMaterials> wrapper = new MPJLambdaWrapper<>();
                wrapper.selectAll(PurchasePlanDetailsWeldingMaterials.class)
                        .isNotNull(PurchasePlanDetailsWeldingMaterials::getPurchasePlanId)
                        .eq(!CommonUtil.isNull(warehousingNo),PurchasePlanDetailsWeldingMaterials::getWarehousingNo,warehousingNo);
                PurchasePlanDetailsWeldingMaterials selectOne = purchasePlanDetailsWeldingMaterialsMapper.selectOne(wrapper);
                if (CommonUtil.isNull(selectOne)){
                    throw new RuntimeException("不存在该物资");
                }
                purchasePlanDetailVO = BeanUtil.copy(selectOne, PurchasePlanDetailVO.class);
                PurchasePlan purchasePlanWeld = purchasePlanMapper.selectById(purchasePlanDetailVO.getPurchasePlanId());
                purchasePlanDetailVO.setAscriptionText(purchasePlanWeld.getProjectName());
                purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,purchasePlanDetailVO.getMaterialType()));
                purchasePlanDetailVO.setContractListId(purchasePlanWeld.getContractListId());
                initQualityNotInStock(purchasePlanDetailVO,dto.getWarehousingNo());
                break;
            case "YQ":
                //油漆
                MPJLambdaWrapper<PurchasePlanDetailsPaint> paintWrapper = new MPJLambdaWrapper<>();
                paintWrapper.selectAll(PurchasePlanDetailsPaint.class)
                        .isNotNull(PurchasePlanDetailsPaint::getPurchasePlanId)
                        .eq(!CommonUtil.isNull(warehousingNo),PurchasePlanDetailsPaint::getWarehousingNo,warehousingNo);
                PurchasePlanDetailsPaint purchasePlanDetailsPaint = purchasePlanDetailsPaintMapper.selectOne(paintWrapper);
                if (CommonUtil.isNull(purchasePlanDetailsPaint)){
                    throw new RuntimeException("不存在该入库编号");
                }
                purchasePlanDetailVO = BeanUtil.copy(purchasePlanDetailsPaint, PurchasePlanDetailVO.class);
                PurchasePlan purchasePlanPaint = purchasePlanMapper.selectById(purchasePlanDetailVO.getPurchasePlanId());
                purchasePlanDetailVO.setAscriptionText(purchasePlanPaint.getProjectName());
                purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,purchasePlanDetailVO.getMaterialType()));
                purchasePlanDetailVO.setContractListId(purchasePlanPaint.getContractListId());
                initQualityNotInStock(purchasePlanDetailVO,dto.getWarehousingNo());
                break;
            default:
                //产品
                MPJLambdaWrapper<PurchasePlanDetailsProductTotal> totalMPJLambdaWrapper = new MPJLambdaWrapper<>();
                totalMPJLambdaWrapper.selectAll(PurchasePlanDetailsProductTotal.class)
                        .isNotNull(PurchasePlanDetailsProductTotal::getPurchasePlanId)
                        .eq(!CommonUtil.isNull(warehousingNo),PurchasePlanDetailsProductTotal::getWarehousingNo,warehousingNo);
                PurchasePlanDetailsProductTotal productTotal = purchasePlanDetailsProductTotalMapper.selectOne(totalMPJLambdaWrapper);
                if (CommonUtil.isNull(productTotal)){
                    throw new RuntimeException("不存在该入库编号");
                }
                purchasePlanDetailVO = BeanUtil.copy(productTotal, PurchasePlanDetailVO.class);
                PurchasePlan purchasePlan = purchasePlanMapper.selectById(purchasePlanDetailVO.getPurchasePlanId());
                purchasePlanDetailVO.setAscriptionText(purchasePlan.getProjectName());
                purchasePlanDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,purchasePlanDetailVO.getMaterialType()));
                //2023/02/20 扫码入库返回信息，合同编号
                purchasePlanDetailVO.setContractListId(purchasePlan.getContractListId());
                initQualityNotInStock(purchasePlanDetailVO,dto.getWarehousingNo());
                break;
        }
        return purchasePlanDetailVO;
    }
}
