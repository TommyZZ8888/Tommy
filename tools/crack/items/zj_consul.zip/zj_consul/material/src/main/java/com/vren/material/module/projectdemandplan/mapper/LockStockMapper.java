package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.projectdemandplan.domain.entity.LockStock;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface LockStockMapper extends MPJBaseMapper<LockStock> {
    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<LockStock> entities);

}
