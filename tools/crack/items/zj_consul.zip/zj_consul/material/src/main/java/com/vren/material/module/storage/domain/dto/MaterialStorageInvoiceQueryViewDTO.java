package com.vren.material.module.storage.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialStorageInvoiceQueryViewDTO {
    @NotBlank(message = "物资入库发票表ID不能为空")
    @ApiModelProperty("物资入库发票表ID")
    private String id;
}
