package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class ProjectInPurchasePlanVO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;
}
