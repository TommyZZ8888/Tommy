package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class UpdateProductDemanPlanDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("产品信息id")
    @NotBlank(message = "产品名称不能为空")
    private String productInformationId;

    @ApiModelProperty("计划编号")
    @NotBlank(message = "计划编号不能为空")
    private String scheduleNo;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("编制说明,按照文本换行")
    private String preparationDescription;


}
