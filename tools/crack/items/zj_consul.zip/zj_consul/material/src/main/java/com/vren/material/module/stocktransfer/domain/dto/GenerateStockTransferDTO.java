package com.vren.material.module.stocktransfer.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class GenerateStockTransferDTO {

    @ApiModelProperty("调拨单编号")
    private String stockTransferNo;

    @ApiModelProperty("拨入单位")
    private String incomingCompany;

    @ApiModelProperty("拨出单位")
    private String transferOutCompany;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("批料")
    private String batch;

    @ApiModelProperty("发料")
    private String issue;

    @ApiModelProperty("记账")
    private String bookkeeping;

    @ApiModelProperty("收料")
    private String materialReceiving;

    @ApiModelProperty("调拨单详情列表")
    private List<StockTransferDetailDTO> stockTransferDetailDTOS;


}
