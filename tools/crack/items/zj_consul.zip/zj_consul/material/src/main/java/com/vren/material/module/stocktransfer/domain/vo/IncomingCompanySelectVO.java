package com.vren.material.module.stocktransfer.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class IncomingCompanySelectVO {

    @ApiModelProperty("项目id")
    private String id;

    @ApiModelProperty("项目名称")
    private String projectName;

}
