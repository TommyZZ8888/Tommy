package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName("paint_demand_plan")
public class PaintDemandPlan {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("库存表ID")
    private String materialStockId;

    @ApiModelProperty("项目需求计划表id")
    private String projectDemandPlanId;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("颜色")
    private String colour;
    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;
    @ConversionNumber
    @ApiModelProperty("面积")
    private Long area;

    @ApiModelProperty("执行标准")
    private String executiveStandards;
    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("库存类型")
    private Integer stockType;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;
    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;

    /**
     * 采购计划模块
     */
    @ApiModelProperty("采购到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Integer purchaseNum;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;




}