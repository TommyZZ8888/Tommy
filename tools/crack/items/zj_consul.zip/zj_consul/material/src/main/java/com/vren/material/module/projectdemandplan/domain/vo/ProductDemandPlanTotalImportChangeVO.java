package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProductDemandPlanTotalImportChangeVO {
    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;

    private String partNo;

    private String materialName;

    @ApiModelProperty("规格")
    private String specification;

    private String texture;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long count;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long  weight;




    private String remarks;
}
