package com.vren.material.module.stockmanagement.domian.vo;

import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class StockStatusVO {
    private Integer code;
    private String name;
}
