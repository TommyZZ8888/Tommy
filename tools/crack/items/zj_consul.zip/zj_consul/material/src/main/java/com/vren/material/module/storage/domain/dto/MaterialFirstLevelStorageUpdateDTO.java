package com.vren.material.module.storage.domain.dto;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialFirstLevelStorageUpdateDTO {
    @ApiModelProperty("材料一级入库表id")
    private String id;
    @ApiModelProperty("合同编号")
    private String contractNo;
    @ApiModelProperty("合同清单id")
    private  String contractListId;
    @ApiModelProperty("归属(项目或设备名称)")
    private String ascription;
    @ApiModelProperty("项目表id")
    private String projectId;


    @ApiModelProperty("设备表id")
    private String deviceId;

    @ApiModelProperty("生产厂家")
    private String manufacturer;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("入库日期")
    private Date storageDate;
    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;


    @ConversionNumber
    @ApiModelProperty("金额")
    private  Long money;

    @ConversionNumber
    @ApiModelProperty("重量")
    private  Long weight;
    @ApiModelProperty("生产日期")
    private Date manufactureDate;


    @ApiModelProperty("有效期")
    private Date validityTerm;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("型号")
    private String model;
    @ApiModelProperty("面积")
    private String area;
    @ApiModelProperty("颜色")
    private String colour;


    @ConversionNumber
    @ApiModelProperty("税前单价")
    private Long  preTaxPrice;
    @ConversionNumber
    @ApiModelProperty("税额")
    private Long tax;

    @ApiModelProperty("入库状态(0,未入库 1,已入库)")
    private Integer warehousingState;

    @ApiModelProperty("入库方式 (0,手动录入 1 ,扫码录入)")
    private Integer warehousingMethod;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;
}
