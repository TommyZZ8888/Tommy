package com.vren.material.module.stocktransfer.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GetStockTransferDTO extends PageParam {

    @ApiModelProperty("拨入单位")
    private String incomingCompany;

    @ApiModelProperty("拨出单位")
    private String transferOutCompany;

}
