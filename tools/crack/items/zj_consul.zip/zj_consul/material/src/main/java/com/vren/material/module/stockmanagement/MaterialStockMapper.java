package com.vren.material.module.stockmanagement;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface MaterialStockMapper extends MPJBaseMapper<MaterialStock> {
    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<MaterialStock> entities);



}
