package com.vren.material.module.productmanagement.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 * 产品信息
 */
@Data
@Api
@TableName("product_information")
public class ProductInformation {

    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("项目表id")
    private String projectId;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("位号")
    private String tagNo;

    @ApiModelProperty("产品规格")
    private String productSpecificatons;

    @ApiModelProperty("总图号")
    private String totalFigureNo;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("容器类别")
    private String containerCategory;

    @ApiModelProperty("使用单位")
    private String useUnit;

    @ApiModelProperty("制造编号(生产编号)")
    private String manufacturingNumber;

    @ApiModelProperty("吨")
    @ConversionNumber
    private Long weight;

    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    private Integer isProductionScheduling;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    private Integer isProductionPlan;


    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date updateTime;


}