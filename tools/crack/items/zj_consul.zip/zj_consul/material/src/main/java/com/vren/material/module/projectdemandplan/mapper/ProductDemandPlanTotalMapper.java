package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.projectdemandplan.domain.entity.ProductDemandPlanTotal;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ProductDemandPlanTotalMapper extends MPJBaseMapper<ProductDemandPlanTotal> {

}
