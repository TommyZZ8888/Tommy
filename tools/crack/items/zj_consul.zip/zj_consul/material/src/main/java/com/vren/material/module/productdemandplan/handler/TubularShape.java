package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class TubularShape implements ComputerHandler{
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        if (CommonUtil.isNull(data.getFirstSize())||CommonUtil.isNull(data.getSecondSize())||CommonUtil.isNull(data.getThirdSize())){
            throw new RuntimeException(data.getMaterialName()+"的第一尺寸、第二尺寸和第三尺寸不能为空");
        }
        double result = Math.PI * (Math.pow(data.getFirstSize().doubleValue()/100, 2) - Math.pow((data.getFirstSize().doubleValue()/100 - 2 * data.getSecondSize().doubleValue()/100), 2)) / 4 * data.getThirdSize().doubleValue()/100 * data.getProportion().doubleValue()/100 / 1000000 * data.getCount().doubleValue()/100;
        String specification = "φ" + data.getFirstSize()/100 + "X" + data.getSecondSize()/100 + ",L=" + data.getThirdSize()/100;
        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
//        if (result<0){
//            throw new RuntimeException("您输入的尺寸有误（第一尺寸应该大于第二尺寸）！");
//        }
        productDemandPlanDetails.setWeight((long) (result*100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        String firstSize = specification.substring(specification.indexOf("φ")+1, specification.indexOf("X"));
        String secondSize = specification.substring(specification.indexOf("X")+1,specification.indexOf(","));
        String thirdSize = specification.substring(specification.indexOf("L")+1);
        vo.setFirstSizeExport(Double.parseDouble(firstSize));
        vo.setSecondSizeExport(Double.parseDouble(secondSize));
        vo.setThirdSizeExport(Double.parseDouble(thirdSize));
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        String firstSize = specification.substring(specification.indexOf("φ")+1, specification.indexOf("X"));
        String secondSize = specification.substring(specification.indexOf("X")+1,specification.indexOf(","));
        String thirdSize = specification.substring(specification.indexOf("L")+1);
        vo.setFirstSizeExport(Double.parseDouble(firstSize));
        vo.setSecondSizeExport(Double.parseDouble(secondSize));
        vo.setThirdSizeExport(Double.parseDouble(thirdSize));
    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        String width = specification.substring(specification.indexOf("φ")+1, specification.indexOf("X"));
        String thickness = specification.substring(specification.indexOf("X")+1,specification.indexOf(","));
        String length = specification.substring(specification.indexOf("L")+2);
        map.put("width", width);
        map.put("length", length);
        map.put("thickness", thickness);
        return map;
    }
}
