package com.vren.material.module.stockmanagement.domian.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class QueryStockDTO extends PageParam {

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("库存状态")
    private Integer stockStatus;

    @ApiModelProperty("入库时间-起始")
    private Date stockInTimeStart;

    @ApiModelProperty("入库时间-结束")
    private Date stockInTimeEnd;

}
