package com.vren.material.module.storage.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@TableName("material_storage_invoice_detail")
public class MaterialStorageInvoiceDetail {
 @ApiModelProperty("发票细节表")
 @TableId(type = IdType.ASSIGN_UUID)
  private String id;
 @ApiModelProperty("一级入库表id")
  private String materialFirstLevelStorageId;
  @ApiModelProperty("发票表id")
  private String materialStorageInvoiceId;

  @ApiModelProperty("数量")
  @ConversionNumber
  private Long count;



}
