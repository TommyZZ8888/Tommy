package com.vren.material.module.materialrenturn.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class EditReturnRecordDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("退库重量")
    @ConversionNumber
    private Long returnWeight;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("退库数量")
    @ConversionNumber
    private Long returnCount;

    @ApiModelProperty("执行标准（技术标准）")
    private String executiveStandards;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("创建时间（回库时间）")
    private Date createTime;


}
