package com.vren.material.module.productdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTypeEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface MaterialTypeMapper extends MPJBaseMapper<MaterialTypeEntity> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<MaterialTypeEntity> entities);
}
