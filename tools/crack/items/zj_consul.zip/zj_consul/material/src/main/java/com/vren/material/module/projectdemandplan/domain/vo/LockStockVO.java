package com.vren.material.module.projectdemandplan.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 *  展示锁库的情况
 */
@Data
public class LockStockVO {

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质（物资库存表）")
    private String texture;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("锁库数量")
    @ConversionNumber
    private Long lockStockNumber;

}
