package com.vren.material.module.productdemandplan.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class MaterialTextureVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("代号")
    private String code;

    @ApiModelProperty("材料")
    private String material;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;

}
