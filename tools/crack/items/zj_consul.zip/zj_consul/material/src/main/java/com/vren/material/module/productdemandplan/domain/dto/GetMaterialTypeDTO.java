package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class GetMaterialTypeDTO {

    @NotBlank(message = "产品信息id不能为空")
    @ApiModelProperty("产品信息id")
    private String productInformationId;

    @ApiModelProperty("批次")
    private String batch;

}
