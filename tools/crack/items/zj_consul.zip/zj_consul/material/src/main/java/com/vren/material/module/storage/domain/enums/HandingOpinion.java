package com.vren.material.module.storage.domain.enums;

public enum HandingOpinion {
    QUALIFIED(1,"合格"),
    UNQUALIFIED(2,"存在问题"),
    RETURN_GOODS(3,"退货"),
    CHANGE_PURPOSE (4,"更改用途");
    HandingOpinion  (Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;

}
