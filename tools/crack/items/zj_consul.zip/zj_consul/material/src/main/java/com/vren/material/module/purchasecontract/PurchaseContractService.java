package com.vren.material.module.purchasecontract;

import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelUtil;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.identity.user.domain.entity.UserInfoEntity;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.productmanagement.domain.dto.ProjectIdDTO;
import com.vren.material.module.projectdemandplan.ProjectDemandPlanService;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.purchasecontract.domain.dto.*;
import com.vren.material.module.purchasecontract.domain.entity.ContractList;
import com.vren.material.module.purchasecontract.domain.entity.PurchaseStatusRecord;
import com.vren.material.module.purchasecontract.domain.vo.*;
import com.vren.material.module.purchasecontract.mapper.ContractListMapper;
import com.vren.material.module.purchasecontract.mapper.PurchaseStatusRecordMapper;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsPaint;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsProductTotal;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsWeldingMaterials;
import com.vren.material.module.purchaseplan.domain.enums.ArrivalStatusEnum;
import com.vren.material.module.purchaseplan.domain.enums.PurchaseStateEnum;
import com.vren.material.module.purchaseplan.domain.vo.PurchasePlanDetailVO;
import com.vren.material.module.purchaseplan.domain.vo.SelectVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class PurchaseContractService {

    @Autowired
    private ContractListMapper contractListMapper;

    @Autowired
    private PurchasePlanService purchasePlanService;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private PurchaseStatusRecordMapper purchaseStatusRecordMapper;

    @Autowired
    private UserService userService;


    @Autowired
    private ProjectDemandPlanService projectDemandPlanService;

    /**
     * 生成采购合同清单，选择一个或多个项目  一个类型
     * @param dto
     */
    @Transactional(rollbackFor = Exception.class)
    public void generateContractList(GenerateContractListDTO dto) {
        //将projectId 拆分出来
        ArrayList<String> list = new ArrayList<>();
        dto.getProjectIds().forEach(
                item -> {
                    list.add(item.split("-")[0]);
                }
        );
        //判断采购计划中是否存在。根据项目id和物资类型，查询是否存在
        if (purchasePlanService.isExistPurchasePlan(list,dto.getMaterialType())){
            //判断采购计划那边对应的项目和物资类型下是否已经被关联到合同清单中
            if (purchasePlanService.isRelatedToContractList(list,dto.getMaterialType())){
                //生成合同清单
                ContractList contractList = new ContractList();
                contractList.setContractNo(dto.getContractNo());
                contractList.setContractName(dto.getContractName());
                contractList.setPurchaseName(dto.getPurchaseName());
                //2023/02/13 合同编号为空的时候，不需要重复校验，否则需要重复校验
                if (CommonUtil.isNull(dto.getContractNo())){
                    contractListMapper.insert(contractList);
                }else {
                    //合同编号重复校验
                    QueryWrapper<ContractList> wrapper = new QueryWrapper<>();
                    wrapper.select("1").eq("contract_no",dto.getContractNo()).last(" limit 1 ");
                    if (contractListMapper.selectCount(wrapper)>0){
                        throw new RuntimeException("合同编号不能重复");
                    }
                    contractListMapper.insert(contractList);
                }

                //将生成的合同清单id关联到采购计划下面
                purchasePlanService.updateContractList(list,dto.getMaterialType(),contractList.getId());

                /**
                 * 将关联后的采购计划详情  自动生成明细的入库编号，格式：R-物资类别（两位）-8+5位（年月日+随机）
                 */


            }
        }
    }

    public PageResult<ContractListVO>   getContractList(QueryContractListDTO dto) {
        Page<ContractListVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 查询合同清单表，同时查询关联了合同清单的采购计划表
         */
        //根据采购状态  查询所有的合同清单
        MPJLambdaWrapper<ContractList> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ContractList.class)
                .eq(!CommonUtil.isNull(dto.getPurchaseStatus()),ContractList::getPurchaseStatus,dto.getPurchaseStatus());
        List<ContractList> contractLists = contractListMapper.selectList(wrapper);
        //合同清单的id
        List<String> collect = contractLists.stream().map(ContractList::getId).collect(Collectors.toList());
        //采购计划
        List<PurchasePlan> purchasePlans = purchasePlanService.getPurchasePlanInContractList(collect,dto);
        List<PurchasePlanInContractListVO> list = BeanUtil.copyList(purchasePlans, PurchasePlanInContractListVO.class);
        //设置项目编号、到货类型
        list.stream().forEach( item -> {
            ProjectVO projectVO = projectService.getById(item.getProjectId());
            if (!CommonUtil.isNull(projectVO)){
                item.setProjectNo(projectVO.getProjectNo());
                item.setOwningFactory(projectVO.getProjectType());
            }
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,item.getMaterialType()));
            item.setArrivalStatusText(EnumUtil.getValue(ArrivalStatusEnum.class,item.getArrivalStatus()));
            //根据项目和物资类型查询需求编号
            List<String> partNo =  projectDemandPlanService.getPlanNo(item.getProjectId(),item.getMaterialTypeText());
            if (CommonUtil.listIsNotEmpty(partNo)){
                item.setDemandPlanNumber(StringUtils.join(partNo,","));
            }
        });
        Map<String, List<PurchasePlanInContractListVO>> map = list.stream().filter( item -> !CommonUtil.isNull(item.getContractListId())).collect(Collectors.groupingBy(PurchasePlanInContractListVO::getContractListId));
        ArrayList<ContractListVO> contractListVOS = new ArrayList<>();
        for (ContractList item :contractLists) {
            ContractListVO contractListVO = new ContractListVO();
            //设置采购类型
            contractListVO.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class,item.getPurchaseStatus()));
            //合同清单内容
            BeanUtil.copyProperties(item,contractListVO);
            if (!CommonUtil.isNull(map.get(item.getId()))){
                contractListVO.setData(map.get(item.getId()));
                contractListVOS.add(contractListVO);
            }
        }
        return PageUtil.convert2PageResult(contractListVOS,dto);
    }

    public void editContractList(EditContractListDTO dto) {
        ContractList contractList = BeanUtil.copy(dto, ContractList.class);
        Integer purchaseStatus  = contractListMapper.selectById(dto.getId()).getPurchaseStatus();
        //更新采购合同时，不填合同编号不需要校重，否则就要校验
        QueryWrapper<ContractList> queryWrapper = new QueryWrapper<>();
        if(!CommonUtil.isNull(dto.getContractNo())){
            queryWrapper.select("1").eq("contract_no",dto.getContractNo())
                    .notIn("id",dto.getId()).last(" limit 1 ");
            if (contractListMapper.selectCount(queryWrapper)>0){
                throw new RuntimeException("合同编号不能重复");
            }
            contractListMapper.updateById(contractList);
        }else {
            contractListMapper.updateById(contractList);
        }



        //如果采购状态更新，新增采购状态记录
        if (!CommonUtil.isNull(dto.getPurchaseStatus())){
            if (!dto.getPurchaseStatus().equals(purchaseStatus)){
                //采购状态变更了
                PurchaseStatusRecord purchaseStatusRecord = new PurchaseStatusRecord();
                purchaseStatusRecord.setContractListId(dto.getId());
                //操作人
//            log.info("用户id：{}",ThreadLocalUser.get().getUserId());
                purchaseStatusRecord.setOperator(ThreadLocalUser.get().getUserId());
                purchaseStatusRecord.setOperationTime(new Date());
                purchaseStatusRecord.setBeforeChange(purchaseStatus);
                purchaseStatusRecord.setAfterChange(dto.getPurchaseStatus());
                int insert = purchaseStatusRecordMapper.insert(purchaseStatusRecord);
                if (insert>0){
                    log.info("新增了一条采购状态操作记录");
                }
            }
        }
    }

    public ContractListVO getContractListById(GetOneOrDeleteDTO dto) {
        ContractList contractList = contractListMapper.selectById(dto.getId());
        ContractListVO contractListVO = BeanUtil.copy(contractList, ContractListVO.class);
        //设置采购状态
        contractListVO.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class,contractListVO.getPurchaseStatus()));
        return contractListVO;
    }

    public List<PurchaseStatusRecordVO> getPurchaseStatesRecord(GetPurchaseStatusRecordDTO dto) {
        /**
         * 根据合同清单id查询采购状态变化的记录情况
         * 根据操作时间排序
         */
        MPJLambdaWrapper<PurchaseStatusRecord> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchaseStatusRecord.class)
                .eq(!CommonUtil.isNull(dto.getContractListId()),PurchaseStatusRecord::getContractListId,dto.getContractListId())
                .orderByAsc(PurchaseStatusRecord::getOperationTime);
        List<PurchaseStatusRecord> purchaseStatusRecords = purchaseStatusRecordMapper.selectList(wrapper);
        List<PurchaseStatusRecordVO> purchaseStatusRecordVOS = BeanUtil.copyList(purchaseStatusRecords, PurchaseStatusRecordVO.class);
        purchaseStatusRecordVOS.stream().forEach( item -> {
            //设置操作人姓名
            UserInfoEntity userInfoByID = userService.getUserInfoByID(item.getOperator());
            if (!CommonUtil.isNull(userInfoByID)){
                item.setOperatorName(userInfoByID.getUserName());
            }
            //设置采购状态的名称
            item.setBeforeChangeText(EnumUtil.getValue(PurchaseStateEnum.class,item.getBeforeChange()));
            item.setAfterChangeText(EnumUtil.getValue(PurchaseStateEnum.class,item.getAfterChange()));
        });
        return purchaseStatusRecordVOS;
    }

    public void deleteRelationContractList(GetOneOrDeleteDTO dto) {
        /**
         * 将采购计划关联的ContractListId更新为null
         */
        //如果合同清单下面关联的采购计划为空，则删除该合同清单
        //查询关联的合同清单id
        String contractListId = purchasePlanService.selectContractListById(dto.getId());
        purchasePlanService.updateRelationContractList(dto.getId());
        if (contractListId!=null){
            //查询这个合同清单下是否还存在关联的采购计划
            if (!purchasePlanService.isExistRelateToContractList(contractListId)){
                //删除合同清单
                contractListMapper.deleteById(contractListId);
            }
        }
    }

    public void deleteContractList(GetOneOrDeleteDTO dto) {
        /**
         * 删除合同清单，同时更新与之关联的采购计划
         */
        int result = contractListMapper.deleteById(dto.getId());
        if (result>0){
            purchasePlanService.updateByContractListId(dto.getId());
        }
    }


    public List<ProjectIdAndNameVO> getProjectIdAndNameInContract(GetOneOrDeleteDTO dto){
        return purchasePlanService.getProjectIdAndNameInContract(dto.getId());
    }

    public List<SelectVO> getMaterialTypeByProjectId(ProjectIdDTO dto) {
        return purchasePlanService.getMaterialTypeByProjectId(dto.getProjectId());
    }

    public List<PurchasePlanDetailVO> getPurchasePlanDetail(PurchasePlanDetailDTO dto) {
        return purchasePlanService.getPurchasePlanDetail(dto.getProjectId(),dto.getMaterialType());
    }

    public List<PurchasePlanNumberInSelectVO> getPurchasePlanNumberInSelect(PurchasePlanNumberInSelectDTO dto) {
        //根据选择的项目和物资类型查询采购计划编号   purchasePlanNumber
        List<String> list = purchasePlanService.getPurchasePlanNumberInSelect(dto.getProjectIds(),dto.getMaterialType());
        ArrayList<PurchasePlanNumberInSelectVO> vos = new ArrayList<>();
        for (String purchasePlanNumber:list) {
            PurchasePlanNumberInSelectVO build = PurchasePlanNumberInSelectVO.builder().purchasePlanNumber(purchasePlanNumber).build();
            vos.add(build);
        }
        return vos;
    }

    public List<ContractNoAndIdVO> getContractNoAndId() {
        List<ContractList> contractLists = contractListMapper.selectList(null);
        List<ContractNoAndIdVO> contractNoAndIdVOS = BeanUtil.copyList(contractLists, ContractNoAndIdVO.class);
        return contractNoAndIdVOS;
    }

    public List<ProjectInPurchasePlanVO> getProjectInPurchasePlan() {
        return purchasePlanService.getProjectInPurchasePlan();
    }

    public void export(HttpServletResponse response,ExportDTO dto) {
        if (dto.getMaterialType().equals(MaterialType.PAINT.getCode())){
            //使用油漆清单模板
            List<PurchasePlanDetailsPaint> paints = purchasePlanService.getPaint(dto.getContractListId(), dto.getProjectId(), dto.getBatch());
            List<ContractProductPaintExportVO> list = BeanUtil.copyList(paints, ContractProductPaintExportVO.class);
            AtomicInteger num = new AtomicInteger();
            list.forEach(item -> {
                item.setNumber(num.incrementAndGet());
                //数量倍数转换
                if (!CommonUtil.isNull(item.getPurchaseArea())){
                    item.setPurchaseAreaExport(item.getPurchaseArea().doubleValue() /100);
                }
                if (!CommonUtil.isNull(item.getDryFilmThickness())){
                    item.setDryFilmThicknessExport(item.getDryFilmThickness().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getAmountOfPaint())){
                    item.setAmountOfPaintExport(item.getAmountOfPaint().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getTheoreticalDosage())){
                    item.setTheoreticalDosageExport(item.getTheoreticalDosage().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getLossFactor())){
                    item.setLossFactorExport(item.getLossFactor().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getVolumeSolidContent())){
                    item.setVolumeSolidContentExport(item.getVolumeSolidContent().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getDensity())){
                    item.setDensityExport(item.getDensity().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getUnitPriceDiluentIncludingTax())){
                    item.setUnitPriceDiluentIncludingTaxExport(item.getUnitPriceDiluentIncludingTax().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getUnitPricePaintIncludingTax())){
                    item.setUnitPricePaintIncludingTaxExport(item.getUnitPricePaintIncludingTax().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getDilutionDose())){
                    item.setDilutionDoseExport(item.getDilutionDose().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getTotalUnitPriceIncludingTax())){
                    item.setTotalUnitPriceIncludingTaxExport(item.getTotalUnitPriceIncludingTax().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getTotalSquarePriceIncludingTax())){
                    item.setTotalSquarePriceIncludingTaxExport(item.getTotalSquarePriceIncludingTax().doubleValue()/100);
                }
                if (!CommonUtil.isNull(item.getTaxRate())){
                    item.setTaxRateExport(item.getTaxRate().doubleValue()/100);
                }
            });
            Long sum = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseArea())).mapToLong(ContractProductPaintExportVO::getPurchaseArea).sum();
            HashMap<String, Object> data = new HashMap<>();
            data.put("sum",sum);
            InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/paintList.xlsx");
            ExcelExportService exportService = new ExcelExportService("询价单", response, resourceAsStream);
            exportService.fill(new FillWrapper("list",list),"询价单");
            exportService.fill(data,"询价单");
            exportService.export();
        }else
        {
            List<ContractProductDetailsExportVO> list = null;
            //产品，使用清单模板
            //根据合同id，项目id 查询所有的产品采购详情
            if (dto.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())){
                List<PurchasePlanDetailsWeldingMaterials> weld = purchasePlanService.getWeld(dto.getContractListId(), dto.getProjectId(),dto.getBatch());
                list = BeanUtil.copyList(weld, ContractProductDetailsExportVO.class);
            }else {
                List<PurchasePlanDetailsProductTotal> productTotals = purchasePlanService.getProductTotal(dto.getContractListId(),dto.getProjectId(),dto.getBatch());
                list = BeanUtil.copyList(productTotals, ContractProductDetailsExportVO.class);
            }
            AtomicInteger num = new AtomicInteger();
            list.forEach( item -> {
                item.setNumber(num.incrementAndGet());
                //数量倍数转换
                //焊材采购重量
                if (!CommonUtil.isNull(item.getPurchaseWeight())){
                    item.setPurchaseWeightExport((item.getPurchaseWeight().doubleValue()/100));
                }
                if (!CommonUtil.isNull(item.getPurchaseAmount())){
                    item.setPurchaseAmount(item.getPurchaseAmount()/100);
                }
                if (dto.getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())){
                }else {
                    //用料类型
                    //解析长度、宽度与厚度
                    if (!CommonUtil.isNull(item.getIngredientsType())){
                        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                        Class<? extends ComputerHandler> clazz = computerType.getClazz();
                        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                        Map<String, String> map = bean.analysis(item.getSize(), item.getIngredientsType());
                        if (!CommonUtil.isNull(map)){
                            String thickness = CommonUtil.isNull(map.get("thickness")) ? null : map.get("thickness");
                            String length = CommonUtil.isNull(map.get("length")) ? null : map.get("length");
                            String width = CommonUtil.isNull(map.get("width")) ? null : map.get("width");
                            item.setThickness(thickness);
                            item.setLength(length);
                            item.setWidth(width);
                        }
                    }
                }
                //几个金额倍率转换
                if (!CommonUtil.isNull(item.getPreTaxPrice())){
                    item.setPreTaxPrice(item.getPreTaxPrice()/100);
                }
                if (!CommonUtil.isNull(item.getUnitPriceWithTax())){
                    item.setUnitPriceWithTax(item.getUnitPriceWithTax()/100);
                }
                if (!CommonUtil.isNull(item.getTotalPriceExcludingTax())){
                    item.setTotalPriceExcludingTax(item.getTotalPriceExcludingTax()/100);
                }
                if (!CommonUtil.isNull(item.getTotalPriceIncludingTax())){
                    item.setTotalPriceIncludingTax(item.getTotalPriceIncludingTax()/100);
                }
            });
            //计算数量总和
            int sum = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseAmount())).mapToInt(ContractProductDetailsExportVO::getPurchaseAmount).sum();
            //计算重量总和
            Double sumWeight = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseWeight())).mapToDouble(ContractProductDetailsExportVO::getPurchaseWeightExport).sum();
            HashMap<String, Object> data = new HashMap<>();
            data.put("sum",sum);
            data.put("sumWeight",sumWeight);
            InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/detailedList.xlsx");
            ExcelExportService exportService = new ExcelExportService("清单", response, resourceAsStream);
            exportService.fill(new FillWrapper("list",list),"清单");
            exportService.fill(data,"清单");
            exportService.export();
        }



    }


    public void productTotalImport(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        LinkedList<ContractProductDetailsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ContractProductDetailsImportVO.class, "清单");
        file.getInputStream().close();
        for (int i = 0; i < 1; i++) {
            list.poll();
        }
        list.removeLast();
        List<PurchasePlanDetailsProductTotal> productTotals = BeanUtil.copyList(list, PurchasePlanDetailsProductTotal.class);
        purchasePlanService.batchUpdateProductTotal(productTotals);
    }

    public void weldImport(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        LinkedList<ContractProductDetailsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ContractProductDetailsImportVO.class, "清单");
        file.getInputStream().close();
        for (int i = 0; i < 1; i++) {
            list.poll();
        }
        list.removeLast();
        List<PurchasePlanDetailsWeldingMaterials> welds = BeanUtil.copyList(list, PurchasePlanDetailsWeldingMaterials.class);
        purchasePlanService.batchUpdateWeld(welds);
    }

    public void paintImport(MultipartFile file) throws IOException {
        LinkedList<ContractProductPaintImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ContractProductPaintImportVO.class, "询价单");
        file.getInputStream().close();
        list.removeLast();
        List<PurchasePlanDetailsPaint> paints = BeanUtil.copyList(list, PurchasePlanDetailsPaint.class);
        paints.forEach( item -> {
            //根据模板文件进行计算
            //油漆用量
            if (!CommonUtil.isNull(item.getDryFilmThickness())&&!CommonUtil.isNull(item.getVolumeSolidContent())&&!CommonUtil.isNull(item.getDensity())){
                double theoreticalDosage = ((item.getDryFilmThickness().doubleValue()/100)/1000/(item.getVolumeSolidContent().doubleValue()/100))*(item.getDensity().doubleValue()/100);
                if (!CommonUtil.isNull(item.getPurchaseArea())&&!CommonUtil.isNull(item.getLossFactor())){
                    double amountOfPaint = (item.getPurchaseArea().doubleValue()/100)*theoreticalDosage*(item.getLossFactor().doubleValue()/100);
                    double dilutionDose = amountOfPaint*25;
                    if (!CommonUtil.isNull(item.getUnitPricePaintIncludingTax())){
                        double totalUnitPriceIncludingTax = (amountOfPaint*(item.getUnitPricePaintIncludingTax().doubleValue()/100))/(item.getPurchaseArea().doubleValue()/100);
                        double totalSquarePriceIncludingTax = amountOfPaint*(item.getUnitPricePaintIncludingTax().doubleValue()/100);
                        item.setTotalUnitPriceIncludingTax((long) (totalUnitPriceIncludingTax*100));
                        item.setTotalSquarePriceIncludingTax((long) (totalSquarePriceIncludingTax*100));
                    }
                    item.setDilutionDose((long) (dilutionDose*100));
                    item.setAmountOfPaint((long) (amountOfPaint*100));
                }
                item.setTheoreticalDosage((long) (theoreticalDosage*100));
            }
        });
        purchasePlanService.batchUpdatePaint(paints);
    }

    public void importPurchaseContractDetail(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        switch (EnumUtil.getEnumByCode(MaterialType.class,dto.getMaterialType())){
            case WELDING_MATERIALS:
                //焊材
                weldImport(file,dto);
                break;
            case PAINT:
                //油漆
                paintImport(file);
                break;
            default:
                productTotalImport(file,dto);
                break;
        }

    }
}
