package com.vren.material.module.stocktransfer.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class StockTransferDetailVO {

    @ApiModelProperty("调拨单编号")
    private String stockTransferNo;

    @ApiModelProperty("拨入单位")
    private String incomingCompany;

    @ApiModelProperty("拨入单位")
    private String incomingCompanyText;

    @ApiModelProperty("拨出单位")
    private String transferOutCompany;

    @ApiModelProperty("拨出单位")
    private String transferOutCompanyText;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("调拨单id")
    private String stockTransferId;

    @ApiModelProperty("料具名称")
    private String materialName;

    @ApiModelProperty("规格与型号")
    private String specificationAndModel;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("实拨数量")
    @ConversionNumber
    private Long actualAllocatedQuantity;

    @ApiModelProperty("单价")
    @ConversionNumber
    private Long unitPrice;

    @ApiModelProperty("金额")
    @ConversionNumber
    private Long money;

    @ApiModelProperty("拨入单位所属厂区")
    private String owningFactory;

}
