package com.vren.material.module.productmanagement.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductAndDemandVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("所有批次数量总和")
    @ConversionNumber
    private Long sum;

    @ApiModelProperty("产品数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("尚未生成批次的数量")
    @ConversionNumber
    private Long count;
}
