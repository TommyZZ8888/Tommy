package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class DeletePurchasePlaDetailDTO {

    @ApiModelProperty("采购计划详情id")
    @NotBlank(message = "id不能为空")
    private String id;

    @ApiModelProperty("物资类型")
    @NotBlank(message = "物资类型不能为空")
    private Integer materialType;

}
