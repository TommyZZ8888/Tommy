package com.vren.material.module.productmanagement;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.common.module.product.ProductService;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.quality.QualityService;
import com.vren.common.module.quality.domain.dto.ProductQualityDTO;
import com.vren.material.common.enums.ContainerType;
import com.vren.material.module.productdemandplan.ProductDemandPlanService;
import com.vren.material.module.productmanagement.domain.dto.*;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.productmanagement.domain.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProductManageService {

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProductInformationMapper productInformationMapper;

    @Autowired
    private ProductDemandPlanService productDemandPlanService;

    @Autowired
    private ProductService productService;

    @Autowired
    private QualityService qualityService;

    public List<String> getContainerType() {
        ArrayList<String> list = new ArrayList<>();
        for (ContainerType item : ContainerType.values()) {
            list.add(item.getName());
        }
        return  list;
    }

    public PageResult<ProductInformationVO> getProductInformation(ProductInformationDTO dto) {
        Page<ProductInformationVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 根据查询条件查询产品信息
         */
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .eq(!CommonUtil.isNull(dto.getProjectName()),ProductInformation::getProjectId,dto.getProjectName())
                .like(!CommonUtil.isNull(dto.getUseUnit()),ProductInformation::getUseUnit,dto.getUseUnit())
                .like(!CommonUtil.isNull(dto.getTagNo()),ProductInformation::getTagNo,dto.getTagNo())
                .like(!CommonUtil.isNull(dto.getManufacturingNumber()),ProductInformation::getManufacturingNumber,dto.getManufacturingNumber())
                .like(!CommonUtil.isNull(dto.getTotalFigureNo()),ProductInformation::getTotalFigureNo,dto.getTotalFigureNo())
                .orderByDesc(ProductInformation::getCreateTime);
        if (!CommonUtil.isNull(dto.getProductName())){
            //拼接的产品名称分离出来
            int start = dto.getProductName().indexOf("【");
            int end = dto.getProductName().indexOf("】");
            String substring = dto.getProductName().substring(start + 1, end);
            wrapper.eq(ProductInformation::getProductName,substring);
        }
        IPage<ProductInformationVO> productInformationVOIPage = productInformationMapper.selectJoinPage(page, ProductInformationVO.class, wrapper);
        productInformationVOIPage.getRecords().stream().forEach(item -> {
            //通过projectId，给项目名称赋值
           item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
        });
        return PageUtil.convert2PageResult(productInformationVOIPage);
    }

    public List<ProjectVO> getProjectOutline() {
       return BeanUtil.copyList(projectService.getOutline(), ProjectVO.class);
    }

    public void batchDeleteProduct(BatchDeleteDTO dto) {
        List<String> list = dto.getIds();
        productInformationMapper.deleteBatchIds(list);
        //删除产品的同时，删除对应的 产品需求计划 和 产品需求计划详情 的数据
        productDemandPlanService.batchDeleteProductDemandPlan(list);
        productDemandPlanService.batchDeleteProductDemandPlanDetails(list);
        //删除产品需求对应的材料说明
        productDemandPlanService.batchDeleteMaterialType(list);
    }

    public void addOrEditProduct(UpdateProductDTO dto) {
        ProductInformation productInformation = BeanUtil.copy(dto, ProductInformation.class);
        QueryWrapper<ProductInformation> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(dto.getProductName()),"product_name",dto.getProductName())
                .last("limit 1");

        QueryWrapper<ProductInformation> queryWrapperCopy = new QueryWrapper<>();
        queryWrapperCopy.select("1")
                .eq(!CommonUtil.isNull(dto.getManufacturingNumber()),"manufacturing_number",dto.getManufacturingNumber())
                .last("limit 1");
        Long nameCount = productInformationMapper.selectCount(queryWrapper);
        Long numberCountCount = productInformationMapper.selectCount(queryWrapperCopy);

        if (CommonUtil.isNull(dto.getId())){
            if (nameCount>0||numberCountCount>0){
                throw new RuntimeException("产品名称或者制造编号重复");
            }
            //新增
            productInformationMapper.insert(productInformation);
            //在物资类型表中创建五种类型对应的数据，材料说明的时候会展示

        }else {
            ProductInformationVO productInformationDetail = getProductInformationDetail(dto.getId());
            if (productInformationDetail.getProductName().equals(dto.getProductName())&&productInformationDetail.getManufacturingNumber().equals(dto.getManufacturingNumber())){
                //产品名称和制造编号没有修改
                productInformationMapper.updateById(productInformation);
            } else if (productInformationDetail.getProductName().equals(dto.getProductName())&&(!productInformationDetail.getManufacturingNumber().equals(dto.getManufacturingNumber()))){
                if (numberCountCount>0){
                    throw new RuntimeException("制造编号重复");
                }
                productInformationMapper.updateById(productInformation);
            } else if ((!productInformationDetail.getProductName().equals(dto.getProductName()))&&productInformationDetail.getManufacturingNumber().equals(dto.getManufacturingNumber())) {
                if (nameCount>0){
                    throw new RuntimeException("产品名称重复");
                }
                productInformationMapper.updateById(productInformation);
            }else {
                if (nameCount>0||numberCountCount>0){
                    throw new RuntimeException("产品名称或者制造编号重复");
                }
                productInformationMapper.updateById(productInformation);
            }
        }
    }

    /**
     *  查询产品id和产品名称，用于前端模糊
     * @return
     */
    public List<ProductOutlineVO> getProductOutline(){
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProductInformation::getId,ProductInformation::getProjectId,ProductInformation::getProductName,ProductInformation::getManufacturingNumber,ProductInformation::getContainerCategory);
        List<ProductInformation> productInformations = productInformationMapper.selectList(wrapper);
        ArrayList<ProductOutlineVO> productOutlineVOS = new ArrayList<>();
        productInformations.forEach(item -> {
            ProductOutlineVO productOutlineVO = new ProductOutlineVO();
            String value = item.getManufacturingNumber()+"【"+item.getProductName()+"】";
            productOutlineVO.setId(item.getId());
            productOutlineVO.setProjectId(item.getProjectId());
            productOutlineVO.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            productOutlineVO.setValue(value);
            productOutlineVO.setProductName(item.getProductName());
            productOutlineVO.setManufacturingNumber(item.getManufacturingNumber());
            productOutlineVO.setContainerCategory(item.getContainerCategory());
            productOutlineVOS.add(productOutlineVO);
        });
        return productOutlineVOS;
    }

    public ProductInformationVO getProductInformationDetail(String id) {
        ProductInformation productInformation = productInformationMapper.selectById(id);
        return BeanUtil.copy(productInformation,ProductInformationVO.class);
    }

    /**
     *  根据项目id查询所有的产品id
     * @param projectId
     * @return
     */
    public List<String> getProductIdByProjectId(String projectId){
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProductInformation::getId)
                .eq(ProductInformation::getProjectId,projectId);
        List<ProductInformation> productInformation = productInformationMapper.selectList(wrapper);
        ArrayList<String> list = new ArrayList<>();
        productInformation.forEach(item -> {
            list.add(item.getId());
        });
        return list;
    }

    public List<ProductAndDemandVO> getProductAndDemand(){
        return productInformationMapper.getProductAndDemand();
    }

    public List<ProductAndDemandVO> getProductOutlineWithDemand() {
        //查询所有没有关联产品需求计划的产品id
        //所有被关联的产品信息表id
        //2023/03/01  多个批次 数量总和小于 产品数量
        List<ProductAndDemandVO> productAndDemand = productInformationMapper.getProductAndDemand();
        //过滤 批次总数  小数  产品数量
        List<ProductAndDemandVO> collect = productAndDemand.stream().filter(o -> o.getSum() < o.getNumber()).collect(Collectors.toList());
        collect.forEach(p -> p.setCount(p.getNumber()-p.getSum()));
        return collect;
    }

    public List<ProductInformationVO> selectByKeyIds(IdsDTO dto) {
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .in(ProductInformation::getId,dto.getKeyIds());
        List<ProductInformation> productInformation = productInformationMapper.selectList(wrapper);
        List<ProductInformationVO> productInformationVOS = BeanUtil.copyList(productInformation, ProductInformationVO.class);
        productInformationVOS.forEach( item -> {
            item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
        });
        return productInformationVOS;
    }

    public Boolean changeProductScheduling(ProductSchedulingDTO dto) {
        UpdateWrapper<ProductInformation> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(dto.getId()),"id",dto.getId())
                .set(!CommonUtil.isNull(dto.getCode()),"is_production_scheduling",dto.getCode());
        int update = productInformationMapper.update(new ProductInformation(), wrapper);
        if (update>0){
            //根据产品id查询产品
            ProductInformation productInformation = productInformationMapper.selectById(dto.getId());
            //调用质量那边的接口，新增一条产品质量记录的信息
            ProductQualityDTO productQualityDTO = new ProductQualityDTO();
            productQualityDTO.setProjectId(productInformation.getProjectId());
            productQualityDTO.setProductId(productInformation.getId());
            Boolean quality = qualityService.insertProductQuality(productQualityDTO);
            if (quality){
                log.info("新增了一条产品质量质检记录");
            }
        }
        return  update > 0;
    }

    public List<ProductInformationVO> getProductNotProductionPlan() {
        /**
         * 查询所有处于未生产状态的产品信息
         */
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .eq(ProductInformation::getIsProductionPlan,0)
                .orderByDesc(ProductInformation::getCreateTime);
        List<ProductInformation> productInformation = productInformationMapper.selectList(wrapper);
        return BeanUtil.copyList(productInformation,ProductInformationVO.class);
    }

    /**
     *  根据产品id生成生产计划（调用产品模块的接口），产品计划生成成功后，更改产品里面的生产状态
     * @param dto   参数
     * @return 创建成功：true  失败：false
     */
    public ResponseResult<Boolean> createProductPlan(CreateProductPlanDTO dto) {
        //根据产品id查询产品信息
        ProductInformation productInformation = productInformationMapper.selectById(dto.getId());
        if (CommonUtil.isNull(productInformation)){
            throw new RuntimeException("该产品不存在");
        }
        //生成生产计划的DTO
        ProductPlanCreateDTO productPlanCreateDTO = new ProductPlanCreateDTO();
        //生产计划关联到项目下面
        productPlanCreateDTO.setProjectKeyId(productInformation.getId());
        productPlanCreateDTO.setManufacturingNumber(productInformation.getManufacturingNumber());
        productPlanCreateDTO.setTagNo(productInformation.getTagNo());
        productPlanCreateDTO.setContainerCategory(productInformation.getContainerCategory());
        productPlanCreateDTO.setProductName(productInformation.getProductName());
        productPlanCreateDTO.setProductSpecificatons(productInformation.getProductSpecificatons());
        //主要材质：先暂时不考虑
        productPlanCreateDTO.setMainMaterial(null);
        productPlanCreateDTO.setQuantity((int) (productInformation.getNumber()/100));
        productPlanCreateDTO.setWeight(Double.valueOf(productInformation.getWeight()));
        //用户：就是使用单位
        productPlanCreateDTO.setCustomer(productInformation.getUseUnit());
        //调用产品模块的创建生产计划的接口
        ResponseResult<Boolean> productPlan = productService.createProductPlan(productPlanCreateDTO);
        if (productPlan.getData()){
            //创建生产计划的成功，更新产品对应的产品生产状态
            UpdateWrapper<ProductInformation> wrapper = new UpdateWrapper<>();
            wrapper.eq("id",dto.getId())
                    .set("is_production_plan",1);
            if (productInformationMapper.update(new ProductInformation(), wrapper)>0){
                return ResponseResult.success("操作成功",true);
            }
        }else {
            return productPlan;
        }
        return ResponseResult.error("创建生产计划失败",false);
    }

    /**
     *  查询处于排产状态的产品
     * @return
     */
    public List<ProductInformationVO> getProductInProductionScheduling() {
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .eq(ProductInformation::getIsProductionScheduling,1)
                .orderByDesc(ProductInformation::getCreateTime);
        List<ProductInformation> productInformations = productInformationMapper.selectList(wrapper);
        return BeanUtil.copyList(productInformations,ProductInformationVO.class);
    }

    public ProductInformationVO getProductInformationByName(com.vren.common.module.material.dto.QueryProductDTO dto) {
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .eq(!CommonUtil.isNull(dto.getId()),ProductInformation::getId,dto.getId())
                .like(!CommonUtil.isNull(dto.getProductName()),ProductInformation::getProductName,dto.getProductName())
                .like(!CommonUtil.isNull(dto.getManufacturingNumber()),ProductInformation::getManufacturingNumber,dto.getManufacturingNumber());
        ProductInformation productInformation = productInformationMapper.selectOne(wrapper);
        return BeanUtil.copy(productInformation,ProductInformationVO.class);
    }

    public List<ProductByProjectIdVO> getProductByProjectId(ProjectIdDTO dto) {
        MPJLambdaWrapper<ProductInformation> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductInformation.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()),ProductInformation::getProjectId,dto.getProjectId());
        List<ProductInformation> productInformations = productInformationMapper.selectList(wrapper);
        return BeanUtil.copyList(productInformations,ProductByProjectIdVO.class);
    }

    public boolean changeProductPlan(DeleteOrGetOneDTO dto) {
        UpdateWrapper<ProductInformation> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("is_production_plan",0)
                .eq("id",dto.getId());
        return productInformationMapper.update(new ProductInformation(),updateWrapper) > 0;
    }

    public Boolean canDeleteProject(String id) {
        QueryWrapper<ProductInformation> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq("project_id",id)
                .last(" limit 1 ");
        return productInformationMapper.selectCount(queryWrapper)>0;
    }

    public ProductInformation getById(String productInformationId) {
        return productInformationMapper.selectById(productInformationId);
    }
}
