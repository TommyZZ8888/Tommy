package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Api
@TableName("material_type_description")
public class MaterialTypeDescription {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;

    @ApiModelProperty("备注")
    private String remarks;
    @ApiModelProperty("项目id")
    private String projectId;
}