package com.vren.material.module.materialcheckout.domain.vo;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialCheckoutRecordVO {
    @ApiModelProperty("出库记录表id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("项目名称")
    private String projectName;
    @ApiModelProperty("领料单表格编号")
    private String pickingFromNo;

    @ApiModelProperty("限额领料计划编号")
    private String quotaPickingPlanNo;

    @ApiModelProperty("领料单编号")
    private String materialRequisitionNo;

    @ApiModelProperty("拨出单位")
    private String spareUnit;

    @ApiModelProperty("领用部门")
    private String requisitionDepartment;

    @ApiModelProperty("领用时间")
    private Date requisitionTime;

    @ApiModelProperty("出库时间")
    private Date checkoutTime;

    @ApiModelProperty("编制人")
    private String compile;

    @ApiModelProperty("审核人")
    private String checker;

    @ApiModelProperty("审批人")
    private String approver;

    @ApiModelProperty("发料人")
    private String issuedBy;

    @ApiModelProperty("领料人")
    private String picker;

    @ApiModelProperty("发起人")
    private String sponsor;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("验收单编号")
    private String acceptanceCertificateNo;

    @ApiModelProperty("一般计税 0 简易计税 1 ")
    private Integer taxMethod;

    @ApiModelProperty("一般计税 0 简易计税 1 ")
    private String taxMethodText;
    @ApiModelProperty("是否超额领料")
    private Boolean excessIssue;

    @ApiModelProperty("是否已经出库")
    private boolean isCheckOut;


}
