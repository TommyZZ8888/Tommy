package com.vren.material.module.storage.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialEasyVO {
    @ApiModelProperty("一级入库表id")
    private  String id;
    @ApiModelProperty("材料名称")
    private String materialName;
}
