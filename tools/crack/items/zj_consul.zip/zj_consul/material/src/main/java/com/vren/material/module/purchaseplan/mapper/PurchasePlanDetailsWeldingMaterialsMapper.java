package com.vren.material.module.purchaseplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsWeldingMaterials;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface PurchasePlanDetailsWeldingMaterialsMapper extends MPJBaseMapper<PurchasePlanDetailsWeldingMaterials> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<PurchasePlanDetailsWeldingMaterials> entities);

}
