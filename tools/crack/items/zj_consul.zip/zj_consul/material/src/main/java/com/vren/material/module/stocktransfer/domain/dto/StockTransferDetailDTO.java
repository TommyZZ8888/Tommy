package com.vren.material.module.stocktransfer.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class StockTransferDetailDTO {

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("料具名称")
    private String materialName;

    @ApiModelProperty("规格与型号")
    private String specificationAndModel;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("实拨数量")
    @ConversionNumber
    private Long actualAllocatedQuantity;

    @ApiModelProperty("单价")
    @ConversionNumber
    private Long unitPrice;

    @ApiModelProperty("金额")
    @ConversionNumber
    private Long money;

}
