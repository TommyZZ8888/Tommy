package com.vren.material.module.storage.domain.enums;

public enum WarehousingMaterialType {
    BOARD(1,"板材"),
    PROFILE(2,"型材"),
    FORGE_PIECE(3,"锻件"),
    PURCHASED_PARTS(4,"外购件"),
    AUXILIARY_MATERIALS(5,"辅材"),
    WELDING_MATERIALS(6,"焊材"),
    PAINT(7,"油漆"),
    SPARE_PART(8,"备件");

    WarehousingMaterialType(Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
