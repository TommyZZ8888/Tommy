package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class PurchasePlanNumberInSelectVO {

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

}
