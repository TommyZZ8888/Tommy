package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class LockStockMoreDTO {

    @ApiModelProperty("锁库数据")
    private List<LockStockDTO> list;


}
