package com.vren.material.module.storage.domain.enums;

public enum WarehousingState {
    UNWAREHOUSING(0,"未入库"),
    WAREHOUSING(1,"已入库"),
    RETURN_GOODS(2,"已退货");
    WarehousingState  (Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
