package com.vren.material.module.stocktransfer.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.stocktransfer.domain.entity.StockTransferDetail;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface StockTransferDetailMapper extends MPJBaseMapper<StockTransferDetail> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<StockTransferDetail> entities);

}
