package com.vren.material.module.productdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 * 物资类型下拉框
 */
@Data
public class MaterialTypeVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("用料单位")
    private String materialUnit;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("产品信息id")
    private String productInformationId;

}
