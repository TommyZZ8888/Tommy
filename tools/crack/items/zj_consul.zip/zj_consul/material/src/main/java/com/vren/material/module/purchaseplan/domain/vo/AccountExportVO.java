package com.vren.material.module.purchaseplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  采购计划台账导出vo
 */
@Data
public class AccountExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("序号")
    private Integer serialNo;

    @ExcelProperty("项目需求计划编号")
    @ApiModelProperty("项目需求计划编号")
    private String planNo;

    @ExcelProperty("单位名称")
    @ApiModelProperty("单位名称（中建五洲工程装备有限公司）")
    private String unitName;

    @ExcelIgnore
    @ApiModelProperty("项目id")
    private String projectId;

    @ExcelProperty("项目名称")
    @ApiModelProperty("项目名称")
    private String projectName;

    @ExcelIgnore
    @ApiModelProperty("物资类型code")
    private Integer materialType;

    @ExcelProperty("主要物资类别")
    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ExcelProperty("需求计划提交人")
    @ApiModelProperty("采购计划提交人")
    private String projectDemandPlanSubmitter;

    @ExcelProperty("需求计划接收人")
    @ApiModelProperty("需求计划接收人")
    private String projectDemandPlanReceiver;

    @ExcelProperty(value = "接收日期",converter = DateConverter.class)
    @ApiModelProperty("接收日期")
    private Date receiveTime;

    @ExcelProperty("采购计划编号")
    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ExcelProperty("采购计划提交人")
    @ApiModelProperty("采购计划提交人")
    private String purchasePlanSubmitter;

    @ExcelProperty(value = "提交日期",converter = DateConverter.class)
    @ApiModelProperty("提交日期")
    private Date submissionDate;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;

    @ExcelProperty("核减量")
    @ApiModelProperty("核减量")
    private String nuclearDecrement;

    @ExcelIgnore
    @ApiModelProperty("采购状态(1招标公告、2投标、3定标、4合同签订)")
    private Integer purchaseStatus;

    @ExcelProperty("采购状态")
    @ApiModelProperty("采购状态(1招标公告、2投标、3定标、4合同签订)")
    private String purchaseStatusText;

}
