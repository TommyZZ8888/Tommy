package com.vren.material.module.purchaseplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @author 耿让
 */
@Data
public class PurchasePlanDateVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目id-批次")
    private String projectIdAndBatch;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目编号")
    private String projectNo;

    @ApiModelProperty("客户名称")
    private String customerName;

    @ApiModelProperty("项目类型")
    private String projectType;

    @ApiModelProperty("项目所在省")
    private Integer province;

    @ApiModelProperty("项目所在省")
    private String provinceText;

    @ApiModelProperty("项目所在市")
    private Integer city;

    @ApiModelProperty("项目所在省")
    private String cityText;

    @ApiModelProperty("项目所在区")
    private Integer area;

    @ApiModelProperty("项目所在区")
    private String areaText;

    @ApiModelProperty("创建时间：拍讯")
    private Date createTime;

    @ApiModelProperty("采购计划")
    private List<PurchasePlanVO> purchasePlanVOS;

}
