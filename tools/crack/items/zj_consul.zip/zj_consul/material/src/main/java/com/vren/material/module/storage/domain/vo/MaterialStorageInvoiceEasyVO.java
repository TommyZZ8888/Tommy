package com.vren.material.module.storage.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialStorageInvoiceEasyVO {
    @ApiModelProperty("规格")
    private String specification;
    @ApiModelProperty("牌号")
    private  String brand;
    @ApiModelProperty("材料名称")
    private String materialName;
    @ApiModelProperty("材质")
    private String texture;
    @ConversionNumber
    @ApiModelProperty("细节表数量")
    private Long count;
}
