package com.vren.material.module.purchaseplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class QueryPurchasePlanDTO extends PageParam {

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("采购状态(1招标公告、2投标、3定标、4合同签订)")
    private Integer purchaseStatus;

    @ApiModelProperty("时间起始")
    private Date timeStart;

    @ApiModelProperty("时间结束")
    private Date timeEnd;

}
