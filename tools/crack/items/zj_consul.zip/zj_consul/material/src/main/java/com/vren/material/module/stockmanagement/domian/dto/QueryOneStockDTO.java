package com.vren.material.module.stockmanagement.domian.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class QueryOneStockDTO {

    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;
}
