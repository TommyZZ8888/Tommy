package com.vren.material.module.productdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class SelectVO {

    @ApiModelProperty("code")
    private Integer id;

    @ApiModelProperty("物资类型下拉框")
    private String materialType;

}
