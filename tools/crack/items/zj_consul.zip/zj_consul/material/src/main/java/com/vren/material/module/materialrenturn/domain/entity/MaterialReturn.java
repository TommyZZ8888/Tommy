package com.vren.material.module.materialrenturn.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
@TableName("material_return")
public class MaterialReturn {
    @ApiModelProperty("材料回库表id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("材料类型")
    private Integer materialType;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("生产公司")
    private String productionCompany;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("退库重量")
    private Long returnWeight;

    @ApiModelProperty("数量")
    private Long returnCount;

    @ApiModelProperty("执行标准（技术标准）")
    private String executiveStandards;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("面积")
    @ConversionNumber
    private Long area;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("创建时间")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty("更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    @ApiModelProperty("退库类型")
    private String returnType;



}
