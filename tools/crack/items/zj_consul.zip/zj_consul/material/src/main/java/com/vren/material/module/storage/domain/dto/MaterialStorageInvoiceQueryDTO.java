package com.vren.material.module.storage.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialStorageInvoiceQueryDTO extends PageParam {

    @ApiModelProperty("发票名称")
    private String invoiceName;

    @ApiModelProperty("发票编号")
    private String invoiceNo;
}
