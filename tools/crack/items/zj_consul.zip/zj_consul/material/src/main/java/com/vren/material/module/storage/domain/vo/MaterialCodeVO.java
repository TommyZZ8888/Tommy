package com.vren.material.module.storage.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/**通过合同编号筛选
 * 材料名称和编号组成的下拉框
 * @author szp
 * @date 2022/12/6 11:03
 */
@Data
public class MaterialCodeVO {
    @ApiModelProperty("一级入库表id")
    private String id;
    @ApiModelProperty("材料名称和编号做区分用")
    private String materialCode;
}
