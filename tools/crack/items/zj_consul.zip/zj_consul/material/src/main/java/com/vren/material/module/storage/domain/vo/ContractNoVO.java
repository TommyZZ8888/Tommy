package com.vren.material.module.storage.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 *
 * @author szp
 * @date 2022/12/2 11:21
 */
@Data
public class ContractNoVO {
    @ApiModelProperty("合同清单表id")
    private String id;
    @ApiModelProperty("合同编号")
    private String  contractNo;
}
