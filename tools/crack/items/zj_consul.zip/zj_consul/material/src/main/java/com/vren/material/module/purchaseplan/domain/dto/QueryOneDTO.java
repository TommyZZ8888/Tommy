package com.vren.material.module.purchaseplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class QueryOneDTO extends PageParam {
    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

    @ApiModelProperty("材料名称(只有查询采购计划详情的时候才用到，其他时候忽略此字段)")
    private String materialName;

}
