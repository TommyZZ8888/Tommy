package com.vren.material.module.storage.domain.dto;

import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

@Data
public class BatchInsertMaterialFirstLevelStorageDTO {
    @Size(min=1,message = "数量不能小于0")
    private List<MaterialFirstLevelStorageSingleDto> list;
}
