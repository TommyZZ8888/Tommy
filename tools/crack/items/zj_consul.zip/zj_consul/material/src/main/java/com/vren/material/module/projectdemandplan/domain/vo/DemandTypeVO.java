package com.vren.material.module.projectdemandplan.domain.vo;


import lombok.Data;

@Data
public class DemandTypeVO {
    private String value;
    private Integer code;
}
