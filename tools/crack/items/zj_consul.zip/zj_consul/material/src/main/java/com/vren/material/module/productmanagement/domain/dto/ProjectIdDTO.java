package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProjectIdDTO {

    @ApiModelProperty("项目id")
    private String projectId;
}
