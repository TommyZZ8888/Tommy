package com.vren.material.module.purchaseplan.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 * 采购计划
 */
@TableName("purchase_plan")
@Data
public class PurchasePlan {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ApiModelProperty("采购状态(1招标公告、2投标、3定标、4合同签订)")
    private Integer purchaseStatus;

    @ApiModelProperty("计划类型(1总、2月度、3临时紧急物资采购计划)")
    private Integer scheduleType;

    @ApiModelProperty("表单编号")
    private String formNo;

    @ApiModelProperty("单位名称（中建五洲工程装备有限公司）")
    private String unitName;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("采购计划提交人")
    private String purchasePlanSubmitter;

    @ApiModelProperty("采购计划接收人")
    private String purchasePlanReceiver;

    @ApiModelProperty("采购计划编制人")
    private String purchasePlanCompiler;

    @ApiModelProperty("编制说明")
    private String preparationDescription;

    @ApiModelProperty("审核人")
    private String reviewer;

    @ApiModelProperty("审批人")
    private String approver;

    @ApiModelProperty("接收日期")
    private Date receiveTime;

    @ApiModelProperty("提交日期")
    private Date submissionDate;

    @ApiModelProperty("创建时间（台账需要）")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty("核减量")
    private String nuclearDecrement;

    @ApiModelProperty("采购日期")
    private Date purchaseDate;

    @ApiModelProperty("标书/认价价格")
    @ConversionNumber
    private Long proposalPrice;

    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long amountIncludingTax;

    @ApiModelProperty("市场含税单价")
    @ConversionNumber
    private Long marketUnitPriceIncludingTax;

    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long priceInTax;

    @ApiModelProperty("标书品牌")
    private String bidBrand;

    @ApiModelProperty("付款条件")
    private String paymentTerms;

    @ApiModelProperty("到货时间")
    private Date arrivalTime;

    @ApiModelProperty("到货地点")
    private String arrivalLocation;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("总重")
    @ConversionNumber
    private Long totalWeight;

    @ApiModelProperty("总数量")
    @ConversionNumber
    private Integer totalAmount;

    @ApiModelProperty("采购说明（富文本）")
    private String purchaseDescription;

    @ApiModelProperty("技术要求（富文本）")
    private String technicalRequirement;

    @ApiModelProperty("到货状态(1未到货、2部分到货、3已到货)")
    private Integer arrivalStatus;

    @ApiModelProperty("付款方式")
    private String paymentMethod;

    @ApiModelProperty("是否删除")
    @TableField(fill = FieldFill.INSERT)
    private Boolean isDeleted;


}