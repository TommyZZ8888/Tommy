package com.vren.material.module.storage.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialStorageInvoiceDetailVO {
    @ApiModelProperty("id")
    private String id;
    @ApiModelProperty("一级入库表id")
    private String materialFirstLevelStorageId;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ApiModelProperty("材质")
    private String texture;
    @ApiModelProperty("规格")
    private String specification;
    @ConversionNumber
    @ApiModelProperty("实际入库数量")
    private Long actualStockAmount;
}
