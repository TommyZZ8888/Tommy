package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class GetPurchaseStatusRecordDTO {

    @NotBlank(message = "合同清单id不能为空")
    @ApiModelProperty("合同清单id")
    private String contractListId;


}
