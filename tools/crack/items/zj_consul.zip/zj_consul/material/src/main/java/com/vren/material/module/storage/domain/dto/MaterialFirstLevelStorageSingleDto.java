package com.vren.material.module.storage.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialFirstLevelStorageSingleDto {

    @ApiModelProperty("合同清单id")
    private  String contractListId;
    @ApiModelProperty("归属(项目或设备类型)")
    private String ascription;
    /* vo加入字段 */
    @ApiModelProperty("归属")
    private String ascriptionText ;


    @ApiModelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("油漆——颜色")
    private String color;

    @ApiModelProperty("采购计划表ID,用来新增项目id")
    private String purchasePlanId;

    @ApiModelProperty("规格来源")
    private String size;
    @ApiModelProperty("用料单位")
    private String useMaterialUnit;
    @ApiModelProperty("产品——采购重量")
    @ConversionNumber
    private Long purchaseWeight;


/*  */

    @ApiModelProperty("项目表id")
    private String projectId;


    @ApiModelProperty("库存表id")
    private  String materialStockId;

    @ApiModelProperty("物资入库通知单表ID")
    private String materialStorageNoticeId;

    @ApiModelProperty("生产厂家")
    private String manufacturer;



    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("牌号")
    private  String brand;
    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("单价")
    private Long univalence;

    @ConversionNumber
    @ApiModelProperty("金额")
    private  Long money;

    @ConversionNumber
    @ApiModelProperty("重量")
    private  Long weight;

    @ApiModelProperty("生产日期")
    private Date manufactureDate;

    @ApiModelProperty("入库日期")
    private Date storageDate;

    @ApiModelProperty("有效期")
    private Date validityTerm;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("型号")
    private String model;
    @ApiModelProperty("面积")
    private String area;
    @ApiModelProperty("颜色")
    private String colour;

    @ConversionNumber
    @ApiModelProperty("实际入库数量")
    private Long actualStockAmount;

    @ConversionNumber
    @ApiModelProperty("税前单价")
    private Long  preTaxPrice;

    @ConversionNumber
    @ApiModelProperty("税额")
    private Long tax;

    @ApiModelProperty("入库状态(0,待入库 1,已入库,2 已退回)")
    private Integer warehousingState;

    @ApiModelProperty("入库方式 (0,手动录入 1 ,扫码录入)")
    private Integer warehousingMethod;
    @ApiModelProperty("发票入库 (0,否  1 是)")
    private Integer invoiceWarehousing;

    @ConversionNumber
    @ApiModelProperty("发票包含数量")
    private  Long invoiceQuantity;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;
}
