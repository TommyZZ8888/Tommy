package com.vren.material.module.storage.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
@TableName("material_storage_invoice")
public class MaterialStorageInvoice {
    @ApiModelProperty("物资入库发票id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("合同清单id")
    private  String contractListId;
    @ApiModelProperty("发票说明")
    private String invoiceDescription;
    @ApiModelProperty("发票名称")
    private String invoiceName;

    @ApiModelProperty("发票编号")
    private String invoiceNo;

    @ApiModelProperty("附件地址")
    private String attachmentPath;

}