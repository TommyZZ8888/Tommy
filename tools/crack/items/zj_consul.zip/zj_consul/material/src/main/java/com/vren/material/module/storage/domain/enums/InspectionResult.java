package com.vren.material.module.storage.domain.enums;

public enum InspectionResult {
    QUALIFIED(1,"合格"),
    EXISTING_PROBLEMS(2,"存在问题")
    ;
    InspectionResult (Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
