package com.vren.material.module.storage.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.storage.domain.entity.MaterialStorageInvoice;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MaterialStorageInvoiceMapper extends MPJBaseMapper<MaterialStorageInvoice> {


}
