package com.vren.material.module.materialcheckout.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 库存回显数据
 * @author szp
 * @date 2022/11/2 14:08
 */
@Data
public class MaterialCheckoutDataVO {

    private String id;

    @ApiModelProperty("项目表id")
    private String projectId;

    @ApiModelProperty("设备表id")
    private String deviceId;

    @ApiModelProperty("物资退库表ID")
    private String materialReturnId;

    @ApiModelProperty("物资入库表ID")
    private String materialStorageId;

    @ApiModelProperty("物资类型:1板材、2型材（型材、管材、棒材）、3辅材（五金等）、4外购件、5锻材、6焊材、7油漆、8备品/备件、9余料")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质（物资库存表）")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("重量")
    @ConversionNumber
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("库存余量")
    private Long stockBalance;


    @ConversionNumber
    @ApiModelProperty("单价")
    private Long univalence;

    @ApiModelProperty("执行标准（技术标准）")
    private String executiveStandards;

    @ApiModelProperty("规格")
    private String standards;

    @ApiModelProperty("颜色")
    private String color;

    @ConversionNumber
    @ApiModelProperty("面积")
    private Long area;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("备注")
    private String remarks;



    @ApiModelProperty("税前单价")
    @ConversionNumber
    private Long preTaxPrice;

    @ApiModelProperty("税额")
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("入库时间")
    private Date stockInTime;
/*新增领料细节的特有字段*/
    @ConversionNumber
    @ApiModelProperty("限额数量")
    private Long quantityRequired;

    @ConversionNumber
    @ApiModelProperty("已领数量")
    private Long pickedQuantity;

    @ConversionNumber
    @ApiModelProperty("出库限额")
    private Long issueLimit;



}
