package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryProductDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;
}
