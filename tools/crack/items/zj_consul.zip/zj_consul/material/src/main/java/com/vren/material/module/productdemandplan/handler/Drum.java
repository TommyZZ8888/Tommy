package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 耿让
 */
@Component
public class Drum implements ComputerHandler{
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        if (CommonUtil.isNull(data.getFirstSize())||CommonUtil.isNull(data.getSecondSize())||CommonUtil.isNull(data.getThirdSize())){
            throw new RuntimeException(data.getMaterialName()+"的第一尺寸、第二尺寸和第三尺寸不能为空");
        }
        double result = Math.PI * (Math.pow(data.getFirstSize().doubleValue()/100 + 2 * data.getSecondSize().doubleValue()/100, 2) - Math.pow(data.getFirstSize().doubleValue()/100, 2)) / 4 * data.getThirdSize().doubleValue()/100 * data.getProportion().doubleValue()/100 / 1000000 * data.getCount().doubleValue()/100;
        String specification = "δ" + data.getSecondSize()/100 + "X" + data.getThirdSize()/100 + "X" + (int) Math.floor(data.getFirstSize().doubleValue()/100 * 3.1416 + data.getSecondSize().doubleValue()/100 * 3.1416 + 1);
        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (result<0){
            throw new RuntimeException("您输入的尺寸有误！");
        }
        productDemandPlanDetails.setWeight((long) (result*100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            String secondSize = specification.substring(specification.indexOf("δ")+1,specification.indexOf("X"));
            String thirdSize = specification.substring(specification.indexOf("X")+1,specification.lastIndexOf("X"));
            String firstSize = specification.substring(specification.lastIndexOf("X")+1);
            vo.setFirstSizeExport((Double.parseDouble(firstSize)-1-Double.parseDouble(secondSize)*3.1416)/3.1416);
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
            vo.setThirdSizeExport(Double.parseDouble(thirdSize));
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            String secondSize = specification.substring(specification.indexOf("δ")+1,specification.indexOf("X"));
            String thirdSize = specification.substring(specification.indexOf("X")+1,specification.lastIndexOf("X"));
            String firstSize = specification.substring(specification.lastIndexOf("X")+1);
            vo.setFirstSizeExport((Double.parseDouble(firstSize)-1-Double.parseDouble(secondSize)*3.1416)/3.1416);
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
            vo.setThirdSizeExport(Double.parseDouble(thirdSize));
        }
    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        if (specification!=null) {
            String thickness = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("X"));
            String length = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            String width = specification.substring(specification.lastIndexOf("X") + 1);
            map.put("width", width);
            map.put("length", length);
            map.put("thickness", thickness);
        }
        return map;
    }
}
