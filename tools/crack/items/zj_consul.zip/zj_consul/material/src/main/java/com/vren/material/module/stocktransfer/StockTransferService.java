package com.vren.material.module.stocktransfer;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectOutlineVO;
import com.vren.material.module.projectdemandplan.domain.dto.QueryLockStockDataDTO;
import com.vren.material.module.projectdemandplan.domain.vo.LockStockData;
import com.vren.material.module.stockmanagement.StockManagementService;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.stocktransfer.domain.dto.GenerateStockTransferDTO;
import com.vren.material.module.stocktransfer.domain.dto.GetStockTransferDTO;
import com.vren.material.module.stocktransfer.domain.dto.IncomingCompanySelectDTO;
import com.vren.material.module.stocktransfer.domain.dto.StockTransferDetailDTO;
import com.vren.material.module.stocktransfer.domain.entity.StockTransfer;
import com.vren.material.module.stocktransfer.domain.entity.StockTransferDetail;
import com.vren.material.module.stocktransfer.domain.vo.IncomingCompanySelectVO;
import com.vren.material.module.stocktransfer.domain.vo.StockTransferDetailVO;
import com.vren.material.module.stocktransfer.mapper.StockTransferDetailMapper;
import com.vren.material.module.stocktransfer.mapper.StockTransferMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
public class StockTransferService {

    @Autowired
    private StockTransferMapper stockTransferMapper;

    @Autowired
    private StockTransferDetailMapper stockTransferDetailMapper;

    @Autowired
    private StockManagementService stockManagementService;


    @Transactional(rollbackFor = Exception.class)
    public boolean generateStockTransfer(GenerateStockTransferDTO dto) {
        /**
         *  新增一条调拨单数据；新增多条调拨单详细数据
         *  stockTransferNo编号不能重复
         */
            QueryWrapper<StockTransfer> queryWrapper = new QueryWrapper<>();
            queryWrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getStockTransferNo()),"stock_transfer_no",dto.getStockTransferNo())
                    .last("limit 1");
            if (stockTransferMapper.selectCount(queryWrapper)>0){
                throw new RuntimeException("调拨单编号已存在");
            }
            //填写的实拨数量要大于库存余量
            List<StockTransferDetailDTO> stockTransferDetailDTOS = dto.getStockTransferDetailDTOS();
            stockTransferDetailDTOS.stream().forEach( item -> {
                if (item.getStockBalance()  < item.getActualAllocatedQuantity()){
                    throw new RuntimeException("实拨数量不能大于库存余量");
                }
            });

            StockTransfer stockTransfer = BeanUtil.copy(dto, StockTransfer.class);
            int insert = stockTransferMapper.insert(stockTransfer);
            if (insert>0){
//                List<StockTransferDetail> stockTransferDetails = BeanUtil.copyList(stockTransferDetailDTOS, StockTransferDetail.class);
//                stockTransferDetails.stream().forEach( item -> {
//                    item.setStockTransferId(stockTransfer.getId());
//                    //金额计算
//                    item.setMoney(item.getActualAllocatedQuantity()*item.getUnitPrice()/100);
//                });

                /**
                 * //2023/02/13 新增调拨，关联的库存表id是调入的库存的 ；应该先处理库存那边的数据，然后再关联
                 * //如果是新增，关联新增的库存表id；如果是更新，关联的是原来的id
                 */

//                if (stockTransferDetailMapper.insertBatchSomeColumn(stockTransferDetails) > 0){
                    //调拨成功
                    //调拨后，库存余量减少；根据库存表id，库存余量=库存余量-实拨数量
                    ArrayList<MaterialStock> materialStocks = new ArrayList<>();
                    ArrayList<MaterialStock> stocks = new ArrayList<>();
                    for (StockTransferDetailDTO stockTransferDetailDTO: stockTransferDetailDTOS) {
                        //更新库存余量的dto
                        MaterialStock materialStock = new MaterialStock();
                        materialStock.setId(stockTransferDetailDTO.getMaterialStockId());
                        materialStock.setStockBalance(stockTransferDetailDTO.getStockBalance()-stockTransferDetailDTO.getActualAllocatedQuantity());
                        materialStocks.add(materialStock);
                        //新增的dto
                        MaterialStock stock = stockManagementService.selectById(stockTransferDetailDTO.getMaterialStockId());
                        stock.setId(null);
                        stock.setStockBalance(stockTransferDetailDTO.getActualAllocatedQuantity());
                        stock.setLockNumber(0);
                        stock.setStockStatus(2);
                        //新增的物资属于调入项目
                        stock.setProjectId(dto.getIncomingCompany());

                        //拨入单位如果该物资的库存记录，则库存余量增加；如果没有的话，就新增一条库存记录(新增库存记录)
                        //判断库存是否存在,通过物资编号判断  调入项目的物资编号  和  库存已有项目的物资编号 比较
                        //入库的物资编号
                        String materialStockId = stockManagementService.updateStock(dto.getIncomingCompany(), stock);
                        stockTransferDetailDTO.setMaterialStockId(materialStockId);

                        StockTransferDetail stockTransferDetail = BeanUtil.copy(stockTransferDetailDTO, StockTransferDetail.class);
                        stockTransferDetail.setStockTransferId(stockTransfer.getId());
                        //金额计算
                        stockTransferDetail.setMoney(stockTransferDetail.getActualAllocatedQuantity()*stockTransferDetail.getUnitPrice()/100);
                        stockTransferDetailMapper.insert(stockTransferDetail);
                    }
                    boolean updateStockBalanceByIds = stockManagementService.updateStockBalanceByIds(materialStocks);
//                    Integer integer = stockManagementService.insertBatchSomeColumn(stocks);

                    if (updateStockBalanceByIds){
                        return true;
                    }
                }
//            }
        return false;
    }

    @Autowired
    private ProjectService projectService;
    public List<IncomingCompanySelectVO> incomingCompanySelect(IncomingCompanySelectDTO dto) {
        List<ProjectOutlineVO> projectOutlineVOS = projectService.getOutline();
        List<ProjectOutlineVO> collect = projectOutlineVOS.stream().filter(item -> !item.getId().equals(dto.getProjectId())).collect(Collectors.toList());
        for (ProjectOutlineVO project:collect) {
            project.setProjectName(project.getProjectName() + "[" + projectService.getById(project.getId()).getProjectType()+"]");
        }
        return BeanUtil.copyList(collect,IncomingCompanySelectVO.class);
    }

    public PageResult<StockTransferDetailVO> getStockTransfer(GetStockTransferDTO dto) {
        MPJLambdaWrapper<StockTransferDetail> detailMPJLambdaWrapper = new MPJLambdaWrapper<>();
        detailMPJLambdaWrapper.selectAll(StockTransferDetail.class)
                .selectAll(StockTransfer.class)
                .leftJoin(StockTransfer.class,StockTransfer::getId,StockTransferDetail::getStockTransferId)
                .orderByDesc(StockTransfer::getCreateTime)
                .eq(!CommonUtil.isNull(dto.getIncomingCompany()),StockTransfer::getIncomingCompany,dto.getIncomingCompany())
                .eq(!CommonUtil.isNull(dto.getTransferOutCompany()),StockTransfer::getTransferOutCompany,dto.getTransferOutCompany());
        List<StockTransferDetailVO> stockTransferDetailVOS = stockTransferDetailMapper.selectJoinList(StockTransferDetailVO.class, detailMPJLambdaWrapper);
        //设置项目名称
        stockTransferDetailVOS.forEach( item -> {
            item.setIncomingCompanyText(projectService.getById(item.getIncomingCompany()).getProjectName());
            item.setTransferOutCompanyText(projectService.getById(item.getTransferOutCompany()).getProjectName());
            item.setOwningFactory(projectService.getById(item.getIncomingCompany()).getProjectType());
        });
        return PageUtil.convert2PageResult(stockTransferDetailVOS,dto);
    }

    public List<LockStockData> getTransferByProject(QueryLockStockDataDTO dto) {
        MPJLambdaWrapper<StockTransfer> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(StockTransfer::getId,StockTransfer::getIncomingCompany)
                .eq(!CommonUtil.isNull(dto.getProjectId()),StockTransfer::getIncomingCompany,dto.getProjectId());
        List<StockTransfer> stockTransfers = stockTransferMapper.selectList(wrapper);
        // 项目下 调拨记录详情的Id
        List<String> list = stockTransfers.stream().map(StockTransfer::getId).distinct().collect(Collectors.toList());
        MPJLambdaWrapper<StockTransferDetail> detailMPJLambdaWrapper = new MPJLambdaWrapper<>();
        detailMPJLambdaWrapper.select(StockTransferDetail::getMaterialStockId)
                .in(CommonUtil.listIsNotEmpty(list),StockTransferDetail::getStockTransferId,list);
        List<StockTransferDetail> stockTransferDetails = stockTransferDetailMapper.selectList(detailMPJLambdaWrapper);
        //符合条件的库存数据  库存表id
        List<String> collect = stockTransferDetails.stream().map(StockTransferDetail::getMaterialStockId).distinct().collect(Collectors.toList());
        return stockManagementService.selectByColorAndMaterialType(dto, collect);
    }
}
