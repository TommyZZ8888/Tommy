package com.vren.material.module.materialcheckout;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.EnumUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.module.materialcheckout.domain.dto.*;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutDetail;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutRecord;
import com.vren.material.module.materialcheckout.domain.enums.ReceiveState;
import com.vren.material.module.materialcheckout.domain.enums.TaxMethod;
import com.vren.material.module.materialcheckout.domain.vo.*;
import com.vren.material.module.materialcheckout.mapper.MaterialCheckoutDetailMapper;
import com.vren.material.module.materialcheckout.mapper.MaterialCheckoutRecordMapper;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.stockmanagement.MaterialStockMapper;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import com.vren.material.module.storage.domain.enums.WarehousingMaterialType;
import com.vren.material.module.storage.mapper.MaterialFirstLevelStorageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MaterialCheckoutService {
    @Autowired
    private MaterialStockMapper materialStockMapper;
    @Autowired
    private MaterialCheckoutRecordMapper materialCheckoutRecordMapper;
    @Autowired
    private MaterialCheckoutDetailMapper materialCheckoutDetailMapper;


    @Autowired
    private ProjectService projectService;
    @Autowired
    private MaterialFirstLevelStorageMapper materialFirstLevelStorageMapper;
    public void addOrEditMaterialCheckout(MaterialCheckoutRecordAddDTO dto) {
               if(CommonUtil.isNull(dto.getId())){
        //查库存
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(MaterialStock::getProjectId,dto.getProjectId());
        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
        if(!CommonUtil.listIsNotEmpty(materialStocks)){
            throw new ErrorException("该项目下没有库存不能生成领料单");
        }

        MaterialCheckoutRecord copy = BeanUtil.copy(dto, MaterialCheckoutRecord.class);
       /* boolean flag=false;
      //查采购计划
        MPJLambdaWrapper<PurchasePlan> purchasePlanMPJLambdaWrapper = new MPJLambdaWrapper<>();
        purchasePlanMPJLambdaWrapper.selectAll(PurchasePlan.class)
                .eq(PurchasePlan::getProjectId,dto.getProjectId());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(purchasePlanMPJLambdaWrapper);
        Map<String, List<MaterialStock>> pickCollect  =materialStocks.stream().collect(Collectors.groupingBy(key -> String.format("%d", key.getMaterialType())));
        List<String> stringList = new ArrayList<>(pickCollect.keySet());


        //相同材料类型比较总数量和已领用数量
        for (PurchasePlan purchasePlan : purchasePlans) {
            for (String s : stringList) {
                if(Objects.equals(s, EnumUtil.getValue(MaterialType.class, purchasePlan.getMaterialType()))){

                    Long sumCount =  pickCollect.get(s).stream().mapToLong(MaterialStock::getStockBalance).sum();
                    if(sumCount>purchasePlan.getTotalAmount()) {flag=true;}

                }
            }
        }
        //设置是否超额状态
        copy.setExcessIssue(flag);*/
        materialCheckoutRecordMapper.insert(copy);
               return;}
        MaterialCheckoutRecord copy = BeanUtil.copy(dto, MaterialCheckoutRecord.class);
               materialCheckoutRecordMapper.updateById(copy);

    }


    public void deleteMaterialCheckout(MaterialCheckoutRecordDeleteDTO dto) {

        materialCheckoutRecordMapper.deleteById(dto.getId());
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
        .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId,dto.getId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        if(CommonUtil.listIsNotEmpty(materialCheckoutDetails)){
            for (MaterialCheckoutDetail materialCheckoutDetail : materialCheckoutDetails) {
                materialCheckoutDetailMapper.deleteById(materialCheckoutDetail);
            }
        }


    }

    public void addMaterialCheckoutDetail(MaterialCheckoutDetailAddDTO dto) {
        if (dto.getStockBalance() < dto.getApplyQuantity()){
            throw new RuntimeException("申领数量不能大于库存余量");
        }
        if (dto.getApplyQuantity() < dto.getActualPickedQuantity()){
            throw new RuntimeException("实领数量不能大于申领数量");
        }

        if(CommonUtil.isNull(dto.getId())){
            MaterialCheckoutDetail copy = BeanUtil.copy(dto, MaterialCheckoutDetail.class);
            //未领取
            copy.setReceiveState(ReceiveState.UNRECEIVE.getCode());
            MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(MaterialCheckoutDetail.class)
                    .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getMaterialCheckoutRecordId())
                    .eq(MaterialCheckoutDetail::getMaterialNumber, dto.getMaterialNumber());
            List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
            if(CommonUtil.listIsNotEmpty(materialCheckoutDetails)){
                throw new ErrorException("不能重复添加同材料编号的材料");
            }
            MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getMaterialCheckoutRecordId());
            MPJLambdaWrapper<MaterialStock> amountWrapper = new MPJLambdaWrapper<>();
            amountWrapper.selectAll(MaterialStock.class)
                    .eq(MaterialStock::getProjectId,materialCheckoutRecord.getProjectId())
                    .eq(MaterialStock::getMaterialNumber,dto.getMaterialNumber());
            MaterialStock materialStocks = materialStockMapper.selectOne(amountWrapper);
            copy.setMaterialTotalPrice((materialStocks.getPreTaxPrice()+materialStocks.getTax())*dto.getActualPickedQuantity());
            copy.setMoney(materialStocks.getPreTaxPrice()*dto.getActualPickedQuantity());
            int insert = materialCheckoutDetailMapper.insert(copy);
//            if(insert >0 ){
//                //生成领料单，库存余量减少；库存余量 = 库存余量 - 实领数量
//                UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
//                updateWrapper.eq(!CommonUtil.isNull(dto.getMaterialNumber()),"material_number",dto.getMaterialNumber())
//                        .setSql(!CommonUtil.isNull(dto.getActualPickedQuantity()),"stock_balance = stock_balance - " + dto.getActualPickedQuantity());
//                materialStockMapper.update(new MaterialStock(),updateWrapper);
//            }
            return;
        }
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId,dto.getId());
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getMaterialCheckoutRecordId());
        String projectId = materialCheckoutRecord.getProjectId();
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        for (MaterialCheckoutDetail materialCheckoutDetail : materialCheckoutDetails) {
            MPJLambdaWrapper<MaterialStock> materialStockMPJLambdaWrapper = new MPJLambdaWrapper<>();
            materialStockMPJLambdaWrapper.selectAll(MaterialStock.class)
                    .eq(MaterialStock::getProjectId,projectId)
                    .eq(MaterialStock::getMaterialName,materialCheckoutDetail.getMaterialName());
            MaterialStock materialStock = materialStockMapper.selectOne(materialStockMPJLambdaWrapper);

            long l = materialStock.getStockBalance() - materialCheckoutDetail.getActualPickedQuantity();
            if(l<0){
                throw new ErrorException( "已领数量超过库存,建议小于" + materialStock.getStockBalance());
            } }
        MaterialCheckoutDetail copy = BeanUtil.copy(dto, MaterialCheckoutDetail.class);
        //未领取
        copy.setReceiveState(ReceiveState.UNRECEIVE.getCode());
        //原来的实领数量，在更新之前查询
//        MaterialCheckoutDetail materialCheckoutDetail = materialCheckoutDetailMapper.selectById(dto.getId());
//        Long actualPickedQuantity = materialCheckoutDetail.getActualPickedQuantity();
        int update = materialCheckoutDetailMapper.updateById(copy);
//        if (update > 0){
//            //更新成功，库存余量更新 ：  库存余量 =  库存余量  +  原来的实领数量  - 现在的实领取数量
//            UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
//            updateWrapper.eq(!CommonUtil.isNull(dto.getMaterialNumber()),"material_number",dto.getMaterialNumber())
//                    .setSql(!CommonUtil.isNull(dto.getActualPickedQuantity()),"stock_balance = stock_balance + " + actualPickedQuantity + "-" +dto.getActualPickedQuantity());
//            materialStockMapper.update(new MaterialStock(),updateWrapper);
//        }
    }

    public PageResult<MaterialCheckoutRecordVO> getMaterialCheckoutList(MaterialCheckoutRecordQueryDTO dto) {
        MPJLambdaWrapper<MaterialCheckoutRecord> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutRecord.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()),MaterialCheckoutRecord::getProjectId,dto.getProjectId());
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(wrapper);
        List<MaterialCheckoutRecordVO> materialCheckoutRecordVOS = BeanUtil.copyList(materialCheckoutRecords, MaterialCheckoutRecordVO.class);
        List<MaterialCheckoutRecordVO> collect = materialCheckoutRecordVOS.stream().peek(item -> {
            ProjectVO projectVO = projectService.getById(item.getProjectId());
            String projectName = projectVO.getProjectName();
            item.setProjectName(projectName);
            item.setTaxMethodText(EnumUtil.getValue(TaxMethod.class,item.getTaxMethod()));
            //根据id查询 出库详情，判断是否已经出库
            MPJLambdaWrapper<MaterialCheckoutDetail> checkoutDetailMPJLambdaWrapper = new MPJLambdaWrapper<>();
            checkoutDetailMPJLambdaWrapper.select(MaterialCheckoutDetail::getReceiveState)
                    .eq(!CommonUtil.isNull(item.getId()),MaterialCheckoutDetail::getMaterialCheckoutRecordId,item.getId());
            List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(checkoutDetailMPJLambdaWrapper);
            if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)){
                Integer receiveState = materialCheckoutDetails.get(0).getReceiveState();
                if (CommonUtil.isNull(receiveState)){
                    item.setCheckOut(false);
                }else {
                    if (receiveState.equals(ReceiveState.UNRECEIVE.getCode())){
                        item.setCheckOut(false);
                    }else {
                        item.setCheckOut(true);
                    }
                }
            }else {
                item.setCheckOut(false);
            }
        }).collect(Collectors.toList());
        return  PageUtil.convert2PageResult(collect ,dto);
    }

    public PageResult<MaterialCheckoutDetailVO> getMaterialCheckoutDetailList(MaterialCheckoutDetailQueryDTO dto) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId,dto.getId())
                .eq(!CommonUtil.isNull(dto.getMaterialType()),MaterialCheckoutDetail::getMaterialType,dto.getMaterialType());

        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        List<MaterialCheckoutDetailVO> materialCheckoutDetailVOS = BeanUtil.copyList(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        List<MaterialCheckoutDetailVO> collect = materialCheckoutDetailVOS.stream().peek(item -> {
            item.setMaterialTypeText(EnumUtil.getValue(WarehousingMaterialType.class, item.getMaterialType()));
            item.setReceiveStateText(EnumUtil.getValue(ReceiveState.class, item.getReceiveState()));
        }).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect,dto);

    }

    public void deleteMaterialCheckoutDetail(MaterialCheckoutDetailDeleteDTO dto) {
        materialCheckoutDetailMapper.deleteById(dto.getId());
    }

    public MaterialCheckoutDetailVO getMaterialCheckoutDetailById(MaterialCheckoutDetailDTO dto) {
        MaterialCheckoutDetail materialCheckoutDetail = materialCheckoutDetailMapper.selectById(dto.getId());
        MaterialCheckoutDetailVO materialCheckoutDetailVO = BeanUtil.copy(materialCheckoutDetail, MaterialCheckoutDetailVO.class);
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(materialCheckoutDetail.getMaterialCheckoutRecordId());
        //根据物资编号填充库存余量（从库存表查询）
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(MaterialStock::getStockBalance)
                .eq(!CommonUtil.isNull(materialCheckoutDetailVO.getMaterialNumber()),MaterialStock::getMaterialNumber,materialCheckoutDetailVO.getMaterialNumber())
                .eq(!CommonUtil.isNull(materialCheckoutRecord.getProjectId()),MaterialStock::getProjectId,materialCheckoutRecord.getProjectId());
        MaterialStock materialStock = materialStockMapper.selectOne(wrapper);
        materialCheckoutDetailVO.setStockBalance(materialStock.getStockBalance());
        return materialCheckoutDetailVO;
    }

    public List<TaxMethodVO> getTaxMethodVOList() {
        ArrayList<TaxMethodVO> list = new ArrayList<>();
        for (TaxMethod value : TaxMethod.values()) {
            TaxMethodVO taxMethodVO = new TaxMethodVO();
            taxMethodVO.setCode(value.getCode());
            taxMethodVO.setValue(value.getName());
            list.add(taxMethodVO);
        }
        return list;
    }

    public MaterialCheckoutDataVO getMaterialCheckoutDataList(MaterialCheckoutDataDTO dto) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(MaterialStock::getProjectId,dto.getProjectId())
                .eq(MaterialStock::getMaterialNumber,dto.getMaterialNumber());
        MaterialStock materialStocks = materialStockMapper.selectOne(wrapper);
        MaterialCheckoutDataVO copy = BeanUtil.copy(materialStocks, MaterialCheckoutDataVO.class);
        //已领数量 ，根据项目id和物资编号 将所有的已经领用数量加起来
        MPJLambdaWrapper<MaterialCheckoutRecord> recordMPJLambdaWrapper = new MPJLambdaWrapper<>();
        recordMPJLambdaWrapper.select(MaterialCheckoutRecord::getId)
                        .eq(!CommonUtil.isNull(copy.getProjectId()),MaterialCheckoutRecord::getProjectId,copy.getProjectId());
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(recordMPJLambdaWrapper);
        List<String> collect = materialCheckoutRecords.stream().map(MaterialCheckoutRecord::getId).collect(Collectors.toList());
        MPJLambdaWrapper<MaterialCheckoutDetail> detailMPJLambdaWrapper = new MPJLambdaWrapper<>();
        detailMPJLambdaWrapper.select(MaterialCheckoutDetail::getPickedQuantity)
                        .in(CommonUtil.listIsNotEmpty(collect),MaterialCheckoutDetail::getMaterialCheckoutRecordId,collect)
                        .eq(!CommonUtil.isNull(copy.getMaterialNumber()),MaterialCheckoutDetail::getMaterialNumber,copy.getMaterialNumber());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(detailMPJLambdaWrapper);
        long sum = materialCheckoutDetails.stream().mapToLong(MaterialCheckoutDetail::getPickedQuantity).sum();
        //已领数量
        copy.setPickedQuantity(sum);
        //todo  已领数量数据放到库存表中
        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(materialStocks.getMaterialStorageId());
   if(!CommonUtil.isNull(materialFirstLevelStorage)){
       //采购数量 =出库限额
       Long purchaseAmount = materialFirstLevelStorage.getPurchaseAmount();
       //限额数量=出库限额-已领数量
       copy.setQuantityRequired(purchaseAmount-sum);

       copy.setIssueLimit(purchaseAmount);
   }


        if (dto.getIsScan()){
            if (CommonUtil.isNull(copy)){
                String projectName = projectService.getById(dto.getProjectId()).getProjectName();
                throw new RuntimeException("【"+projectName+"】项目下不存在该物资，不可领取");
            }
        }
        return copy;
    }

    public List<MaterialNumberVO> getMaterialNameList(MaterialCheckoutRecordQueryDTO dto) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()),MaterialStock::getProjectId,dto.getProjectId());
        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
        List<MaterialNumberVO> materialNumberVOList = materialStocks.stream().map(item -> {
            MaterialNumberVO materialNumberVO = new MaterialNumberVO();
            materialNumberVO.setMaterialNumber(item.getMaterialNumber());
            return materialNumberVO;
        }).collect(Collectors.toList());
        MPJLambdaWrapper<MaterialCheckoutDetail> mpjLambdaWrapper = new MPJLambdaWrapper<>();
        mpjLambdaWrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId,dto.getMaterialCheckoutRecordId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(mpjLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
            List<MaterialNumberVO> collect = materialCheckoutDetails.stream().map(item -> {
                MaterialNumberVO materialNumberVO = new MaterialNumberVO();
                materialNumberVO.setMaterialNumber(item.getMaterialNumber());
                return materialNumberVO;
            }).collect(Collectors.toList());
            materialNumberVOList.removeAll(collect);
        }
        return materialNumberVOList;
    }

    public void materialCheckout(MaterialCheckoutDTO dto) {
        /**
         *  根据出库记录表id更新  出库详情表的receive_state
         *  根据关联的出库详情  更新库存表的库存余量
         */
        String projectId = materialCheckoutRecordMapper.selectById(dto.getId()).getProjectId();
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(!CommonUtil.isNull(dto.getId()),MaterialCheckoutDetail::getMaterialCheckoutRecordId,dto.getId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        if (!CommonUtil.listIsNotEmpty(materialCheckoutDetails)){
            throw new RuntimeException("该出库单下面不存在出库记录,不可出库");
        }
        materialCheckoutDetails.forEach( item -> {
            //出库详情
            //更新库存余量  :   根据物资编号更新库存余量
            String materialNumber = item.getMaterialNumber();
            //生成领料单，库存余量减少；库存余量 = 库存余量 - 实领数量
            UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
            //2023/02/28 根据物资编号和项目id
            updateWrapper.eq(!CommonUtil.isNull(materialNumber),"material_number",materialNumber)
                    .eq(!CommonUtil.isNull(projectId),"project_id",projectId)
                    .setSql(!CommonUtil.isNull(item.getActualPickedQuantity()),"stock_balance = stock_balance - " + item.getActualPickedQuantity());
            int update = materialStockMapper.update(new MaterialStock(), updateWrapper);
            if (update > 0){
                //库存余量更新成功，更新库存详情的领取状态
                item.setReceiveState(ReceiveState.RECEIVED.getCode());
                //2023/02/28  根据项目id和物资编号  更新所有的已领数量  （累加）
                //  新增的时候，查询所有已领数量，累加起来
                UpdateWrapper<MaterialCheckoutDetail> detailUpdateWrapper = new UpdateWrapper<>();
                detailUpdateWrapper.eq("material_checkout_record_id",dto.getId())
                                .eq("material_number",materialNumber)
                                .set("picked_quantity",item.getPickedQuantity() + item.getActualPickedQuantity());
                materialCheckoutDetailMapper.update(new MaterialCheckoutDetail(),detailUpdateWrapper);
                materialCheckoutDetailMapper.updateById(item);
            }
        });
    }

    /**
     * 根据项目id和领料单编号查询  出库详情
     * @param projectId
     * @param materialRequisitionNo
     * @return
     */
    public List<MaterialCheckoutDetailVO> selectCheckoutDetailProjectIdAndNo(String projectId, String materialRequisitionNo) {
        //查询出库记录表id
        MPJLambdaWrapper<MaterialCheckoutRecord> checkoutRecordMPJLambdaWrapper = new MPJLambdaWrapper<>();
        checkoutRecordMPJLambdaWrapper.select(MaterialCheckoutRecord::getId)
                .eq(!CommonUtil.isNull(projectId),MaterialCheckoutRecord::getProjectId,projectId)
                .like(!CommonUtil.isNull(materialRequisitionNo),MaterialCheckoutRecord::getMaterialRequisitionNo,materialRequisitionNo);
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(checkoutRecordMPJLambdaWrapper);
        if (materialCheckoutRecords.size()==0){
            throw new RuntimeException("该项目下没有相关的出库记录");
        }
        List<String> collect = materialCheckoutRecords.stream().map(MaterialCheckoutRecord::getId).collect(Collectors.toList());
        //根据出库记录表id，在出库记录详情中查询结果
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .in(CommonUtil.listIsNotEmpty(collect), MaterialCheckoutDetail::getMaterialCheckoutRecordId,collect);
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        List<MaterialCheckoutDetailVO> materialCheckoutDetailVOS = BeanUtil.copyList(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        materialCheckoutDetailVOS.forEach(item -> {
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,item.getMaterialType()));
        });
        return materialCheckoutDetailVOS;
    }

    public MaterialCheckoutDetailVO selectCheckoutDetailByMaterialName(Integer materialType, String materialName, String materialNumber) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(!CommonUtil.isNull(materialType),MaterialCheckoutDetail::getMaterialType,materialType)
                .eq(!CommonUtil.isNull(materialName),MaterialCheckoutDetail::getMaterialName,materialName)
                .eq(!CommonUtil.isNull(materialNumber),MaterialCheckoutDetail::getMaterialNumber,materialNumber);
        MaterialCheckoutDetail materialCheckoutDetail = materialCheckoutDetailMapper.selectOne(wrapper);
        return BeanUtil.copy(materialCheckoutDetail,MaterialCheckoutDetailVO.class);
    }

    public MaterialCheckoutDetailVO selectCheckoutByMaterialNumber(String materialNumber) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialNumber,materialNumber);
        MaterialCheckoutDetail materialCheckoutDetails = materialCheckoutDetailMapper.selectOne(wrapper);
        if (CommonUtil.isNull(materialCheckoutDetails)){
            throw new RuntimeException("不存在该物资");
        }
        MaterialCheckoutDetailVO materialCheckoutDetailVO = BeanUtil.copy(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        materialCheckoutDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class,materialCheckoutDetailVO.getMaterialType()));
        return materialCheckoutDetailVO;
    }
}
