package com.vren.material.module.productmanagement.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class UpdateProductDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目表id")
    @NotBlank(message = "项目名称不能为空")
    private String projectId;

    @ApiModelProperty("产品名称")
    @NotBlank(message = "产品名称不能为空")
    private String productName;

    @ApiModelProperty("位号")
    private String tagNo;

    @ApiModelProperty("产品规格")
    private String productSpecificatons;

    @ApiModelProperty("总图号")
    @NotBlank(message = "总图号不能为空")
    private String totalFigureNo;

    @ApiModelProperty("数量")
    @ConversionNumber
    @Min(0)
    private Long number;

    @ApiModelProperty("容器类别")
    private String containerCategory;

    @ApiModelProperty("使用单位")
    @NotBlank(message = "使用单位不能为空")
    private String useUnit;

    @ApiModelProperty("制造编号(生产编号)，具有唯一性")
    @NotBlank(message = "制造编号不能为空")
    private String manufacturingNumber;

    @ApiModelProperty("重量（吨）")
    @ConversionNumber
    @Min(0)
    private Long weight;

}
