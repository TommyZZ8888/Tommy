package com.vren.material.module.storage.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialQueryDTO extends PageParam {
    @NotBlank(message = "合同清单id不能为空")
    @ApiModelProperty("合同清单id")
    private  String contractListId;
}
