package com.vren.material.module.projectdemandplan;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelFillCellMergeStrategy;
import com.vren.common.common.utils.easyexcel.ExcelUtil;
import com.vren.common.common.utils.easyexcel.MyMergeHandler;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import com.vren.material.module.materialremain.MaterialRemainService;
import com.vren.material.module.productdemandplan.ProductDemandPlanDetailsMapper;
import com.vren.material.module.productdemandplan.ProductDemandPlanService;
import com.vren.material.module.productdemandplan.domain.dto.EditTimeAndLocationDTO;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTypeEntity;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlan;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.domain.vo.RemarkVO;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.productdemandplan.mapper.MaterialTypeMapper;
import com.vren.material.module.productdemandplan.mapper.ProductDemandPlanMapper;
import com.vren.material.module.productmanagement.ProductInformationMapper;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.projectdemandplan.domain.dto.*;
import com.vren.material.module.projectdemandplan.domain.entity.*;
import com.vren.material.module.projectdemandplan.domain.enums.DemandType;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.domain.vo.*;
import com.vren.material.module.projectdemandplan.mapper.*;
import com.vren.material.module.purchaseplan.domain.vo.ProjectNameInDemandPlanVO;
import com.vren.material.module.stockmanagement.StockManagementService;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.stockmanagement.domian.vo.MaterialStockVO;
import com.vren.material.module.stocktransfer.StockTransferService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Slf4j
@Service
public class ProjectDemandPlanService {

    @Autowired
    private StockTransferService stockTransferService;
    @Autowired
    private ProjectService projectService;
    @Autowired
    private ProjectDemandPlanMapper projectDemandPlanMapper;
    @Autowired
    private MaterialTypeDescriptionMapper materialTypeDescriptionMapper;
    @Autowired
    private MaterialTypeMapper materialTypeMapper;

    @Autowired
    private ProductDemandPlanTotalMapper productDemandPlanTotalMapper;
    @Autowired
    private ProductInformationMapper productInformationMapper;
    @Autowired
    private PaintDemandPlanMapper paintDemandPlanMapper;
    @Autowired
    private WeldingMaterialsDemandPlanMapper weldingMaterialsDemandPlanMapper;

    @Autowired
    private ProductDemandPlanMapper productDemandPlanMapper;

    @Autowired
    private StockManagementService stockManagementService;

    @Autowired
    private LockStockMapper lockStockMapper;

    @Autowired
    private MaterialRemainService materialRemainService;

    /**
     * 根据项目id和物资类型查询项目需求计划
     * @param projectId
     * @param demandType
     * @return
     */
    public ProjectDemandPlan selectByProjectIdAndDemandType(String projectId, Integer demandType) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId,projectId)
                .eq(ProjectDemandPlan::getDemandType,demandType);
        return projectDemandPlanMapper.selectOne(wrapper);
    }


    /**
     * 根据项目id 查询项目需求计划
     * @param projectId
     * @return
     */
    public List<ProjectDemandPlan> selectByProjectId(String projectId,String batch) {
        //2023/03/02 根据项目id和批次查询项目需求计划 ， projectId 的格式为： projectId-批次


        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(!CommonUtil.isNull(projectId),ProjectDemandPlan::getProjectId,projectId)
                .eq(!CommonUtil.isNull(batch),ProjectDemandPlan::getProjectDemandPlanBatch,batch);
        return projectDemandPlanMapper.selectList(wrapper);
    }

    /**
     *  根据项目需求计划查询产品需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<ProductDemandPlanTotal> selectProductDemandByProjectDemandPlanId(String projectDemandPlanId){
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId),ProductDemandPlanTotal::getProjectDemandPlanId,projectDemandPlanId);
        return productDemandPlanTotalMapper.selectList(wrapper);
    }

    /**
     *  根据项目需求计划id查询焊材需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<WeldingMaterialDemandPlan> selectWeldByProjectDemandPlanId(String projectDemandPlanId) {
        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId),PaintDemandPlan::getProjectDemandPlanId,projectDemandPlanId);
        return weldingMaterialsDemandPlanMapper.selectList(wrapper);
    }

    /**
     *  根据项目需求计划id查询油漆需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<PaintDemandPlan> selectPaintByProjectDemandPlanId(String projectDemandPlanId){
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId),PaintDemandPlan::getProjectDemandPlanId,projectDemandPlanId);
        return paintDemandPlanMapper.selectList(wrapper);
    }

    /**
     * 根据id查询项目需求计划
     * @param id
     * @return
     */
    public ProjectDemandPlan selectOneById(String id){
        return projectDemandPlanMapper.selectById(id);
    }

    /**
     * 计算采购总数
     * @param ids
     * @return
     */
    public HashMap<String,PurchaseCount> purchaseCount(List<String> ids){
        HashMap<String, PurchaseCount> map =  new HashMap<>();

        //产品采购总数、焊材采购总数、油漆采购总数
        //查询产品计划汇总表：库存数量、数量、重量、物资类型
        //计算结果新增到对应的子表中
        /**
         * 采购汇总
         *  采购数量累加起来
         *  采购重量累加起来
         * 对于焊材，只有重量，没有数量这一说法
         */
        MPJLambdaWrapper<ProductDemandPlanTotal> totalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        totalMPJLambdaWrapper.select(ProductDemandPlanTotal::getStockAmount,ProductDemandPlanTotal::getCount,ProductDemandPlanTotal::getWeight,ProductDemandPlanTotal::getMaterialType,ProductDemandPlanTotal::getBidPrice)
                .in(ProductDemandPlanTotal::getProjectDemandPlanId,ids);
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(totalMPJLambdaWrapper);

        //根据物资类型，计算采购数量和重量   采购数量=需求数量-锁库数量
        //根据物资类型分类
        Map<Integer, List<ProductDemandPlanTotal>> collect = productDemandPlanTotals.stream().collect(Collectors.groupingBy(ProductDemandPlanTotal::getMaterialType));
        for (Integer item:collect.keySet()) {
            Integer purchaseNum = 0;
            Long purchaseWeight = 0L;
            List<ProductDemandPlanTotal> planTotals = collect.get(item);
            for (ProductDemandPlanTotal i:planTotals) {
                //数量减去库存数量  =   采购数量
                purchaseNum += Math.toIntExact((i.getCount() - i.getStockAmount()));
                if (i.getCount()>0){

                    purchaseWeight += i.getWeight()*(purchaseNum/i.getCount());
                }
            }
            //根据类型存放到map中
            if (purchaseNum>0){
                PurchaseCount purchaseCount = PurchaseCount.builder().purchaseNum(purchaseNum).purchaseWeight(purchaseWeight).build();
                map.put(EnumUtil.getValue(MaterialType.class, item), purchaseCount);
            }else {
                //如果采购数量小于0，不需要采购
                map.put(EnumUtil.getValue(MaterialType.class, item),  PurchaseCount.builder().purchaseNum(0).purchaseWeight(0L).build());
            }
        }
        //查询焊材需求计划，计算采购重量
        MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingWrapper = new MPJLambdaWrapper<>();
        weldingWrapper.select(WeldingMaterialDemandPlan::getStockAmount,WeldingMaterialDemandPlan::getCount,WeldingMaterialDemandPlan::getWeight,WeldingMaterialDemandPlan::getBidPrice)
                .in(WeldingMaterialDemandPlan::getProjectDemandPlanId,ids);
        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(weldingWrapper);
        Long weldPurchaseWeight = 0L;
        for (WeldingMaterialDemandPlan item:weldingMaterialDemandPlans) {
            //数量减去库存数量  =   采购数量
            weldPurchaseWeight += item.getWeight() - item.getStockAmount();
        }
        if (weldPurchaseWeight>0){
            PurchaseCount weldPurchaseCount = PurchaseCount.builder().purchaseWeight(weldPurchaseWeight).build();
            map.put("焊材",weldPurchaseCount);
        }else {
            map.put("焊材",PurchaseCount.builder().purchaseWeight(0L).build());
        }


        //查询油漆需求计划，计算采购数量和采购重量;数量单位是桶
        MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
        paintWrapper.select(PaintDemandPlan::getStockAmount,PaintDemandPlan::getCount,PaintDemandPlan::getBidPrice)
                .in(PaintDemandPlan::getProjectDemandPlanId,ids);
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
        Integer paintPurchaseNum = 0;
        for (PaintDemandPlan item:paintDemandPlans) {
            //数量减去库存数量  =   采购数量
            paintPurchaseNum += Math.toIntExact((item.getCount() - item.getStockAmount()));
        }
        if (paintPurchaseNum>0){
            PurchaseCount paintPurchaseCount = PurchaseCount.builder().purchaseNum(paintPurchaseNum).build();
            map.put("油漆",paintPurchaseCount);
        }else {
            PurchaseCount paintPurchaseCount = PurchaseCount.builder().purchaseNum(0).build();
            map.put("油漆",paintPurchaseCount);
        }
        return map;
    }

    /**
     * 根据项目需求id 查询项目名称
     * @param id
     * @return
     */
    public String selectProjectNameByDemandPlanId(String id){
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(id);
        return projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
    }


    public List<ProjectDemandPlan> selectByIds(List<String> ids){
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .in(ProjectDemandPlan::getId,ids);
        return projectDemandPlanMapper.selectList(wrapper);

    }

    public PageResult<ProjectDataVO> getDataList(ProjectDemandQueryDTO dto) {

        List<ProjectViewVO> projectViewVOS = projectService.queryDataList(dto);
        List<ProjectDataVO> projectDataVOS = BeanUtil.copyList(projectViewVOS, ProjectDataVO.class);
        List<ProjectDataVO> projectDatalist = new ArrayList<>();
        for (ProjectDataVO projectDataVO : projectDataVOS) {
            MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(ProjectDemandPlan.class)
                    .eq(ProjectDemandPlan::getProjectId, projectDataVO.getId());
            List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
            List<ProjectDemandPlanVO> projectDemandPlanVOS = BeanUtil.copyList(projectDemandPlans, ProjectDemandPlanVO.class);
            List<ProjectDemandPlanVO> collect = projectDemandPlanVOS.stream().
                    peek(iteam -> iteam.setDemandTypeText(EnumUtil.getValue(DemandType.class, iteam.getDemandType()))).collect(Collectors.toList());
            Map<String, List<ProjectDemandPlanVO>> map = collect.stream().collect(Collectors.groupingBy(ProjectDemandPlanVO::getProjectDemandPlanBatch));
            for (String s : map.keySet()) {
                //list循环add注意事项
                ProjectDataVO result= new ProjectDataVO();
                projectDataVO.setProjectDemandPlanBatch(s);
                projectDataVO.setList(map.get(s));
                projectDataVO.setSearchId(s+projectDataVO.getId());
                BeanUtils.copyProperties(projectDataVO,result);
                projectDatalist.add(result);
            }
        }
        List<ProjectDataVO> collect = projectDatalist.stream().filter(projectDataVO -> projectDataVO.getList().size() > 0).
                sorted(Comparator.comparing(ProjectDataVO::getProjectName)).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);

    }

    public List<ProjectNameDataVO> getProjectName(ProjectDemandQueryDTO dto) {
        List<ProjectViewVO> projectViewVOS = projectService.queryDataList(dto);
        ArrayList<ProjectNameDataVO> list = new ArrayList<>();
        for (ProjectViewVO projectViewVO : projectViewVOS) {
            ProjectNameDataVO projectNameDataVO = new ProjectNameDataVO();
            projectNameDataVO.setProjectId(projectViewVO.getId());
            projectNameDataVO.setProjectName(projectViewVO.getProjectName());
            list.add(projectNameDataVO);
        }

        return list;
    }

    public List<DemandTypeVO> getDemandType() {
        ArrayList<DemandTypeVO> list = new ArrayList<>();
        for (DemandType statue : DemandType.values()) {
            DemandTypeVO responsibilityTypeVO = new DemandTypeVO();
            responsibilityTypeVO.setCode(statue.getCode());
            responsibilityTypeVO.setValue(statue.getName());
            list.add(responsibilityTypeVO);
        }
        return list;
    }

    public void addOrEditProjectDemandPlan(ProjectDemandPlanUpdateDTO dto) {

        if (CommonUtil.isNull(dto.getId())) {

            MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(ProjectDemandPlan.class)
                    .eq(!CommonUtil.isNull(dto.getProjectId()), ProjectDemandPlan::getProjectId, dto.getProjectId())
                    .eq(ProjectDemandPlan::getDemandType, dto.getDemandType());
            List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);

            if (CommonUtil.listIsNotEmpty(projectDemandPlans)) {
                throw new ErrorException("需求类型已存在,不能新增");
            }
            switch (dto.getDemandType()){
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    QueryWrapper<ProjectDemandPlan> totalWrapper = new QueryWrapper<>();
                    totalWrapper.select("1").eq(!CommonUtil.isNull(dto.getPlanNo()), "plan_no", dto.getPlanNo()).last("limit 1");
                    if (projectDemandPlanMapper.selectCount(totalWrapper) > 0) {
                        throw new ErrorException("计划编号已存在");
                    }
                    break;

                default:
                    break;
            }

            ProjectDemandPlan copy = BeanUtil.copy(dto, ProjectDemandPlan.class);
            projectDemandPlanMapper.insert(copy);
            return;

        }
        ProjectDemandPlan copy = BeanUtil.copy(dto, ProjectDemandPlan.class);
        projectDemandPlanMapper.updateById(copy);
    }

    public void deleteProjectDemandPlan(ProjectDemandPlanDeleteDTO dto) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId())
                .eq(ProjectDemandPlan::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        for (ProjectDemandPlan projectDemandPlan : projectDemandPlans) {
            projectDemandPlanMapper.deleteById(projectDemandPlan.getId());
            //
            MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingMaterialWrapper = new MPJLambdaWrapper<>();
            weldingMaterialWrapper.selectAll(WeldingMaterialDemandPlan.class)
                    .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId,projectDemandPlan.getId());
            List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans =weldingMaterialsDemandPlanMapper.selectList(weldingMaterialWrapper);
            if(CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)){
                for (WeldingMaterialDemandPlan weldingMaterialDemandPlan : weldingMaterialDemandPlans) {
                    weldingMaterialsDemandPlanMapper.deleteById(weldingMaterialDemandPlan);
                }
            }

            MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
            paintWrapper.selectAll(PaintDemandPlan.class)
                    .eq(PaintDemandPlan::getProjectDemandPlanId,projectDemandPlan.getId());
            List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
            if(CommonUtil.listIsNotEmpty(paintDemandPlans)){
                for (PaintDemandPlan paintDemandPlan : paintDemandPlans) {
                    paintDemandPlanMapper.deleteById(paintDemandPlan);
                }
            }


            MPJLambdaWrapper<ProductDemandPlanTotal> planTotalLambdaWrapper = new MPJLambdaWrapper<>();
            planTotalLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                    .eq(ProductDemandPlanTotal::getProjectDemandPlanId,projectDemandPlan.getId());
            List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalLambdaWrapper);
            if(CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
                for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                    productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
                }
            }
            MPJLambdaWrapper<MaterialTypeDescription> materialTypeDescriptionLambdaWrapper = new MPJLambdaWrapper<>();
            materialTypeDescriptionLambdaWrapper.selectAll(MaterialTypeDescription.class)
                    .eq(MaterialTypeDescription::getProjectId,dto.getProjectId())
                    .eq(MaterialTypeDescription::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch());
            List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(materialTypeDescriptionLambdaWrapper);
            if(CommonUtil.listIsNotEmpty(materialTypeDescriptions)){
                for (MaterialTypeDescription materialTypeDescription : materialTypeDescriptions) {
                    materialTypeDescriptionMapper.deleteById(materialTypeDescription);
                }
            }

            //

        }


    }


    public List<MaterialTypeVO> getMaterialType() {

        ArrayList<MaterialTypeVO> list = new ArrayList<>();
        for (MaterialType statue : MaterialType.values()) {
            MaterialTypeVO materialTypeVO = new MaterialTypeVO();
            materialTypeVO.setCode(statue.getCode());
            materialTypeVO.setValue(statue.getName());
            list.add(materialTypeVO);
        }
        return list;
    }

    public void editWeldingMaterial(WeldingMaterialUpdateDTO dto) {


        WeldingMaterialDemandPlan copy = BeanUtil.copy(dto, WeldingMaterialDemandPlan.class);
        weldingMaterialsDemandPlanMapper.updateById(copy);
    }

    public void editPaint(PaintUpdateDTO dto) {

        PaintDemandPlan copy = BeanUtil.copy(dto, PaintDemandPlan.class);
        paintDemandPlanMapper.updateById(copy);
    }

    public void deleteProductDemandPlanTotal(ProductDemandPlanTotalDeleteDTO dto) {
        productDemandPlanTotalMapper.deleteById(dto.getId());

    }


    public void addPaintDemandPlan(BatchInsertOrUpdatePaintDemandPlanDTO dto) {
        List<PaintDemandPlanDTO> list = dto.getList();
        for (PaintDemandPlanDTO pdto : list) {
            PaintDemandPlan copy = BeanUtil.copy(pdto, PaintDemandPlan.class);
            paintDemandPlanMapper.insert(copy);
        }

    }

    public void addWeldingMaterialDemandPlan(BatchInsertOrUpdateWeldingMaterialDemandPlanDTO dto) {
        List<WeldingMaterialDemandPlanDTO> list = dto.getList();
        for (WeldingMaterialDemandPlanDTO wdto : list) {
            WeldingMaterialDemandPlan copy = BeanUtil.copy(wdto, WeldingMaterialDemandPlan.class);
            weldingMaterialsDemandPlanMapper.insert(copy);
        }

    }

    public PageResult<WeldingMaterialsVO> getWeldingDemandPlanList(WeldingMaterialDemandQueryPlanDTO dto) {

        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, WeldingMaterialDemandPlan::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .like(!CommonUtil.isNull(dto.getMaterialName()), WeldingMaterialDemandPlan::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getBrand()), WeldingMaterialDemandPlan::getBrand, dto.getBrand())
                .like(!CommonUtil.isNull(dto.getModel()), WeldingMaterialDemandPlan::getModel, dto.getModel());

        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        List<WeldingMaterialsVO> weldingMaterialsVOS = BeanUtil.copyList(weldingMaterialDemandPlans, WeldingMaterialsVO.class);
        List<WeldingMaterialsVO> collect = weldingMaterialsVOS.stream().peek(item -> {
            if(!CommonUtil.isNull(item.getCount())&&!CommonUtil.isNull(item.getBidPrice())&&item.getCount()!=0){
                item.setBidUnitPrice(100*(item.getBidPrice()/item.getCount()));

            }
            item.setMaterialType(MaterialType.WELDING_MATERIALS.getCode());
            item.setMaterialTypeText("焊材");
        }).collect(Collectors.toList());


        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<PaintVO> getPaintDemandPlanList(PaintDemandPlanQueryDTO dto) {
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, PaintDemandPlan::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .like(!CommonUtil.isNull(dto.getColour()), PaintDemandPlan::getColour, dto.getColour())
                .like(!CommonUtil.isNull(dto.getMaterialName()), PaintDemandPlan::getMaterialName, dto.getMaterialName());


        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        List<PaintVO> paintVOS = BeanUtil.copyList(paintDemandPlans, PaintVO.class);
        List<PaintVO> collect = paintVOS.stream().peek(item -> {
            if(!CommonUtil.isNull(item.getCount())&&!CommonUtil.isNull(item.getBidPrice())&&item.getCount()!=0){
                item.setBidUnitPrice(100*(item.getBidPrice()/item.getCount()));

            }
            item.setMaterialType(MaterialType.PAINT.getCode());
            item.setMaterialTypeText("油漆");
        }).collect(Collectors.toList());


        return PageUtil.convert2PageResult(collect, dto);
    }
    @Autowired
    private ProductDemandPlanDetailsMapper productDemandPlanDetailsMapper;
    public void generateProjectDemandPlan(ProjectGenerateDemandQueryDTO dto) {
            QueryWrapper<ProductDemandPlanDetails> mpjLambdaWrapper = new QueryWrapper<>();
            mpjLambdaWrapper.in("product_demand_plan_id",dto.getIdList());
        List<ProductDemandPlanDetails> productDemandPlanDetailsList = productDemandPlanDetailsMapper.selectList(mpjLambdaWrapper);
        List<ProjectDemandPlanGenerateVO> projectDemandPlanGenerateVOS = BeanUtil.copyList(productDemandPlanDetailsList, ProjectDemandPlanGenerateVO.class);
        Set<Integer> collectInteger = projectDemandPlanGenerateVOS.stream().map(item -> {
            String code = EnumUtil.getCode(DemandType.class, item.getMaterialType());
            Integer integer = Integer.valueOf(code);
            return integer;
        }).collect(Collectors.toSet());
        //新增批次
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId,dto.getProjectId());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        Integer max;

        Set<Integer> integerSet = projectDemandPlans.stream().map(item -> {
            Integer integer;
            if(CommonUtil.isNull(item.getProjectDemandPlanBatch())){
                integer=0;
            }else{ integer = Integer.valueOf(item.getProjectDemandPlanBatch().substring(1, item.getProjectDemandPlanBatch().length() - 2));
                }
            return integer;
        }).collect(Collectors.toSet());
        //已有批次最大值
        if(!CommonUtil.listIsNotEmpty(projectDemandPlans)){
            max=0;
        }else{ max = Collections.max(integerSet);}



        //id 字符串
        String[] arr = dto.getIdList();
        String idListString= Arrays.toString(arr).replace(" ","");

        for (Integer integer : collectInteger) {

           if (integer == 3) {
                /*                                                                        */
                ProjectDemandPlan bprojectDemandPlan=new ProjectDemandPlan();
                bprojectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt=  new Random().nextInt(10000)+10000;
                bprojectDemandPlan.setPlanNo("计划编号" + randomInt);
                bprojectDemandPlan.setDemandType(3);
                bprojectDemandPlan.setProjectDemandPlanBatch("第"+(max+1)+"批次");
                bprojectDemandPlan.setIdListString(idListString);
                projectDemandPlanMapper.insert(bprojectDemandPlan);
                List<ProjectDemandPlanGenerateVO> boardCollect  = projectDemandPlanGenerateVOS.stream().filter(item -> "板材".equals(item.getMaterialType())).collect(Collectors.toList());

                List<ProjectDemandPlanGenerateVO> collect = boardCollect.stream().peek(item -> {
                    if ("管".equals(item.getIngredientsType())) {
                        item.setMaterial(item.getId());
                    }

                }).collect(Collectors.toList());
                Map<String, List<ProjectDemandPlanGenerateVO>> boardCollect1 = collect.stream().collect(Collectors.groupingBy(key -> {
                    String format = String.format("%d-%d-%s", key.getFirstSize(), key.getSecondSize(), key.getMaterial());
                    return format;
                }));
                //按照规定的格式分组 合并成一个对象
                for (String s : boardCollect1.keySet()) {
                    List<ProjectDemandPlanGenerateVO> productDemandPlanDetails1 = boardCollect1.get(s);
                    if (productDemandPlanDetails1.size() > 0) {
                        ProjectDemandPlanGenerateVO generateVO = productDemandPlanDetails1.get(0);
                        ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                        productDemandPlanTotal.setProjectDemandPlanId(bprojectDemandPlan.getId());
                        productDemandPlanTotal.setMaterialType(1);
                        productDemandPlanTotal.setMaterialName(generateVO.getMaterialName());
                        ProductDemandPlanDetails execution = getProductDemandPlanDetails(productDemandPlanDetails1, generateVO);
                        productDemandPlanTotal.setSpecification(execution.getSpecification());
                        productDemandPlanTotal.setUnit(generateVO.getUseMaterialUnit());
                        //增加用料类型
                        productDemandPlanTotal.setIngredientsType(generateVO.getIngredientsType());
                        //后加的字段属性
                        if("管".equals(generateVO.getIngredientsType())){
                            productDemandPlanTotal.setTexture(productDemandPlanDetailsMapper.selectById(generateVO.getId()).getMaterial());
                        }else{   productDemandPlanTotal.setTexture(generateVO.getMaterial());}

                        productDemandPlanTotal.setDeliveryTime(generateVO.getDeliveryTime());
                        productDemandPlanTotal.setDeliveryLocation(generateVO.getDeliveryLocation());
                        Set<String> set = new HashSet<>();
                        for (ProjectDemandPlanGenerateVO projectDemandPlanGenerateVO : productDemandPlanDetails1) {
                            if (CommonUtil.isNull(projectDemandPlanGenerateVO.getWeight()) || CommonUtil.isNull(projectDemandPlanGenerateVO.getCount())) {
                                projectDemandPlanGenerateVO.setWeight(0L);
                                projectDemandPlanGenerateVO.setCount(0L);
                            }
                            set.add(projectDemandPlanGenerateVO.getPartNo());
                        }
                        StringBuilder builder = new StringBuilder();

                        for (String s1 : set) {
                            builder.append(s1);
                        }
                        productDemandPlanTotal.setPartNo(builder.toString());

                        Long sumWeight = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getWeight).sum();
                        Long sumCount = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getCount).sum();
                        Long sumSparePartsQuantity = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getSparePartsQuantity).sum();
                        productDemandPlanTotal.setSparePartsQuantity(sumSparePartsQuantity);
                        productDemandPlanTotal.setWeight(sumWeight);
                        productDemandPlanTotal.setCount(sumCount);
                        productDemandPlanTotal.setRemarks(generateVO.getRemarks());
                        productDemandPlanTotal.setBidPrice(generateVO.getDemandProposalPrice());
                        productDemandPlanTotalMapper.insert(productDemandPlanTotal);

                    }}
                /*                                               */
            } else if (integer == 4) {

                /*                                                */

                ProjectDemandPlan xprojectDemandPlan =new ProjectDemandPlan();
                xprojectDemandPlan.setProjectId(dto.getProjectId());
               int randomInt=  new Random().nextInt(10000)+10000;
                xprojectDemandPlan.setPlanNo("计划编号" + randomInt);
                xprojectDemandPlan.setProjectDemandPlanBatch("第"+(max+1)+"批次");
                xprojectDemandPlan.setIdListString(idListString);
                xprojectDemandPlan.setDemandType(4);
                projectDemandPlanMapper.insert(xprojectDemandPlan);
                //合并型材
                List<ProjectDemandPlanGenerateVO> collect= projectDemandPlanGenerateVOS.stream().filter(item -> "型材".equals(item.getMaterialType())).collect(Collectors.toList());
                List<ProjectDemandPlanGenerateVO> jcollect = collect.stream().filter(item -> "角钢".equals(item.getMaterialName())&&item.getIsCalculate()).collect(Collectors.toList());
                Map<String, List<ProjectDemandPlanGenerateVO>> jcollect1 = jcollect.stream().collect(Collectors.groupingBy(key -> {
                    String format = String.format("%s", key.getSpecification().split(",")[0]);
                    return format;
                }));
                for (String js : jcollect1.keySet()) {
                    List<ProjectDemandPlanGenerateVO> jproductDemandPlanDetails = jcollect1.get(js);
                    if (jproductDemandPlanDetails.size() > 0) {

                        ProjectDemandPlanGenerateVO jgenerateVO = jproductDemandPlanDetails.get(0);

                        ProductDemandPlanTotal jproductDemandPlanTotal = new ProductDemandPlanTotal();
                        jproductDemandPlanTotal.setProjectDemandPlanId(xprojectDemandPlan.getId());
                        jproductDemandPlanTotal.setMaterialType(2);
                        jproductDemandPlanTotal.setMaterialName(jgenerateVO.getMaterialName());
                        jproductDemandPlanTotal.setUnit(jgenerateVO.getUseMaterialUnit());
                        //增加用料类型
                        jproductDemandPlanTotal.setIngredientsType(jgenerateVO.getIngredientsType());
                        //后加的字段属性
                        jproductDemandPlanTotal.setTexture(jgenerateVO.getMaterial());
                        jproductDemandPlanTotal.setDeliveryTime(jgenerateVO.getDeliveryTime());
                        jproductDemandPlanTotal.setDeliveryLocation(jgenerateVO.getDeliveryLocation());
                        Set<String> jset = new HashSet<>();
                        for (ProjectDemandPlanGenerateVO projectDemandPlanGenerateVO : jproductDemandPlanDetails) {
                            if (CommonUtil.isNull(projectDemandPlanGenerateVO.getWeight()) || CommonUtil.isNull(projectDemandPlanGenerateVO.getCount())) {
                                projectDemandPlanGenerateVO.setWeight(0L);
                                projectDemandPlanGenerateVO.setCount(0L);
                            }
                            jset.add(projectDemandPlanGenerateVO.getPartNo());
                        }
                        StringBuilder jbuilder = new StringBuilder();

                        for (String s1 : jset) {
                            jbuilder.append(s1);
                        }
                        jproductDemandPlanTotal.setPartNo(jbuilder.toString());

                        Long jsumWeight = jproductDemandPlanDetails.stream().mapToLong(ProjectDemandPlanGenerateVO::getWeight).sum();
                        Long jsumCount = jproductDemandPlanDetails.stream().mapToLong(ProjectDemandPlanGenerateVO::getCount).sum();
                        int result = jproductDemandPlanDetails.stream().map(item -> item.getSpecification().split(",")[1].split("=")[1]).mapToInt(Integer::valueOf).sum();
                        //拆分规格里面的长度 ∠100*10，L=391
                        String s = jgenerateVO.getSpecification().split(",")[0];
                        String jresult = s + "," + "L=" + String.valueOf(result);
                        jproductDemandPlanTotal.setSpecification(jresult);
                        //新增备件数量
                        Long sumSparePartsQuantity = jproductDemandPlanDetails.stream().mapToLong(ProjectDemandPlanGenerateVO::getSparePartsQuantity).sum();
                        jproductDemandPlanTotal.setSparePartsQuantity(sumSparePartsQuantity);
                        jproductDemandPlanTotal.setWeight(jsumWeight);
                        jproductDemandPlanTotal.setCount(jsumCount);
                        jproductDemandPlanTotal.setRemarks(jgenerateVO.getRemarks());
                        jproductDemandPlanTotal.setBidPrice(jgenerateVO.getDemandProposalPrice());
                        productDemandPlanTotalMapper.insert(jproductDemandPlanTotal);}}
/***********************************************************************************************************************************************************/
                Map<String, List<ProjectDemandPlanGenerateVO>> collect1 = collect.stream().collect(Collectors.groupingBy(key -> {
                    String format = String.format("%d-%d-%s", key.getFirstSize(), key.getSecondSize(), key.getMaterial());
                    return format;
                }));
                //按照规定的格式分组 合并成一个对象
                for (String s : collect1.keySet()) {
                    List<ProjectDemandPlanGenerateVO> productDemandPlanDetails1 = collect1.get(s);
                    if (productDemandPlanDetails1.size() > 0) {

                        ProjectDemandPlanGenerateVO generateVO = productDemandPlanDetails1.get(0);

                        ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                        productDemandPlanTotal.setProjectDemandPlanId(xprojectDemandPlan.getId());
                        productDemandPlanTotal.setMaterialType(2);
                        productDemandPlanTotal.setMaterialName(generateVO.getMaterialName());

                        productDemandPlanTotal.setUnit(generateVO.getUseMaterialUnit());
                        //增加用料类型
                        productDemandPlanTotal.setIngredientsType(generateVO.getIngredientsType());
                        //后加的字段属性
                        productDemandPlanTotal.setTexture(generateVO.getMaterial());
                        productDemandPlanTotal.setDeliveryTime(generateVO.getDeliveryTime());
                        productDemandPlanTotal.setDeliveryLocation(generateVO.getDeliveryLocation());
                        Set<String> set = new HashSet<>();
                        for (ProjectDemandPlanGenerateVO projectDemandPlanGenerateVO : productDemandPlanDetails1) {
                            if (CommonUtil.isNull(projectDemandPlanGenerateVO.getWeight()) || CommonUtil.isNull(projectDemandPlanGenerateVO.getCount())) {
                                projectDemandPlanGenerateVO.setWeight(0L);
                                projectDemandPlanGenerateVO.setCount(0L);
                            }
                            set.add(projectDemandPlanGenerateVO.getPartNo());
                        }
                        StringBuilder builder = new StringBuilder();

                        for (String s1 : set) {
                            builder.append(s1);
                        }
                        productDemandPlanTotal.setPartNo(builder.toString());
                        //新增备件数量
                        Long sumSparePartsQuantity = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getSparePartsQuantity).sum();
                        productDemandPlanTotal.setSparePartsQuantity(sumSparePartsQuantity);
                        Long sumWeight = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getWeight).sum();
                        Long sumCount = productDemandPlanDetails1.stream().mapToLong(ProjectDemandPlanGenerateVO::getCount).sum();
                        ProductDemandPlanDetails execution = getProductDemandPlanDetails(productDemandPlanDetails1, generateVO);
                        productDemandPlanTotal.setSpecification(execution.getSpecification());
                        productDemandPlanTotal.setWeight(sumWeight);
                        productDemandPlanTotal.setCount(sumCount);
                        productDemandPlanTotal.setRemarks(generateVO.getRemarks());
                        productDemandPlanTotal.setBidPrice(generateVO.getDemandProposalPrice());
                        productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                    }
                }

                /*                                               */
            } else if(integer==5){

                /*                                                */
                List<ProjectDemandPlanGenerateVO> forgecollect = projectDemandPlanGenerateVOS.stream().filter(item -> "锻件".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
               int randomInt=  new Random().nextInt(10000)+10000;
                projectDemandPlan.setPlanNo("计划编号" + randomInt);
                projectDemandPlan.setProjectDemandPlanBatch("第"+(max+1)+"批次");
                projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(5);
                projectDemandPlanMapper.insert(projectDemandPlan);
                for (ProjectDemandPlanGenerateVO vo :forgecollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());

                    productDemandPlanTotal.setMaterialType(3);
                    productDemandPlanTotal.setPartNo(vo.getPartNo());
                    productDemandPlanTotal.setSparePartsQuantity(vo.getSparePartsQuantity());
                    productDemandPlanTotal.setMaterialName(vo.getMaterialName());
                    productDemandPlanTotal.setSpecification(vo.getSpecification());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setWeight(vo.getWeight());
                    productDemandPlanTotal.setCount(vo.getCount());
                    productDemandPlanTotal.setRemarks(vo.getRemarks());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    productDemandPlanTotal.setIngredientsType(vo.getIngredientsType());
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotal.setDeliveryTime(vo.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryLocation(vo.getDeliveryLocation());

                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }
                /*                                               */

            }
            else if(integer==6){

                /*                                                */
                List<ProjectDemandPlanGenerateVO> purcollect = projectDemandPlanGenerateVOS.stream().filter(item -> "外购件".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt=  new Random().nextInt(10000)+10000;
                projectDemandPlan.setPlanNo("计划编号" +randomInt);
                projectDemandPlan.setProjectDemandPlanBatch("第"+(max+1)+"批次");
                projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(6);
                projectDemandPlanMapper.insert(projectDemandPlan);
                for (ProjectDemandPlanGenerateVO vo :purcollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());

                    productDemandPlanTotal.setMaterialType(4);
                    productDemandPlanTotal.setSparePartsQuantity(vo.getSparePartsQuantity());
                    productDemandPlanTotal.setPartNo(vo.getPartNo());
                    productDemandPlanTotal.setMaterialName(vo.getMaterialName());
                    productDemandPlanTotal.setSpecification(vo.getSpecification());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setWeight(vo.getWeight());
                    productDemandPlanTotal.setCount(vo.getCount());
                    productDemandPlanTotal.setRemarks(vo.getRemarks());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    productDemandPlanTotal.setIngredientsType(vo.getIngredientsType());
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotal.setDeliveryTime(vo.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryLocation(vo.getDeliveryLocation());

                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }

                /*                                               */

            }
            else if(integer==7){

                /*                                                */
                List<ProjectDemandPlanGenerateVO> auxcollect = projectDemandPlanGenerateVOS.stream().filter(item -> "辅材".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt=  new Random().nextInt(10000)+10000;
                projectDemandPlan.setPlanNo("计划编号" +randomInt);
                projectDemandPlan.setProjectDemandPlanBatch("第"+(max+1)+"批次");
               projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(7);
                projectDemandPlanMapper.insert(projectDemandPlan);
                for (ProjectDemandPlanGenerateVO vo :auxcollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());

                    productDemandPlanTotal.setMaterialType(5);
                    productDemandPlanTotal.setSparePartsQuantity(vo.getSparePartsQuantity());
                    productDemandPlanTotal.setPartNo(vo.getPartNo());
                    productDemandPlanTotal.setMaterialName(vo.getMaterialName());
                    productDemandPlanTotal.setSpecification(vo.getSpecification());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setWeight(vo.getWeight());
                    productDemandPlanTotal.setCount(vo.getCount());
                    productDemandPlanTotal.setRemarks(vo.getRemarks());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    productDemandPlanTotal.setIngredientsType(vo.getIngredientsType());
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotal.setDeliveryTime(vo.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryLocation(vo.getDeliveryLocation());

                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }


                /*                                               */

            }
        }


    }
    /**
     * @author szp
     * @date 2022/11/16
     *   计算合并后的规则
     */
    private ProductDemandPlanDetails getProductDemandPlanDetails(List<ProjectDemandPlanGenerateVO> productDemandPlanDetails1, ProjectDemandPlanGenerateVO generateVO) {
        List<ProjectDemandPlanGenerateVO> collect = productDemandPlanDetails1.stream().peek(item -> {
            if(CommonUtil.isNull(item.getThirdSize())){item.setThirdSize(0l);}
        }).collect(Collectors.toList());
        Long sumThirdSize= collect.stream().mapToLong(ProjectDemandPlanGenerateVO::getThirdSize).sum();
        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, generateVO.getIngredientsType());
        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
        Class<? extends ComputerHandler> clazz = computerType.getClazz();
        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
        generateVO.setThirdSize(sumThirdSize);
        InsertDetailDTO copy = BeanUtil.copy(generateVO, InsertDetailDTO.class);
        copy.setProportion(generateVO.getProportion());
        ProductDemandPlanDetails execution = bean.execution(copy);
        return execution;
    }

    public void paintEditTimeAndLocation(EditTimeAndLocationDTO dto) {
        paintDemandPlanMapper.paintEditTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }

    public void deletePaintDemandPlan(PaintDemandPlanDeleteDTO dto) {
        paintDemandPlanMapper.deleteById(dto.getId());
    }

    public void deleteWeldingMaterialDemandPlan(WeldingMaterialDemandPlanDelteDTO dto) {
        weldingMaterialsDemandPlanMapper.deleteById(dto.getId());
    }

    public void weldingMaterialEditTimeAndLocation(EditTimeAndLocationDTO dto) {
        weldingMaterialsDemandPlanMapper.weldingMaterialEditTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }

    public PaintDemandPlanViewVO getPaintDemandPlanVO(PaintDemandPlanQueryOneDTO dto) {
        PaintDemandPlan paintDemandPlan = paintDemandPlanMapper.selectById(dto.getId());
        if(!CommonUtil.isNull(paintDemandPlan.getCount())&&!CommonUtil.isNull(paintDemandPlan.getBidPrice())&&paintDemandPlan.getCount()!=0){
            paintDemandPlan.setBidUnitPrice(100*(paintDemandPlan.getBidPrice()/paintDemandPlan.getCount()));

        }

        return BeanUtil.copy(paintDemandPlan, PaintDemandPlanViewVO.class);
    }

    public WeldingMaterialDemandPlanViewVO getWeldingMaterialDemandPlanVO(WeldingMaterialDemandPlanQueryOneDTO dto) {

        WeldingMaterialDemandPlan weldingMaterialDemandPlan = weldingMaterialsDemandPlanMapper.selectById(dto.getId());
        if(!CommonUtil.isNull(weldingMaterialDemandPlan.getCount())&&!CommonUtil.isNull(weldingMaterialDemandPlan.getBidPrice())&&weldingMaterialDemandPlan.getCount()!=0){
            weldingMaterialDemandPlan.setBidUnitPrice(100*(weldingMaterialDemandPlan.getBidPrice()/weldingMaterialDemandPlan.getCount()));

        }

        return BeanUtil.copy(weldingMaterialDemandPlan, WeldingMaterialDemandPlanViewVO.class);
    }

    public void productDemandPlanTotalRead(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {

        LinkedList<BoardImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), BoardImportVO.class, MaterialType.BOARD.getName());
        file.getInputStream().close();
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.BOARD.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }}
            for (int i = 0; i < 2; i++) {
                list.poll();
            }
            list.stream().forEach(item -> {
                if (!CommonUtil.isNull(item.getId())) {
                    ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                    copy.setMaterialType(MaterialType.BOARD.getCode());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                    Date parse=new Date();
                    try {
                        if(item.getDeliveryTime().contains("-")){
                            parse = sdf.parse(item.getDeliveryTime());
                        }else if(item.getDeliveryTime().contains("/")){
                            parse=format.parse(item.getDeliveryTime());
                        }

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    copy.setDeliveryTime(parse);
                    copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                    productDemandPlanTotalMapper.insert(copy);
                }
            });


    }
    /**
     *
     * @author szp
     * @date 2023/3/8 17:35
     */
    public List<MaterialTypeDescriptionViewVO> getMaterialEntityViewVOList(MaterialTypeQueryDTO dto) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId())
                .eq(ProjectDemandPlan::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);

        for (ProjectDemandPlan projectDemandPlan : projectDemandPlans) {
            if (projectDemandPlan.getDemandType() == DemandType.PAINT.getCode()) {

                MaterialTypeDescription materialTypeDescription = new MaterialTypeDescription();
                materialTypeDescription.setRemarks("");
                materialTypeDescription.setProjectDemandPlanBatch(projectDemandPlan.getProjectDemandPlanBatch());
                materialTypeDescription.setMaterialType(MaterialType.PAINT.getName());
                materialTypeDescription.setProjectId(dto.getProjectId());
                MPJLambdaWrapper<MaterialTypeDescription> materialTypeDescriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
                materialTypeDescriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                        .eq(MaterialTypeDescription::getMaterialType, MaterialType.PAINT.getName())
                        .eq(MaterialTypeDescription::getProjectId, dto.getProjectId());
                MaterialTypeDescription description = materialTypeDescriptionMapper.selectOne(materialTypeDescriptionMPJLambdaWrapper);
                if (CommonUtil.isNull(description)) {
                    materialTypeDescriptionMapper.insert(materialTypeDescription);
                }

            }

            if (projectDemandPlan.getDemandType() == DemandType.WELDING_MATERIALS.getCode()) {

                MaterialTypeDescription materialTypeDescription = new MaterialTypeDescription();
                materialTypeDescription.setProjectDemandPlanBatch(projectDemandPlan.getProjectDemandPlanBatch());
                materialTypeDescription.setRemarks("");
                materialTypeDescription.setMaterialType(MaterialType.WELDING_MATERIALS.getName());
                materialTypeDescription.setProjectId(dto.getProjectId());
                MPJLambdaWrapper<MaterialTypeDescription> materialTypeDescriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
                materialTypeDescriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                        .eq(MaterialTypeDescription::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch())
                        .eq(MaterialTypeDescription::getMaterialType, MaterialType.WELDING_MATERIALS.getName())
                        .eq(MaterialTypeDescription::getProjectId, dto.getProjectId());
                MaterialTypeDescription description = materialTypeDescriptionMapper.selectOne(materialTypeDescriptionMPJLambdaWrapper);
                if (CommonUtil.isNull(description)) {
                    materialTypeDescriptionMapper.insert(materialTypeDescription);
                }
            }

            if (projectDemandPlan.getDemandType() !=DemandType.PAINT.getCode()&&projectDemandPlan.getDemandType() !=DemandType.WELDING_MATERIALS.getCode()) {
                String str = projectDemandPlan.getIdListString().substring(1, projectDemandPlan.getIdListString().length()-1);
                String[] split = str.split(",");

                ArrayList<String> strings = new ArrayList<String>();
                for (String s : split) {
                    strings.add(s);
                }
                MPJLambdaWrapper<ProductDemandPlan> mpjLambdaWrapper = new MPJLambdaWrapper();
                mpjLambdaWrapper.selectAll(ProductDemandPlan.class)
                        .in(CommonUtil.listIsNotEmpty(strings),ProductDemandPlan::getId,strings);
                List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(mpjLambdaWrapper);

                ArrayList<MaterialTypeEntity> materialTypeEntities = new ArrayList<>();
                if(CommonUtil.listIsNotEmpty(productDemandPlans)){
                    for (ProductDemandPlan productDemandPlan : productDemandPlans) {
                    MPJLambdaWrapper<MaterialTypeEntity> lambdaWrapper = new MPJLambdaWrapper<>();
                    lambdaWrapper.selectAll(MaterialTypeEntity.class)
                            .eq(MaterialTypeEntity::getProductInformationId,productDemandPlan.getProductInformationId())
                            .eq(MaterialTypeEntity::getBatch,productDemandPlan.getBatch());
                    List<MaterialTypeEntity> entities = materialTypeMapper.selectList(lambdaWrapper);
                    materialTypeEntities.addAll(entities);

                }}
                Map<String, List<MaterialTypeEntity>> collect = materialTypeEntities.stream().collect(Collectors.groupingBy(MaterialTypeEntity::getMaterialType));

                for (String s : collect.keySet()) {
                    Set<String> set = new HashSet();
                    for (MaterialTypeEntity material : collect.get(s)) {
                        if (!CommonUtil.isNull(material.getRemarks())) {
                            set.add(material.getRemarks());
                        }
                    }
                    StringBuilder builder = new StringBuilder();
                    for (String string : set) {
                        builder.append(string);
                    }
                    String substring = null;
                    if (builder.toString().length() > 250) {
                        substring = builder.toString().substring(0, 250);
                    } else {
                        substring = builder.toString();
                    }
                    MaterialTypeDescription materialTypeDescription = new MaterialTypeDescription();
                    materialTypeDescription.setRemarks(substring);
                    materialTypeDescription.setProjectDemandPlanBatch(projectDemandPlan.getProjectDemandPlanBatch());
                    materialTypeDescription.setMaterialType(s);
                    materialTypeDescription.setProjectId(dto.getProjectId());

                    MPJLambdaWrapper<MaterialTypeDescription> materialTypeDescriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
                    materialTypeDescriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                            .eq(MaterialTypeDescription::getMaterialType, s)
                            .eq(MaterialTypeDescription::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch())
                            .eq(MaterialTypeDescription::getProjectId, dto.getProjectId());
                    MaterialTypeDescription description = materialTypeDescriptionMapper.selectOne(materialTypeDescriptionMPJLambdaWrapper);
                    if (CommonUtil.isNull(description) || description.getMaterialType() == null) {
                        materialTypeDescriptionMapper.insert(materialTypeDescription);
                    }
                }

            }

        }
        MPJLambdaWrapper<MaterialTypeDescription> materialWrapper = new MPJLambdaWrapper<>();
        materialWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, dto.getProjectId())
                .eq(MaterialTypeDescription::getProjectDemandPlanBatch,dto.getProjectDemandPlanBatch());
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(materialWrapper);
        List<MaterialTypeDescriptionViewVO> materialTypeDescriptionViewVOS = BeanUtil.copyList(materialTypeDescriptions, MaterialTypeDescriptionViewVO.class);
        return materialTypeDescriptionViewVOS;
    }


    public void editMaterialType(MaterialTypeEditDTO dto) {
        MaterialTypeDescription copy = BeanUtil.copy(dto, MaterialTypeDescription.class);
        materialTypeDescriptionMapper.updateById(copy);


    }

    @Autowired
    private ProductDemandPlanService productDemandPlanService;
    public void exportBoard(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.BOARD.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if(!CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ProductDemandPlanTotalExportVO> list = BeanUtil.copyList(productDemandPlanTotals, ProductDemandPlanTotalExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
//            MaterialTextureVO materialTexture = productDemandPlanService.getMaterialTexture(item.getTexture());
            //根据材质解析
            /**
             * 根据材质表id获取用料类型
             *  根据用料类型，解析出尺寸
             */
            ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
            ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
            Class<? extends ComputerHandler> clazz = computerType.getClazz();
            ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
            bean.analysis(item);
            //备注加上备件数量{}
            item.setRemarks(item.getRemarks()==null?"":item.getRemarks()+"备件数量"+item.getSparePartsQuantity().doubleValue()/100+"件");
            //设置材质
            item.setMaterial(item.getTexture());
            //设置数量(数量+备件数量)
            item.setCountExport(item.getCount().doubleValue()/100+item.getSparePartsQuantity().doubleValue()/100);
            if (item.getWeight()!=null){
                item.setWeightExport(item.getWeight().doubleValue()/100);
            }else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("板材"), 5, List.of(10, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("板材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(),5 + list.size(), 1, 12))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/template2.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("项目需求计划导出", response, resourceAsStream,writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "板材");

        //计算列总和
        double total = list.stream().mapToDouble(ProductDemandPlanTotalExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String param1 = projectDemandPlan.getManufacturingNumber()!=null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo()!=null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1",param1);
        data.put("param2",param2);
        data.put("total",total);
        excelExportService.fill(data, "板材");


        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> materialTypeVOS = productDemandPlanService.getMaterialType();
        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> collect = materialTypeVOS.stream().filter(o -> o.getMaterialType().equals("板材")).collect(Collectors.toList());
        //备注数据
        String remarks = collect.get(0).getRemarks();
        List<RemarkVO> remarkVOS = new ArrayList<>();
        if(!CommonUtil.isNull(remarks)){
            remarkVOS = new ArrayList<>();
            String[] split = remarks.split("\n");
            for (int j = 0; j < split.length; j++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(j + 1);
                remarkVO.setContent(split[j]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "板材");

        excelExportService.export();
    }

    public void weldingExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        /**
         * 焊材导出
         *  根据项目需求计划表id查询焊材需求计划
         */
        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(!CommonUtil.isNull(dto.getProjectDemandPlanId()),WeldingMaterialDemandPlan::getProjectDemandPlanId,dto.getProjectDemandPlanId());
        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        if(!CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<WeldingMaterialsExportVO> list = BeanUtil.copyList(weldingMaterialDemandPlans, WeldingMaterialsExportVO.class);
        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setId(String.valueOf(atomicInteger.incrementAndGet()));
            //计算总重
                  if(CommonUtil.isNull(item.getCount())){
                      item.setCount(1);
                  }
            item.setTotalWeight(item.getWeight().doubleValue()/100 *item.getCount());
        });
        //计算重量总和
        double total = list.stream().mapToDouble(WeldingMaterialsExportVO::getTotalWeight).sum();
        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("焊材报料"), 4, List.of(9, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("焊材报料"), 4 + list.size(), List.of(new CellRangeAddress(4 + list.size(), 4 + list.size(), 1, 10))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/weldTemplate.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("焊材报料", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //工程名称:项目需求计划表关联id，查询获得项目id
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        ProjectVO projectVO = projectService.getById(projectDemandPlan.getProjectId());
        String param1 = projectVO.getProjectName();
        //计划编号
        String param2 = projectDemandPlan.getPlanNo();

        HashMap<String, Object> data = new HashMap<>();
        //自定义参数数据
        //焊材列表页面
        data.put("param1", param1);
        data.put("param2", projectDemandPlan.getPlanNo());
        data.put("param3", projectDemandPlan.getCompiler());
        data.put("param4", projectDemandPlan.getProofreader());
        data.put("param5", projectDemandPlan.getReviewer());
        data.put("param6", projectDemandPlan.getChecker());
        data.put("total", total);
        //备注
        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId,projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType,"焊材");
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
   if(CommonUtil.listIsNotEmpty(materialTypeDescriptions)){
       String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
     remarkVOS = new ArrayList<>();
       for (int i = 0; i < split.length; i++) {
           RemarkVO remarkVO = new RemarkVO();
           remarkVO.setSeq(i + 1);
           remarkVO.setContent(split[i]);
           remarkVOS.add(remarkVO);
       }
   }
        excelExportService.fill(new FillWrapper("list", list), "焊材报料");
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "焊材报料");
        excelExportService.fill(data, "焊材报料");
        //封面
        HashMap<String, Object> map = new HashMap<>();
        map.put("param2",param2);
        map.put("organization", projectDemandPlan.getCompiler());
        map.put("organizationTime",projectDemandPlan.getCompileTime());
        map.put("engineer",projectDemandPlan.getProofreader());
        map.put("process",projectDemandPlan.getProofreadingTime());
        map.put("manager",projectDemandPlan.getReviewer());
        map.put("reviewTime",projectDemandPlan.getReviewTime());
        map.put("approval",projectDemandPlan.getChecker());
        map.put("approvalTime",projectDemandPlan.getCheckTime());
        map.put("projectNo",projectVO.getProjectNo());
        map.put("projectName",projectVO.getProjectName());
        excelExportService.fill(map, "封面");
        //编制说明
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("explain",projectDemandPlan.getPreparationDescription());
        excelExportService.fill(hashMap, "编制说明");
        excelExportService.export();
    }

    public void paintExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        /**
         * 油漆导出
         *
         *
         */
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(!CommonUtil.isNull(dto.getProjectDemandPlanId()),PaintDemandPlan::getProjectDemandPlanId,dto.getProjectDemandPlanId());
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        if(!CommonUtil.listIsNotEmpty(paintDemandPlans)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<PaintExportVO> list = BeanUtil.copyList(paintDemandPlans, PaintExportVO.class);
        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(Integer.valueOf(atomicInteger.incrementAndGet()));
            //计算总面积
            item.setTotalArea(item.getArea().doubleValue()/100 * item.getCount());
        });

        //计算面积总和
        double total = list.stream().mapToDouble(PaintExportVO::getTotalArea).sum();
        log.info("导出的数据：{}",list);
        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("油漆"), 4, List.of(9, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("油漆"), 4 + list.size(), List.of(new CellRangeAddress(4 + list.size(), 4 + list.size(), 1, 10))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/paintTemplate.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("油漆", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //工程名称:项目需求计划表关联id，查询获得项目id
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        ProjectVO projectVO = projectService.getById(projectDemandPlan.getProjectId());
        String param1 = projectVO.getProjectName();
        //计划编号
        String param2 = projectDemandPlan.getPlanNo();
        //编号
        String param3=projectVO.getProjectNo();

        HashMap<String, Object> data = new HashMap<>();
        //自定义参数数据
        //焊材列表页面
        data.put("param1", param1);
        data.put("param2", projectDemandPlan.getPlanNo());
        data.put("param3",param3);
        data.put("total", total);
        //备注
        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId,projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType,"油漆");
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
         if(CommonUtil.listIsNotEmpty(materialTypeDescriptions)){
             String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
             log.info("备注：{}",split[0]);
             remarkVOS = new ArrayList<>();
             for (int i = 0; i < split.length; i++) {
                 RemarkVO remarkVO = new RemarkVO();
                 remarkVO.setSeq(i + 1);
                 remarkVO.setContent(split[i]);
                 remarkVOS.add(remarkVO);
             }
         }
        List<PaintExportVO> collect = list.stream().peek(item -> item.setMaterialNameAndSize(item.getMaterialName()+item.getSize())).collect(Collectors.toList());
        excelExportService.fill(new FillWrapper("list",collect), "油漆");
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "油漆");
        excelExportService.fill(data, "油漆");
        //封面
        HashMap<String, Object> map = new HashMap<>();
        map.put("param1",param1);
        map.put("param2",param2);
        map.put("param3",param3);
        map.put("organization", projectDemandPlan.getCompiler());
        map.put("organizationTime",projectDemandPlan.getCompileTime());
        map.put("engineer",projectDemandPlan.getProofreader());
        map.put("process",projectDemandPlan.getProofreadingTime());
        map.put("manager",projectDemandPlan.getReviewer());
        map.put("reviewTime",projectDemandPlan.getReviewTime());
        map.put("approval",projectDemandPlan.getChecker());
        map.put("approvalTime",projectDemandPlan.getCheckTime());
        map.put("projectNo",projectVO.getProjectNo());
        map.put("projectName",projectVO.getProjectName());
        excelExportService.fill(map, "封面展示");
        //编制说明
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("explain",projectDemandPlan.getPreparationDescription());
        excelExportService.fill(hashMap, "编制说明");
        excelExportService.export();
    }

    /**
     * 根据项目id和物资类型查询计划编号
     * @param projectId
     * @param materialType
     * @return
     */
    public String selectPlanNoByProjectId(String projectId, Integer materialType) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProjectDemandPlan::getPlanNo)
                .eq(!CommonUtil.isNull(projectId),ProjectDemandPlan::getProjectId,projectId);
        if(materialType.equals(MaterialType.WELDING_MATERIALS.getCode())){
            //焊材
            wrapper.eq(ProjectDemandPlan::getDemandType,1);
        }else if (materialType.equals(MaterialType.PAINT.getCode())){
            wrapper.eq(ProjectDemandPlan::getDemandType,2);
        }else {
            wrapper.eq(ProjectDemandPlan::getDemandType,3);
        }
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectOne(wrapper);
        return CommonUtil.isNull(projectDemandPlan) ? "" : projectDemandPlan.getPlanNo() ;
    }

    public List<LockStockData> getLockStockData(QueryLockStockDataDTO dto) {
        /**
         *  在物资表中查询没有关联项目的物资
         *      如果是产品类型，根据材料名称、材质和规格，在库存表里面匹配
         *      如果时油漆类型，根据颜色在库存表里面匹配
         *      如果是焊材类型，根据名称、型号和规格匹配
         *   将匹配结果返回（包含库存id，库存数量（填写锁库数量要比较））
         *   锁库时，将项目需求明细id、库存id、锁库数量传到后台，在锁库表进行批量新增
         *   锁库完成，更新项目需求数量中的锁库数量，减少库存表里面的库存数量
         *   //2023/02/13 锁库数据：从该项目下的调拨记录中的数据中锁库
         */
        List<LockStockData> lockStockData = stockManagementService.selectByColorAndMaterialType(dto,null);
        List<LockStockData> data = stockTransferService.getTransferByProject(dto);
        if(CommonUtil.listIsNotEmpty(lockStockData)){
            lockStockData.addAll(data);
            return lockStockData;
        }else if (CommonUtil.listIsNotEmpty(data)){
            data.addAll(lockStockData);
            return data;
        }else {
            return null;
        }
    }


    public void lockStock(LockStockMoreDTO dto) {
        //填写的锁库数量  <=需求数量-锁库数量     <=库存数量
        //多个锁库，将锁库数量累加起来，就是这个材料被锁库的数量
        List<LockStockDTO> list = dto.getList();
        Long stockNUmber = list.stream().mapToLong(LockStockDTO::getLockStockNumber).sum();
        if (list.get(0).getMaterialType().equals(MaterialType.PAINT.getCode())){
            //油漆
            PaintDemandPlan paintDemandPlan = paintDemandPlanMapper.selectById(list.get(0).getProjectDemandDetailId());
            if (paintDemandPlan.getCount()<stockNUmber-paintDemandPlan.getStockAmount()){
                throw new RuntimeException("锁库数量需小于等于需求数量！");
            }
        } else if (list.get(0).getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
            WeldingMaterialDemandPlan weldingMaterialDemandPlan = weldingMaterialsDemandPlanMapper.selectById(list.get(0).getProjectDemandDetailId());
            if (weldingMaterialDemandPlan.getWeight()<stockNUmber-weldingMaterialDemandPlan.getStockAmount()){
                throw new RuntimeException("锁库重量需小于等于需求数量！");
            }
        }else {
            ProductDemandPlanTotal productDemandPlanTotal = productDemandPlanTotalMapper.selectById(list.get(0).getProjectDemandDetailId());
            if (productDemandPlanTotal.getCount()<stockNUmber-productDemandPlanTotal.getStockAmount()){
                throw new RuntimeException("锁库数量需小于等于需求数量！");
            }
        }
        list.stream().forEach( item -> {
            //锁库数量 <= 库存数量
            MaterialStockVO materialStockVO = stockManagementService.getMaterialStockById(item.getMaterialStockId());
            if(materialStockVO.getStockBalance() < item.getLockStockNumber()){
                throw new RuntimeException("锁库数量不能大于库存余量");
            }
        });

        List<LockStock> lockStocks = BeanUtil.copyList(list, LockStock.class);
        lockStocks.stream().forEach( item -> {
            item.setStockType("锁库存");
        });
        Integer integer = lockStockMapper.insertBatchSomeColumn(lockStocks);
        if (integer>0){
            //新增锁库，，
            //更新项目需求数量中的锁库数量
            /**
             * 根据物资类型确定更新哪张表中的锁库数量
             */
            if (list.get(0).getMaterialType().equals(MaterialType.PAINT.getCode())){
                //油漆
                this.updatePaintStockAmount(list.get(0).getProjectDemandDetailId(),stockNUmber,1);
            } else if (list.get(0).getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                //焊材
                this.updateWeldStockAmount(list.get(0).getProjectDemandDetailId(),stockNUmber,1);
            }else{
                //产品
                this.updateDetailStockAmount(list.get(0).getProjectDemandDetailId(),stockNUmber,1);
            }
            //减少库存表里面的库存数量
            list.stream().forEach( item -> {
                //根据物资表id，更新库存数量和锁库数量
                stockManagementService.updateStockAndLockNumber(item.getMaterialStockId(),item.getLockStockNumber());
            });
        }

    }

    /**
     *  项目需求计划汇总表  更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updateDetailStockAmount(String projectDemandDetailId, Long stockNUmber,Integer stockType) {
        UpdateWrapper<ProductDemandPlanTotal> wrapper = new UpdateWrapper<>();
        wrapper.eq("id",projectDemandDetailId)
                .set("stock_type",stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = productDemandPlanTotalMapper.update(new ProductDemandPlanTotal(), wrapper);
        if (update>0){
            log.info("产品的锁库数量更新了：{}",stockNUmber);
        }
    }

    /**
     *  焊材表 更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updateWeldStockAmount(String projectDemandDetailId, Long stockNUmber,Integer stockType) {
        UpdateWrapper<WeldingMaterialDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("id",projectDemandDetailId)
                .set("stock_type",stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = weldingMaterialsDemandPlanMapper.update(new WeldingMaterialDemandPlan(), wrapper);
        if (update>0){
            log.info("焊材的锁库数量更新了：{}",stockNUmber);
        }

    }

    /**
     *  油漆表  更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updatePaintStockAmount(String projectDemandDetailId, Long stockNUmber,Integer stockType) {
        UpdateWrapper<PaintDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("id",projectDemandDetailId)
                .set("stock_type",stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = paintDemandPlanMapper.update(new PaintDemandPlan(), wrapper);
        if (update>0){
            log.info("油漆的锁库数量更新了：{}",stockNUmber);
        }
    }

    /**
     *  在余料表中，根据余料名称、规格和材质匹配符合锁余料的数据
     * @param dto
     * @return
     */
    public List<MaterialRemainData> getMaterialRemainData(QueryMaterialRemainDataDTO dto) {
        List<MaterialRemainData> materialRemainData = materialRemainService.getByNameAndSpecification(dto.getMaterialName(),dto.getTexture(),dto.getSpecification());
        return materialRemainData;
    }

    public void lockRemain(LockRemainMoreDTO dto) {
        /**
         *  锁余料数量  <= 需求数量 - 锁余料数量    <=  余料数量（前端传过来）
         */
        List<MaterialRemainDTO> list = dto.getList();
        long sum = list.stream().mapToLong(MaterialRemainDTO::getLockStockNumber).sum();
        list.stream().forEach( item -> {
            if (item.getLockStockNumber()>item.getRemainingMaterialCount()){
                throw new RuntimeException("锁余料数量应该小于等于余料数量");
            }
        });
        if (sum> list.get(0).getCount() - list.get(0).getStockAmount()){
            throw new RuntimeException("锁余料数量应该小于需求数量");
        }
        List<LockStock> lockStocks = BeanUtil.copyList(list, LockStock.class);
        lockStocks.stream().forEach( item -> {
            item.setStockType("锁余料");
        });
        Integer integer = lockStockMapper.insertBatchSomeColumn(lockStocks);
        if (integer>0){
            //新增锁库，，
            //更新项目需求数量中的锁库数量
            /**
             * 根据物资类型确定更新哪张表中的锁库数量
             */

            if (list.get(0).getMaterialType().equals(MaterialType.PAINT.getCode())){
                //油漆
                this.updatePaintStockAmount(list.get(0).getProjectDemandDetailId(),sum,2);
            } else if (list.get(0).getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                //焊材
                this.updateWeldStockAmount(list.get(0).getProjectDemandDetailId(),sum,2);
            }else{
                //产品
                this.updateDetailStockAmount(list.get(0).getProjectDemandDetailId(),sum,2);
            }
            //减少库存表里面的库存数量
            list.stream().forEach( item -> {
                //根据余料表id，更新库存数量和锁库数量
                materialRemainService.updateStockAndLockNumber(item.getMaterialStockId(),item.getLockStockNumber());
            });
        }
    }

    public List<LockStockVO> getLockStock(QueryLockStockDTO dto) {

        /**
         * 根据项目需求计划详情id，在锁库表中查询
         *  返回的VO展示库存表的主要信息 和 锁库数量  已领数量  锁库类型
         *  关联查询
         */
        MPJLambdaWrapper<LockStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(LockStock.class)
                .selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getId()),LockStock::getProjectDemandDetailId,dto.getId())
                .leftJoin(MaterialStock.class,MaterialStock::getId,LockStock::getMaterialStockId);
        List<LockStockVO> lockStockVOS = lockStockMapper.selectJoinList(LockStockVO.class, wrapper);
        return lockStockVOS;
    }

    public void deleteOneProjectDemandPlan(ProjectDemandPlanDeleteOneDTO dto) {
        int i = projectDemandPlanMapper.deleteById(dto.getId());
        if(i>0){switch (dto.getDemandType()){

            case 1:
                MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingMaterialWrapper = new MPJLambdaWrapper<>();
                weldingMaterialWrapper.selectAll(WeldingMaterialDemandPlan.class)
                        .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId,dto.getId());
                List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans =weldingMaterialsDemandPlanMapper.selectList(weldingMaterialWrapper);
                for (WeldingMaterialDemandPlan weldingMaterialDemandPlan : weldingMaterialDemandPlans) {
                    weldingMaterialsDemandPlanMapper.deleteById(weldingMaterialDemandPlan);
                }
                break;
            case 2:
                MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
                paintWrapper.selectAll(PaintDemandPlan.class)
                        .eq(PaintDemandPlan::getProjectDemandPlanId,dto.getId());
                List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
                for (PaintDemandPlan paintDemandPlan : paintDemandPlans) {
                    paintDemandPlanMapper.deleteById(paintDemandPlan);
                }
                break;
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                MPJLambdaWrapper<ProductDemandPlanTotal> planTotalLambdaWrapper = new MPJLambdaWrapper<>();
                planTotalLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                        .eq(ProductDemandPlanTotal::getProjectDemandPlanId,dto.getId());
                List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalLambdaWrapper);
                for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                    productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
                }
                break;
            default:
                break;
        }
        }


    }

    public PageResult<ProductTotalVO> getProductDataList(ProductDemandPlanTotalQueryDTO dto) {

        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq( ProductDemandPlanTotal::getMaterialType, dto.getDemandType()-2)
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> {
                    if (!CommonUtil.isNull(item.getCount()) && !CommonUtil.isNull(item.getBidPrice())&&item.getCount()!=0) {
                        item.setBidUnitPrice(100*(item.getBidPrice() / item.getCount()));
                    }
                    item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
                }
        ).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getProfileList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq( ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getForgePieceList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq( ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getPurchasedPartsList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq( ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getAuxiliaryMaterialsList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq( ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public void profileExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if(!CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ProfileExportVO> list = BeanUtil.copyList(productDemandPlanTotals, ProfileExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
//            MaterialTextureVO materialTexture = productDemandPlanService.getMaterialTexture(item.getTexture());
            //根据材质解析
            /**
             * 根据材质表id获取用料类型
             *  根据用料类型，解析出尺寸
             */
            ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
            ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
            Class<? extends ComputerHandler> clazz = computerType.getClazz();
            ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
            bean.analysis(item);

            //设置材质
            item.setMaterial(item.getTexture());
            //备注加上备件数量{}
            //备注加上备件数量{}
            item.setRemarks(item.getRemarks()==null?"":item.getRemarks()+"备件数量"+item.getSparePartsQuantity().doubleValue()/100+"件");
            //设置数量(数量+备件数量)
            item.setCountExport(item.getCount().doubleValue()/100+item.getSparePartsQuantity().doubleValue()/100);
            if (item.getWeight()!=null){
                item.setWeightExport(item.getWeight().doubleValue()/100);
            }else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("一台管材型材"), 5, List.of(10, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("一台管材型材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(),5 + list.size(), 1, 12))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/profile.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("项目需求计划导出", response, resourceAsStream,writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "一台管材型材");

        //计算列总和
        double total = list.stream().mapToDouble(ProfileExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String param1 = projectDemandPlan.getManufacturingNumber()!=null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo()!=null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1",param1);
        data.put("param2",param2);
        data.put("total",total);
        excelExportService.fill(data, "一台管材型材");


        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> materialTypeVOS = productDemandPlanService.getMaterialType();
        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> collect = materialTypeVOS.stream().filter(o -> o.getMaterialType().equals("型材")).collect(Collectors.toList());
        //备注数据
        String remarks = collect.get(0).getRemarks();
        List<RemarkVO> remarkVOS = new ArrayList<>();
        if(!CommonUtil.isNull(remarks)){
            remarkVOS = new ArrayList<>();
            String[] split = remarks.split("\n");
            for (int j = 0; j < split.length; j++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(j + 1);
                remarkVO.setContent(split[j]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "一台管材型材");

        excelExportService.export();
    }

    public void forgePieceExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if(!CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ForgePieceExportVO> list = BeanUtil.copyList(productDemandPlanTotals, ForgePieceExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            item.setRemarks(item.getRemarks()==null?"":item.getRemarks()+"备件数量"+item.getSparePartsQuantity().doubleValue()/100+"件");
            //设置材质
            item.setMaterial(item.getTexture());
            //设置名称与规格
            item.setMaterialNameAndSpecification(item.getMaterialName()+item.getSpecification());
            //设置数量(数量+备件数量)
            item.setCountExport(item.getCount().doubleValue()/100+item.getSparePartsQuantity().doubleValue()/100);
            if (item.getWeight()!=null){
                item.setWeightExport(item.getWeight().doubleValue()/100);
            }else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("锻件"), 5, List.of(10, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("锻件"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(),5 + list.size(), 1, 12))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/forgepiece.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("项目需求计划导出", response, resourceAsStream,writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "锻件");

        //计算列总和
        double total = list.stream().mapToDouble(ForgePieceExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String param1 = projectDemandPlan.getManufacturingNumber()!=null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo()!=null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1",param1);
        data.put("param2",param2);
        data.put("total",total);
        excelExportService.fill(data, "锻件");


        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> materialTypeVOS = productDemandPlanService.getMaterialType();
        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> collect = materialTypeVOS.stream().filter(o -> o.getMaterialType().equals("锻件")).collect(Collectors.toList());
        //备注数据
        String remarks = collect.get(0).getRemarks();
        List<RemarkVO> remarkVOS = new ArrayList<>();
        if(!CommonUtil.isNull(remarks)){
            remarkVOS = new ArrayList<>();
            String[] split = remarks.split("\n");
            for (int j = 0; j < split.length; j++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(j + 1);
                remarkVO.setContent(split[j]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "锻件");

        excelExportService.export();
    }

    public void purchasedPartsExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {

        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if(!CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<PurchasedPartsExportVO> list = BeanUtil.copyList(productDemandPlanTotals, PurchasedPartsExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            item.setRemarks(item.getRemarks()==null?"":item.getRemarks()+"备件数量"+item.getSparePartsQuantity().doubleValue()/100+"件");
            //设置材质
            item.setMaterial(item.getTexture());
            //设置名称与规格
            item.setMaterialNameAndSpecification(item.getMaterialName()+item.getSpecification());
            //设置数量(数量+备件数量)
            item.setCountExport(item.getCount().doubleValue()/100+item.getSparePartsQuantity().doubleValue()/100);
            if (item.getWeight()!=null){
                item.setWeightExport(item.getWeight().doubleValue()/100);
            }else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("外购件"), 5, List.of(10, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("外购件"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(),5 + list.size(), 1, 12))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/purchasedparts.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("项目需求计划导出", response, resourceAsStream,writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "外购件");

        //计算列总和
        double total = list.stream().mapToDouble(PurchasedPartsExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String param1 = projectDemandPlan.getManufacturingNumber()!=null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo()!=null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1",param1);
        data.put("param2",param2);
        data.put("total",total);
        excelExportService.fill(data, "外购件");


        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> materialTypeVOS = productDemandPlanService.getMaterialType();
        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> collect = materialTypeVOS.stream().filter(o -> o.getMaterialType().equals("外购件")).collect(Collectors.toList());
        //备注数据
        String remarks = collect.get(0).getRemarks();
        List<RemarkVO> remarkVOS = new ArrayList<>();
        if(!CommonUtil.isNull(remarks)){
            remarkVOS = new ArrayList<>();
            String[] split = remarks.split("\n");
            for (int j = 0; j < split.length; j++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(j + 1);
                remarkVO.setContent(split[j]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "外购件");

        excelExportService.export();
    }

    public void auxiliaryMaterialsExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if(!CommonUtil.listIsNotEmpty(productDemandPlanTotals)){
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<AuxiliaryMaterialsExportVO> list = BeanUtil.copyList(productDemandPlanTotals, AuxiliaryMaterialsExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            item.setRemarks(item.getRemarks()==null?"":item.getRemarks()+"备件数量"+item.getSparePartsQuantity().doubleValue()/100+"件");
            //设置材质
            item.setMaterial(item.getTexture());
            //设置名称与规格
            item.setMaterialNameAndSpecification(item.getMaterialName()+item.getSpecification());
            //设置数量(数量+备件数量)
            item.setCountExport(item.getCount().doubleValue()/100+item.getSparePartsQuantity().doubleValue()/100);
            if (item.getWeight()!=null){
                item.setWeightExport(item.getWeight().doubleValue()/100);
            }else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("辅材"), 5, List.of(10, 11)));
        writeHandlers.add(new MyMergeHandler(List.of("辅材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(),5 + list.size(), 1, 12))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/auxiliarymaterials.xlsx");
        ExcelExportService excelExportService = new ExcelExportService("项目需求计划导出", response, resourceAsStream,writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "辅材");

        //计算列总和
        double total = list.stream().mapToDouble(AuxiliaryMaterialsExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String param1 = projectDemandPlan.getManufacturingNumber()!=null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo()!=null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1",param1);
        data.put("param2",param2);
        data.put("total",total);
        excelExportService.fill(data, "辅材");


        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> materialTypeVOS = productDemandPlanService.getMaterialType();
        List<com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO> collect = materialTypeVOS.stream().filter(o -> o.getMaterialType().equals("辅材")).collect(Collectors.toList());
        //备注数据
        String remarks = collect.get(0).getRemarks();
        List<RemarkVO> remarkVOS = new ArrayList<>();
        if(!CommonUtil.isNull(remarks)){
            remarkVOS = new ArrayList<>();
            String[] split = remarks.split("\n");
            for (int j = 0; j < split.length; j++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(j + 1);
                remarkVO.setContent(split[j]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "辅材");

        excelExportService.export();
    }

    public List<ProjectNameInDemandPlanVO> getProject() {
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(null);
        ArrayList<ProjectNameInDemandPlanVO> list = new ArrayList<>();
        ArrayList<ProjectDemandPlan> collect = projectDemandPlans.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                new TreeSet<>(Comparator.comparing(o -> o.getProjectId() + ";" + o.getProjectDemandPlanBatch()))
        ), ArrayList::new));
        log.info("去重后的集合：{}",collect);
        collect.forEach(
                item -> {
                    ProjectNameInDemandPlanVO build = ProjectNameInDemandPlanVO.builder().projectId(item.getProjectId() + "-" + item.getProjectDemandPlanBatch())
                            .projectName(projectService.getById(item.getProjectId()).getProjectName() + "-" + item.getProjectDemandPlanBatch()).build();
                    list.add(build);
                }
        );
        return list;
    }

    public void profileUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<BoardImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), BoardImportVO.class, MaterialType.PROFILE.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }}
            for (int i = 0; i < 2; i++) {
                list.poll();
            }
            list.stream().forEach(item -> {
                if (!CommonUtil.isNull(item.getId())) {
                    ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                    Date parse=new Date();
                    try {
                        if(item.getDeliveryTime().contains("-")){
                            parse = sdf.parse(item.getDeliveryTime());
                        }else if(item.getDeliveryTime().contains("/")){
                            parse=format.parse(item.getDeliveryTime());
                        }

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    copy.setDeliveryTime(parse);
                    copy.setMaterialType(MaterialType.PROFILE.getCode());
                    copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                    productDemandPlanTotalMapper.insert(copy);
                }
            });


    }

    public List<String> getPlanNo(String projectId, String materialTypeText) {
        String code = EnumUtil.getCode(DemandType.class, materialTypeText);
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProjectDemandPlan::getPlanNo)
                .eq(!CommonUtil.isNull(projectId),ProjectDemandPlan::getProjectId,projectId)
                .eq(!CommonUtil.isNull(materialTypeText),ProjectDemandPlan::getDemandType,code);
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        return projectDemandPlans.stream().map(ProjectDemandPlan::getPlanNo).collect(Collectors.toList());
    }

    public void forgePieceUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<ForgePieceImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ForgePieceImportVO.class, MaterialType.FORGE_PIECE.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }}
            for (int i = 0; i < 2; i++) {
                list.poll();
            }
            list.stream().forEach(item -> {
                if (!CommonUtil.isNull(item.getId())) {
                    ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                    copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(),""));
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                    Date parse=new Date();
                    try {
                        if(item.getDeliveryTime().contains("-")){
                            parse = sdf.parse(item.getDeliveryTime());
                        }else if(item.getDeliveryTime().contains("/")){
                            parse=format.parse(item.getDeliveryTime());
                        }

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    copy.setDeliveryTime(parse);
                    copy.setMaterialType(MaterialType.FORGE_PIECE.getCode());
                    copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                    productDemandPlanTotalMapper.insert(copy);
                }
            });


    }

    public void purchasedPartsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<PurchasedPartsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), PurchasedPartsImportVO.class, MaterialType.PURCHASED_PARTS.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }}
            for (int i = 0; i < 2; i++) {
                list.poll();
            }
            list.stream().forEach(item -> {
                if (!CommonUtil.isNull(item.getId())) {
                    ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                    copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(),""));
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                    Date parse=new Date();
                    try {
                        if(item.getDeliveryTime().contains("-")){
                            parse = sdf.parse(item.getDeliveryTime());
                        }else if(item.getDeliveryTime().contains("/")){
                            parse=format.parse(item.getDeliveryTime());
                        }

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    copy.setDeliveryTime(parse);
                    copy.setMaterialType(MaterialType.PURCHASED_PARTS.getCode());
                    copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                    productDemandPlanTotalMapper.insert(copy);
                }
            });


    }

    public void auxiliaryMaterialsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<AuxiliaryMaterialsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), AuxiliaryMaterialsImportVO.class, MaterialType.AUXILIARY_MATERIALS.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }}
            for (int i = 0; i < 2; i++) {
                list.poll();
            }
            list.stream().forEach(item -> {
                if (!CommonUtil.isNull(item.getId())) {
                    ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                    copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(),""));
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                    Date parse=new Date();
                    try {
                        if(item.getDeliveryTime().contains("-")){
                            parse = sdf.parse(item.getDeliveryTime());
                        }else if(item.getDeliveryTime().contains("/")){
                            parse=format.parse(item.getDeliveryTime());
                        }

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }
                    copy.setDeliveryTime(parse);
                    copy.setMaterialType(MaterialType.AUXILIARY_MATERIALS.getCode());
                    copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                    productDemandPlanTotalMapper.insert(copy);
                }
            });


    }

    public void export(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        switch (dto.getDemandType()) {
            case 1:
                this.weldingExport(response, dto);
                break;
            case 2:
                this.paintExport(response, dto);
                break;

            case 3:
                this.exportBoard(response, dto);
                break;

            case 4:
                this.profileExport(response, dto);
                break;

            case 5:
                this.forgePieceExport(response, dto);
                break;
            case 6:
                this.purchasedPartsExport(response, dto);
                break;
            case 7:
                this.auxiliaryMaterialsExport(response, dto);
                break;
            default:
                break;

        }

    }

    public void weldingMaterialsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {

        LinkedList<WeldingMaterialsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), WeldingMaterialsImportVO.class, MaterialType.WELDING_MATERIALS.getName());
        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());

        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)) {
            for (WeldingMaterialDemandPlan weldingMaterialDemandPlan : weldingMaterialDemandPlans) {
                weldingMaterialsDemandPlanMapper.deleteById(weldingMaterialDemandPlan);
            }}
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                WeldingMaterialDemandPlan copy = BeanUtil.copy(item, WeldingMaterialDemandPlan.class);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse=new Date();
                try {
                    if(item.getDeliveryTime().contains("-")){
                        parse = sdf.parse(item.getDeliveryTime());
                    }else if(item.getDeliveryTime().contains("/")){
                        parse=format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                weldingMaterialsDemandPlanMapper.insert(copy);
            }
        });
    }

    public void paintUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<PaintImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), PaintImportVO.class, MaterialType.PAINT.getName());
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<PaintDemandPlan>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(PaintDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(paintDemandPlans)) {
            for (PaintDemandPlan paintDemandPlan : paintDemandPlans) {
                paintDemandPlanMapper.deleteById(paintDemandPlan);
            }}
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                PaintDemandPlan copy = BeanUtil.copy(item, PaintDemandPlan.class);
                copy.setMaterialName(item.getMaterialName().replace(item.getSize(),""));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse=new Date();
                try {
                    if(item.getDeliveryTime().contains("-")){
                        parse = sdf.parse(item.getDeliveryTime());
                    }else if(item.getDeliveryTime().contains("/")){
                        parse=format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                paintDemandPlanMapper.insert(copy);
            }
        });
    }

    public void productDemandPlanTotalupload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        switch (dto.getDemandType()){


            case 3:
                this.productDemandPlanTotalRead(file,dto);
                break;

            case 4:
                this.profileUpload(file, dto);
                break;

            case 5:
                this.forgePieceUpload(file, dto);
                break;
            case 6:
                this.purchasedPartsUpload(file, dto);
                break;
            case 7:
                this.auxiliaryMaterialsUpload(file, dto);
                break;
            default:
                break;
        }
    }

    public List<ProjectDemandPlan> getProjectDemandPlanByProject(String projectId) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId,projectId);
        return projectDemandPlanMapper.selectList(wrapper);
    }

    public List<ProjectDemandPlan> getProjectAndDemandType(String demandPlanNumber) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .like(ProjectDemandPlan::getPlanNo,demandPlanNumber);
        return projectDemandPlanMapper.selectList(wrapper);
    }
}
