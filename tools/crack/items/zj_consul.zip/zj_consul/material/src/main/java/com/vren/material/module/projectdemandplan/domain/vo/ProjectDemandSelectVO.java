package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProjectDemandSelectVO {

    @ApiModelProperty("项目需求计划id")
    private String id;

    @ApiModelProperty("项目需求计划信息")
    private String value;

}
