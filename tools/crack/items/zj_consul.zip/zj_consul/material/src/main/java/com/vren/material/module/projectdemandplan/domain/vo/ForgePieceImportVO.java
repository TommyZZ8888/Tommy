package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/**
 * 锻件导入VO
 * @author szp
 * @date 2023/2/2 8:51
 */
@Data
public class ForgePieceImportVO {
    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;

    private String partNo;

    private String materialName;


    @ExcelProperty(index = 4)
    private String texture;

    @ConversionNumber
    @ExcelProperty(index = 5,converter = EasyExcelToLongConverter.class)
    private Long count;

    @ConversionNumber
    @ExcelProperty(index = 6,converter = EasyExcelToLongConverter.class)
    private Long  weight;

    @ApiModelProperty("执行标准")
    @ExcelProperty(index = 7)
    private String enforceStandards;

    @ExcelProperty(index = 8)
    private String deliveryTime;

    @ExcelProperty(index = 9)
    private String deliveryLocation;

    @ExcelProperty(index = 10)
    private String remarks;

    //新增的导出列的字段
    @ApiModelProperty("规格")
    @ExcelProperty(index = 11)
    private String specification;

    @ConversionNumber
    @ExcelProperty(index = 12,converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("标书价")
    private Long bidPrice;


    @ApiModelProperty("用料类型")
    @ExcelProperty(index = 13)
    private String ingredientsType;

    @ApiModelProperty("单位")
    @ExcelProperty(index = 14)
    private String unit;
    @ConversionNumber
    @ExcelProperty(index = 15,converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;
}
