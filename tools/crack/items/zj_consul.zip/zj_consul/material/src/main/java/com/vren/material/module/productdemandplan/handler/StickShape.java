package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName:Test
 * @Author: vren
 * @Date: 2022/10/19 15:33
 */
@Component
public class StickShape implements ComputerHandler {

    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        if (CommonUtil.isNull(data.getFirstSize())||CommonUtil.isNull(data.getSecondSize())){
            throw new RuntimeException(data.getMaterialName()+"的第一尺寸和第二尺寸不能为空");
        }
        double result = Math.PI * Math.pow(data.getFirstSize().doubleValue()/100, 2) / 4 * data.getSecondSize().doubleValue()/100 * data.getProportion().doubleValue()/100 / 1000000 * data.getCount().doubleValue()/100;
        String specification = "φ" + data.getFirstSize()/100+ ",L=" + data.getSecondSize()/100;
        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (result<0){
            throw new RuntimeException("您输入的尺寸有误！");
        }
        productDemandPlanDetails.setWeight((long) (result*100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            String firstSize = specification.substring(specification.indexOf("φ")+1, specification.indexOf(","));
            String secondSize = specification.substring(specification.indexOf("L")+2);
            vo.setFirstSizeExport(Double.parseDouble(firstSize));
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification!=null){
            String firstSize = specification.substring(specification.indexOf("φ")+1, specification.indexOf(","));
            String secondSize = specification.substring(specification.indexOf("L")+1);
            vo.setFirstSizeExport(Double.parseDouble(firstSize));
            vo.setSecondSizeExport(Double.parseDouble(secondSize));
        }
    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>(2);
        if (specification!=null) {
            String width = specification.substring(specification.indexOf("φ") + 1, specification.indexOf(","));
            String length = specification.substring(specification.indexOf("L") + 2);
            map.put("width",width);
            map.put("length", length);
        }
        return map;
    }

}
