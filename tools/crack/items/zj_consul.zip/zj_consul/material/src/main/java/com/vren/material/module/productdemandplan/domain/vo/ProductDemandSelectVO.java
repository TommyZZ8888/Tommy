package com.vren.material.module.productdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class ProductDemandSelectVO {

    @ApiModelProperty("产品需求计划id")
    private String id;

    @ApiModelProperty("产品名称-产品批次-计划编号-数量")
    private String value;

}
