package com.vren.material.module.projectdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ProductDemandPlanTotalQueryDTO extends PageParam {
    @ApiModelProperty("计划编号")
    @NotBlank(message = "计划编号不能为空")
    private String planNo;

    @ApiModelProperty("材料名称")
    private String materialName;


    @NotNull(message = "需求类型不能为空")
    @ApiModelProperty("需求类型")
    private Integer demandType;

    @ApiModelProperty("件号")
    private String partNo;
}
