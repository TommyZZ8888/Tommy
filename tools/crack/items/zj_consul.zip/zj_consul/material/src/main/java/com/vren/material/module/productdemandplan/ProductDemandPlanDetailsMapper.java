package com.vren.material.module.productdemandplan;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * @author 耿让
 * 产品需求计划详情
 */
@Mapper
public interface ProductDemandPlanDetailsMapper extends MPJBaseMapper<ProductDemandPlanDetails> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<ProductDemandPlanDetails> entities);

    /**
     *  批量更新交货时间和交货地点
     * @param ids
     * @param deliveryTime
     * @param deliveryLocation
     * @return
     */
    Integer editTimeAndLocation(@Param("ids") List<String> ids, @Param("deliveryTime") Date deliveryTime, @Param("deliveryLocation") String deliveryLocation);

}
