package com.vren.material.module.stockmanagement.domian.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 * 暂估入库数更新
 */
@Data
public class EstimatedStorageCountDTO {

    @ApiModelProperty("数量")
    private Integer count;

    @ApiModelProperty("物资编号")
    private String materialNumber;

}
