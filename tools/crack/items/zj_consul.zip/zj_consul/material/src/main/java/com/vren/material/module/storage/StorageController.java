package com.vren.material.module.storage;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.material.entity.MaterialNoticeVO;
import com.vren.material.module.stockmanagement.domian.dto.MaterialStockDTO;
import com.vren.material.module.storage.domain.dto.*;
import com.vren.material.module.storage.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/storage")
@Api(tags = {"材料入库"})
@OperateLog
public class StorageController {
    @Autowired
    private StorageService storageService;
    @RequestMapping(value = "/getStorageDataList", method = RequestMethod.POST)
    @ApiOperation("主界面展示待入库数据")
    public ResponseResult<PageResult<MaterialFirstLevelStorageVO>> getDataList(@RequestBody @Valid MaterialFirstLevelStorageQueryDTO dto) {

        return ResponseResult.success("获取成功", storageService.getDataList(dto));
    }
    @RequestMapping(value = "/getMaterialFirstLevelStorageById", method = RequestMethod.POST)
    @ApiOperation("根据id获取单个待入库数据详情")
    public ResponseResult<MaterialFirstLevelStorageVO> getMaterialFirstLevelStorageById(@RequestBody @Valid MaterialFirstLevelStorageDTO dto) {

        return ResponseResult.success("获取成功", storageService.getMaterialFirstLevelStorageById(dto));
    }

    @RequestMapping(value = "/getMaterialStockById", method = RequestMethod.POST)
    @ApiOperation("根据id获取单个库存数据详情")
    public ResponseResult<MaterialStockDTO> getMaterialStockById(@RequestBody @Valid MaterialFirstLevelStorageDTO dto) {

        return ResponseResult.success("获取成功", storageService.getMaterialStockById(dto));
    }

    @RequestMapping(value = "/generateMaterialStorageNotice", method = RequestMethod.POST)
    @ApiOperation("新增通知单")
    public ResponseResult<Boolean> addMaterialStorageNotice(@RequestBody @Valid GenerateMaterialStorageNoticeDTO dto) {
        storageService.addMaterialStorageNotice(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/getMaterialStorageNoticeDetailList", method = RequestMethod.POST)
    @ApiOperation("返回通知单及其明细(远程调用)")
    public ResponseResult<List<MaterialNoticeVO>> getMaterialStorageNoticeDetailList() {

        return ResponseResult.success("操作成功", storageService.getMaterialStorageNoticeDetailList());
    }
    @RequestMapping(value = "/batchInsertMaterialFirstLevelStorage", method = RequestMethod.POST)
    @ApiOperation("批量新增一级入库数据")
    public ResponseResult<Boolean> batchInsertMaterialFirstLevelStorage(@RequestBody @Valid BatchInsertMaterialFirstLevelStorageDTO dto) {
        storageService.batchInsertMaterialFirstLevelStorage(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/addOrUpdateMaterialFirstLevelStorage", method = RequestMethod.POST)
    @ApiOperation("新增或修改一级入库数据")
    public ResponseResult<Boolean> addOrUpdateMaterialFirstLevelStorage(@RequestBody @Valid MaterialFirstLevelStorageUpdateDTO dto) {
        storageService.addOrUpdateMaterialFirstLevelStorage(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/deleteMaterialFirstLevelStorage", method = RequestMethod.POST)
    @ApiOperation("删除一级入库数据")
    public ResponseResult<Boolean> deleteMaterialFirstLevelStorage(@RequestBody @Valid DeleteMaterialFirstLevelStorageDTO dto) {
        storageService.deleteMaterialFirstLevelStorage(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/getDeviceDropList", method = RequestMethod.POST)
    @ApiOperation("获取设备类型下拉框")
    public ResponseResult<List<DeviceDataVO>> getDeviceDropList() {

        return ResponseResult.success("获取成功", storageService.getDeviceDropList());
    }


    @RequestMapping(value = "/getWarehousingMaterialType", method = RequestMethod.POST)
    @ApiOperation("获取入库物资类型下拉框")
    public ResponseResult<List<WarehousingMaterialTypeVO>> getWarehousingMaterialType() {

        return ResponseResult.success("获取成功", storageService.getWarehousingMaterialType());
    }

    @RequestMapping(value = "/getWarehousingMethod", method = RequestMethod.POST)
    @ApiOperation("获取入库方式下拉框")
    public ResponseResult<List<WarehousingMethodVO>> getWarehousingMethod() {

        return ResponseResult.success("获取成功", storageService.getWarehousingMethod());
    }

    @RequestMapping(value = "/getWarehousingState ", method = RequestMethod.POST)
    @ApiOperation("获取入库状态下拉框")
    public ResponseResult<List<WarehousingStateVO>> getWarehousingState() {

        return ResponseResult.success("获取成功", storageService.getWarehousingState());
    }

    @RequestMapping(value = "/getMaterialStorageInvoiceList", method = RequestMethod.POST)
    @ApiOperation("展示物资入库发票数据")
    public ResponseResult<PageResult<MaterialStorageInvoiceVO>> getMaterialStorageInvoiceList(@RequestBody @Valid MaterialStorageInvoiceQueryDTO dto) {

        return ResponseResult.success("获取成功", storageService.getMaterialStorageInvoiceList(dto));
    }
    @RequestMapping(value = "/getMaterialStorageInvoiceById", method = RequestMethod.POST)
    @ApiOperation("获取单个物资入库发票数据")
    public ResponseResult<MaterialStorageInvoiceViewVO> getMaterialStorageInvoiceById(@RequestBody @Valid MaterialStorageInvoiceQueryViewDTO dto) {
        return ResponseResult.success("获取成功",storageService.getMaterialStorageInvoiceById(dto));
    }

    @RequestMapping(value = "/getContractNo", method = RequestMethod.POST)
    @ApiOperation("获取合同编号下拉框")
    public ResponseResult<List<ContractNoVO>> getContractNo() {

        return ResponseResult.success("获取成功", storageService.getContractNo());
    }


    @RequestMapping(value = "/getMaterialFirstLevelStorageListByContractNo", method = RequestMethod.POST)
    @ApiOperation("通过合同编号获取一级入库数据(发票新增用)")
    public ResponseResult<PageResult<MaterialFirstLevelStorageVO>> getMaterialFirstLevelStorageListByContractNo(@RequestBody @Valid MaterialQueryDTO dto) {

        return ResponseResult.success("获取成功", storageService.getMaterialFirstLevelStorageListByContractNo(dto));
    }
    @RequestMapping(value = "/addOrUpdateMaterialStorageInvoice", method = RequestMethod.POST)
    @ApiOperation("新增或修改物资入库发票")
    public ResponseResult<Boolean> addOrUpdateMaterialStorageInvoice(@RequestBody @Valid MaterialStorageInvoiceUpdateDTO dto) {
        storageService.addOrUpdateMaterialStorageInvoice(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialCode", method = RequestMethod.POST)
    @ApiOperation("获取材料名称和编号(代号)下拉框")
    public ResponseResult<List<MaterialCodeVO>> getMaterialCode(@RequestBody @Valid MaterialCodeQueryDTO dto) {

        return ResponseResult.success("获取成功", storageService.getMaterialCode(dto));
    }



    @RequestMapping(value = "/deleteMaterialStorageInvoice", method = RequestMethod.POST)
    @ApiOperation("删除物资入库发票")
    public ResponseResult<Boolean> deleteMaterialStorageInvoice(@RequestBody @Valid DeleteMaterialStorageInvoiceDTO dto) {
        storageService.deleteMaterialStorageInvoice(dto);
        return ResponseResult.success("操作成功");
    }



}
