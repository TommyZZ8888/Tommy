package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.projectdemandplan.domain.entity.PaintDemandPlan;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface PaintDemandPlanMapper extends MPJBaseMapper<PaintDemandPlan> {
    /**
     *  批量更新交货时间和交货地点
     * @param ids
     * @param deliveryTime
     * @param deliveryLocation
     * @return
     */
    Integer paintEditTimeAndLocation(@Param("ids") List<String> ids, @Param("deliveryTime") Date deliveryTime, @Param("deliveryLocation") String deliveryLocation);

}
