package com.vren.material.module.productdemandplan.domain.handler;

import com.alibaba.excel.write.handler.AbstractRowWriteHandler;
import com.alibaba.excel.write.handler.context.RowWriteHandlerContext;
import com.vren.material.module.productdemandplan.ProductDemandPlanService;
import com.vren.material.module.productdemandplan.domain.vo.MaterialTypeVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author 耿让
 */
@Slf4j
@Component
public class Excelandler extends AbstractRowWriteHandler {

    private int size;

    private ProductDemandPlanService productDemandPlanService;

    public Excelandler(){

    }
    public Excelandler(int size,ProductDemandPlanService productDemandPlanService) {
        this.size=size;
        this.productDemandPlanService=productDemandPlanService;
    }

    @Override
    public void afterRowDispose(RowWriteHandlerContext context) {
        List<MaterialTypeVO> materialType = productDemandPlanService.getMaterialType();
        AtomicReference<String> remark = new AtomicReference<>("");
        materialType.stream().filter(item -> item.getMaterialType().equals(context.getWriteSheetHolder().getSheetName())).forEach(i -> {
            remark.set(i.getRemarks());
        });
        String[] split = remark.get().split("\n");
        if (context.getRow().getRowNum()==size+4){
            Sheet sheetAt = context.getWriteWorkbookHolder().getWorkbook().getSheetAt(0);
            for (int i = 0; i < split.length; i++) {
                sheetAt.createRow(size+i+5).createCell(1).setCellValue(split[i]);
            }
//            sheetAt.createRow(size+5).createCell(1).setCellValue("备注一");
//            sheetAt.createRow(size+6).createCell(1).setCellValue("备注二");
        }
    }

//    @Override
//    public void afterRowDispose(WriteSheetHolder writeSheetHolder, WriteTableHolder writeTableHolder, Row row, Integer relativeRowIndex, Boolean isHead) {
//        log.info("物资类型：{}",writeSheetHolder.getSheetName());
//        List<MaterialTypeVO> materialType = productDemandPlanService.getMaterialType();
//        AtomicReference<String> remark = new AtomicReference<>("");
//        materialType.stream().filter(item -> item.getMaterialType().equals(writeSheetHolder.getSheetName())).forEach(i -> {
//            remark.set(i.getRemarks());
//        });
//
//        log.info("备注：{}",remark.get());
//        log.info("备注包含转义符：{}",remark.get().contains("\n"));
//        //通过换行转义符，将备注换成多行
//        String[] split = remark.get().split("\n");
//        log.info("备注分割后的结果0：{}", split[0]);
//        log.info("备注分割后的结果1：{}", split[1]);
//        log.info("备注分割后的结果2：{}", split[2]);
//        log.info("备注分割后的结果：{}", split.length);
//
//        //将备注换为多行，放到List<String>中
//        Sheet sheet = writeSheetHolder.getSheet();
////        for (int i = 0; i < split.length; i++) {
//
////        }
//
//        if (relativeRowIndex==0) {
//            log.info("行号：{}", relativeRowIndex);
////            Row row1 = sheet.createRow(size +5);
////            Cell cell1 = row1.createCell(1);
////            //设置值
////            cell1.setCellValue(split[0]);
////            row1.createCell(1).setCellValue(split[0]);
//            Row row1 = sheet.createRow(size + 5);
//            row1.createCell(1).setCellValue(split[0]);
////            row.createCell(relativeRowIndex+1).setCellValue(split[0]);
////            row.getCell(relativeRowIndex+1).setCellValue(split[0]);
//        }
//    }
//

}
