package com.vren.material.module.materialremain;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialremain.domain.entity.RemainingMaterial;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 */
@Mapper
public interface MaterialRemainMapper extends MPJBaseMapper<RemainingMaterial> {


}
