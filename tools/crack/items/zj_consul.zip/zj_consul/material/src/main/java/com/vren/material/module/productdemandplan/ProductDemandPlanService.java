package com.vren.material.module.productdemandplan;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelFillCellMergeStrategy;
import com.vren.common.common.utils.easyexcel.MyMergeHandler;
import com.vren.common.module.product.ProductService;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.quality.QualityService;
import com.vren.common.module.quality.domain.dto.ProductQualityDTO;
import com.vren.material.module.productdemandplan.domain.dto.*;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTexture;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTypeEntity;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlan;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.domain.vo.*;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.productdemandplan.mapper.MaterialTextureMapper;
import com.vren.material.module.productdemandplan.mapper.MaterialTypeMapper;
import com.vren.material.module.productdemandplan.mapper.ProductDemandPlanMapper;
import com.vren.material.module.productmanagement.ProductManageService;
import com.vren.material.module.productmanagement.domain.dto.DeleteOrGetOneDTO;
import com.vren.material.module.productmanagement.domain.dto.*;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.productmanagement.domain.vo.ProductAndDemandVO;
import com.vren.material.module.productmanagement.domain.vo.ProductByProjectIdVO;
import com.vren.material.module.productmanagement.domain.vo.ProductDemandVO;
import com.vren.material.module.productmanagement.domain.vo.ProductInformationVO;
import com.vren.material.module.projectdemandplan.ProjectDemandPlanService;
import com.vren.material.module.projectdemandplan.domain.entity.ProjectDemandPlan;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.vren.common.module.material.dto.QueryProductDTO;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProductDemandPlanService {

    @Autowired
    private QualityService qualityService;

    @Autowired
    private ProductService productService;

    @Autowired
    private MaterialTypeMapper materialTypeMapper;
    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProductManageService productManageService;

    @Autowired
    private ProductDemandPlanMapper productDemandPlanMapper;

    @Autowired
    private ProductDemandPlanDetailsMapper productDemandPlanDetailsMapper;

    @Autowired
    private MaterialTextureMapper materialTextureMapper;


    public List<ProductDemandPlan> selectAllProductDemandPlan() {
        return productDemandPlanMapper.selectList(null);
    }


    public PageResult<ProductDemandPlanVO> getProductDemandPlan(QueryDTO dto) {
        Page<ProductDemandPlanVO> page = PageUtil.convert2QueryPage(dto);
        /**
         * 根据计划编号、产品名称(产品id)、项目名称（项目id） 查询产品需求计划
         */

        //根据计划编号查询产品计划表
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlan.class)
                .like(!CommonUtil.isNull(dto.getScheduleNo()), ProductDemandPlan::getScheduleNo, dto.getScheduleNo())
                .eq(!CommonUtil.isNull(dto.getReviewState()), ProductDemandPlan::getReviewState, dto.getReviewState())
                .orderByDesc(ProductDemandPlan::getCreateTime);
        //项目名称不为空（项目id）
        if (!CommonUtil.isNull(dto.getProjectName())) {
            //根据项目id筛选查询结果
            //根据项目id查询所有的产品id
            List<String> productIds = productManageService.getProductIdByProjectId(dto.getProjectName());
            if (productIds.size() > 0) {
                wrapper.in(ProductDemandPlan::getProductInformationId, productIds);
            } else {
                //项目下面没有产品，查询结果为空
                return new PageResult<>();
            }
        }
        //产品名称不为空时
        if (!CommonUtil.isNull(dto.getProductName())) {
            wrapper.eq(ProductDemandPlan::getProductInformationId, dto.getProductName());
        }
        IPage<ProductDemandPlanVO> productDemandPlanVOIPage = productDemandPlanMapper.selectJoinPage(page, ProductDemandPlanVO.class, wrapper);
        productDemandPlanVOIPage.getRecords().stream().forEach(item -> {
            ProductInformationVO productInformationDetail = productManageService.getProductInformationDetail(item.getProductInformationId());
            //设置产品名称
            item.setProductName(productInformationDetail.getProductName());
            //通过产品id获取项目名称
            String projectName = projectService.getById(productInformationDetail.getProjectId()).getProjectName();
            item.setProjectName(projectName);
        });
        return PageUtil.convert2PageResult(productDemandPlanVOIPage);
    }


    public void addOrEditProductDemandPlan(UpdateProductDemanPlanDTO dto) {
        if (dto.getNumber()<1){
            throw new RuntimeException("数量不能小于1");
        }
        //2023/03/01 产品需求计划新增，加上需求数量，每次新增的数量累加起来不能大于产品实际数量
        // 某个产品需求计的总和  <  产品总数

        ProductDemandPlan productDemand = BeanUtil.copy(dto, ProductDemandPlan.class);
        String manufacturingNumber = productManageService.getProductInformationDetail(dto.getProductInformationId()).getManufacturingNumber();
        productDemand.setManufacturingNumber(manufacturingNumber);
        QueryWrapper<ProductDemandPlan> wrapper = new QueryWrapper<>();
        if (CommonUtil.isNull(dto.getId())) {
            //新增,计划编号不能重复
            wrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getScheduleNo()), "schedule_no", dto.getScheduleNo())
                    .last("limit 1");
            Long count = productDemandPlanMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("计划编号已经存在");
            }
            //2023/03/01  新增批次字段
            //已有的产品需求计划 数量加1  格式：  第i批次
            MPJLambdaWrapper<ProductDemandPlan> queryWrapper = new MPJLambdaWrapper<>();
            queryWrapper.select(ProductDemandPlan::getBatch)
                    .eq(!CommonUtil.isNull(dto.getProductInformationId()),ProductDemandPlan::getProductInformationId,dto.getProductInformationId());
            List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(queryWrapper);
            String batch = productDemandPlans.stream().map(ProductDemandPlan::getBatch).collect(Collectors.toList()).stream().max(Comparator.comparing(x -> x)).orElse(null);
            //2023/03/02
            //批次用最大的批次  加1
            String batchInsert;
            if (!CommonUtil.isNull(batch)){
                int substring = Integer.parseInt(batch.substring(1, 2));
                batchInsert = "第"+(substring+1)+"批次";
            }else {
                batchInsert = "第1批次";
            }
            productDemand.setBatch(batchInsert);

            productDemandPlanMapper.insert(productDemand);
            String id = productDemand.getProductInformationId();
            this.addByProductId(id,batchInsert);
        } else {
            //编辑，计划不能重复
            wrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getScheduleNo()), "schedule_no", dto.getScheduleNo())
                    .notIn("id", dto.getId())
                    .last("limit 1");
            Long count = productDemandPlanMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("计划编号已经存在");
            }
            productDemandPlanMapper.updateById(productDemand);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteProductDemandPlan(String id,String batch) {
        String productInformationId = productDemandPlanMapper.selectById(id).getProductInformationId();
        if (productDemandPlanMapper.deleteById(id) > 0) {
            //产品需求计划删除成功，删除下面关联的详情
            QueryWrapper<ProductDemandPlanDetails> queryWrapper = new QueryWrapper<>();
            queryWrapper.in("product_information_id", productInformationId);
            productDemandPlanDetailsMapper.delete(queryWrapper);
            //产品需求计划删除成功，删除对应的物资类型（材料说明）
            QueryWrapper<MaterialTypeEntity> materialTypeEntityQueryWrapper = new QueryWrapper<>();
            materialTypeEntityQueryWrapper.in("product_information_id", productInformationId)
                            .eq(!CommonUtil.isNull(batch),"batch",batch);
            materialTypeMapper.delete(materialTypeEntityQueryWrapper);
        }
    }

    public ProductDemandPlanVO getProductDemandPlanDetail(String id) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(id);
        ProductDemandPlanVO productDemandPlanVO = BeanUtil.copy(productDemandPlan, ProductDemandPlanVO.class);
        //根据产品id获得产品名称
        String productName = productManageService.getProductInformationDetail(productDemandPlanVO.getProductInformationId()).getProductName();
        productDemandPlanVO.setProductName(productName);
        //产品 所有批次数量， 产品数量
        List<ProductAndDemandVO> productOutlineWithDemand = productManageService.getProductAndDemand();
        List<ProductAndDemandVO> collect = productOutlineWithDemand.stream().filter(o -> o.getId().equals(productDemandPlanVO.getProductInformationId())).collect(Collectors.toList());
        productDemandPlanVO.setCount(collect.get(0).getNumber()-collect.get(0).getSum()+productDemandPlanVO.getNumber());
        return productDemandPlanVO;
    }


    public PageResult<ProductDemandPlanDetailsVO> selectProductDemandPlanDetails(QueryDetailsDTO dto) {
        /*
          根据产品id和查询条件查询产品产品需求详情
          1.只传产品id，主界面跳转到子界面(pass)
          2.传查询条件，则是子界面的查询，此时产品id依旧是必传值
         */
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                //2023/03/01 根据产品需求计划id查询
                .eq(!CommonUtil.isNull(dto.getProductDemandPlanId()),ProductDemandPlanDetails::getProductDemandPlanId,dto.getProductDemandPlanId())
                .eq(!CommonUtil.isNull(dto.getProductInformationId()), ProductDemandPlanDetails::getProductInformationId, dto.getProductInformationId())
                .like(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanDetails::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanDetails::getPartNo, dto.getPartNo())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), ProductDemandPlanDetails::getMaterialType, dto.getMaterialType())
                .orderByAsc(ProductDemandPlanDetails::getPartNo);
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        //根据件号排序
        List<ProductDemandPlanDetailsVO> productDemandPlanDetailsVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsVO.class);
        PartNoSortUtil.sort(productDemandPlanDetailsVOS);
        return PageUtil.convert2PageResult(productDemandPlanDetailsVOS,dto);
    }

    public List<MaterialTypeVO> getMaterialType() {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class);
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeEntities, MaterialTypeVO.class);
    }

    public MaterialTextureVO getMaterialTexture(String id) {
        MaterialTexture materialTexture = materialTextureMapper.selectById(id);
        return BeanUtil.copy(materialTexture, MaterialTextureVO.class);
    }


    /**
     * 批量删除产品需求计划
     *
     * @param list
     */
    public void batchDeleteProductDemandPlan(List<String> list) {
        //根据产品信息id批量删除
        LambdaUpdateWrapper<ProductDemandPlan> wrapper = new LambdaUpdateWrapper<>();
        wrapper.in(ProductDemandPlan::getProductInformationId, list);
        productDemandPlanMapper.delete(wrapper);
    }


    /**
     * 批量删除产品需求计划详情
     *
     * @param list
     */
    public void batchDeleteProductDemandPlanDetails(List<String> list) {
        LambdaUpdateWrapper<ProductDemandPlanDetails> wrapper = new LambdaUpdateWrapper<>();
        //根据产品信息id批量删除
        wrapper.in(ProductDemandPlanDetails::getProductInformationId, list);
        productDemandPlanDetailsMapper.delete(wrapper);
    }

    public MaterialTypeVO getMaterialTypeById(GetMaterialTypeByProductId dto) {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialTypeEntity::getMaterialType, dto.getMaterialType())
                .eq(!CommonUtil.isNull(dto.getProductInformationId()), MaterialTypeEntity::getProductInformationId, dto.getProductInformationId())
                .eq(!CommonUtil.isNull(dto.getBatch()),MaterialTypeEntity::getBatch,dto.getBatch());
        MaterialTypeEntity materialTypeEntity = materialTypeMapper.selectOne(wrapper);
        return BeanUtil.copy(materialTypeEntity, MaterialTypeVO.class);
    }

    public void editMaterialType(UpdateMaterialTypeDTO dto) {
        UpdateWrapper<MaterialTypeEntity> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(dto.getProductInformationId()), "product_information_id", dto.getProductInformationId())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), "material_type", dto.getMaterialType())
                //2023.03.03 根据批次修改
                .eq(!CommonUtil.isNull(dto.getBatch()),"batch",dto.getBatch())
                .set("remarks", dto.getRemarks());
        materialTypeMapper.update(new MaterialTypeEntity(), wrapper);
    }

    public PageResult<MaterialTextureVO> selectAllMaterialTexture(QueryMaterialTextureDTO dto) {
        Page<MaterialTextureVO> page = PageUtil.convert2QueryPage(dto);
        /*
          查询材质表：代号和材料字段模糊，用料类型下拉等于
         */
        MPJLambdaWrapper<MaterialTexture> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTexture.class)
                .like(!CommonUtil.isNull(dto.getCode()), MaterialTexture::getCode, dto.getCode())
                .like(!CommonUtil.isNull(dto.getMaterial()), MaterialTexture::getMaterial, dto.getMaterial());
        IPage<MaterialTextureVO> materialTextureVOIPage = materialTextureMapper.selectJoinPage(page, MaterialTextureVO.class, wrapper);
        return PageUtil.convert2PageResult(materialTextureVOIPage);
    }

    public void addMaterialTexture(InsertOrUpdateMaterialTextureDTO dto) {
        MaterialTexture materialTexture = BeanUtil.copy(dto, MaterialTexture.class);
        QueryWrapper<MaterialTexture> queryWrapper = new QueryWrapper<>();
        if (CommonUtil.isNull(dto.getId())) {
            //新增
            //code不能重复
            queryWrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getCode()), "code", dto.getCode())
                    .last("limit 1");
            if (materialTextureMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("代号不能重复");
            }
            materialTextureMapper.insert(materialTexture);
        } else {
            //编辑
            queryWrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getCode()), "code", dto.getCode())
                    .notIn(!CommonUtil.isNull(dto.getId()), "id", dto.getId())
                    .last("limit 1");
            if (materialTextureMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("代号不能重复");
            }
            materialTextureMapper.updateById(materialTexture);
        }
    }

    public void batchDeleteMaterialTexture(BatchDeleteDTO dto) {
        //批量删除
        materialTextureMapper.deleteBatchIds(dto.getIds());
    }

    public void batchDeleteMaterialType(List<String> productInformationIds) {
        //根据产品id删除
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.in(MaterialTypeEntity::getProductInformationId, productInformationIds);
        materialTypeMapper.delete(wrapper);
    }

    public List<MaterialTextureVO> selectAllMaterialTextureWithoutPage() {
        MPJLambdaWrapper<MaterialTexture> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTexture.class);
        List<MaterialTexture> materialTextures = materialTextureMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTextures, MaterialTextureVO.class);
    }


    public void batchAddProductDemandPlanDetails(BatchInsertDetailDTO dto) {
        /*
          批量新增，计算重量和规格
          12/05:一个产品下面的件号不能重复
         */
        //新增方法的参数
        ArrayList<ProductDemandPlanDetails> productDemandPlanDetailsList = new ArrayList<>();
        //对前端参数进行处理
        List<InsertDetailDTO> list = dto.getList();
        //判断参数中的件号，是否已经存在
        //根据产品信息id和参数中的件号，查询件号出现的次数
        //件号
        List<String> partNos = list.stream().map(InsertDetailDTO::getPartNo).collect(Collectors.toList());
        QueryWrapper<ProductDemandPlanDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(list.get(0).getProductDemandPlanId()), "product_demand_plan_id", list.get(0).getProductDemandPlanId())
                .in(CommonUtil.listIsNotEmpty(partNos), "part_no", partNos);
        Long count = productDemandPlanDetailsMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new RuntimeException("一个产品下面的件号不能重复");
        }
        list.forEach(item -> {
            if (item.getMaterialType().equals(MaterialType.BOARD.getName()) || (item.getMaterialType().equals(MaterialType.PROFILE.getName())) && !item.getIsCalculate()) {
                //需要计算
                //第一尺寸由String转为Long
                Number number = Float.parseFloat(item.getFirstSizeString()) * 100;
                int value = number.intValue();
                Long firstSize = (long) value;
                item.setFirstSize(firstSize);

                //计算重量和规格
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                ProductDemandPlanDetails execution = bean.execution(item);
                productDemandPlanDetailsList.add(execution);
            } else {
                //如果是锻件、外购件和辅材类型，第一尺寸就是规格
                ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(item, ProductDemandPlanDetails.class);
                if (item.getFirstSizeString() != null) {
                    productDemandPlanDetails.setSpecification(item.getFirstSizeString());
                }
                if (item.getSecondSize() != null) {
                    productDemandPlanDetails.setWeight(item.getSecondSize());
                }
                productDemandPlanDetailsList.add(productDemandPlanDetails);
            }
        });
        productDemandPlanDetailsMapper.insertBatchSomeColumn(productDemandPlanDetailsList);

        //判断code是否在材质表存在，如果已经存在，则忽略；如果不存在，则直接新增
        //参数中的code
        List<MaterialTexture> materialTextures = BeanUtil.copyList(list, MaterialTexture.class);
        List<String> codeList = materialTextures.stream().map(MaterialTexture::getCode).distinct().collect(Collectors.toList());
        //表中已经存在的code
        List<MaterialTextureVO> materialTextureVOS = selectAllMaterialTextureWithoutPage();
        List<String> collect = materialTextureVOS.stream().map(MaterialTextureVO::getCode).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(codeList)) {
            collect.retainAll(codeList);
            codeList.removeAll(collect);
            //新增code为codeList的材质数据
            for (String code : codeList) {
                List<MaterialTexture> textures = materialTextures.stream().filter(item -> item.getCode().equals(code)).collect(Collectors.toList());
                int insert = materialTextureMapper.insert(textures.get(0));
                log.info("材质表新增数据条数：{}", insert);
            }
        }
    }


    public ProductDemandPlanDetailVO selectDetailsOne(DeleteOrGetOneDTO dto) {
        ProductDemandPlanDetails productDemandPlanDetails = productDemandPlanDetailsMapper.selectById(dto.getId());
        ProductDemandPlanDetailVO vo = BeanUtil.copy(productDemandPlanDetails, ProductDemandPlanDetailVO.class);
        //如果是型材和板材，第一尺寸就是数字；否则就是规格
        if (vo.getMaterialType().equals(MaterialType.BOARD.getName()) || (vo.getMaterialType().equals(MaterialType.PROFILE.getName()) && !vo.getIsCalculate())) {
            vo.setFirstSizeString(String.valueOf(vo.getFirstSize() / 100));
        } else {
            vo.setFirstSizeString(vo.getSpecification());
        }
        return vo;
    }

    public void editDetails(InsertDetailDTO dto) {
        /*
           12/06:编辑功能同新增那边一样
         */
        if (dto.getMaterialType().equals(MaterialType.BOARD.getName()) || dto.getMaterialType().equals(MaterialType.PROFILE.getName())) {
            if (!dto.getIsCalculate()) {
                //需要进行计算
                //第一尺寸由String转为Long
                Number number = Float.parseFloat(dto.getFirstSizeString()) * 100;
                int value = number.intValue();
                Long firstSize = (long) value;
                dto.setFirstSize(firstSize);
                //计算
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, dto.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                ProductDemandPlanDetails execution = bean.execution(dto);
                productDemandPlanDetailsMapper.updateById(execution);
            } else {
                //型材第一尺寸是规格，第二尺寸是重量
                ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(dto, ProductDemandPlanDetails.class);
                if (dto.getFirstSizeString() != null) {
                    productDemandPlanDetails.setSpecification(dto.getFirstSizeString());
                }
                if (dto.getSecondSize() != null) {
                    productDemandPlanDetails.setWeight(dto.getSecondSize());
                }
                productDemandPlanDetailsMapper.updateById(productDemandPlanDetails);
            }
        } else {
            //第一尺寸就是规格，第二尺寸就是重量
            //如果是锻件、外购件和辅材类型，第一尺寸就是规格
            ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(dto, ProductDemandPlanDetails.class);
            if (!CommonUtil.isNull(dto.getFirstSizeString())) {
                productDemandPlanDetails.setSpecification(dto.getFirstSizeString());
            }
            if (!CommonUtil.isNull(dto.getSecondSize())) {
                productDemandPlanDetails.setWeight(dto.getSecondSize());
            }
            productDemandPlanDetailsMapper.updateById(productDemandPlanDetails);
        }

    }

    public void deleteDetails(DeleteOrGetOneDTO dto) {
        //删除
        productDemandPlanDetailsMapper.deleteById(dto.getId());
    }

    public void editTimeAndLocation(EditTimeAndLocationDTO dto) {
        productDemandPlanDetailsMapper.editTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }

    /**
     * 根据产品信息表id 查询产品需求计划明细
     * 按照物资类型分为多个sheet页（自定义表头）
     *      板材  管材/型材  导出格式一样  （ProductDemandPlanDetailsExportVO）
     *      锻件  辅材   外购件  导出格式一样
     *     材质是组合件的不导出
     *     12/19 材质是组合件的正常导出；锻材、辅材、外购件导出材质为空；型材中第一尺寸填写的是规格，材料为角钢，对规格进行单独的解析
     *
     */
    public void export(HttpServletResponse response, DeleteOrGetOneDTO dto) throws IOException {
        //根据所有产品id所有的产品需求计划明细（pass）
        //2023/03/01 根据产品需求计划id查询产品需求计划详情
        MPJLambdaWrapper<ProductDemandPlanDetails> detailsWrapper = new MPJLambdaWrapper<>();
        detailsWrapper.selectAll(ProductDemandPlanDetails.class)
//                .eq(ProductDemandPlanDetails::getProductInformationId, dto.getId())
                .eq(ProductDemandPlanDetails::getProductDemandPlanId,dto.getId())
//                .ne(ProductDemandPlanDetails::getMaterial,"组合件")
//                .orderByAsc(ProductDemandPlanDetails::getProductInformationId)
                .orderByAsc(ProductDemandPlanDetails::getPartNo);
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(detailsWrapper);
        //复制到vo中
        List<ProductDemandPlanDetailsExportVO> vos = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsExportVO.class);
        //根据件号排序
        PartNoSortUtil.sort(vos);
        //通过产品信息表id获取制造编号和计划编号
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        //todo 这里的物资类型根据产品需求计划获取，而不是产品
        List<MaterialTypeVO> materialTypes = this.getMaterialTypeByProductId(dto.getId(),productDemandPlanMapper.selectById(dto.getId()).getBatch());

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //将数据按照物资类型分组
        Map<String, List<ProductDemandPlanDetailsExportVO>> map = vos.stream().collect(Collectors.groupingBy(ProductDemandPlanDetailsExportVO::getMaterialType));
        /*
             此时vos就是需要导出的数据
         */
        //每个sheet代表一种物资类型，sheet下面的备注就是物资类型下面的备注
        //查询所有的物资类型
        writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("板材", "型材", "锻件", "外购件", "辅材"), 5, List.of(10, 11)));

        for (MaterialTypeVO type : materialTypes) {
            String materialType = type.getMaterialType();
            if (map.get(materialType) != null) {
                //该类型存在数据不存,map获取结果可能为null
                if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 12))));
                } else {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 10))));
                }
            }
        }
        ProductInformationVO productInformationDetail = productManageService.getProductInformationDetail(productDemandPlan.getProductInformationId());
        String productName = productInformationDetail.getProductName();

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/template.xlsx");

        ExcelExportService excelExportService = new ExcelExportService("产品需求计划详情-"+productName+"-"+productDemandPlan.getScheduleNo()+"-"+productDemandPlan.getBatch(), response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //制造编号
        String param1 = productDemandPlan.getManufacturingNumber() != null ? productDemandPlan.getManufacturingNumber() : "";
        //计划编号
        String param2 = productDemandPlan.getScheduleNo() != null ? productDemandPlan.getScheduleNo() : "";
        for (int i = 0; i < materialTypes.size(); i++) {
            String materialType = materialTypes.get(i).getMaterialType();
            //自增序号，列表数据
            List<ProductDemandPlanDetailsExportVO> voList = map.get(materialType);
            List<RemarkVO> remarkVOS = new ArrayList<>();
            HashMap<String, Object> data = new HashMap<>();
            if (voList != null) {
                AtomicInteger num = new AtomicInteger();
                for (ProductDemandPlanDetailsExportVO vo : voList) {
                    vo.setAutoincrementId(num.incrementAndGet());
                }
                for (ProductDemandPlanDetailsExportVO item : voList) {
                    //根据用料类型来设置厚度、宽度和长度
                    String ingredientsType = item.getIngredientsType();
                    if ("角钢".equals(item.getMaterialName())) {
                        try{
                            String specification = item.getSpecification();
                            //长度是第三尺寸
                            int indexOf = specification.indexOf("=");
                            item.setThirdSizeExport(Double.valueOf(specification.substring(indexOf + 1)));
                            //厚度是第二尺寸
                            int end = 0;
                            //规格里面的逗号可能是中文，可能是英文
                            if (specification.contains(",")) {
                                end = specification.indexOf(",");
                            } else if (specification.contains("，")) {
                                end = specification.indexOf("，");
                            }
                            item.setSecondSizeExport(specification.substring(0, end));
                        }catch (Exception e){
                            throw new RuntimeException("角钢的规格不符合规范");
                        }
                    }
                    if (!CommonUtil.isNull(ingredientsType)) {
                        //第三尺寸是长度
                        //第二尺寸是厚度
                        //第一尺寸是直径
                        if (ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                            //管形
                            item.setThirdSizeExport(item.getThirdSize().doubleValue() / 100);
                            item.setSecondSizeExport(String.valueOf(item.getSecondSize() / 100));
                            item.setFirstSizeExport(item.getFirstSize().doubleValue() / 100);
                        } else if (ingredientsType.equals(ComputerType.SQUARE.getCode())) {
                            //方形
                            item.setThirdSizeExport(item.getFirstSize().doubleValue() / 100);
                            item.setSecondSizeExport(String.valueOf(item.getSecondSize() / 100));
                        } else if (ingredientsType.equals(ComputerType.RECTANGLE.getCode())) {
                            //矩形
                            item.setThirdSizeExport(item.getFirstSize().doubleValue() / 100);
                            item.setSecondSizeExport(String.valueOf(item.getThirdSize() / 100));
                            item.setFirstSizeExport(item.getFirstSize().doubleValue() / 100);
                        } else if (ingredientsType.equals(ComputerType.STICK_SHAPE.getCode())) {
                            //棒形
                            item.setThirdSizeExport(item.getSecondSize().doubleValue() / 100);
                            item.setFirstSizeExport(item.getFirstSize().doubleValue() / 100);
                        } else if (ingredientsType.equals(ComputerType.ANNULAR.getCode())) {
                            //环形：从规格中解析出来
                            String specification = item.getSpecification();
                            //长度
                            String firstSize = specification.substring(specification.indexOf("X")+1, specification.lastIndexOf("X"));
                            //宽度
                            String secondSize = specification.substring(specification.lastIndexOf("X")+1);
                            //厚度
                            String thirdSize = specification.substring(1,specification.indexOf("X"));
                            //厚度
                            item.setSecondSizeExport(thirdSize);
                            //长度
                            item.setThirdSizeExport(Double.valueOf(firstSize));
                            //宽度
                            item.setFirstSizeExport(Double.valueOf(secondSize));

                        } else if (ingredientsType.equals(ComputerType.CIRCULAR.getCode())) {
                            //圆形
                            item.setSecondSizeExport(String.valueOf(item.getSecondSize() / 100));
                            item.setFirstSizeExport(item.getFirstSize().doubleValue() / 100);
                        } else if (ingredientsType.equals(ComputerType.DRUM.getCode())) {
                            //根据规格拆分
                            String specification = item.getSpecification();
                            //δ48X350X175   拆分规则如下
                            //厚度   直径  长度
                            int lastIndexOf = specification.lastIndexOf("X");
                            int indexOf = specification.indexOf("X");
                            item.setThirdSizeExport(Double.valueOf(specification.substring(lastIndexOf + 1)));
                            item.setFirstSizeExport(Double.valueOf(specification.substring(indexOf + 1, lastIndexOf)));
                            item.setSecondSizeExport(specification.substring(1, indexOf));
                        } else {
                            item.setThirdSizeExport(item.getThirdSize().doubleValue() / 100);
                            item.setSecondSizeExport(String.valueOf(item.getSecondSize() / 100));
                            item.setFirstSizeExport(item.getFirstSize().doubleValue() / 100);
                        }
                    }
                    //2023/01/30  数量 = 数量 +  备件数量
                    item.setCountExport( (item.getCount().doubleValue() + item.getSparePartsQuantity().doubleValue() ) / 100);
                    //2023/02/01  如果有备件，导出就在备注里面加上：备件+数量
                    if (!CommonUtil.isNull(item.getSparePartsQuantity())){
                        if (item.getSparePartsQuantity() > 0){
                            item.setRemarks(item.getRemarks() + "备件" +item.getSparePartsQuantity()/100 + "件" );
                        }
                    }
                    if ( !CommonUtil.isNull(item.getWeight())) {
                        if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())){
                            item.setWeightExport(item.getWeight().doubleValue()/100);
                        }else {
                            item.setWeightExport(item.getWeight().doubleValue() / 100);
                        }
                    } else {
                        item.setWeightExport(0.0);
                    }
                }
                //计算列总和
                double total = voList.stream().filter(item -> !CommonUtil.isNull(item.getWeightExport())).mapToDouble(ProductDemandPlanDetailsExportVO::getWeightExport).sum();
                //数据库尺寸是扩大一百倍的，这里需要缩小
                //自定义参数数据
                data.put("param1", param1);
                data.put("param2", param2);
                data.put("param3", materialType);
                data.put("total", total);
                //备注数据:根据产品id查询
                String remarks = materialTypes.get(i).getRemarks();
                if (CommonUtil.isNull(remarks)) {
                    RemarkVO remarkVO = new RemarkVO();
                    remarkVOS.add(remarkVO);
                } else {
                    String[] split = remarks.split("\n");
                    for (int j = 0; j < split.length; j++) {
                        RemarkVO remarkVO = new RemarkVO();
                        remarkVO.setSeq(j + 1);
                        remarkVO.setContent(split[j]);
                        remarkVOS.add(remarkVO);
                    }
                }
            }
            if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                excelExportService.fill(new FillWrapper("list", voList), materialType);
            } else {
                List<ProductDemandPlanDetailsExportCopyVO> copyVOS = BeanUtil.copyList(voList, ProductDemandPlanDetailsExportCopyVO.class);
                excelExportService.fill(new FillWrapper("list", copyVOS), materialType);
            }
            //备注
            excelExportService.fill(new FillWrapper("remark", remarkVOS), materialType);
            //表头
            excelExportService.fill(data, materialType);
        }
        /*
          导出封面内容
         */
        //项目编号:根据产品需求计划id查询产品信息表，在产品信息表中获取项目id，获得项目信息
        String projectId = productInformationDetail.getProjectId();
        ProjectVO projectVO = projectService.getById(projectId);
        String projectNo = projectVO.getProjectNo();
        //项目名称
        String projectName = projectVO.getProjectName();
        HashMap<String, Object> data = new HashMap<>();
        data.put("param2", param2);
        data.put("organization", productDemandPlan.getCompiler());
        data.put("organizationTime", productDemandPlan.getPrepartation());
        data.put("engineer", productDemandPlan.getProofreader());
        data.put("process", productDemandPlan.getProofreadingTime());
        data.put("manager", productDemandPlan.getReviewer());
        data.put("reviewTime", productDemandPlan.getReviewTime());
        data.put("approval", productDemandPlan.getChecker());
        data.put("approvalTime", productDemandPlan.getCheckTime());
        data.put("projectNo", projectNo);
        data.put("projectName", projectName);
        excelExportService.fill(data, "封面");
        /*
          导出编制说明
         */
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
        String[] split = productDemandPlan.getPreparationDescription().split("\n");
        for (int i = 0; i < split.length; i++) {
            RemarkVO remarkVO = new RemarkVO();
            remarkVO.setSeq(i + 1);
            remarkVO.setContent(split[i]);
            remarkVOS.add(remarkVO);
        }
        excelExportService.fill(new FillWrapper("explain", remarkVOS), "编制说明");
        excelExportService.export();
    }

    public List<ProductDemandPlanDetailsVO> selectDetailsByProductId(GetManyById dto) {
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .eq(!CommonUtil.isNull(dto.getKeyId()), ProductDemandPlanDetails::getProductInformationId, dto.getKeyId());
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        List<ProductDemandPlanDetailsVO> productDemandServiceVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsVO.class);
        productDemandServiceVOS.forEach(item -> {
            if (CommonUtil.isNull(item.getCount())) {
                item.setCount(0L);
            }
            if (CommonUtil.isNull(item.getFirstSize())) {
                item.setFirstSize(0L);
            }
            if (CommonUtil.isNull(item.getSecondSize())) {
                item.setSecondSize(0L);
            }
            if (CommonUtil.isNull(item.getThirdSize())) {
                item.setThirdSize(0L);
            }
            if (CommonUtil.isNull(item.getDemandProposalPrice())) {
                item.setDemandProposalPrice(0L);
            }
            if (CommonUtil.isNull(item.getProportion())) {
                item.setProportion(0L);
            }
            if (CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantity(0L);
            }
            if (CommonUtil.isNull(item.getWeight())) {
                item.setWeight(0L);
            }
            item.setSpecificationText(item.getSpecification());
            //规格和备注
            //材料类型是板材规格是  δ + 厚度
            if (item.getMaterialType().equals(MaterialType.BOARD.getName())) {
                if (!CommonUtil.isNull(item.getIngredientsType())){
                    //根据用料类型判断厚度
                    //环形和矩形的第三尺寸是厚度， 圆形、管形、管、方形和卷筒的第二尺寸厚度
                    //棒形没有厚度
                    String ingredientsType = item.getIngredientsType();
                    if (ingredientsType.equals(ComputerType.ANNULAR.getCode())||ingredientsType.equals(ComputerType.RECTANGLE.getCode())){
                        item.setSpecificationText("δ" + item.getThirdSize() / 100);
                    }
                    if (ingredientsType.equals(ComputerType.CIRCULAR.getCode())||
                    ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode())||
                    ingredientsType.equals(ComputerType.TUBE.getCode())||
                    ingredientsType.equals(ComputerType.SQUARE.getCode())||
                    ingredientsType.equals(ComputerType.DRUM.getCode())){
                        item.setSpecificationText("δ" +item.getSecondSize() / 100);
                    }
                }else {
                    item.setSpecificationText("δ" +item.getThirdSize() / 100);
                }
            }
            //用料类型是棒形规格是直径 φ + 直径
            if (item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                item.setSpecificationText("φ" + item.getFirstSize() / 100);
            }
            //用料类型是管形规格是φ273×8
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                if (item.getSpecification().contains(",") && item.getSpecification().contains("φ")) {
                    //根据逗号拆分
                    int index = item.getSpecification().indexOf(",");
                    item.setSpecificationText(item.getSpecification().substring(0, index));
                }
            }
            //用料类型环形 第四尺寸放在备注
            if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())) {
                item.setRemarkText(item.getFourthSizeOutsourcingStandards()+"拼");
            }
            //用料类型是管形、棒形 长度放在备注
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                    item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                if (item.getSpecification().contains("L")) {
                    int indexOf = item.getSpecification().indexOf(",");
                    item.setRemarkText(item.getSpecification().substring(indexOf + 1));
                }
            }
            //材料类型是型材第一尺寸是str 长度放在备注
            if (item.getMaterialType().equals(MaterialType.PROFILE.getName()) && item.getIsCalculate()) {
                if (item.getSpecification().contains("L")) {
                    //后面  L=5000要去掉
                    int index = item.getSpecification().indexOf("L");
                    item.setSpecificationText(item.getSpecification().substring(0,index-1));
                    item.setRemarkText(item.getSpecification().substring(index));
                }
            }

        });
        return productDemandServiceVOS;
    }

    public List<MaterialTypeVO> getMaterialTypeByProductIdAndBatch(GetMaterialTypeDTO dto) {
        return this.getMaterialTypeByProductId(dto.getProductInformationId(),dto.getBatch());
    }

    public List<MaterialTypeVO> getMaterialTypeByProductId(String productInformationId,String batch) {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class)
                .eq(!CommonUtil.isNull(productInformationId), MaterialTypeEntity::getProductInformationId, productInformationId)
                .eq(!CommonUtil.isNull(batch),MaterialTypeEntity::getBatch,batch);
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeEntities, MaterialTypeVO.class);
    }

    public void addByProductId(String id,String batch) {
        ArrayList<MaterialTypeEntity> materialTypeEntities = new ArrayList<>();
        ArrayList<String> list = new ArrayList<>();
        list.add("板材");
        list.add("型材");
        list.add("锻件");
        list.add("外购件");
        list.add("辅材");
        //五种类型数据添加
        for (String s : list) {
            MaterialTypeEntity materialTypeEntity = new MaterialTypeEntity();
            materialTypeEntity.setProductInformationId(id);
            materialTypeEntity.setMaterialType(s);
            materialTypeEntity.setBatch(batch);
            materialTypeEntities.add(materialTypeEntity);
        }
        materialTypeMapper.insertBatchSomeColumn(materialTypeEntities);
    }

    @Autowired
    private ProjectDemandPlanService projectDemandPlanService;

    public List<ProductDemandSelectVO> getProductDemandSelect(DeleteOrGetOneDTO dto) {
        //根据项目id，查询所有未生成过产品需求计划 的产品需求计划
        //查询项目下面的产品
        ProjectIdDTO projectIdDTO = new ProjectIdDTO();
        projectIdDTO.setProjectId(dto.getId());
        List<ProductByProjectIdVO> productByProjectId = productManageService.getProductByProjectId(projectIdDTO);
        //产品id
        Map<String, List<ProductByProjectIdVO>> collect = productByProjectId.stream().collect(Collectors.groupingBy(ProductByProjectIdVO::getId));
        //在产品需求计划中查询  属于该项目下的产品 并且 尚未生成项目需求计划的
        //项目需求计划里面查询该项目下面所有的产品需求计划id
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanService.getProjectDemandPlanByProject(dto.getId());
        ArrayList<String> arrayList = new ArrayList<>();
        projectDemandPlans.forEach(
                item -> {
                    if (!CommonUtil.isNull(item.getIdListString())){
                        //产品需求计划id
                        String[] split = item.getIdListString().substring(1, item.getIdListString().length() - 1).split(",");
                        for (int i = 0; i < split.length; i++) {
                            split[i] = split[i].trim();
                        }
                        arrayList.addAll(List.of(split));
                    }
                }
        );
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        ArrayList<String> strings = new ArrayList<>(collect.keySet());
        wrapper.selectAll(ProductDemandPlan.class)
                .in(CommonUtil.listIsNotEmpty(strings),ProductDemandPlan::getProductInformationId,strings)
                .notIn(CommonUtil.listIsNotEmpty(arrayList),ProductDemandPlan::getId,arrayList);
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
        ArrayList<ProductDemandSelectVO> productDemandSelectVOS = new ArrayList<>();
        productDemandPlans.forEach(
                item -> {
                    String value = collect.get(item.getProductInformationId()).get(0).getProductName()+"_"
                            +item.getScheduleNo()+"_"+item.getBatch()+"_"+(item.getNumber()/100);
                    ProductDemandSelectVO build = ProductDemandSelectVO.builder().id(item.getId()).value(value).build();
                    productDemandSelectVOS.add(build);
                }
        );
        return productDemandSelectVOS;
    }

    public List<SelectVO> getMaterialTypeSelect() {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        selectVOS.add(SelectVO.builder().id(1).materialType("板材").build());
        selectVOS.add(SelectVO.builder().id(2).materialType("型材").build());
        selectVOS.add(SelectVO.builder().id(3).materialType("锻件").build());
        selectVOS.add(SelectVO.builder().id(4).materialType("辅材").build());
        selectVOS.add(SelectVO.builder().id(5).materialType("外购件").build());
        
        return selectVOS;
    }

    public List<SelectVO> getMaterialType(GetMaterialTypeDTO dto) {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        selectVOS.add(SelectVO.builder().id(1).materialType("板材").build());
        selectVOS.add(SelectVO.builder().id(2).materialType("型材").build());
        selectVOS.add(SelectVO.builder().id(3).materialType("锻件").build());
        selectVOS.add(SelectVO.builder().id(4).materialType("辅材").build());
        selectVOS.add(SelectVO.builder().id(5).materialType("外购件").build());
        return selectVOS;
    }

    public List<ProductDemandPlanSelectVO> getProductDemandPlanSelect() {
        //value 的值产品需求计划拼接
        //所有的产品需求计划
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(null);
        ArrayList<ProductDemandPlanSelectVO> productOutlineVOS = new ArrayList<>();
        productDemandPlans.forEach(item -> {
            ProductDemandPlanSelectVO productOutlineVO = new ProductDemandPlanSelectVO();
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            if (!CommonUtil.isNull(productInformation)){
                productOutlineVO.setId(item.getId());
                productOutlineVO.setProjectId(productInformation.getProjectId());
                productOutlineVO.setProjectName(projectService.getById(productInformation.getProjectId()).getProjectName());
                String value = productInformation.getManufacturingNumber() + "【"+productInformation.getProductName()+"】"+"-"+item.getScheduleNo();
                productOutlineVO.setValue(value);
                productOutlineVO.setProductName(productInformation.getProductName());
                productOutlineVO.setManufacturingNumber(productInformation.getManufacturingNumber());
                productOutlineVO.setContainerCategory(productInformation.getContainerCategory());
                productOutlineVO.setBatch(item.getBatch());
                productOutlineVO.setScheduleNo(item.getScheduleNo());
                productOutlineVOS.add(productOutlineVO);
            }
        });
        return productOutlineVOS;
    }

    public List<ProductDemandPlanDetailsVO> selectDetailsByProductDemandPlanId(GetManyById dto) {
        //根据产品需求 查询产品需求明细，dto中的keyId是产品需求计划id
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getKeyId());
        Long count = productDemandPlan.getNumber()/100;
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .eq(!CommonUtil.isNull(dto.getKeyId()), ProductDemandPlanDetails::getProductDemandPlanId, dto.getKeyId());
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        List<ProductDemandPlanDetailsVO> productDemandServiceVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsVO.class);
        productDemandServiceVOS.forEach(item -> {
            //产品需求明细里面的 重量、数量和备件数量 需要除以  产品需求数量
            if (CommonUtil.isNull(item.getCount())) {
                item.setCount(0L);
            }else {
                item.setCount(item.getCount()/count);
            }
            if (CommonUtil.isNull(item.getFirstSize())) {
                item.setFirstSize(0L);
            }
            if (CommonUtil.isNull(item.getSecondSize())) {
                item.setSecondSize(0L);
            }
            if (CommonUtil.isNull(item.getThirdSize())) {
                item.setThirdSize(0L);
            }
            if (CommonUtil.isNull(item.getDemandProposalPrice())) {
                item.setDemandProposalPrice(0L);
            }
            if (CommonUtil.isNull(item.getProportion())) {
                item.setProportion(0L);
            }
            if (CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantity(0L);
            }else {
                item.setSparePartsQuantity(item.getSparePartsQuantity()/count);
            }
            if (CommonUtil.isNull(item.getWeight())) {
                item.setWeight(0L);
            }else {
                item.setWeight(item.getWeight()/count);
            }
            item.setSpecificationText(item.getSpecification());
            //规格和备注
            //材料类型是板材规格是  δ + 厚度
            if (item.getMaterialType().equals(MaterialType.BOARD.getName())) {
                if (!CommonUtil.isNull(item.getIngredientsType())){
                    //根据用料类型判断厚度
                    //环形和矩形的第三尺寸是厚度， 圆形、管形、管、方形和卷筒的第二尺寸厚度
                    //棒形没有厚度
                    String ingredientsType = item.getIngredientsType();
                    if (ingredientsType.equals(ComputerType.ANNULAR.getCode())||ingredientsType.equals(ComputerType.RECTANGLE.getCode())){
                        item.setSpecificationText("δ" + item.getThirdSize() / 100);
                    }
                    if (ingredientsType.equals(ComputerType.CIRCULAR.getCode())||
                            ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode())||
                            ingredientsType.equals(ComputerType.TUBE.getCode())||
                            ingredientsType.equals(ComputerType.SQUARE.getCode())||
                            ingredientsType.equals(ComputerType.DRUM.getCode())){
                        item.setSpecificationText("δ" +item.getSecondSize() / 100);
                    }
                }else {
                    item.setSpecificationText("δ" +item.getThirdSize() / 100);
                }
            }
            //用料类型是棒形规格是直径 φ + 直径
            if (item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                item.setSpecificationText("φ" + item.getFirstSize() / 100);
            }
            //用料类型是管形规格是φ273×8
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                if (item.getSpecification().contains(",") && item.getSpecification().contains("φ")) {
                    //根据逗号拆分
                    int index = item.getSpecification().indexOf(",");
                    item.setSpecificationText(item.getSpecification().substring(0, index));
                }
            }
            //用料类型环形 第四尺寸放在备注
            if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())) {
                item.setRemarkText(item.getFourthSizeOutsourcingStandards()+"拼");
            }
            //用料类型是管形、棒形 长度放在备注
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                    item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                if (item.getSpecification().contains("L")) {
                    int indexOf = item.getSpecification().indexOf(",");
                    item.setRemarkText(item.getSpecification().substring(indexOf + 1));
                }
            }
            //材料类型是型材第一尺寸是str 长度放在备注
            if (item.getMaterialType().equals(MaterialType.PROFILE.getName()) && item.getIsCalculate()) {
                if (item.getSpecification().contains("L")) {
                    //后面  L=5000要去掉
                    int index = item.getSpecification().indexOf("L");
                    item.setSpecificationText(item.getSpecification().substring(0,index-1));
                    item.setRemarkText(item.getSpecification().substring(index));
                }
            }
        });
        return productDemandServiceVOS;
    }

    public List<ProductDemandPlanNotProductionPlanVO> getProductDemandPlanNotProductionPlan() {
        //查询未处于生产计划的产品需求计划
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
         wrapper.selectAll(ProductDemandPlan.class)
                 .eq(ProductDemandPlan::getIsProductionPlan,0)
                 .orderByDesc(ProductDemandPlan::getCreateTime);
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
        //封装信息主要还是产品信息，只保留批次 和 计划编号
        ArrayList<ProductDemandPlanNotProductionPlanVO> productDemandPlanNotProductionPlanVOS = new ArrayList<>();
        productDemandPlans.forEach(item -> {
            ProductDemandPlanNotProductionPlanVO vo = new ProductDemandPlanNotProductionPlanVO();
            //获取产品信息
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            vo.setId(item.getId());
            vo.setProjectId(productInformation.getProjectId());
            vo.setProductName(productInformation.getProductName());
            vo.setTagNo(productInformation.getTagNo());
            vo.setProductSpecificatons(productInformation.getProductSpecificatons());
            vo.setTotalFigureNo(productInformation.getTotalFigureNo());
            vo.setNumber(item.getNumber());
            vo.setContainerCategory(productInformation.getContainerCategory());
            vo.setUseUnit(productInformation.getUseUnit());
            vo.setManufacturingNumber(productInformation.getManufacturingNumber());
            vo.setWeight(productInformation.getWeight());
            vo.setIsProductionPlan(item.getIsProductionPlan());
            vo.setIsProductionScheduling(item.getIsProductionScheduling());
            vo.setBatch(item.getBatch());
            vo.setScheduleNo(item.getScheduleNo());
            productDemandPlanNotProductionPlanVOS.add(vo);
        });
        return productDemandPlanNotProductionPlanVOS;
    }

    /**
     *  根据产品需求计划创建生产计划（调用产品模块的接口），产品计划生成成功后，更改产品需求计划里面的生产状态
     * @param dto 产品需求计划id
     * @return  创建成功：true  失败：false
     */
    @Transactional(rollbackFor = Exception.class)
    public ResponseResult<Boolean> createProductPlan(CreateProductPlanDTO dto) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        if (CommonUtil.isNull(productDemandPlan)){
            throw new RuntimeException("该产品需求计划不存在");
        }
        ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
        //生产计划的DTO
        ProductPlanCreateDTO productPlanCreateDTO = new ProductPlanCreateDTO();
        //生产计划关联到产品需求计划
        productPlanCreateDTO.setProjectKeyId(productDemandPlan.getProductInformationId());
        productPlanCreateDTO.setManufacturingNumber(productInformation.getManufacturingNumber());
        productPlanCreateDTO.setTagNo(productInformation.getTagNo());
        productPlanCreateDTO.setContainerCategory(productInformation.getContainerCategory());
        productPlanCreateDTO.setProductName(productInformation.getProductName());
        productPlanCreateDTO.setProductSpecificatons(productInformation.getProductSpecificatons());
        //主要材质，暂时不考虑
        productPlanCreateDTO.setMainMaterial(null);
        productPlanCreateDTO.setQuantity((int) (productDemandPlan.getNumber()/100));
        productPlanCreateDTO.setWeight(Double.valueOf(productInformation.getWeight()));
        //用户：就是使用单位
        productPlanCreateDTO.setCustomer(productInformation.getUseUnit());
        //2023/03/09
        productPlanCreateDTO.setProductDemandKeyId(dto.getId());
        productPlanCreateDTO.setBatch(productDemandPlan.getBatch());
        productPlanCreateDTO.setScheduleNo(productDemandPlan.getScheduleNo());
        //调用产品模块的创建生产计划的接口
        ResponseResult<Boolean> productPlan = productService.createProductPlan(productPlanCreateDTO);
        if (productPlan.getData()){
            //创建生产计划成功，更新产品需求计划对应的产品生产状态
            UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
            wrapper.eq("id",dto.getId())
                    .set("is_production_plan",1);
            if (productDemandPlanMapper.update(new ProductDemandPlan(),wrapper)>0){
                return ResponseResult.success("操作成功",true);
            }
        }else {
            return productPlan;
        }
        return ResponseResult.error("创建生产计划失败",false);
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean changeProductScheduling(ProductSchedulingDTO dto) {
        UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(dto.getId()),"id",dto.getId())
                .set(!CommonUtil.isNull(dto.getCode()),"is_production_scheduling",dto.getCode());
        int update = productDemandPlanMapper.update(new ProductDemandPlan(), wrapper);
        if (update>0){
            //之前productId 现在改成产品需求计划id，其他的保持不变
            ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
            ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
            //调用质量模块的接口，新增一条产品质量记录的信息
            ProductQualityDTO productQualityDTO = new ProductQualityDTO();
            productQualityDTO.setProjectId(productInformation.getProjectId());
            productQualityDTO.setProductId(dto.getId());
            Boolean quality = qualityService.insertProductQuality(productQualityDTO);
            if (quality){
                log.info("新增了一条产品质量质检记录");
            }
        }
        return update > 0;
    }

    public boolean changeProductPlan(DeleteOrGetOneDTO dto) {
        //更新产品需求计划中的生产状态
        UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.set("is_production_plan",0)
                .eq("id",dto.getId());
        if (productDemandPlanMapper.update(new ProductDemandPlan(), wrapper)>0){
            //生产模块删除数据  删除质量模块的 质检数据
            boolean demand = qualityService.deleteProductQualityByProductDemand(dto.getId());
            log.info("质量模块删除数据:{}",demand);
            return demand;
        }
        return false;
    }

    public List<ProductDemandInProductionSchedulingVO> getProductDemandInProductionScheduling() {
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlan.class)
                .eq(ProductDemandPlan::getIsProductionScheduling,1)
                .orderByDesc(ProductDemandPlan::getCreateTime);
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
        ArrayList<ProductDemandInProductionSchedulingVO> list = new ArrayList<>();
        productDemandPlans.forEach( item -> {
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            if (!CommonUtil.isNull(productInformation)){
                ProductDemandInProductionSchedulingVO demand = BeanUtil.copy(productInformation, ProductDemandInProductionSchedulingVO.class);
                demand.setId(item.getId());
                demand.setIsProductionPlan(item.getIsProductionPlan());
                demand.setIsProductionScheduling(item.getIsProductionScheduling());
                demand.setBatch(item.getBatch());
                demand.setScheduleNo(item.getScheduleNo());
                list.add(demand);
            }
        });
        return list;
    }

    public ProductDemandVO selectByKeyId(KeyIdDTO dto) {
        //根据产品需求计划id查询
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getKeyId());
        ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
        ProductDemandVO productDemandVO = BeanUtil.copy(productInformation, ProductDemandVO.class);
        productDemandVO.setId(productDemandPlan.getId());
        productDemandVO.setBatch(productDemandPlan.getBatch());
        productDemandVO.setScheduleNo(productDemandPlan.getScheduleNo());
        productDemandVO.setProjectName(projectService.getById(productDemandVO.getProjectId()).getProjectName());
        return productDemandVO;
    }

    public com.vren.common.module.material.entity.ProductInformationVO getProductInformationByName(QueryProductDTO dto) {

        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        dto.setId(productDemandPlan.getProductInformationId());
        ProductInformationVO productInformationVO = productManageService.getProductInformationByName(dto);
        com.vren.common.module.material.entity.ProductInformationVO copy = BeanUtil.copy(productInformationVO, com.vren.common.module.material.entity.ProductInformationVO.class);
        copy.setBatch(productDemandPlan.getBatch());
        copy.setScheduleNo(productDemandPlan.getScheduleNo());
        return copy;
    }
}
