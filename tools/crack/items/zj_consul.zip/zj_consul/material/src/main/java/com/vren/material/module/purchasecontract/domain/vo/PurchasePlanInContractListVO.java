package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  合同清单下的采购计划
 */
@Data
public class PurchasePlanInContractListVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目编号")
    private String projectNo;

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("单位名称")
    private String unitName;

    @ApiModelProperty("到货时间")
    private Date arrivalTime;

    @ApiModelProperty("到货地点")
    private String arrivalLocation;

    @ApiModelProperty("到货状态(1未到货、2部分到货、3已到货)")
    private Integer arrivalStatus;

    @ApiModelProperty("到货状态")
    private String arrivalStatusText;

    @ApiModelProperty("所属厂区")
    private String owningFactory;

    @ApiModelProperty("需求计划编号")
    private String demandPlanNumber;


}
