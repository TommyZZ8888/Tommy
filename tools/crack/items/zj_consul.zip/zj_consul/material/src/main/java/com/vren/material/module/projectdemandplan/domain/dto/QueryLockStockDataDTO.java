package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryLockStockDataDTO {

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("规格——焊材")
    private String size;

    @ApiModelProperty("项目id")
    private String projectId;


}
