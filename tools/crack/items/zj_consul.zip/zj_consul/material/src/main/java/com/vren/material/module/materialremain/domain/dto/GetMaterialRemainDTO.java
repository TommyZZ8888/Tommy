package com.vren.material.module.materialremain.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GetMaterialRemainDTO extends PageParam {

    @ApiModelProperty("余料名称")
    private String remainingMaterialName;

    @ApiModelProperty("余料编号")
    private String remainingMaterialNo;

    @ApiModelProperty("库存状态")
    private Integer stockStatus;

}
