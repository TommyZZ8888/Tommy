package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryDTO extends PageParam {

    @ApiModelProperty("产品名称（传产品id）")
    private String productName;

    @ApiModelProperty("项目名称（传项目id）")
    private String projectName;

    @ApiModelProperty("计划编号")
    private String scheduleNo;

    @ApiModelProperty("审核状态")
    private String reviewState;
}
