package com.vren.material.module.projectdemandplan.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 *  推荐的锁库数据：库存里面符合条件的数据
 */
@Data
public class LockStockData {

    @ApiModelProperty("库存表id")
    private String id;

    @ApiModelProperty("物资类型:1板材、2型材（型材、管材、棒材）、3辅材（五金等）、4外购件、5锻材、6焊材、7油漆、8备品/备件、9余料")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("规格——焊材")
    private String size;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ApiModelProperty("库存状态 1锁库、2未锁库")
    private Integer stockStatus;

    @ApiModelProperty("库存状态")
    private String stockStatusText;


}
