package com.vren.material.module.projectdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class WeldingMaterialDemandQueryPlanDTO extends PageParam {
    @ApiModelProperty("计划编号")
    @NotBlank(message = "计划编号不能为空")
    private String planNo;
    @ApiModelProperty("材料名称")
    private String materialName;
    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;
}
