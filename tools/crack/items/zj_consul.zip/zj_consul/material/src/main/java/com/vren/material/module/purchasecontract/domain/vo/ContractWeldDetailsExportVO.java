package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ContractWeldDetailsExportVO {
    @ApiModelProperty("序号")
    @ExcelProperty("序号")
    private Integer number;

    @ApiModelProperty("入库编号")
    @ExcelIgnore
    private String warehousingNo;

    @ApiModelProperty("材料名称")
    @ExcelProperty("物资名称")
    private String materialName;


    @ApiModelProperty("规格")
    @ExcelIgnore
    private String size;

    @ApiModelProperty("厚度")
    @ExcelProperty("厚度")
    private String thickness;

    @ApiModelProperty("宽度")
    @ExcelProperty("宽度")
    private String width;

    @ApiModelProperty("长度")
    @ExcelProperty("长度")
    private String length;

    @ApiModelProperty("材质")
    @ExcelProperty("材质")
    private String texture;

    @ApiModelProperty("执行标准")
    @ExcelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    @ExcelProperty("单位1")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelProperty("数量")
    private Integer purchaseAmount;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    @ExcelProperty("采购重量")
    private Long purchaseWeight;

    @ApiModelProperty("单位2")
    @ExcelProperty("单位2")
    private String unitTwo;

    @ApiModelProperty("不含税单价")
    @ConversionNumber
    @ExcelProperty("不含税单价")
    private Long preTaxPrice;

    @ApiModelProperty("含税单价")
    @ConversionNumber
    @ExcelProperty("含税单价")
    private Long unitPriceWithTax;

    @ApiModelProperty("不含税总价")
    @ConversionNumber
    @ExcelProperty("不含税总价")
    private Long totalPriceExcludingTax;

    @ApiModelProperty("含税总价")
    @ConversionNumber
    @ExcelProperty("含税总价")
    private Long totalPriceIncludingTax;


    @ApiModelProperty("税额")
    @ExcelIgnore
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("税率")
    @ExcelProperty("税率")
    private Integer taxRate;

    @ApiModelProperty("牌号")
    @ExcelProperty("品牌")
    private String brand;


    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;

    @ApiModelProperty("用料类型")
    @ExcelIgnore
    private String ingredientsType;





}
