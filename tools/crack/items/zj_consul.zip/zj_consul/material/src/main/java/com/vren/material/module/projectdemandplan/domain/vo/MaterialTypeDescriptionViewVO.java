package com.vren.material.module.projectdemandplan.domain.vo;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialTypeDescriptionViewVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;

    @ApiModelProperty("备注")
    private String remarks;
}
