package com.vren.material.module.purchasecontract.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@TableName("contract_list")
@Data
public class ContractList {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("合同名称")
    private String contractName;

    @ApiModelProperty("采购状态（1招标公告、2投标、3定标、4合同签订）")
    private Integer purchaseStatus;

    @ApiModelProperty("采购名称")
    private String purchaseName;

    @ApiModelProperty("采购人")
    private String purchaser;

}
