package com.vren.material.module.purchaseplan;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.purchaseplan.domain.dto.*;
import com.vren.material.module.purchaseplan.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/purchaseplan")
@Api(tags = {"采购计划"})
@OperateLog
public class PurchasePlanController {

    @Autowired
    private PurchasePlanService purchasePlanService;

    @RequestMapping(value = "/generatePurchasePlan", method = RequestMethod.POST)
    @ApiOperation("生成采购计划")
    public ResponseResult<Boolean> generatePurchasePlan(@RequestBody @Valid GeneratePurchasePlanDTO dto) {
        purchasePlanService.generatePurchasePlan(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/selectPurchasePlan", method = RequestMethod.POST)
    @ApiOperation("查询采购计划")
    public ResponseResult<PageResult<PurchasePlanDateVO>> getPurchasePlan(@RequestBody QueryPurchasePlanDTO dto){
        return  ResponseResult.success("获取成功",purchasePlanService.getPurchasePlan(dto));
    }

    @RequestMapping(value = "/purchaseStatusSelect", method = RequestMethod.POST)
    @ApiOperation("采购状态下拉框")
    public ResponseResult<List<SelectVO>> purchaseStatusSelect(){
        return  ResponseResult.success("获取成功",purchasePlanService.purchaseStatusSelect());
    }

    @RequestMapping(value = "/planTypeSelect", method = RequestMethod.POST)
    @ApiOperation("计划类型下拉框")
    public ResponseResult<List<SelectVO>> planTypeSelect(){
        return  ResponseResult.success("获取成功",purchasePlanService.planTypeSelect());
    }

    @RequestMapping(value = "/arrivalStatusSelect", method = RequestMethod.POST)
    @ApiOperation("到货状态下拉框")
    public ResponseResult<List<SelectVO>> arrivalStatusSelect(){
        return  ResponseResult.success("获取成功",purchasePlanService.arrivalStatusSelect());
    }

    @RequestMapping(value = "/selectPurchasePlanById", method = RequestMethod.POST)
    @ApiOperation("根据id查询采购计划")
    public ResponseResult<PurchasePlanVO> getPurchasePlanById(@RequestBody QueryOneDTO dto){
        return  ResponseResult.success("获取成功",purchasePlanService.getPurchasePlanById(dto));
    }

    @RequestMapping(value = "/deletePurchasePlan", method = RequestMethod.POST)
    @ApiOperation("按项目删除采购计划")
    public ResponseResult<Boolean> deletePurchasePlan(@RequestBody DeletePurchasePlanDTO dto){
        purchasePlanService.deletePurchasePlan(dto);
        return  ResponseResult.success("获取成功",true);
    }

    @RequestMapping(value = "/editPurchasePlan", method = RequestMethod.POST)
    @ApiOperation("编辑采购计划")
    public ResponseResult<Boolean> editPurchasePlan(@RequestBody @Valid UpdatePurchasePlanDTO dto){
        purchasePlanService.editPurchasePlan(dto);
        return  ResponseResult.success("操作成功",true);
    }

//    @NoNeedLogin
//    @RequestMapping(value = "/selectPurchasePlanStatusRecord", method = RequestMethod.POST)
//    @ApiOperation("根据采购计划id查询采购状态记录")
//    public ResponseResult<List<PurchaseStatusRecordVO>> getPurchasePlanStatus(@RequestBody @Valid QueryOneDTO dto){
//        List<PurchaseStatusRecordVO> result = purchasePlanService.getPurchasePlanStatus(dto);
//        return  ResponseResult.success("操作成功",result);
//    }

    //***************************************子列表：采购计划详情****************************

    @RequestMapping(value = "/selectPurchasePlanDetails", method = RequestMethod.POST)
    @ApiOperation("查询采购计划详情(根据采购计划id和查询条件查询)")
    public ResponseResult<PageResult<PurchasePlanDetailVO>> getPurchasePlanDetails(@RequestBody QueryOneDTO dto){
        return  ResponseResult.success("获取成功",purchasePlanService.getPurchasePlanDetails(dto));
    }

    @RequestMapping(value = "/editPurchasePlanDetail", method = RequestMethod.POST)
    @ApiOperation("编辑采购计划详情（物资类型不可编辑）")
    public ResponseResult<Boolean> editPurchasePlanDetail(@RequestBody @Valid UpdatePurchasePlanDetailDTO dto){
        purchasePlanService.editPurchasePlanDetail(dto);
        return  ResponseResult.success("操作成功",true);
    }

    @RequestMapping(value = "/deletePurchasePlanDetail", method = RequestMethod.POST)
    @ApiOperation("删除采购计划详情")
    public ResponseResult<Boolean> deletePurchasePlanDetail(@RequestBody DeletePurchasePlaDetailDTO dto){
        purchasePlanService.deletePurchasePlanDetail(dto);
        return  ResponseResult.success("获取成功",true);
    }

    @RequestMapping(value = "/selectPurchasePlanDetailById", method = RequestMethod.POST)
    @ApiOperation("根据id和物资类型查询采购计划详情")
    public ResponseResult<PurchasePlanDetailVO> getPurchasePlanDetailById(@RequestBody DeletePurchasePlaDetailDTO dto){
        PurchasePlanDetailVO result = purchasePlanService.getPurchasePlanDetailById(dto);
        return  ResponseResult.success("获取成功",result);
    }


    @RequestMapping(value = "accountExport", method = RequestMethod.POST)
    @ApiOperation("采购计划台账导出")
    public ResponseResult<Boolean> accountExport(HttpServletResponse response, @RequestBody @Valid QueryPurchasePlanDTO dto){
        purchasePlanService.accountExport(response,dto);
        return  ResponseResult.success("操作成功",true);
    }

    @RequestMapping(value = "purchasePlanExport", method = RequestMethod.POST)
    @ApiOperation("采购计划导出(只传id，查询详情表)")
    public ResponseResult<Boolean> purchasePlanExport(HttpServletResponse response, @RequestBody @Valid PurchasePlanExportDTO dto){
        purchasePlanService.purchasePlanExport(response,dto);
        return  ResponseResult.success("操作成功",true);
    }

    @RequestMapping(value = "generateMarketUnitPriceTax", method = RequestMethod.POST)
    @ApiOperation("自动导入市场含税单价")
    public ResponseResult<Long> generateMarketUnitPriceTax( @RequestBody @Valid MarketUnitPriceTaxDTO dto){
        return  ResponseResult.success("操作成功",purchasePlanService.generateMarketUnitPriceTax(dto));
    }

    @RequestMapping(value = "getProjectNameInDemandPlan", method = RequestMethod.POST)
    @ApiOperation("项目名称下拉框")
    public ResponseResult<List<ProjectNameInDemandPlanVO>> getProjectNameInDemandPlan(){
        return  ResponseResult.success("操作成功",purchasePlanService.getProjectNameInDemandPlan());
    }



    @RequestMapping(value = "getPriceControl", method = RequestMethod.POST)
    @ApiOperation("查询控价表")
    public ResponseResult<PageResult<PriceControlVO>> getPriceControl(@RequestBody @Valid QueryOneDTO dto){
        return  ResponseResult.success("操作成功",purchasePlanService.getPriceControl(dto));
    }

    @RequestMapping(value = "getPurchaseDetailByWarehousingNo", method = RequestMethod.POST)
    @ApiOperation("根据入库编号查询采购信息")
    public ResponseResult<PurchasePlanDetailVO> getPurchaseDetailByWarehousingNo(@RequestBody @Valid WarehousingNoDTO dto){
        return  ResponseResult.success("操作成功",purchasePlanService.getPurchaseDetailByWarehousingNo(dto));
    }

}
