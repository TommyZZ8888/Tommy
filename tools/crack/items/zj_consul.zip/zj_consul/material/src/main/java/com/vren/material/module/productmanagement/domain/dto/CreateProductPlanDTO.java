package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class CreateProductPlanDTO {

    @NotBlank(message = "产品需求计划id不能为空")
    @ApiModelProperty("产品需求计划id")
    private String id;

}
