package com.vren.material.module.storage.domain.dto;



import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class MaterialStorageInvoiceUpdateDTO {
    @ApiModelProperty("物资入库发票id")
    private String id;
    @ApiModelProperty("合同清单id")
    private  String contractListId;
    @ApiModelProperty("发票细节表集合")
    private List<MaterialStorageInvoiceDetailDTO> list;
    @ApiModelProperty("发票名称")
    private String invoiceName;
    @ApiModelProperty("发票说明")
    private String invoiceDescription;
    @ApiModelProperty("发票编号")
    private String invoiceNo;

    @ApiModelProperty("附件地址")
    private String attachmentPath;
}
