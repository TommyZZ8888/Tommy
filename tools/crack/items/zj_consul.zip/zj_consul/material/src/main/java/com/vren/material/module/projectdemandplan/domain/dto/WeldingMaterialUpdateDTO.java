package com.vren.material.module.projectdemandplan.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class WeldingMaterialUpdateDTO {
    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;
    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;


    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ConversionNumber
    @ApiModelProperty("库存数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;

    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;
}
