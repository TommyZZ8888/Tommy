package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GetMaterialTypeByProductId {
    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("产品信息id")
    private String productInformationId;

    @ApiModelProperty("批次")
    private String batch;

}
