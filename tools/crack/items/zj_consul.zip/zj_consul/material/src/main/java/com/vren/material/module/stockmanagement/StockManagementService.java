package com.vren.material.module.stockmanagement;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.*;
import com.vren.common.module.project.ProjectService;
import com.vren.material.module.projectdemandplan.domain.dto.QueryLockStockDataDTO;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.domain.vo.LockStockData;
import com.vren.material.module.projectdemandplan.domain.vo.MaterialTypeVO;
import com.vren.material.module.stockmanagement.domian.dto.*;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.stockmanagement.domian.enums.MaterialTypeEnum;
import com.vren.material.module.stockmanagement.domian.vo.MaterialStockVO;
import com.vren.material.module.stockmanagement.domian.vo.StockStatusVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class StockManagementService {

    @Autowired
    private MaterialStockMapper materialStockMapper;

    @Autowired
    private ProjectService projectService;


    public PageResult<MaterialStockVO> getMaterialStock(QueryStockDTO dto) {
        Page<MaterialStockVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialStock::getMaterialType, dto.getMaterialType())
                .like(!CommonUtil.isNull(dto.getMaterialName()), MaterialStock::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getMaterialNumber()), MaterialStock::getMaterialNumber, dto.getMaterialNumber())
                .eq(!CommonUtil.isNull(dto.getStockStatus()), MaterialStock::getStockStatus, dto.getStockStatus())
                .orderByDesc(MaterialStock::getCreateTime);
        SearchUtil.timeRangeSearch(wrapper, MaterialStock::getStockInTime, dto.getStockInTimeStart(), dto.getStockInTimeEnd());
        IPage<MaterialStockVO> materialStockVOIPage = materialStockMapper.selectJoinPage(page, MaterialStockVO.class, wrapper);
        materialStockVOIPage.getRecords().stream().forEach(item -> {
            //通过项目id，设置项目名称
            if (item.getProjectId() != null) {
                item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            }
            //设置物资类型
            item.setMaterialTypeText(EnumUtil.getValue(MaterialTypeEnum.class, item.getMaterialType()));
            //设置库存状态
            if (item.getStockStatus().equals(1)) {
                item.setStockStatusText("锁库");
            } else {
                item.setStockStatusText("未锁库");
            }
        });
        return PageUtil.convert2PageResult(materialStockVOIPage);
    }

    public List<MaterialTypeVO> getMaterialType() {
        ArrayList<MaterialTypeVO> materialTypeVOS = new ArrayList<>();
        for (MaterialTypeEnum item : MaterialTypeEnum.values()) {
            MaterialTypeVO materialTypeVO = new MaterialTypeVO();
            materialTypeVO.setCode(item.getCode());
            materialTypeVO.setValue(item.getName());
            materialTypeVOS.add(materialTypeVO);
        }
        return materialTypeVOS;
    }

    public List<StockStatusVO> getStockStatus() {
        ArrayList<StockStatusVO> stockStatusVOS = new ArrayList<>();
        StockStatusVO stockStatusVO = StockStatusVO.builder().code(1).name("已锁库").build();
        StockStatusVO stockStatusVO1 = StockStatusVO.builder().code(2).name("未锁库").build();
        stockStatusVOS.add(stockStatusVO);
        stockStatusVOS.add(stockStatusVO1);
        return stockStatusVOS;
    }

    /**
     * 根据项目id和物资编号  更新库存数量和关联回库表id
     */
    public void updateStockByProjectIdAndNumber(String id, String projectId, String materialNumber, Long returnCount) {
        //退库数量就是库存余量，创建时间就是入库时间，锁库状态为未锁库，取消关联的项目
        //重新关联项目
        UpdateWrapper<MaterialStock> wrapper = new UpdateWrapper<>();
        wrapper.eq("project_id",projectId)
                .eq("material_number",materialNumber)
                .set("material_return_id",id)
                .setSql("stock_balance = stock_balance +" + returnCount);
        int update = materialStockMapper.update(new MaterialStock(), wrapper);
        if (update > 0) {
            log.info("库存更新了库存余量和退库表的关联关系");
        }
    }

    public void editMaterialStock(EditStockDTO dto) {
        MaterialStock materialStock = BeanUtil.copy(dto, MaterialStock.class);
        materialStockMapper.updateById(materialStock);
    }

    /**
     * 根据条件在物资表中筛选
     *
     * @param dto
     * @return
     */
    public List<LockStockData> selectByColorAndMaterialType(QueryLockStockDataDTO dto,List<String> materialStockIds) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialStock::getMaterialType, dto.getMaterialType());

        if (!CommonUtil.isNull(materialStockIds)){
            wrapper.in(CommonUtil.listIsNotEmpty(materialStockIds),MaterialStock::getId,materialStockIds);
        }else {
            wrapper.isNull(MaterialStock::getProjectId);
        }
        //材料名称的匹配规则
//                .like(!CommonUtil.isNull(dto.getMaterialName()),MaterialStock::getMaterialName,dto.getMaterialName());

        if (MaterialType.PAINT.getCode().equals(dto.getMaterialType())) {
            //油漆
            wrapper.like(!CommonUtil.isNull(dto.getColor()), MaterialStock::getColor, dto.getColor());
        } else if (MaterialType.WELDING_MATERIALS.getCode().equals(dto.getMaterialType())) {
            wrapper.like(!CommonUtil.isNull(dto.getModel()), MaterialStock::getModel, dto.getModel())
                    .like(!CommonUtil.isNull(dto.getSize()), MaterialStock::getSpecification, dto.getSize());
        } else {
            wrapper.eq(!CommonUtil.isNull(dto.getTexture()), MaterialStock::getTexture, dto.getTexture())
                    .like(!CommonUtil.isNull(dto.getSpecification()), MaterialStock::getSpecification, dto.getSpecification());
        }
        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
        List<LockStockData> lockStockData = BeanUtil.copyList(materialStocks, LockStockData.class);
        lockStockData.stream().forEach(item -> {
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            //设置锁库状态
            if (item.getStockStatus().equals(1)) {
                item.setStockStatusText("已锁库");
            } else {
                item.setStockStatusText("未锁库");
            }
        });
        return lockStockData;
    }

    public MaterialStock selectById(String id){
          return materialStockMapper.selectById(id);
    }

    public MaterialStockVO getMaterialStockById(String id) {
        MaterialStock materialStock = selectById(id);
        MaterialStockVO materialStockVO = BeanUtil.copy(materialStock, MaterialStockVO.class);
        materialStockVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, materialStockVO.getMaterialType()));
        if (materialStockVO.getStockStatus().equals(0)) {
            materialStockVO.setStockStatusText("已锁库");
        } else {
            materialStockVO.setStockStatusText("未锁库");
        }
        return materialStockVO;
    }

    /**
     * 跟新物资表的库存余量和锁库数量
     *
     * @param materialStockId 库存表id
     * @param lockStockNumber 锁库数量
     */
    public void updateStockAndLockNumber(String materialStockId, Long lockStockNumber) {
        UpdateWrapper<MaterialStock> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(materialStockId), "id", materialStockId)
                .setSql(!CommonUtil.isNull(lockStockNumber), "stock_balance = stock_balance - " + lockStockNumber)
                .setSql(!CommonUtil.isNull(lockStockNumber), "lock_number = lock_number + " + lockStockNumber)
                .set("stock_status", "1");
        materialStockMapper.update(new MaterialStock(), wrapper);
    }

    public List<MaterialStockVO> getManyStockByIds(List<QueryManyStockDTO> dto) {
        //调拨只能从一个项目调拨到另一个项目,参数中的项目id不能有重复的
        List<String> projectIds = dto.stream().map(QueryManyStockDTO::getProjectId).collect(Collectors.toList());
        HashSet<String> stringHashSet = new HashSet<>(projectIds);
        if (stringHashSet.size()>1){
            throw new RuntimeException("只能选择同一个项目中的物资");
        }
        List<String> ids = dto.stream().map(QueryManyStockDTO::getId).collect(Collectors.toList());
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .in(CommonUtil.listIsNotEmpty(ids),MaterialStock::getId,ids);
        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
        List<MaterialStockVO> materialStockVOS = BeanUtil.copyList(materialStocks, MaterialStockVO.class);
        materialStockVOS.stream().forEach( item -> {
            if (!CommonUtil.isNull(item.getProjectId())){
                item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            }
        });
        return materialStockVOS;
    }


    public boolean updateStockBalanceByIds(ArrayList<MaterialStock> materialStocks) {
        for (MaterialStock item:materialStocks) {
            int update = materialStockMapper.updateById(item);
            if (update<1){
                return false;
            }
        }
        return true;
    }

    public Integer insertBatchSomeColumn(List<MaterialStock> entities){
        return materialStockMapper.insertBatchSomeColumn(entities);
    }

    public boolean insertMaterialStock(MaterialStockDTO dto) {
        /**
         *  根据物资编号是否存在判断是更新还是新增才做
         */
        String materialNumber = dto.getMaterialNumber();
        QueryWrapper<MaterialStock> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(materialNumber),"material_number",materialNumber)
                .eq(!CommonUtil.isNull(dto.getProjectId()),"project_id",dto.getProjectId())
                .last("limit 1 ");
        Long count = materialStockMapper.selectCount(queryWrapper);
        MaterialStock materialStock = BeanUtil.copy(dto, MaterialStock.class);
        if (count > 0){
            //更新操作
            UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq(!CommonUtil.isNull(dto.getMaterialNumber()),"material_number",dto.getMaterialNumber())
                    .eq(!CommonUtil.isNull(dto.getProjectId()),"project_id",dto.getProjectId())
                    .setSql(!CommonUtil.isNull(dto.getStockBalance()),"stock_balance = stock_balance + "+ dto.getStockBalance()+"-"+dto.getActualReceiptQuantity())
                    .setSql(!CommonUtil.isNull(dto.getEstimatedStorageCount()),"estimated_storage_count = estimated_storage_count + "+ dto.getEstimatedStorageCount());
            return materialStockMapper.update(materialStock,updateWrapper) > 0;
        }else {
            //新增操作
            return materialStockMapper.insert(materialStock) > 0;
        }
    }

    public boolean updateEstimatedStorageCount(EstimatedStorageCountDTO dto) {
        UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq(!CommonUtil.isNull(dto.getMaterialNumber()),"material_number",dto.getMaterialNumber())
                .setSql(!CommonUtil.isNull(dto.getCount()),"estimated_storage_count = estimated_storage_count - " + dto.getCount());
        return materialStockMapper.update(new MaterialStock(),updateWrapper) > 0;
    }

    public Long getLatestPrice(String specification, String texture) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(MaterialStock::getPreTaxPrice,MaterialStock::getTax)
                .eq(!CommonUtil.isNull(specification),MaterialStock::getSpecification,specification)
                .eq(!CommonUtil.isNull(texture),MaterialStock::getTexture,texture)
                .last(" limit 1");
        MaterialStock materialStock = materialStockMapper.selectOne(wrapper);
        if (!CommonUtil.isNull(materialStock)){
            Long preTaxPrice = materialStock.getPreTaxPrice() != null ?  materialStock.getPreTaxPrice() : 0L;
            Long tax = materialStock.getTax() != null ?  materialStock.getTax() : 0L;
            return preTaxPrice + tax;
        }else {
            return 0L;
        }
    }

    public List<MaterialStock> selectWeldInThreeMonth(String model, String brand, String size) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(model),MaterialStock::getModel,model)
                .eq(!CommonUtil.isNull(brand),MaterialStock::getBrand,brand)
                .eq(!CommonUtil.isNull(size),MaterialStock::getSpecification,size)
                .last(" and stock_in_time > DATE_SUB(CURDATE(), INTERVAL 3 MONTH) ");
        return materialStockMapper.selectList(wrapper);
    }

    public List<MaterialStock> selectPaintInThreeMonth(String size, String colour) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(colour),MaterialStock::getColor,colour)
                .eq(!CommonUtil.isNull(size),MaterialStock::getSpecification,size)
                .last(" and stock_in_time > DATE_SUB(CURDATE(), INTERVAL 3 MONTH) ");
        return materialStockMapper.selectList(wrapper);
    }

    public List<MaterialStock> selectProductTotalInThreeMonth(String specification, String texture) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(specification),MaterialStock::getSpecification,specification)
                .eq(!CommonUtil.isNull(texture),MaterialStock::getTexture,texture)
                .last(" and stock_in_time > DATE_SUB(CURDATE(), INTERVAL 3 MONTH) ");
        return materialStockMapper.selectList(wrapper);
    }

    public String updateStock(String incomingCompany, MaterialStock stock) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(incomingCompany),MaterialStock::getProjectId,incomingCompany)
                .eq(!CommonUtil.isNull(stock.getMaterialNumber()),MaterialStock::getMaterialNumber,stock.getMaterialNumber());
        MaterialStock materialStock = materialStockMapper.selectOne(wrapper);
        if (CommonUtil.isNull(materialStock)){
            //不存在，新增一条库存记录
            materialStockMapper.insert(stock);
            return stock.getId();
        }else {
            //该项目已存在该 物资，更新该物资的库存余量
            materialStock.setStockBalance(materialStock.getStockBalance() + stock.getStockBalance() );
            materialStockMapper.updateById(materialStock);
            return materialStock.getId();
        }
    }

//    /**
//     *  根据焊材名称、型号、规格，在库存表中查询未被关联到项目上的库存
//     * @param materialName 名称
//     * @param model 型号
//     * @param size  规格
//     * @param materialType 类型
//     * @return
//     */
//    public List<LockStockData> selectByNameAndModel(String materialName, String model, String size, Integer materialType) {
//        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
//        wrapper.selectAll(MaterialStock.class)
//                .like(!CommonUtil.isNull(materialName),MaterialStock::getMaterialName,materialName)
//                .like(!CommonUtil.isNull(model),MaterialStock::getModel,model)
//                .eq(!CommonUtil.isNull(materialType),MaterialStock::getMaterialType,materialType)
//                .like(!CommonUtil.isNull(size),MaterialStock::getSpecification,size)
//                .isNull(MaterialStock::getProjectId);
//        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
//        BeanUtil.copyList(materialStocks,LockStockData.class)
//
//
//    }
}
