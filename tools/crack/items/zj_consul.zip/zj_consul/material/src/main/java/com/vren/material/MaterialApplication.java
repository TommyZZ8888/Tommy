package com.vren.material;

import com.github.yulichang.injector.MPJSqlInjector;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @ClassName:ProjectApplication
 * @Author: vren
 * @Date: 2022/9/14 8:55
 */

@SpringBootApplication(exclude = {MPJSqlInjector.class})
@EnableDiscoveryClient
@EnableFeignClients(basePackages = {"com.vren.common", "com.vren.material"})
@ServletComponentScan
@EnableTransactionManagement
@ComponentScan(basePackages = {"com.vren.common", "com.vren.material"})
@MapperScan(basePackages = {"com.vren.common.module", "com.vren.material.module"})
public class MaterialApplication {
    public static void main(String[] args) {
        SpringApplication.run(MaterialApplication.class);
    }
}
