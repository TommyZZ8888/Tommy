package com.vren.material.module.stocktransfer.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class IncomingCompanySelectDTO {
    @NotBlank(message = "项目id不能为空")
    @ApiModelProperty("项目id")
    private String projectId;
}
