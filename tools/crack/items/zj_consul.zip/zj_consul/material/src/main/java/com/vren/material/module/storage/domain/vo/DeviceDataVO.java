package com.vren.material.module.storage.domain.vo;


import lombok.Data;

@Data
public class DeviceDataVO {
    private String keyId;
    private String spotType;
}
