package com.vren.material.module.purchaseplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class PurchasePlanExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("id")
    private Integer serialNo;

    @ExcelProperty("材料名称")
    @ApiModelProperty("材料名称")
    private String materialName;

    @ExcelProperty("图号")
    @ApiModelProperty("图号")
    private String figureNo;

    @ExcelProperty("规格")
    @ApiModelProperty("规格")
    private String size;

    @ExcelIgnore
    @ApiModelProperty("材质")
    private String texture;

    @ExcelProperty("材质")
    @ApiModelProperty("材质")
    private String textureText;

    @ExcelProperty("执行标准")
    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ExcelProperty("单位")
    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ExcelProperty("数量")
    @ApiModelProperty("采购数量")
    private Integer purchaseAmount;

    @ExcelProperty("重量")
    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    @ExcelProperty("标书/认价价格")
    @ApiModelProperty("标书/认价价格")
    @ConversionNumber
    private Long proposalPrice;

    @ExcelProperty("含税金额")
    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long amountIncludingTax;

    @ExcelProperty("市场含税单价")
    @ApiModelProperty("市场含税单价")
    @ConversionNumber
    private Long marketUnitPriceIncludingTax;

    @ExcelProperty("含税金额")
    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long priceInTax;

    @ExcelProperty("标书品牌")
    @ApiModelProperty("标书品牌")
    private String bidBrand;

    @ExcelProperty("付款条件")
    @ApiModelProperty("付款条件")
    private String paymentTerms;

    @ExcelProperty(value = "到货时间",converter = DateConverter.class)
    @ApiModelProperty("到货时间")
    private Date arrivalTime;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;

}
