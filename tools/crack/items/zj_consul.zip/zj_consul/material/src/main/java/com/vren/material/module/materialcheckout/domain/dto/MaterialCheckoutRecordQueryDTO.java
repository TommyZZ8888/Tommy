package com.vren.material.module.materialcheckout.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

@Data
public class MaterialCheckoutRecordQueryDTO extends PageParam {
    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("领料单记录id")
    private String materialCheckoutRecordId;
}
