package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName("welding_material_demand_plan")
public class WeldingMaterialDemandPlan {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("项目需求计划表id")
    private String projectDemandPlanId;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ApiModelProperty("技术标准")
    private String technicalStandards;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("库存类型")
    private Integer stockType;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;
    /**
     * 采购计划模块
     */
    @ApiModelProperty("采购到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Integer purchaseNum;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

}