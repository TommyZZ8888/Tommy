package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;

/**
 * @author 耿让
 */
@Data
public class EditTimeAndLocationDTO {

    @Size(min = 1,message = "id不能为空")
    @ApiModelProperty("id数组")
    private List<String> ids;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;
}
