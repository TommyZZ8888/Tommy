package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProductTotalVO {


    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;
    @ApiModelProperty("物资类型描述")
    private String materialTypeText;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("规格")
    private String specification;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;
}
