package com.vren.material.module.storage.domain.enums;

public enum WarehousingMethod {
    MANUAL_ENTRY(0,"手动录入"),
    SCANNING_CODE_MANUALLY_ENTER(1,"扫码录入");

    WarehousingMethod  (Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
