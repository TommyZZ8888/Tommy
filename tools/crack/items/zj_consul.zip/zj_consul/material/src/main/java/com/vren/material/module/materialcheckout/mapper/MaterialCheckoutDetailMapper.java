package com.vren.material.module.materialcheckout.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutDetail;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MaterialCheckoutDetailMapper extends MPJBaseMapper<MaterialCheckoutDetail> {
}
