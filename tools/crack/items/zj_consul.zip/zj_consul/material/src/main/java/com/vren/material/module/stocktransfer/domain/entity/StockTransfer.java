package com.vren.material.module.stocktransfer.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@TableName("stock_transfer")
@Data
public class StockTransfer {

    @TableId(type = IdType.ASSIGN_UUID)
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("调拨单编号")
    private String stockTransferNo;

    @ApiModelProperty("拨入单位")
    private String incomingCompany;

    @ApiModelProperty("拨出单位")
    private String transferOutCompany;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("批料")
    private String batch;

    @ApiModelProperty("发料")
    private String issue;

    @ApiModelProperty("记账")
    private String bookkeeping;

    @ApiModelProperty("收料")
    private String materialReceiving;

    @ApiModelProperty("创建时间")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty("更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

}