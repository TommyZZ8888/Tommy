package com.vren.material.module.materialcheckout.domain.enums;

public enum ReceiveState {
    UNRECEIVE(0,"未领取"),
    RECEIVED(1,"已领取");
    private Integer code;
    private String name;
    ReceiveState(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
