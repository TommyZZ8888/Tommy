package com.vren.material.module.stocktransfer.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@TableName("stock_transfer_detail")
public class StockTransferDetail {

    @TableId(type = IdType.ASSIGN_UUID)
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("调拨单id")
    private String stockTransferId;

    @ApiModelProperty("料具名称")
    private String materialName;

    @ApiModelProperty("规格与型号")
    private String specificationAndModel;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("实拨数量")
    @ConversionNumber
    private Long actualAllocatedQuantity;

    @ApiModelProperty("单价")
    @ConversionNumber
    private Long unitPrice;

    @ApiModelProperty("金额")
    @ConversionNumber
    private Long money;

}