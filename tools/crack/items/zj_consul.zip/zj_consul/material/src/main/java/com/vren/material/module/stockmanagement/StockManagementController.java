package com.vren.material.module.stockmanagement;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.projectdemandplan.domain.vo.MaterialTypeVO;
import com.vren.material.module.stockmanagement.domian.dto.*;
import com.vren.material.module.stockmanagement.domian.vo.MaterialStockVO;
import com.vren.material.module.stockmanagement.domian.vo.StockStatusVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/stockmanagement")
@Api(tags = {"库存管理"})
@OperateLog
public class StockManagementController {

    @Autowired
    private StockManagementService stockManagementService;

    @RequestMapping(value = "/select", method = RequestMethod.POST)
    @ApiOperation("查询物资库存")
    public ResponseResult<PageResult<MaterialStockVO>> getMaterialStock(@RequestBody QueryStockDTO dto){
        return  ResponseResult.success("获取成功",stockManagementService.getMaterialStock(dto));
    }

    @RequestMapping(value = "/getMaterialType", method = RequestMethod.POST)
    @ApiOperation("物资类型下拉框")
    public ResponseResult<List<MaterialTypeVO>> getMaterialType() {
        List<MaterialTypeVO> list = stockManagementService.getMaterialType();
        return ResponseResult.success("获取成功", list);
    }

    @RequestMapping(value = "/getStockStatus", method = RequestMethod.POST)
    @ApiOperation("库存状态下拉框")
    public ResponseResult<List<StockStatusVO>> getStockStatus() {
        List<StockStatusVO> list = stockManagementService.getStockStatus();
        return ResponseResult.success("获取成功", list);
    }


    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    @ApiOperation("编辑物资库存")
    public ResponseResult<Boolean> editMaterialStock(@RequestBody EditStockDTO dto){
        stockManagementService.editMaterialStock(dto);
        return  ResponseResult.success("获取成功",true);
    }

    @RequestMapping(value = "/selectById", method = RequestMethod.POST)
    @ApiOperation("根据id查询物资情况")
    public ResponseResult<MaterialStockVO> getMaterialStockById(@RequestBody @Valid QueryOneStockDTO dto){
        return  ResponseResult.success("获取成功",stockManagementService.getMaterialStockById(dto.getId()));
    }


    @RequestMapping(value = "/getManyStockByIds", method = RequestMethod.POST)
    @ApiOperation("根据多个id查询物资情况")
    public ResponseResult<List<MaterialStockVO>> getManyStockByIds(@RequestBody @Valid List<QueryManyStockDTO> dto){
        return  ResponseResult.success("获取成功",stockManagementService.getManyStockByIds(dto));
    }


    @RequestMapping(value = "/insertMaterialStock", method = RequestMethod.POST)
    @ApiOperation("新增或更新物资信息（根据物资编号判断新增还是更新，入库检验合格后调用此接口）")
    public ResponseResult<Boolean> insertMaterialStock(@RequestBody @Valid MaterialStockDTO dto){
        return  ResponseResult.success("获取成功",stockManagementService.insertMaterialStock(dto));
    }


    @RequestMapping(value = "/updateEstimatedStorageCount", method = RequestMethod.POST)
    @ApiOperation("根据物资编号更新暂估入库数（暂估入库数量减去绑定的发票数量）")
    public ResponseResult<Boolean> updateEstimatedStorageCount(@RequestBody @Valid EstimatedStorageCountDTO dto){
        return  ResponseResult.success("获取成功",stockManagementService.updateEstimatedStorageCount(dto));
    }



}
