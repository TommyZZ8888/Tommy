package com.vren.material.module.storage.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DeleteMaterialFirstLevelStorageDTO {
    @NotBlank(message = "材料一级入库表id不能为空")
    @ApiModelProperty("材料一级入库表")
    private String id;
}
