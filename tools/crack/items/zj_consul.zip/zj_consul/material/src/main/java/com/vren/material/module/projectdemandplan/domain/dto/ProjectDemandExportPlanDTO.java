package com.vren.material.module.projectdemandplan.domain.dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectDemandExportPlanDTO {


    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("计划编号")
    private String planNo;

}
