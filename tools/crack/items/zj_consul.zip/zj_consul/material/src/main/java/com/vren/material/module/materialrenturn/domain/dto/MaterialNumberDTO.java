package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class MaterialNumberDTO {

    @ApiModelProperty("物资编号")
    @NotBlank(message = "物资编号不能为空")
    private String materialNumber;

}
