package com.vren.material.module.projectdemandplan.domain.vo;

import lombok.Data;

@Data
public class MaterialTypeVO{
    private  Integer code;
    private  String value;
}
