package com.vren.material.module.projectdemandplan.domain.dto;

import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 * 采购计算
 */
@Data
@Builder
public class PurchaseCount {

    /**
     * 采购数量
     */
    private Integer purchaseNum;

    /**
     *  采购重量
     */
    private Long purchaseWeight;


}
