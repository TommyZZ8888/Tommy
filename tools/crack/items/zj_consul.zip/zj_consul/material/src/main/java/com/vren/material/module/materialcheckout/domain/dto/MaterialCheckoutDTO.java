package com.vren.material.module.materialcheckout.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 出库专用DTO
 * @author szp
 * @date 2022/11/3 8:41
 */
@Data
public class MaterialCheckoutDTO {
    @ApiModelProperty("出库记录表id")
    private String id;
}
