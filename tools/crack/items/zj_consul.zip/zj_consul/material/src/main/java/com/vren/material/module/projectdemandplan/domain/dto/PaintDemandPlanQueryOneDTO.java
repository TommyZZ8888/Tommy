package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class PaintDemandPlanQueryOneDTO {
    @ApiModelProperty("油漆需求计划id")
    private String id;
}
