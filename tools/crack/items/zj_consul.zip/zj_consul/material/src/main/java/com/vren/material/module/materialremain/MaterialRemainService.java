package com.vren.material.module.materialremain;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.module.materialremain.domain.dto.EditMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.GetMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.QueryOneDTO;
import com.vren.material.module.materialremain.domain.entity.RemainingMaterial;
import com.vren.material.module.materialremain.domain.vo.MaterialRemainVO;
import com.vren.material.module.materialrenturn.domain.dto.GenerateSpareRecordDTO;
import com.vren.material.module.projectdemandplan.domain.vo.MaterialRemainData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class MaterialRemainService {

    @Autowired
    private MaterialRemainMapper materialRemainMapper;

    @Autowired
    private ProjectService projectService;


    public void insert(GenerateSpareRecordDTO dto) {
        RemainingMaterial remainingMaterial = BeanUtil.copy(dto, RemainingMaterial.class);
        //余料编号不能重复
        QueryWrapper<RemainingMaterial> wrapper = new QueryWrapper<>();
        wrapper.select("1")
                .eq(!CommonUtil.isNull(dto.getRemainingMaterialNo()),"remaining_material_no",dto.getRemainingMaterialNo())
                .last("limit 1");
        Long count = materialRemainMapper.selectCount(wrapper);
        if (count>0){
            throw new RuntimeException("余料编号【"+dto.getRemainingMaterialNo()+"】已存在，不能重复添加");
        }
        int insert = materialRemainMapper.insert(remainingMaterial);
        if (insert>0){
            log.info("新增了一条余料记录");
        }
    }

    public PageResult<MaterialRemainVO> getMaterialRemain(GetMaterialRemainDTO dto) {
        Page<Object> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(RemainingMaterial.class)
                .like(!CommonUtil.isNull(dto.getRemainingMaterialName()),RemainingMaterial::getRemainingMaterialName,dto.getRemainingMaterialName())
                .like(!CommonUtil.isNull(dto.getRemainingMaterialNo()),RemainingMaterial::getRemainingMaterialNo,dto.getRemainingMaterialNo())
                .eq(!CommonUtil.isNull(dto.getStockStatus()),RemainingMaterial::getStockStatus,dto.getStockStatus());
        IPage<MaterialRemainVO> materialRemainVOIPage = materialRemainMapper.selectJoinPage(page, MaterialRemainVO.class, wrapper);
        materialRemainVOIPage.getRecords().stream().forEach(item -> {
            //设置项目名称
            if (item.getProjectId()!=null){
                item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            }
            //设置库存状态
            if (item.getStockStatus()!=null&&item.getStockStatus().equals(1)) {
                item.setStockStatusText("锁库");
            } else {
                item.setStockStatusText("未锁库");
            }
        });
        return PageUtil.convert2PageResult(materialRemainVOIPage);
    }

    public MaterialRemainVO getMaterialRemainById(QueryOneDTO dto) {
        RemainingMaterial remainingMaterial = materialRemainMapper.selectById(dto.getId());
        MaterialRemainVO materialRemainVO = BeanUtil.copy(remainingMaterial, MaterialRemainVO.class);
        //设置项目名称
        ProjectVO projectVO = projectService.getById(materialRemainVO.getProjectId());
        if (projectVO!=null){
            materialRemainVO.setProjectName(projectVO.getProjectName());
        }
        //设置库存状态
        if (materialRemainVO.getStockStatus()!=null&&materialRemainVO.getStockStatus().equals(1)) {
            materialRemainVO.setStockStatusText("锁库");
        } else {
            materialRemainVO.setStockStatusText("未锁库");
        }
        return materialRemainVO;
    }

    public void editMaterialRemain(EditMaterialRemainDTO dto) {
        RemainingMaterial remainingMaterial = BeanUtil.copy(dto, RemainingMaterial.class);
        materialRemainMapper.updateById(remainingMaterial);
    }

    public String getAttachment(QueryOneDTO dto) {
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(RemainingMaterial::getAttachmentPath)
                .eq(!CommonUtil.isNull(dto.getId()),RemainingMaterial::getId,dto.getId());
        RemainingMaterial remainingMaterial = materialRemainMapper.selectOne(wrapper);
        return remainingMaterial.getAttachmentPath();
    }

    /**
     *  根据物资名称、材质和规格模糊查询 符合条件的余料
     * @param materialName
     * @param texture
     * @param specification
     * @return
     */
    public List<MaterialRemainData> getByNameAndSpecification(String materialName, String texture, String specification) {
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(RemainingMaterial.class)
                .like(!CommonUtil.isNull(materialName),RemainingMaterial::getRemainingMaterialName,materialName)
                .or()
                .like(!CommonUtil.isNull(texture),RemainingMaterial::getTexture,texture)
                .or()
                .like(!CommonUtil.isNull(specification),RemainingMaterial::getSpecification,specification);
        List<RemainingMaterial> remainingMaterials = materialRemainMapper.selectList(wrapper);
        List<MaterialRemainData> materialRemainData = BeanUtil.copyList(remainingMaterials, MaterialRemainData.class);
        return materialRemainData;
    }

    /**
     *  更新余料数量，修改库存状态
     * @param materialStockId
     * @param lockStockNumber
     */
    public void updateStockAndLockNumber(String materialStockId, Long lockStockNumber) {
        UpdateWrapper<RemainingMaterial> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(materialStockId),"id",materialStockId)
                .setSql(!CommonUtil.isNull(lockStockNumber),"remaining_material_count = remaining_material_count - " + lockStockNumber)
                .setSql(!CommonUtil.isNull(lockStockNumber),"lock_number = lock_number + " + lockStockNumber)
                .set("stock_status","2");
        materialRemainMapper.update(new RemainingMaterial(),wrapper);
    }
}
