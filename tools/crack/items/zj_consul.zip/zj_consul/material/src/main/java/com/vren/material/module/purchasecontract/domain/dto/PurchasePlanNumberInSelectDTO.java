package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class PurchasePlanNumberInSelectDTO {

    @ApiModelProperty("项目id（多个）")
    private List<String> projectIds;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
