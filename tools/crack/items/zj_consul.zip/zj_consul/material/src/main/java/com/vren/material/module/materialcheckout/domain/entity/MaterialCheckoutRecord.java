package com.vren.material.module.materialcheckout.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
@Data
@TableName("material_checkout_record")
public class MaterialCheckoutRecord {
    @ApiModelProperty("出库记录表id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("领料单表格编号")
    private String pickingFromNo;

    @ApiModelProperty("限额领料计划编号")
    private String quotaPickingPlanNo;

    @ApiModelProperty("领料单编号")
    private String materialRequisitionNo;

    @ApiModelProperty("拨出单位")
    private String spareUnit;

    @ApiModelProperty("领用部门")
    private String requisitionDepartment;

    @ApiModelProperty("领用时间")
    private Date requisitionTime;

    @ApiModelProperty("出库时间")
    private Date checkoutTime;

    @ApiModelProperty("编制人")
    private String compile;

    @ApiModelProperty("审核人")
    private String checker;

    @ApiModelProperty("审批人")
    private String approver;

    @ApiModelProperty("发料人")
    private String issuedBy;

    @ApiModelProperty("领料人")
    private String picker;

    @ApiModelProperty("发起人")
    private String sponsor;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("验收单编号")
    private String acceptanceCertificateNo;

    @ApiModelProperty("一般计税 0 简易计税 1 ")
    private Integer taxMethod;

    @ApiModelProperty("是否超额领料")
    private Boolean excessIssue;


}