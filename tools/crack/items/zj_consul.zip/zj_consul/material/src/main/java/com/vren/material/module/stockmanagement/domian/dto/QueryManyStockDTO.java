package com.vren.material.module.stockmanagement.domian.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryManyStockDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;
}
