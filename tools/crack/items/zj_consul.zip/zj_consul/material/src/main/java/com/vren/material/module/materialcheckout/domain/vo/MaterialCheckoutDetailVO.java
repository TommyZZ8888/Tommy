package com.vren.material.module.materialcheckout.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class MaterialCheckoutDetailVO {
    private String id;

    @ApiModelProperty("材料出库记录表id")
    private String materialCheckoutRecordId;

    @ApiModelProperty("")
    private String purchasePlanDetailOtherId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("型号")
    private String model;

    @ConversionNumber
    @ApiModelProperty("面积")
    private Long area;
    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("单价")
    private Long univalence;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ConversionNumber
    @ApiModelProperty("限额数量")
    private Long quantityRequired;

    @ConversionNumber
    @ApiModelProperty("已领数量")
    private Long pickedQuantity;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ConversionNumber
    @ApiModelProperty("申领数量")
    private Long applyQuantity;

    @ConversionNumber
    @ApiModelProperty("实领数量")
    private Long actualPickedQuantity;

    @ApiModelProperty("颜色")
    private String colour;

    @ApiModelProperty("税前单价")
    @ConversionNumber
    private Long preTaxPrice;

    @ConversionNumber
    @ApiModelProperty("金额")
    private Long money;

    @ConversionNumber
    @ApiModelProperty("税率")
    private Long taxRate;

    @ApiModelProperty("税额")
    @ConversionNumber
    private Long tax;

    @ConversionNumber
    @ApiModelProperty("价税合计金额")
    private Long materialTotalPrice;

    @ConversionNumber
    @ApiModelProperty("出库限额")
    private Long issueLimit;
    @ApiModelProperty("领取状态 0 已领取 1 未领取")
    private Integer receiveState;
    @ApiModelProperty("领取状态 0 已领取 1 未领取")
    private String receiveStateText;
}
