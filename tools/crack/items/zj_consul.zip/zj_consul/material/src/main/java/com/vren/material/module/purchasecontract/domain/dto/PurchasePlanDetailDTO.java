package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class PurchasePlanDetailDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
