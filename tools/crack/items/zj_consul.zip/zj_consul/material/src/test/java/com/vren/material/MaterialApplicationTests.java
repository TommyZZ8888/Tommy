package com.vren.material;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


/**
 * @ClassName:MaterialApplicaitonTests
 * @Author: vren
 * @Date: 2022/10/18 10:07
 */
@SpringBootTest
public class MaterialApplicationTests {


    @Test
    void context() throws Exception {
//        LinkedList<BoardImportVO> list = ExcelUtil.read("C:\\Users\\45046\\Desktop\\板材导入模板.xlsx",5,BoardImportVO.class);
//        System.out.println(list);
//        LinkedList<Object> res = ExcelUtil.read("C:\\Users\\45046\\Desktop\\型材导入模板.xlsx");

    }
    @Test
    void testString(){
        String specification="φ50,L=770";
        String firstSize = specification.substring(specification.indexOf("φ")+1, specification.indexOf(","));
        String secondSize = specification.substring(specification.indexOf("L")+2);
        System.out.println(firstSize);
        System.out.println(secondSize);
    }

}
