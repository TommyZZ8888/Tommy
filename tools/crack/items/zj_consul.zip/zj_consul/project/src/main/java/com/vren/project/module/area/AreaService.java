package com.vren.project.module.area;

import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.project.module.area.domain.entity.AreaEntity;
import com.vren.project.module.area.domain.enums.AreaEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Description:
 * @Author: 张文Uncle
 * @Date: 2021-07-27 15:39
 **/
@Service
public class AreaService {

    private List<AreaEntity> province;
    private List<AreaEntity> city;
    private List<AreaEntity> area;

    private List<AreaEntity> all;

    private Map<Long,String> nameByCode;
    @Autowired
    private AreaMapper areaMapper;

    public List<AreaEntity> getAll() {
        return all;
    }

    @PostConstruct
    private void initAddress() {
        List<AreaEntity> list = areaMapper.getList(4L);
        all = list;
        Map<Integer, List<AreaEntity>> result = list.stream()
                .collect(Collectors.groupingBy(AreaEntity::getLevel));
        nameByCode = list.stream().collect(Collectors.toMap(AreaEntity::getCode,AreaEntity::getName));
        province = result.get(AreaEnum.PROVINCE.getCode());
        city = result.get(AreaEnum.CITY.getCode());
        area = result.get(AreaEnum.AREA.getCode());
    }

    public List<AreaEntity> getProvinceList() {
        return province;
    }

    public String getNameByCode(Long code){
        return nameByCode.get(code);
    }

    public List<AreaEntity> getCityList() {
        return city;
    }

    public List<AreaEntity> getAreaList() {
        return area;
    }

    public List<AreaEntity> getCityListByProvinceCode(Long provinceCode) {
        return this.getCityList().stream().filter(item -> item.getProvince().equals(provinceCode)).collect(Collectors.toList());
    }

    public List<AreaEntity> getAreaListByCityCode(Long cityCode) {
        return this.getAreaList().stream().filter(item -> item.getCity().equals(cityCode)).collect(Collectors.toList());
    }

    public void export(HttpServletResponse response) {
        ExcelExportService excelExportService = new ExcelExportService("测试", response);
        excelExportService.write(getProvinceList(), "省", AreaEntity.class)
                .write(getAreaList(), "区", AreaEntity.class)
                .write(getCityList(),"市",AreaEntity.class)
                .export();
    }

}
