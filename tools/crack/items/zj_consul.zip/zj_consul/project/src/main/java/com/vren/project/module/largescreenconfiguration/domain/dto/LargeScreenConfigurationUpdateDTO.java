package com.vren.project.module.largescreenconfiguration.domain.dto;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class LargeScreenConfigurationUpdateDTO {
    @ApiModelProperty("大屏配置id")
    private String id;
    @NotBlank(message = "项目类型不能为空")
    @ApiModelProperty("项目类型")
    private String projectType;

    @NotBlank(message = "年份不能为空")
    @ApiModelProperty("年份")
    private String year;

    @ConversionNumber
    @ApiModelProperty("预期合同额")
    private Long expectedContractAmount;

    @ConversionNumber
    @ApiModelProperty("实际合同额")
    private Long actualContractAmount;

    @ConversionNumber
    @NotNull(message = "安全累计天数不能为空")
    @ApiModelProperty("安全累计天数")
    private Long safetyCumulativeDays;
}
