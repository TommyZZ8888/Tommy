package com.vren.project.module.management;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.module.material.MaterialService;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import com.vren.project.common.handler.CustomCellWriteHandler;
import com.vren.project.module.area.AreaService;
import com.vren.project.module.management.domain.dto.ProjectExportDTO;
import com.vren.project.module.management.domain.dto.ProjectQueryDTO;
import com.vren.project.module.management.domain.dto.ProjectUpdateDTO;
import com.vren.project.module.management.domain.dto.SavePathDTO;
import com.vren.project.module.management.domain.entity.Project;
import com.vren.project.module.management.domain.enums.WarningStatus;
import com.vren.project.module.management.domain.vo.*;
import com.vren.project.module.projectdelayrecord.ProjectDelayRecordMapper;
import com.vren.project.module.projectdelayrecord.domain.entity.ProjectDelayRecord;
import com.vren.project.module.projectdisclosure.ProjectDisclosureMapper;
import com.vren.project.module.projectdisclosure.domain.entity.ProjectDisclosure;
import com.vren.project.module.valuation.domin.enums.ProjectType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProjectManagementService {

    @Autowired
    private MaterialService materialService;

    @Autowired
    private ProjectManagementMapper projectManagementMapper;
    @Autowired
    private ProjectDisclosureMapper projectDisclosureMapper;

    @Autowired
    private AreaService areaService;
    @Autowired
    private ProjectDelayRecordMapper projectDelayRecordMapper;


    public Project queryByProjectNo(String projectNo) {
        MPJLambdaWrapper<Project> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(Project.class)
                .eq(StringUtils.isNotEmpty(projectNo), Project::getProjectNo, projectNo);

        return projectManagementMapper.selectOne(queryWrapper);
    }


    public PageResult<ProjectVO> queryList(ProjectQueryDTO dto) {
        Page<Project> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<Project> wrapper = new MPJLambdaWrapper<>();
        SearchUtil.timeRangeSearch(wrapper, Project::getContractCommencementTime, dto.getCommencementStartTime(), dto.getCommencementEndTime());
        SearchUtil.timeRangeSearch(wrapper, Project::getContractCompletionTime, dto.getCompletionStartTime(), dto.getCompletionEndTime());
        wrapper.selectAll(Project.class)
                .in((dto.getProjectType() != null && dto.getProjectType().size() > 0), Project::getProjectType, dto.getProjectType())
                .like(!CommonUtil.isNull(dto.getProjectNo()), Project::getProjectNo, dto.getProjectNo())
                .like(!CommonUtil.isNull(dto.getProjectName()), Project::getProjectName, dto.getProjectName())
                .like(!CommonUtil.isNull(dto.getCustomerName()), Project::getCustomerName, dto.getCustomerName())
                .eq(!CommonUtil.isNull(dto.getProvince()), Project::getProvince, dto.getProvince())
                .eq(!CommonUtil.isNull(dto.getCity()), Project::getCity, dto.getCity())
                .eq(!CommonUtil.isNull(dto.getArea()), Project::getArea, dto.getArea());

        Page<Project> selectPage = projectManagementMapper.selectPage(page, wrapper);
        PageResult<ProjectVO> pageResult = PageUtil.convert2PageResult(page, selectPage.getRecords(), ProjectVO.class);
        pageResult.setList(pageResult.getList().stream()
                .peek(item -> {
                    //设置预警状态
                    item.setWarningStatusText(EnumUtil.getValue(WarningStatus.class,item.getWarningStatus()));
                    //根据code设置省市区
                    item.setProvinceText(areaService.getNameByCode(item.getProvince()));
                    item.setCityText(areaService.getNameByCode(item.getCity()));
                    item.setAreaText(areaService.getNameByCode(item.getArea()));
                }).collect(Collectors.toList()));
        return pageResult;
    }

    public static void setWarningStatus(Project project) {
        if (CommonUtil.isNull(project.getEstimatedCompletionTime())){
            return;
        }
        int l = DateUtil.differentDays(project.getEstimatedCompletionTime(), new Date());
        if (l > 0 && l <= 10) {
            //蓝色预警
            project.setWarningStatus(1);

        } else if (!CommonUtil.isNull(project.getContractAmount()) && l >= 11 && l <= 29 && project.getContractAmount() <= 200000) {
            project.setWarningStatus(2);

        } else if (l > 30 || (!CommonUtil.isNull(project.getContractAmount()) && project.getContractAmount() >= 500000)) {
            project.setWarningStatus(3);

        } else {
            //正常
            project.setWarningStatus(0);
        }

    }

    public void editProject(ProjectUpdateDTO dto) {
        if (CommonUtil.isNull(dto.getId())) {
            Project copy = BeanUtil.copy(dto, Project.class);
            ProjectManagementService.setWarningStatus(copy);
            Long count = projectManagementMapper.getCount(dto.getProjectNo());
            if (count > 0) {
                throw new ErrorException("项目编号不唯一,不能新增");
            }
            projectManagementMapper.insert(copy);
            return;
        }

        Project copy = BeanUtil.copy(dto, Project.class);
        ProjectManagementService.setWarningStatus(copy);
        projectManagementMapper.updateById(copy);
    }

    public void delProject(String id) {
        MPJLambdaWrapper<ProjectDisclosure> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDisclosure.class)
                .eq(ProjectDisclosure::getProjectId, id);

        List<ProjectDisclosure> projectDisclosures = projectDisclosureMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(projectDisclosures)) {
            throw new ErrorException("该项目有对应的关联不可以删除");
        }

        //2023/03/01 gr 删除项目的时候，判断项目下面是否有产品，有产品的话，不让删除
        if (materialService.canDeleteProject(id)){
            throw new RuntimeException("该项目下尚存在产品列表，不可删除");
        }

         projectManagementMapper.deleteById(id);
         //同步删除相应的延误记录
            MPJLambdaWrapper<ProjectDelayRecord> lambdaWrapper = new MPJLambdaWrapper<>();
            lambdaWrapper.selectAll(ProjectDelayRecord.class)
                    .eq(ProjectDelayRecord::getProjectId,id);
            List<ProjectDelayRecord> projectDelayRecords = projectDelayRecordMapper.selectList(lambdaWrapper);
            if(CommonUtil.listIsNotEmpty(projectDelayRecords)){
                for (ProjectDelayRecord projectDelayRecord : projectDelayRecords) {
                    projectDelayRecordMapper.deleteById(projectDelayRecord);
                }
            }

    }

    public void exportProject(HttpServletResponse response, ProjectExportDTO dto) {
        List<String> projectTypes = dto.getProjectType();
        MPJLambdaWrapper<Project> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(Project.class)
                .in(projectTypes.size() != 0, Project::getProjectType, projectTypes);
        //合同开工时间
        SearchUtil.timeRangeSearch(queryWrapper, Project::getContractCommencementTime, dto.getCommencementStartTime(), dto.getCommencementEndTime());
        //合同竣工时间
        SearchUtil.timeRangeSearch(queryWrapper, Project::getContractCompletionTime, dto.getCompletionStartTime(), dto.getCompletionEndTime());
        List<Project> projects = projectManagementMapper.selectList(queryWrapper);

        projects.forEach(item -> {
            setWarningStatus(item);
        });

        //数据处理，将不同项目类型的数据分开
        HashMap<String, List<ProjectExportVO>> stringListHashMap = new HashMap<>();
        for (int i = 0; i < projectTypes.size(); i++) {
            int finalI = i;
            List<Project> collect = projects.stream().filter(item -> projectTypes.get(finalI).equals(item.getProjectType())).collect(Collectors.toList());
            List<ProjectExportVO> projectExport = BeanUtil.copyList(collect, ProjectExportVO.class);
            List<ProjectExportVO> projectExportVOS = projectExport.stream().peek(item->{
                MPJLambdaWrapper<ProjectDelayRecord> lambdaWrapper = new MPJLambdaWrapper<>();
                lambdaWrapper.selectAll(ProjectDelayRecord.class)
                        .eq(ProjectDelayRecord::getProjectId,item.getId());
                List<ProjectDelayRecord> projectDelayRecords = projectDelayRecordMapper.selectList(lambdaWrapper);
                StringBuilder delayDescription = new StringBuilder();
                StringBuilder delayReasons = new StringBuilder();
                StringBuilder expeditingMeasures = new StringBuilder();

                if(CommonUtil.listIsNotEmpty(projectDelayRecords)){
                  for (ProjectDelayRecord projectDelayRecord : projectDelayRecords) {
                      String format = new SimpleDateFormat("yyyy-MM-dd").format(projectDelayRecord.getCreateTime());
                      delayDescription.append(format+" "+projectDelayRecord.getDelayedDescription()+"\n");
                      delayReasons.append(format+" "+projectDelayRecord.getDelayedReason()+"\n");
                      expeditingMeasures.append(format+" "+projectDelayRecord.getExpeditingMeasures()+"\n");
                  }
                    String description = delayDescription.toString();
                    String reasons = delayReasons.toString();
                    String measures = expeditingMeasures.toString();

                    item.setDelayDescription(description);
                    item.setDelayReasons(reasons);
                    item.setExpeditingMeasures(measures);
                }else{
                    item.setDelayDescription("");
                    item.setDelayReasons("");
                    item.setExpeditingMeasures("");
                }
            }).collect(Collectors.toList());
            projectExportVOS.stream().peek(item -> item.setWarningStatusText(EnumUtil.getValue(WarningStatus.class, item.getWarningStatus()))).collect(Collectors.toList());
            //自增序号
            AtomicInteger num = new AtomicInteger();
            for (ProjectExportVO item : projectExportVOS) {
                item.setId(String.valueOf(num.incrementAndGet()));
            }
            stringListHashMap.put(projectTypes.get(finalI), projectExportVOS);
        }
        ExcelExportService excelExportService = new ExcelExportService("项目管理", response);
        for (int i = 0; i < projectTypes.size(); i++) {
            excelExportService.write(stringListHashMap.get(projectTypes.get(i)), projectTypes.get(i), ProjectExportVO.class, new CustomCellWriteHandler());
        }
        excelExportService.export();
    }



    public List<ProjectOutlineVO> queryOutline() {
        MPJLambdaWrapper<Project> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.select(Project::getId, Project::getProjectNo, Project::getProjectName);
        List<Project> projects = projectManagementMapper.selectList(queryWrapper);
        List<ProjectOutlineVO> projectOutlineVOS = BeanUtil.copyList(projects, ProjectOutlineVO.class);
        return projectOutlineVOS;
    }

    public List<String> getProjectType() {
        ArrayList<String> list = new ArrayList<>();
        for (ProjectType statue : ProjectType.values()) {
            list.add(statue.getName());
        }
        return list;
    }

    public ProjectVO queryById(String id) {
        Project project = projectManagementMapper.selectById(id);
        ProjectVO copy = BeanUtil.copy(project, ProjectVO.class);
        //设置省市区
        if (copy!=null){
            if (copy.getProvince()!=null){
                copy.setProvinceText(areaService.getNameByCode(copy.getProvince()));
            }
            if (copy.getCity()!=null){
                copy.setCityText(areaService.getNameByCode(copy.getCity()));
            }
            if (copy.getArea()!=null){
                copy.setAreaText(areaService.getNameByCode(copy.getArea()));
            }
            return copy;
        }else{
            return new ProjectVO();
        }

    }

    public void saveAttachmentPath(SavePathDTO dto) {
        Project project = projectManagementMapper.selectById(dto.getId());
        project.setAttachmentPath(dto.getAttachmentPath());
        projectManagementMapper.updateById(project);
    }

    public ProjectFileVO getAttachmentPath(String id) {
        Project project = projectManagementMapper.selectById(id);
        ProjectFileVO projectFileVO = new ProjectFileVO();
        projectFileVO.setAttachmentPath(project.getAttachmentPath());
        return projectFileVO;
    }

    public List<ProjectViewVO> queryDataList(ProjectDemandQueryDTO dto) {
        MPJLambdaWrapper<Project> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(Project.class)
                .like(!CommonUtil.isNull(dto.getProjectNo()), Project::getProjectNo, dto.getProjectNo())
                .like(!CommonUtil.isNull(dto.getProjectType()), Project::getProjectType, dto.getProjectType())
                .like(!CommonUtil.isNull(dto.getProjectName()), Project::getProjectName, dto.getProjectName())
                .like(!CommonUtil.isNull(dto.getCustomerName()), Project::getCustomerName, dto.getCustomerName());
        List<Project> projects = projectManagementMapper.selectList(queryWrapper);
        List<ProjectViewVO> projectViewVOS = BeanUtil.copyList(projects, ProjectViewVO.class);
        return projectViewVOS;
    }

    public List<String> findIdByProjectType(String projectUnit) {
        MPJLambdaWrapper<Project> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(Project::getId)
                .eq(Project::getProjectType,projectUnit);
        List<Project> projects = projectManagementMapper.selectList(wrapper);
        List<String> list = projects.stream().map(Project::getId).collect(Collectors.toList());
        return list;
    }

    public List<ProjectWithContractCostVO> getProjectWithContractCost() {
        List<Project> projects = projectManagementMapper.selectList(null);
        return BeanUtil.copyList(projects,ProjectWithContractCostVO.class);
    }
}

