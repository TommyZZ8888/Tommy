package com.vren.project.module.largescreenconfiguration.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectActualContractAmountVO {
    @ApiModelProperty("实际合同额")
    private Long actualContractAmount;
}
