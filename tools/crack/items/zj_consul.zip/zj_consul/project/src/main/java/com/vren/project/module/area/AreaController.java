package com.vren.project.module.area;

import com.vren.common.common.anno.NoNeedLogin;
import com.vren.common.common.domain.ResponseResult;
import com.vren.project.module.area.domain.entity.AreaEntity;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.List;


/**
 * @ClassName:AreaController
 * @Author: vren
 * @Date: 2022/9/14 9:27
 */
@RestController
@Api(tags = {"地址管理"})
@RequestMapping("/area")
public class AreaController {


    @Autowired
    private AreaService areaService;

    @NoNeedLogin
    @ApiOperation("获取省")
    @RequestMapping(value = "/getProvince", method = RequestMethod.POST)
    public ResponseResult<List<AreaEntity>> getProvince() {
        return ResponseResult.success("获取成功", areaService.getProvinceList());
    }

    @NoNeedLogin
    @ApiOperation("根据省获取市")
    @RequestMapping(value = "/getCity", method = RequestMethod.POST)
    public ResponseResult<List<AreaEntity>> getCity(@RequestParam("provinceCode") Long provinceCode) {
        return ResponseResult.success("获取成功", areaService.getCityListByProvinceCode(provinceCode));
    }

    @NoNeedLogin
    @ApiOperation("根据市获取区")
    @RequestMapping(value = "/getArea", method = RequestMethod.POST)
    public ResponseResult<List<AreaEntity>> getArea(@RequestParam("cityCode") Long cityCode) {
        return ResponseResult.success("获取成功", areaService.getAreaListByCityCode(cityCode));
    }

    @NoNeedLogin
    @RequestMapping(value = "/export", method = RequestMethod.GET)
    public void export(HttpServletResponse response) {
        areaService.export(response);
    }
}
