package com.vren.project.module.management.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class QueryByTypeAndUnitDTO {


    @ApiModelProperty("项目合同开工时间的起始时间")
    private Date commencementStartTime;

    @ApiModelProperty("项目合同开工时间的结束时间")
    private Date commencementEndTime;

    @ApiModelProperty("项目合同竣工时间的开始时间")
    private Date CompletionStartTime;

    @ApiModelProperty("项目合同竣工时间的结束时间")
    private Date CompletionEndTime;


}
