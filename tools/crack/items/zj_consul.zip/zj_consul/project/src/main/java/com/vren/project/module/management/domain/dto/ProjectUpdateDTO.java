package com.vren.project.module.management.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
public class ProjectUpdateDTO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目编号")
    private String projectNo;

    /**
     * 项目名称
     */
    @ApiModelProperty("项目名称")
    private String projectName;

    /**
     * 项目类型
     */
    @ApiModelProperty("项目类型")
    private String projectType;



    /**
     * 项目所在省
     */
    @ApiModelProperty("项目所在省（省市区必选）")
    @NotNull(message = "项目所在省不能为空")
    private Long province;

    /**
     * 项目所在市
     */
    @ApiModelProperty("项目所在市")
    @NotNull(message = "项目所在市不能为空")
    private Long city;

    /**
     * 项目所在区
     */
    @ApiModelProperty("项目所在区")
    @NotNull(message = "项目所在区不能为空")
    private Long area;


    /**
     *  客户名称(建设单位)
     */
    @ApiModelProperty("客户名称")
    private String customerName;

    /**
     * 客户联系人
     */
    @ApiModelProperty("客户联系人")
    private String customerContact;

    /**
     * 客户联系电话
     */
    @ApiModelProperty("客户联系电话")
    private String customerPhone;

    /**
     * 承/发包模式
     */
    @ApiModelProperty("承/发包模式")
    private String contractingMode;

    /**
     * 签约时间
     */
    @ApiModelProperty("签约时间")
    private Date signingTime;

    /**
     * 合同额
     */
    @ApiModelProperty("合同额")
    @ConversionNumber
    @NotNull(message = "合同额不能为空")
    private Long contractAmount;

    /**
     * 合同开工时间
     */
    @ApiModelProperty("合同开工时间")
    private Date contractCommencementTime;

    /**
     * 合同竣工时间
     */
    @ApiModelProperty("合同竣工时间")
    private Date contractCompletionTime;

    /**
     * 预计完工时间
     */
    @ApiModelProperty("预计完工时间")
    private Date estimatedCompletionTime;
    @ApiModelProperty("备注")
    private String remarks;

    @NotBlank(message = "付款比例不能为空")
    @ApiModelProperty("付款比例")
    private String paymentProportion;

    @ApiModelProperty("合同签订时间")
    private Date contractSigningTime;
}
