package com.vren.project.module.distribution.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 * 项目信息
 */
@Data
public class ProjectDistribution{

    @ApiModelProperty("项目类型")
    private String projectType;

//    @ApiModelProperty("项目数量")
//    private Integer count;

    @ApiModelProperty("省")
    private Long province;

    @ApiModelProperty("市")
    private Long city;

    @ApiModelProperty("区")
    private Long area;



}
