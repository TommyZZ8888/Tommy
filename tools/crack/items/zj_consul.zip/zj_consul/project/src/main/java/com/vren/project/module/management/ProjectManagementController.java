package com.vren.project.module.management;


import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import com.vren.project.module.management.domain.dto.ProjectExportDTO;
import com.vren.project.module.management.domain.dto.ProjectQueryDTO;
import com.vren.project.module.management.domain.dto.ProjectUpdateDTO;
import com.vren.project.module.management.domain.dto.SavePathDTO;
import com.vren.project.module.management.domain.vo.ProjectFileVO;
import com.vren.project.module.management.domain.vo.ProjectOutlineVO;
import com.vren.project.module.management.domain.vo.ProjectVO;
import com.vren.project.module.management.domain.vo.ProjectWithContractCostVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author szp
 * @date 2022/9/14 15:43
 */
@RestController
@RequestMapping("/project")
@Api(tags = {"项目管理"})
@OperateLog
public class ProjectManagementController {
    @Autowired
    private ProjectManagementService projectManagementService;

    @RequestMapping(value = "/getList", method = RequestMethod.POST)
    @ApiOperation("获取项目列表基本信息")
    public ResponseResult<PageResult<ProjectVO>> get(@RequestBody @Valid  ProjectQueryDTO dto) {
        return ResponseResult.success("获取成功", projectManagementService.queryList(dto));
    }
    @RequestMapping(value = "/getById", method = RequestMethod.POST)
    @ApiOperation("获取单个项目信息")
    public ResponseResult<ProjectVO> getById(@RequestParam(required = false,value = "id") @Valid @NotBlank(message = "ID不能为空")  String id) {
        return ResponseResult.success("获取成功", projectManagementService.queryById(id));
    }

    @RequestMapping(value = "/addOrUpdate", method = RequestMethod.POST)
    @ApiOperation("新增或修改项目基本信息")
    public ResponseResult<Boolean>  editProject(@RequestBody @Valid ProjectUpdateDTO dto) {
        projectManagementService.editProject(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/delProject", method = RequestMethod.POST)
    @ApiOperation("删除项目基本信息")
    public ResponseResult<Boolean>  delProject(@RequestParam(required = false,value = "id") @Valid @NotBlank(message = "ID不能为空")  String id) {
        projectManagementService.delProject(id);
        return ResponseResult.success("删除成功");
    }

    @RequestMapping(value = "/export", method = RequestMethod.POST)
    @ApiOperation("导出项目信息")
    public void exportProject(HttpServletResponse response,@RequestBody @Valid ProjectExportDTO dto) throws IOException {
        projectManagementService.exportProject(response,dto);
    }

    @RequestMapping(value = "/getOutline", method = RequestMethod.POST)
    @ApiOperation("获取项目基本信息  用于下拉选择")
    public ResponseResult<List<ProjectOutlineVO>> getOutline() {
        return ResponseResult.success("获取成功", projectManagementService.queryOutline());
    }
    @RequestMapping(value = "/getProjectData", method = RequestMethod.POST)
    @ApiOperation("获取项目基本信息用于远程调用")
    public ResponseResult<List<ProjectViewVO>> getDataList(@RequestBody ProjectDemandQueryDTO dto) {
        return ResponseResult.success("获取成功", projectManagementService.queryDataList(dto));
    }
    @RequestMapping(value = "/getProjectType", method = RequestMethod.POST)
    @ApiOperation("获取项目类型下拉框")
    public ResponseResult<List<String>> getProjectType() {
        List<String> list =  projectManagementService.getProjectType();
        return ResponseResult.success("获取成功", list);
    }


    @RequestMapping(value = "/saveAttachmentPath", method = RequestMethod.POST)
    @ApiOperation("保存关联附件路径")
    public ResponseResult<Boolean> saveAttachmentPath(@RequestBody SavePathDTO dto) {
        projectManagementService.saveAttachmentPath(dto);
        return ResponseResult.success("保存成功");
    }


    @RequestMapping(value = "/getAttachmentPath", method = RequestMethod.POST)
    @ApiOperation("获取关联附件路径信息")
    public ResponseResult<ProjectFileVO> getAttachmentPath(@RequestParam(value = "id", required = false) @NotBlank(message = "项目Id不能为空") String id) {
        return ResponseResult.success("获取成功",projectManagementService.getAttachmentPath(id));
    }


    @RequestMapping(value = "/getProjectWithContractCost", method = RequestMethod.POST)
    @ApiOperation("返回项目名称、项目编号和合同造价")
    public ResponseResult<List<ProjectWithContractCostVO>> getProjectWithContractCost() {
        return ResponseResult.success("获取成功",projectManagementService.getProjectWithContractCost());
    }


}
