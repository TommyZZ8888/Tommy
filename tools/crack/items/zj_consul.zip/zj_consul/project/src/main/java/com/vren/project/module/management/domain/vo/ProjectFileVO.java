package com.vren.project.module.management.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;


@Data
public class ProjectFileVO implements Serializable {


    private static final long serialVersionUID = -4711966837744859410L;
    /**
     * 关联附件路径
     */
    @ApiModelProperty("关联附件路径")
    private String attachmentPath;
}
