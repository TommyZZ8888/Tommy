package com.vren.project.common.handler;
import com.alibaba.excel.util.BooleanUtils;
import com.alibaba.excel.write.handler.AbstractCellWriteHandler;
import com.alibaba.excel.write.handler.context.CellWriteHandlerContext;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;

/**
 * @author 耿让
 * 表格单元格字体颜色变化处理器
 */
@Component
public class CustomCellWriteHandler extends AbstractCellWriteHandler {
    @Override
    public void afterCellDispose(CellWriteHandlerContext context) {
        Cell cell = context.getCell();
        int rowIndex = cell.getRowIndex();
        int cellIndex = cell.getColumnIndex();

        // 自定义宽度处理

        // 自定义样式处理
        // 当前事件会在 数据设置到poi的cell里面才会回调
        // 判断不是头的情况 如果是fill 的情况 这里会==null 所以用not true
        if (BooleanUtils.isNotTrue(context.getHead())) {
            if (cell.getColumnIndex() == 11 && cell.getStringCellValue().contains("黄")) {
                // 拿到poi的workbook
                Workbook workbook = context.getWriteWorkbookHolder().getWorkbook();
                // 不同单元格尽量传同一个 cellStyle
                CellStyle cellStyle = workbook.createCellStyle();
                cellStyle.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
                cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                cell.setCellStyle(cellStyle);
                context.getFirstCellData().setWriteCellStyle(null);
            }else if (cell.getColumnIndex() == 11 && cell.getStringCellValue().contains("红")){
                // 拿到poi的workbook
                Workbook workbook = context.getWriteWorkbookHolder().getWorkbook();
                // 不同单元格尽量传同一个 cellStyle
                CellStyle cellStyle = workbook.createCellStyle();
                cellStyle.setFillForegroundColor(IndexedColors.RED.getIndex());
                cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                cell.setCellStyle(cellStyle);
                context.getFirstCellData().setWriteCellStyle(null);
            }else if (cell.getColumnIndex() == 11 && cell.getStringCellValue().contains("蓝")){
                // 拿到poi的workbook
                Workbook workbook = context.getWriteWorkbookHolder().getWorkbook();
                // 不同单元格尽量传同一个 cellStyle
                CellStyle cellStyle = workbook.createCellStyle();
                cellStyle.setFillForegroundColor(IndexedColors.BLUE.getIndex());
                cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
                cell.setCellStyle(cellStyle);
                context.getFirstCellData().setWriteCellStyle(null);
            }
        }
    }
}
