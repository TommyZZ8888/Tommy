package com.vren.project.module.distribution.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.LinkedList;

/**
 * @author 耿让
 * 项目分布
 */
@Data
public class ProjectDistributionVO {

    @ApiModelProperty("code")
    private Long code;

    @ApiModelProperty("地区名称")
    private String name;

    @ApiModelProperty("经度 纬度 塔筒 钢结构 压力容器 金属装饰")
    private LinkedList<Object> value;

}
