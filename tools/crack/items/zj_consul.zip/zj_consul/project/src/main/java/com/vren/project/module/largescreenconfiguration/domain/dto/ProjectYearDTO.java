package com.vren.project.module.largescreenconfiguration.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ProjectYearDTO {
    @NotBlank(message = "项目类型不能为空")
    @ApiModelProperty("项目类型")
    private String projectType;
}
