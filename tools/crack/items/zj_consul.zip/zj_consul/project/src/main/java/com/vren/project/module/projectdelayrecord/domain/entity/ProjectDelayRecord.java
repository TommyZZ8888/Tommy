package com.vren.project.module.projectdelayrecord.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.ctc.wstx.shaded.msv_core.grammar.DataExp;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName("project_delay_record")
public class ProjectDelayRecord {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("延误完工时间")
    private Date delayedCompletionDate;

    @ApiModelProperty("延误描述")
    private String delayedDescription;

    @ApiModelProperty("延误原因")
    private String delayedReason;

    @ApiModelProperty("赶工措施")
    private String expeditingMeasures;

    @ApiModelProperty("延误附件路径")
    private String delayedAttachmentPath;

    @ApiModelProperty("创建时间")
    private Date createTime;
}
