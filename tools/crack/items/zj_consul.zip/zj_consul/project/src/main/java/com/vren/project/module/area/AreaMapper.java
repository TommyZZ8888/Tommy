package com.vren.project.module.area;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.project.module.area.domain.entity.AreaEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AreaMapper extends MPJBaseMapper<AreaEntity> {

    @Select("SELECT * FROM area WHERE level < ${level} order by code asc")
    List<AreaEntity> getList(Long level);

}