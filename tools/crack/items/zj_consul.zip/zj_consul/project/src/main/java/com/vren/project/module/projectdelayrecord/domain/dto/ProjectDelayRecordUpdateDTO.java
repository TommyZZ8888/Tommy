package com.vren.project.module.projectdelayrecord.domain.dto;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
@Data
public class ProjectDelayRecordUpdateDTO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("延误完工时间")
    private Date delayedCompletionDate;

    @ApiModelProperty("延误描述")
    private String delayedDescription;

    @ApiModelProperty("延误原因")
    private String delayedReason;

    @ApiModelProperty("赶工措施")
    private String expeditingMeasures;

    @ApiModelProperty("延误附件路径")
    private String delayedAttachmentPath;
}
