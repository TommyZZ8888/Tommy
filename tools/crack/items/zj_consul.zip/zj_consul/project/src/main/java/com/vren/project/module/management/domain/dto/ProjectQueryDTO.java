package com.vren.project.module.management.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class ProjectQueryDTO extends PageParam {
    @ApiModelProperty("项目编号")
    private String projectNo;
    @ApiModelProperty("项目名称")
    private String projectName;
    @ApiModelProperty("项目类型")
    private List<String> projectType;

    @ApiModelProperty("客户名称")
    private String customerName;

    @ApiModelProperty("项目所在省")
    private Long province;

    @ApiModelProperty("项目所在市")
    private Long city;

    @ApiModelProperty("项目所在区")
    private Long area;

    @ApiModelProperty("项目合同开工时间的起始时间")
    private Date commencementStartTime;

    @ApiModelProperty("项目合同开工时间的结束时间")
    private Date commencementEndTime;

    @ApiModelProperty("项目合同竣工时间的开始时间")
    private Date completionStartTime;

    @ApiModelProperty("项目合同竣工时间的结束时间")
    private Date completionEndTime;
}
