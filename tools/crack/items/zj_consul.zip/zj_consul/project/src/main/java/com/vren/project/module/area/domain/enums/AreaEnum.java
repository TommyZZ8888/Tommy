package com.vren.project.module.area.domain.enums;

public enum AreaEnum {
    PROVINCE(1, "省/直辖市"),
    CITY(2, "市/州"),
    AREA(3, "县/区 "),
    STREET(4, "乡/镇"),
    ;
    private final int code;
    private final String message;

    AreaEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }
}
