package com.vren.project.module.largescreenconfiguration;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.project.module.largescreenconfiguration.domain.entity.LargeScreenConfiguration;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LargeScreenConfigurationMapper extends MPJBaseMapper<LargeScreenConfiguration> {
}
