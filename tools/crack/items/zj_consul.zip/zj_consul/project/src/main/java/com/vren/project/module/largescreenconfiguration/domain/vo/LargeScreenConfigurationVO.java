package com.vren.project.module.largescreenconfiguration.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class LargeScreenConfigurationVO {


    @ApiModelProperty("年份")
    private String year;

    @ConversionNumber
    @ApiModelProperty("安全累计天数")
    private Long safetyCumulativeDays;

    @ApiModelProperty("车间和合同额信息列表")
    private   List<ProjectTypeAndContractAmountVO> list;
}
