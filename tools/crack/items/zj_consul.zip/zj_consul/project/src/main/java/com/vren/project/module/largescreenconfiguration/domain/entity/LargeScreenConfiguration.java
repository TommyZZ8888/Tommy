package com.vren.project.module.largescreenconfiguration.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;

import lombok.Data;

@Data
public class LargeScreenConfiguration {
  @ApiModelProperty("大屏配置id")
  @TableId(type = IdType.ASSIGN_UUID)
  private String id;

  @ApiModelProperty("项目类型")
  private String projectType;

  @ApiModelProperty("年份")
  private String year;

  @ConversionNumber
  @ApiModelProperty("预期合同额")
  private Long expectedContractAmount;

  @ConversionNumber
  @ApiModelProperty("实际合同额")
  private Long actualContractAmount;

  @ConversionNumber
  @ApiModelProperty("安全累计天数")
  private Long safetyCumulativeDays;


}
