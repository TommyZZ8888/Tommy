package com.vren.project.module.projectdelayrecord.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ProjectDelayRecordQueryDTO extends PageParam {
    @ApiModelProperty("项目id")
    @NotBlank(message ="项目id不能为空")
    private String projectId;
}
