package com.vren.project.module.distribution;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.ResponseResult;
import com.vren.project.module.distribution.domain.dto.ProjectDistributionDTO;
import com.vren.project.module.distribution.domain.dto.TopFiveByProvinceDTO;
import com.vren.project.module.distribution.domain.vo.ProjectDistributionTopVO;
import com.vren.project.module.distribution.domain.vo.ProjectDistributionVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author 耿让
 * 项目分布
 */
@RestController
@RequestMapping("/distribution")
@Api(tags = {"项目分布"})
@OperateLog
public class ProjectDistributionController {

    @Autowired
    private ProjectDistributionService projectDistributionService;

    @RequestMapping(value = "/getProjectDistribution", method = RequestMethod.POST)
    @ApiOperation("获取项目分布信息")
    public ResponseResult<List<ProjectDistributionVO>> getProjectDistribution(@RequestBody ProjectDistributionDTO dto) {
        List<ProjectDistributionVO> list = projectDistributionService.getProjectDistribution(dto);
        return ResponseResult.success("获取成功",list);
    }


    @RequestMapping(value = "/getTopFiveByProvince", method = RequestMethod.POST)
    @ApiOperation("获取项目总数全国前五的信息")
    public ResponseResult<List<ProjectDistributionTopVO>> getTopFiveByProvince(TopFiveByProvinceDTO dto) {
        List<ProjectDistributionTopVO> list = projectDistributionService.getTopFiveByProvince(dto);
        return ResponseResult.success("获取成功",list);
    }

}
