package com.vren.project.module.largescreenconfiguration.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectYearVO {
    @ApiModelProperty("年份")
    private String year;
}
