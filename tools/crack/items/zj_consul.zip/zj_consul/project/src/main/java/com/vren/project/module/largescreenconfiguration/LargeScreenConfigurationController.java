package com.vren.project.module.largescreenconfiguration;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.project.module.largescreenconfiguration.domain.dto.*;
import com.vren.project.module.largescreenconfiguration.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;


@RestController
@RequestMapping("/largescreenconfiguration")
@Api(tags = {"项目大屏配置"})
@OperateLog
public class LargeScreenConfigurationController {

    @Autowired
    private LargeScreenConfigurationService largeScreenConfigurationService;
    @RequestMapping(value = "/getProjectIdAndProjectTypeVOList", method = RequestMethod.POST)
    @ApiOperation("获得车间(项目类型)列表(新增配置信息用)")
    public ResponseResult<List<ProjectTypeVO>> getProjectIdAndProjectTypeVOList() {

        return ResponseResult.success("获取成功",largeScreenConfigurationService.getProjectIdAndProjectTypeVOList());
    }
    @RequestMapping(value = "/getProjectYearVOList", method = RequestMethod.POST)
    @ApiOperation("根据车间(项目类型)获得年份列表(新增配置信息用)")
    public ResponseResult<List<ProjectYearVO>> getProjectYearVOList(@RequestBody @Valid ProjectYearDTO dto) {

        return ResponseResult.success("获取成功",largeScreenConfigurationService.getProjectYearVOList(dto));
    }

    @RequestMapping(value = "/addOrUpdateProjectLargeScreenConfiguration", method = RequestMethod.POST)
    @ApiOperation("新增或修改大屏配置信息")
    public ResponseResult<Boolean> updateProjectLargeScreenConfiguration(@RequestBody @Valid LargeScreenConfigurationUpdateDTO dto) {
        largeScreenConfigurationService.updateProjectLargeScreenConfiguration(dto);
        return ResponseResult.success("操作成功");
    }
    @RequestMapping(value = "/getProjectLargeScreenConfigurationList", method = RequestMethod.POST)
    @ApiOperation("获得大屏配置信息列表(返回给大屏)")
    public ResponseResult<LargeScreenConfigurationVO> getProjectLargeScreenConfigurationList() {

        return ResponseResult.success("获取成功",largeScreenConfigurationService.getProjectLargeScreenConfigurationList());
    }

    @RequestMapping(value = "/getLargeScreenConfigurationSingleVOList", method = RequestMethod.POST)
    @ApiOperation("获得大屏配置信息列表")
    public ResponseResult<PageResult<LargeScreenConfigurationSingleVO>> getLargeScreenConfigurationSingleVOList(@RequestBody @Valid LargeScreenConfigurationDTO dto) {

        return ResponseResult.success("获取成功",largeScreenConfigurationService.getLargeScreenConfigurationSingleVOList(dto));
    }
    @RequestMapping(value = "/getProjectLargeScreenConfigurationById", method = RequestMethod.POST)
    @ApiOperation("获得单个大屏配置信息")
    public ResponseResult<LargeScreenConfigurationSingleVO> getProjectLargeScreenConfigurationById(@RequestBody @Valid LargeScreenConfigurationSingleDTO dto) {
        return ResponseResult.success("获取成功",largeScreenConfigurationService.getProjectLargeScreenConfigurationById(dto));
    }
    @RequestMapping(value = "/deleteProjectLargeScreenConfigurationById", method = RequestMethod.POST)
    @ApiOperation("删除单个大屏配置信息")
    public ResponseResult<Boolean> deleteProjectLargeScreenConfigurationById(@RequestBody @Valid LargeScreenConfigurationDeleteDTO dto) {
        largeScreenConfigurationService.deleteProjectLargeScreenConfigurationById(dto);
        return ResponseResult.success("操作成功");
    }



}
