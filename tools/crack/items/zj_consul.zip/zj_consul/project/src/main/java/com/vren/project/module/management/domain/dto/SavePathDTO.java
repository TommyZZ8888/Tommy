package com.vren.project.module.management.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class SavePathDTO {

    @NotBlank(message = "项目id不能为空")
    private String id;

    @ApiModelProperty("关联附件路径")
    private String attachmentPath;

}
