package com.vren.project.module.projectdelayrecord.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ProjectDelayRecordDeleteDTO {
    @ApiModelProperty("项目记录延误表id")
    @NotBlank(message = "项目记录延误表id不能为空")
    private String projectDelayRecordId;
}
