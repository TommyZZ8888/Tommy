package com.vren.project.module.largescreenconfiguration.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
@Data
public class LargeScreenConfigurationDeleteDTO {
    @ApiModelProperty("大屏配置id")
    @NotBlank(message = "id不能为空")
    private String id;
}
