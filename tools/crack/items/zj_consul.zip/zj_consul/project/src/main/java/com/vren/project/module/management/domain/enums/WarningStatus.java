package com.vren.project.module.management.domain.enums;

public enum WarningStatus {
   RED(1,"蓝"),
    YELLOW(2,"黄"),
    GREEN(3,"红"),

    ;
    WarningStatus(Integer code,String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String name;
}
