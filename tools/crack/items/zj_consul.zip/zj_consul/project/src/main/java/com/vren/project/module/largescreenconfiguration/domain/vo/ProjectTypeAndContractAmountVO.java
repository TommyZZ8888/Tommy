package com.vren.project.module.largescreenconfiguration.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectTypeAndContractAmountVO {
    @ApiModelProperty("项目类型")
    private String projectType;

    @ConversionNumber
    @ApiModelProperty("预期合同额")
    private Long expectedContractAmount;

    @ConversionNumber
    @ApiModelProperty("实际合同额")
    private Long actualContractAmount;
}
