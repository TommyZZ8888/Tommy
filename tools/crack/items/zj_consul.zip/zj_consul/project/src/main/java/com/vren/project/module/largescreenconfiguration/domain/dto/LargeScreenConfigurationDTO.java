package com.vren.project.module.largescreenconfiguration.domain.dto;

import com.vren.common.common.domain.PageParam;
import lombok.Data;

@Data
public class LargeScreenConfigurationDTO extends PageParam {
}
