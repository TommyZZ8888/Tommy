package com.vren.project.module.distribution;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.SearchUtil;
import com.vren.project.module.area.AreaService;
import com.vren.project.module.area.domain.entity.AreaEntity;
import com.vren.project.module.distribution.domain.dto.ProjectDistributionDTO;
import com.vren.project.module.distribution.domain.dto.TopFiveByProvinceDTO;
import com.vren.project.module.distribution.domain.entity.ProjectDistribution;
import com.vren.project.module.distribution.domain.vo.ProjectDistributionTopVO;
import com.vren.project.module.distribution.domain.vo.ProjectDistributionVO;
import com.vren.project.module.management.ProjectManagementMapper;
import com.vren.project.module.management.domain.entity.Project;
import com.vren.project.module.valuation.domin.enums.ProjectType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProjectDistributionService {
    @Autowired
    private ProjectManagementMapper projectManagementMapper;

    @Autowired
    private AreaService areaService;

    public List<ProjectDistributionVO> getProjectDistribution(ProjectDistributionDTO dto) {
        initTime(dto);
        /**
         * 查询所有省份的项目分布情况
         *  返回的一个实体代表一个省份的项目分布情况（项目类型：数量）
         */
        //查询所有项目信息：地点、类型
        MPJLambdaWrapper<Project> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(Project.class);
        if (CommonUtil.isNull(dto.getProvince())&&CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())){

        } else if (!CommonUtil.isNull(dto.getProvince())&&CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())) {
            //只传省份参数
            queryWrapper.eq(Project::getProvince, dto.getProvince());
        } else if (CommonUtil.isNull(dto.getProvince())&&!CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())) {
            queryWrapper.eq(Project::getCity, dto.getCity());
        }
        SearchUtil.timeRangeSearch(queryWrapper, Project::getContractCommencementTime, dto.getCommencementStartTime(), dto.getCommencementEndTime());
        SearchUtil.timeRangeSearch(queryWrapper, Project::getContractCompletionTime, dto.getCompletionStartTime(), dto.getCompletionEndTime());
        List<Project> projects = projectManagementMapper.selectList(queryWrapper);
        List<ProjectDistribution> projectDistributions = BeanUtil.copyList(projects, ProjectDistribution.class);
        //根据前端的参数判断如何分组
        //前端季没有传省份，也没有传市级信息
        Map<Long, List<ProjectDistribution>> collect = null;
        if (CommonUtil.isNull(dto.getProvince())&&CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())){
            //通过省code分组
             collect = projectDistributions.stream().collect(Collectors.groupingBy(ProjectDistribution::getProvince));
        } else if (!CommonUtil.isNull(dto.getProvince())&&CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())) {
            //只传省份参数，通过市分组
            collect = projectDistributions.stream().collect(Collectors.groupingBy(ProjectDistribution::getCity));
        } else if (CommonUtil.isNull(dto.getProvince())&&!CommonUtil.isNull(dto.getCity())&&CommonUtil.isNull(dto.getArea())) {
            //通过区分组
            collect = projectDistributions.stream().collect(Collectors.groupingBy(ProjectDistribution::getArea));
        }
        ArrayList<ProjectDistributionVO> list = new ArrayList<>();
        //遍历查询出来的省份
        for (Long item : collect.keySet()) {
            ProjectDistributionVO projectDistributionVO = new ProjectDistributionVO();
            projectDistributionVO.setCode(item);
            projectDistributionVO.setName(areaService.getNameByCode(item));
            //TODO 给地点设置经纬度
            setLatAndLng(projectDistributionVO,item);
            //一个省份下面所有数据，按类型累加数量
            List<ProjectDistribution> projectDistributionList = collect.get(item);
            //A省份下类型一的总数
            for (ProjectType statue : ProjectType.values()) {
                //一个省份、一种类型的集合
                List<ProjectDistribution> collect1 = projectDistributionList.stream().filter(type -> type.getProjectType().equals(statue.getName())).collect(Collectors.toList());
                projectDistributionVO.getValue().add(collect1.size());
            }
            list.add(projectDistributionVO);
        }
        return list;
    }
    public List<ProjectDistributionTopVO> getTopFiveByProvince(TopFiveByProvinceDTO dto) {
        ProjectDistributionDTO distributionDTO = BeanUtil.copy(dto, ProjectDistributionDTO.class);
        initTime(distributionDTO);
        /**
         * 按照省份分组，查询前五
         */
        QueryWrapper<Project> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("province", "COUNT(id) count")
                .groupBy("province")
                //降序排列
                .orderByDesc("count")
                .last("limit 5");
        SearchUtil.timeRangeSearch(queryWrapper, "contract_commencement_time", distributionDTO.getCommencementStartTime(), distributionDTO.getCommencementEndTime());
        SearchUtil.timeRangeSearch(queryWrapper, "contract_completion_time", distributionDTO.getCompletionStartTime(), distributionDTO.getCompletionEndTime());
        List<Project> projects = projectManagementMapper.selectList(queryWrapper);
        List<ProjectDistributionTopVO> projectDistributionTopVOS = BeanUtil.copyList(projects, ProjectDistributionTopVO.class);
        projectDistributionTopVOS.stream().forEach(item -> {
            item.setProvinceText(areaService.getNameByCode(item.getProvince()));
        });
        return projectDistributionTopVOS;
    }
    public void initTime(ProjectDistributionDTO dto) {
        //项目结束时间默认当年
        //获取当年
        Calendar currCal = Calendar.getInstance();
        int currentYear = currCal.get(Calendar.YEAR);
        //通过当年获取当年的第一天
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, currentYear);
        Date currYearFirst = calendar.getTime();
        //如果没有项目开始时间
        if (CommonUtil.isNull(dto.getCommencementStartTime()) && CommonUtil.isNull(dto.getCommencementEndTime())) {
            //当年第一天
            dto.setCommencementStartTime(currYearFirst);
            //当前时间
            dto.setCommencementEndTime(new Date());
        }
        //如果没有项目结束时间
        if (CommonUtil.isNull(dto.getCompletionStartTime()) && CommonUtil.isNull(dto.getCompletionEndTime())) {
            //当年第一天
            dto.setCompletionStartTime(currYearFirst);
            //当前时间
            dto.setCompletionEndTime(new Date());
        }
    }

    /**
     * 给地区设置经纬度
     *
     * @param code
     */
    public void setLatAndLng(ProjectDistributionVO projectDistributionVO, Long code) {
        AreaEntity area = areaService.getAll()
                .stream()
                .filter(item -> item.getCode().equals(code))
                .findFirst().orElse(null);
        if (area != null) {
            LinkedList<Object> objects = new LinkedList<>();
            objects.add(area.getLng());
            objects.add(area.getLat());
            projectDistributionVO.setValue(objects);
        }
    }

}
