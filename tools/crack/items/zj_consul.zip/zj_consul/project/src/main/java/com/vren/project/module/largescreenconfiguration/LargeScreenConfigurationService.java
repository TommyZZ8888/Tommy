package com.vren.project.module.largescreenconfiguration;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;

import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.project.module.largescreenconfiguration.domain.dto.*;
import com.vren.project.module.largescreenconfiguration.domain.entity.LargeScreenConfiguration;
import com.vren.project.module.largescreenconfiguration.domain.vo.*;
import com.vren.project.module.management.ProjectManagementMapper;
import com.vren.project.module.management.domain.entity.Project;
import com.vren.project.module.projectlargescreen.ProjectLargeScreenService;
import com.vren.project.module.projectlargescreen.domain.entity.ProjectLargeScreen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class LargeScreenConfigurationService {
    @Autowired
    private ProjectManagementMapper projectManagementMapper;

    @Autowired
    private LargeScreenConfigurationMapper largeScreenConfigurationMapper;



    public void updateProjectLargeScreenConfiguration(LargeScreenConfigurationUpdateDTO dto) {
        if(CommonUtil.isNull(dto.getId())){
            LargeScreenConfiguration copy = BeanUtil.copy(dto, LargeScreenConfiguration.class);
            ProjectActualContractAmountDTO projectActualContractAmountDTO = new ProjectActualContractAmountDTO();
            projectActualContractAmountDTO.setProjectType(dto.getProjectType());
            projectActualContractAmountDTO.setYear(dto.getYear());
            Long actualContractAmount = this.getProjectActualContractAmountVOList(projectActualContractAmountDTO).getActualContractAmount();
            copy.setActualContractAmount(actualContractAmount);


            MPJLambdaWrapper<LargeScreenConfiguration> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(LargeScreenConfiguration.class)
                            .eq(!CommonUtil.isNull(dto.getProjectType()),LargeScreenConfiguration::getProjectType,dto.getProjectType())
                             .eq(!CommonUtil.isNull(dto.getYear()),LargeScreenConfiguration::getYear,dto.getYear());
            LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectOne(wrapper);
            if(CommonUtil.isNull(largeScreenConfiguration)){
                largeScreenConfigurationMapper.insert(copy);}

            return;
        }
        LargeScreenConfiguration copy = BeanUtil.copy(dto, LargeScreenConfiguration.class);

        largeScreenConfigurationMapper.updateById(copy);

    }

    public LargeScreenConfigurationVO getProjectLargeScreenConfigurationList() {
        List<LargeScreenConfiguration> largeScreenConfigurations = largeScreenConfigurationMapper.selectList(null);
        Calendar date = Calendar.getInstance();
        String year = String.valueOf(date.get(Calendar.YEAR));
        List<LargeScreenConfiguration> collect = largeScreenConfigurations.stream().
                filter(item -> year.equals(item.getYear())).collect(Collectors.toList());
        ArrayList<ProjectTypeAndContractAmountVO> list = new ArrayList<>();
        Long safetyCumulativeDays = collect.stream().min(Comparator.comparing(LargeScreenConfiguration::getSafetyCumulativeDays)).stream().findFirst().orElse(null).getSafetyCumulativeDays();

        for (LargeScreenConfiguration largeScreenConfiguration : collect) {
            if("压力容器".equals(largeScreenConfiguration.getProjectType())){
                extracted(list, largeScreenConfiguration);
            }else if("钢结构".equals(largeScreenConfiguration.getProjectType())){
                extracted(list, largeScreenConfiguration);
            }else if("塔筒".equals(largeScreenConfiguration.getProjectType())){
                extracted(list, largeScreenConfiguration);
            }else if("金属装饰".equals(largeScreenConfiguration.getProjectType())){
                extracted(list, largeScreenConfiguration);
            }
        }
        LargeScreenConfigurationVO largeScreenConfigurationVO = new LargeScreenConfigurationVO();
        largeScreenConfigurationVO.setYear(year);
        largeScreenConfigurationVO.setSafetyCumulativeDays(safetyCumulativeDays);
        largeScreenConfigurationVO.setList(list);

        return largeScreenConfigurationVO;
    }

    private void extracted(ArrayList<ProjectTypeAndContractAmountVO> list, LargeScreenConfiguration largeScreenConfiguration) {
        ProjectTypeAndContractAmountVO copy = BeanUtil.copy(largeScreenConfiguration, ProjectTypeAndContractAmountVO.class);
        list.add(copy);
    }

    public LargeScreenConfigurationSingleVO getProjectLargeScreenConfigurationById(LargeScreenConfigurationSingleDTO dto) {
        LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectById(dto.getId());
        LargeScreenConfigurationSingleVO copy = BeanUtil.copy(largeScreenConfiguration, LargeScreenConfigurationSingleVO.class);
        return copy;
    }

    public void deleteProjectLargeScreenConfigurationById(LargeScreenConfigurationDeleteDTO dto) {
        largeScreenConfigurationMapper.deleteById(dto.getId());
    }

    public List<ProjectTypeVO> getProjectIdAndProjectTypeVOList() {
        List<Project> projects = projectManagementMapper.selectList(null);
        List<ProjectTypeVO> list = BeanUtil.copyList(projects, ProjectTypeVO.class);
        List<ProjectTypeVO> collect = list.stream().distinct().collect(Collectors.toList());
        return collect;
    }

    public List<ProjectYearVO> getProjectYearVOList(ProjectYearDTO dto) {
        MPJLambdaWrapper<Project> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(Project.class)
                .eq(Project::getProjectType,dto.getProjectType());
        List<Project> projects = projectManagementMapper.selectList(wrapper);
        List<ProjectYearVO> collect = projects.stream().map(item -> {
            ProjectYearVO projectYearVO = new ProjectYearVO();
            projectYearVO.setYear(item.getContractSigningTime().toString().substring(item.getContractSigningTime().toString().length() - 4));
            return projectYearVO;
        }).distinct().collect(Collectors.toList());
        return collect;
    }


    public ProjectActualContractAmountVO getProjectActualContractAmountVOList(ProjectActualContractAmountDTO dto) {
        List<Project> projects = projectManagementMapper.selectList(null);
        Map<String, List<Project>> projectCollect  = projects.stream().collect(Collectors.groupingBy(key -> {
            return String.format("%s-%s", key.getContractSigningTime().toString().substring(key.getContractSigningTime().toString().length()-4),key.getProjectType());
        }));
        ProjectActualContractAmountVO projectActualContractAmountVO = new ProjectActualContractAmountVO();
        for (String s : projectCollect.keySet()) {
            String resultString = dto.getYear() + "-" + dto.getProjectType();
            if(resultString.equals(s)){
                List<Project> projectList = projectCollect.get(s);
                Long actualSumCount = projectList.stream().mapToLong(Project::getContractAmount).sum();
                projectActualContractAmountVO = new ProjectActualContractAmountVO();
                projectActualContractAmountVO.setActualContractAmount(actualSumCount);
            }
        }
        return projectActualContractAmountVO;
    }
    /**  000**?
     *：每天凌晨【当前年】的所有车间数据安全天数自动+1，实际合同额重新计算
     * @author szp
     * @date 2023/1/16 8:43
     */
    @Scheduled(cron = "0 0 0 * * ?")
    public void timingUpdateProjectLargeScreenConfiguration() {
        Calendar date = Calendar.getInstance();
        String year = String.valueOf(date.get(Calendar.YEAR));
        List<LargeScreenConfiguration> largeScreenConfigurations = largeScreenConfigurationMapper.selectList(null);
        if(CommonUtil.listIsNotEmpty(largeScreenConfigurations)){
            for (LargeScreenConfiguration largeScreenConfiguration : largeScreenConfigurations) {
                largeScreenConfiguration.setSafetyCumulativeDays(largeScreenConfiguration.getSafetyCumulativeDays()==null?100L:(largeScreenConfiguration.getSafetyCumulativeDays()+100L));
                largeScreenConfigurationMapper.updateById(largeScreenConfiguration);
            }
        }
        List<Project> projects = projectManagementMapper.selectList(null);
        Map<String, List<Project>> projectCollect  = projects.stream().collect(Collectors.groupingBy(key -> {
            return String.format("%s-%s", key.getContractSigningTime().toString().substring(key.getContractSigningTime().toString().length()-4),key.getProjectType());
        }));
        for (String s : projectCollect.keySet()) {
            if((year+"-"+"压力容器").equals(s)) {
                List<Project> projectList = projectCollect.get(s);
                Long actualSumCount = projectList.stream().mapToLong(Project::getContractAmount).sum();
                MPJLambdaWrapper<LargeScreenConfiguration> wrapper = new MPJLambdaWrapper<>();
                wrapper.selectAll(LargeScreenConfiguration.class)
                        .eq(LargeScreenConfiguration::getProjectType,"压力容器")
                        .eq(LargeScreenConfiguration::getYear,year);
                LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectOne(wrapper);
                if(!CommonUtil.isNull(largeScreenConfiguration)){
                    largeScreenConfiguration.setActualContractAmount(actualSumCount);
                    largeScreenConfigurationMapper.updateById(largeScreenConfiguration);
                }
            } else if ((year + "-" + "钢结构").equals(s)) {
                List<Project> projectList = projectCollect.get(s);
                Long actualSumCount = projectList.stream().mapToLong(Project::getContractAmount).sum();
                MPJLambdaWrapper<LargeScreenConfiguration> wrapper = new MPJLambdaWrapper<>();
                wrapper.selectAll(LargeScreenConfiguration.class)
                        .eq(LargeScreenConfiguration::getProjectType,"钢结构")
                        .eq(LargeScreenConfiguration::getYear,year);
                LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectOne(wrapper);
                if(!CommonUtil.isNull(largeScreenConfiguration)){
                    largeScreenConfiguration.setActualContractAmount(actualSumCount);
                    largeScreenConfigurationMapper.updateById(largeScreenConfiguration);
                }
            } else if ((year + "-" + "塔筒").equals(s)) {
                List<Project> projectList = projectCollect.get(s);
                Long actualSumCount = projectList.stream().mapToLong(Project::getContractAmount).sum();
                MPJLambdaWrapper<LargeScreenConfiguration> wrapper = new MPJLambdaWrapper<>();
                wrapper.selectAll(LargeScreenConfiguration.class)
                        .eq(LargeScreenConfiguration::getProjectType,"塔筒")
                        .eq(LargeScreenConfiguration::getYear,year);
                LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectOne(wrapper);
                if(!CommonUtil.isNull(largeScreenConfiguration)){
                    largeScreenConfiguration.setActualContractAmount(actualSumCount);
                    largeScreenConfigurationMapper.updateById(largeScreenConfiguration);
                }
            } else if ((year + "-" + "金属装饰").equals(s)) {
                List<Project> projectList = projectCollect.get(s);
                Long actualSumCount = projectList.stream().mapToLong(Project::getContractAmount).sum();
                MPJLambdaWrapper<LargeScreenConfiguration> wrapper = new MPJLambdaWrapper<>();
                wrapper.selectAll(LargeScreenConfiguration.class)
                        .eq(LargeScreenConfiguration::getProjectType,"金属装饰")
                        .eq(LargeScreenConfiguration::getYear,year);
                LargeScreenConfiguration largeScreenConfiguration = largeScreenConfigurationMapper.selectOne(wrapper);
                if(!CommonUtil.isNull(largeScreenConfiguration)){
                    largeScreenConfiguration.setActualContractAmount(actualSumCount);
                    largeScreenConfigurationMapper.updateById(largeScreenConfiguration);
                }
            }


        }

    }

    public PageResult<LargeScreenConfigurationSingleVO> getLargeScreenConfigurationSingleVOList(LargeScreenConfigurationDTO dto) {
        List<LargeScreenConfiguration> largeScreenConfigurations = largeScreenConfigurationMapper.selectList(null);
        List<LargeScreenConfigurationSingleVO> largeScreenConfigurationSingleVOS = BeanUtil.copyList(largeScreenConfigurations, LargeScreenConfigurationSingleVO.class);
        return PageUtil.convert2PageResult(largeScreenConfigurationSingleVOS, dto);
    }
}
