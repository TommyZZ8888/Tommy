package com.vren.project.module.area.domain.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName:AreaEntity
 * @Description:
 * @Author: vren
 * @Date: 2022/6/24 14:10
 */
@TableName("area")
@Data
public class AreaEntity implements Serializable {

    private static final long serialVersionUID = -8963802244337195794L;

    @TableId
    private Long code;

    private Long pCode;

    private String name;

    private Long province;

    private Long city;

    private Long area;

    private Integer level;

    @ApiModelProperty("纬度")
    private Double lat;

    @ApiModelProperty("经度")
    private Double lng;

    private String polygon;

}
