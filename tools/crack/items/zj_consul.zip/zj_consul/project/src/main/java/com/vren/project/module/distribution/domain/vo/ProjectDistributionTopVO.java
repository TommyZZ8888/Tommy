package com.vren.project.module.distribution.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProjectDistributionTopVO {

    @ApiModelProperty("省")
    private Long province;

    @ApiModelProperty("省名称")
    private String provinceText;

    @ApiModelProperty("项目总数")
    private String count;
}
