package com.vren.project.module.largescreenconfiguration.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectTypeVO {


    @ApiModelProperty("项目类型")
    private String projectType;
}
