package com.vren.project.module.management.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProjectWithContractCostVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目编号")
    private String projectNo;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("合同额")
    @ConversionNumber
    private Long contractAmount;

}
