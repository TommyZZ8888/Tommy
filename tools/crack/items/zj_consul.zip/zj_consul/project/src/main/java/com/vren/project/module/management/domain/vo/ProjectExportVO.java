package com.vren.project.module.management.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.project.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 耿让
 * 项目导出VO
 */
@Data
public class ProjectExportVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ExcelProperty("序号")
    @ApiModelProperty("序号")
    @ColumnWidth(5)
    private String id;

    @ApiModelProperty("项目名称")
    @ExcelProperty("项目名称")
    @ColumnWidth(20)
    private String projectName;

    @ApiModelProperty("客户名称")
    @ExcelProperty("业主名称")
    @ColumnWidth(10)
    private String customerName;

    @ApiModelProperty("合同额")
    @ExcelProperty(value = "合同额（万元）")
    @ColumnWidth(20)
    @ConversionNumber
    private Long contractAmount;

    @ApiModelProperty("合同开工时间")
    @ExcelProperty(value = "开工时间",converter = DateConverter.class)
    @ColumnWidth(18)
    private Date contractCommencementTime;

    @ApiModelProperty("合同竣工时间")
    @ExcelProperty(value = "竣工时间",converter = DateConverter.class)
    @ColumnWidth(18)
    private Date contractCompletionTime;

    @ExcelProperty("目前完成量及形象进度")
    @ApiModelProperty("进度")
    @ColumnWidth(20)
    private String progress;

    @ApiModelProperty("延误描述")
    @ExcelProperty("总工期和工期节点延误情况")
    @ColumnWidth(20)
    private String delayDescription;

    @ApiModelProperty("延误描述")
    @ExcelProperty("延误原因分析")
    @ColumnWidth(20)
    private String delayReasons;

    @ApiModelProperty("赶工措施")
    @ExcelProperty("赶工措施")
    @ColumnWidth(20)
    private String expeditingMeasures;

    @ApiModelProperty("预计完工时间")
    @ExcelProperty(value = "预计完工时间",converter = DateConverter.class)
    @ColumnWidth(18)
    private Date estimatedCompletionTime;

    @ApiModelProperty("预警状态")
    @ExcelIgnore
    private Integer warningStatus;

    @ApiModelProperty("预警")
    @ExcelProperty("预警")
    @ColumnWidth(8)
    private String warningStatusText;

}
