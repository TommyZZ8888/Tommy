package com.vren.project.module.management.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.Date;
import java.util.List;

/**
 * @author 耿让
 * 项目导出DTO
 */
@Data
public class ProjectExportDTO {

    @Size(min = 1,message = "项目类型不能为空")
    @ApiModelProperty("项目类型")
    private List<String> projectType;

    @ApiModelProperty("项目合同开工时间的起始时间")
    private Date commencementStartTime;

    @ApiModelProperty("项目合同开工时间的结束时间")
    private Date commencementEndTime;

    @ApiModelProperty("项目合同竣工时间的开始时间")
    private Date completionStartTime;

    @ApiModelProperty("项目合同竣工时间的结束时间")
    private Date completionEndTime;

}
