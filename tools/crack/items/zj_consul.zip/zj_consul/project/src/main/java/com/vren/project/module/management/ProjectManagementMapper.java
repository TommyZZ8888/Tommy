package com.vren.project.module.management;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.project.module.management.domain.entity.Project;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @author 耿让
 */
@Mapper
public interface ProjectManagementMapper extends MPJBaseMapper<Project> {
    @Select("SELECT count(id) FROM project where project_no=#{projectNo}")
    Long getCount(@Param("projectNo") String projectNo);

}
