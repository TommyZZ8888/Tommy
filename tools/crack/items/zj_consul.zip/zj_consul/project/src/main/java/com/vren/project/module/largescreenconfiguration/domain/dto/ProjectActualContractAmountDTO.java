package com.vren.project.module.largescreenconfiguration.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class ProjectActualContractAmountDTO {
    @NotBlank(message = "项目类型不能为空")
    @ApiModelProperty("项目类型")
    private String projectType;

    @NotBlank(message = "年份不能为空")
    @ApiModelProperty("年份")
    private String year;
}
