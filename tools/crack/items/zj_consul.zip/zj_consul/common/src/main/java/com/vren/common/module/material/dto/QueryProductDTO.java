package com.vren.common.module.material.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class QueryProductDTO {

    @NotBlank(message = "产品需求计划id不能为空")
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;
}
