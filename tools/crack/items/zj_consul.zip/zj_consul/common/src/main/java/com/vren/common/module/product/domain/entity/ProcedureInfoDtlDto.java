package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProcedureInfoDtlDto {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("序号")
    private Integer seq;

    @ApiModelProperty("工序名称")
    private String name;

    @ApiModelProperty("工序说明")
    private String explain;

    @ApiModelProperty("工种或设备")
    private String typeOrDevice;

    @ApiModelProperty("工作者")
    private String worker;

    @ApiModelProperty("工作日期")
    private String workDate;

    @ApiModelProperty("检验类型")
    private String inspectionType;

    @ApiModelProperty("检验员")
    private String inspector;

    @ApiModelProperty("检验日期")
    private String inspectDate;

    @ApiModelProperty("接收车间")
    private String receiveWorkShop;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("工序卡id")
    private String procedureInfoId;
}
