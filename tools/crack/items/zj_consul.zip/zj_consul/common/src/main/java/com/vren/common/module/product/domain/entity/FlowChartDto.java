package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class FlowChartDto {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("产品信息Id")
    private String productInfoId;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("制造编号")
    private String manufacturingNo;

    @ApiModelProperty("")
    private String flowChartJsonStr;

    private List<FlowChartDtlDto> listDtl;
}
