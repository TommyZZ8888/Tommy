package com.vren.common.module.product.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductPlanCreateDTO {

    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    @ApiModelProperty(" 项目id")
    private String projectKeyId;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("图号")
    private String tagNo;

    @ApiModelProperty("类别")
    private String containerCategory;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("产品规格")
    private String productSpecificatons;

    @ApiModelProperty("主体材质")
    private String mainMaterial;

    @ApiModelProperty("数量（台）")
    private Integer quantity;

    @ApiModelProperty("重量（吨）")
    private Double weight;

    @ApiModelProperty("用户")
    private String customer;

    @ApiModelProperty("产品需求计划id")
    private String productDemandKeyId;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("计划编号")
    private String scheduleNo;

}
