package com.vren.common.module.basedb.dictdata;

import com.vren.common.common.utils.FastJsonConversionNumber;
import com.vren.common.module.basedb.dictdata.domain.dto.DictDataDTO;
import com.vren.common.module.basedb.dictdata.domain.dto.DictDataSingleDTO;
import com.vren.common.module.basedb.dictdata.domain.entity.DictDataEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class DictDataService {

    @Autowired
    private DictDataFeign dictDataFeign;

    public List<DictDataEntity> getDicDataForPage(String parentCode) {
        DictDataDTO dto = new DictDataDTO();
        dto.setParentCode(parentCode);
        String info = dictDataFeign.getDicDataForPage(dto);
        return FastJsonConversionNumber.parseObject2List(info, DictDataEntity.class,"data");
    }

    public DictDataEntity getDicDataByIdOrCode(String code) {
        DictDataSingleDTO dto = new DictDataSingleDTO();
        dto.setDicCode(code);
        String info = dictDataFeign.getDicDataByIdOrCode(dto);
        return FastJsonConversionNumber.parseObject(info, DictDataEntity.class,"data");
    }

    public DictDataEntity test(String code) {
        Map<String, String> form = new HashMap<>();
        form.put("dicCode", code);
        String info = dictDataFeign.test(form);
        return FastJsonConversionNumber.parseObject(info, DictDataEntity.class,"data");
    }
}
