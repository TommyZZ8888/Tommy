package com.vren.common.module.identity.user;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.identity.user.domain.dto.BaseReceiveDTO;
import com.vren.common.module.identity.user.domain.dto.GetUserInfoDTO;
import com.vren.common.module.identity.user.domain.dto.SaveUserInfoDTO;
import com.vren.common.module.identity.user.domain.dto.UserInfoDto;
import com.vren.common.module.identity.user.domain.entity.BaseSelectDtoListResultData;
import com.vren.common.module.identity.user.domain.entity.UserInfoEntity;
import com.vren.common.common.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserService {

    @Autowired
    private UserFeign userFeign;

    @Resource
    private RedisUtil redisUtil;

    /**
     * 获取所有用户的ID和Username
     *
     * @return
     */
    public List<UserInfoEntity> getAllUserList() {
        final String redisKey = "GetAllUsers";
        Object redisValue = redisUtil.get(redisKey);
        List<UserInfoEntity> list = null;
        if (redisValue == null) {
            synchronized (this) {
                redisValue = redisUtil.get(redisKey);
                if (redisValue == null) {
                    String result = userFeign.getUserBindSelect();
                    ResponseResult<List<UserInfoEntity>> responseResult = JSONObject.parseObject(result, new TypeReference<>() {
                    });
                    list = responseResult.getData();
                    //更新缓存
                    List<Map<String, String>> mapList = list.stream().map(item -> new HashMap<String, String>() {

                        private static final long serialVersionUID = -2926340890760157556L;

                        {
                            put("KeyId", item.getUserId());
                            put("Value", item.getUserName());
                        }
                    }).collect(Collectors.toList());
                    redisUtil.set(redisKey, mapList, 60 * 60 * 2);
                }
            }
        }
        if (list == null) list = JSONObject.parseObject(redisValue.toString(), new TypeReference<>() {
        });
        return list;
    }


    public void saveUserInfo(SaveUserInfoDTO userInfoDTO){
       //数据库已有的数据，不用添加
        List<UserInfoDto> collect = null;
        for (UserInfoEntity item:getAllUserList()) {
            collect  = userInfoDTO.getUserRequests().stream().filter(userInfo -> !userInfo.getUserName().equals(item.getUserName())).collect(Collectors.toList());
        }
        userInfoDTO.setUserRequests(collect);
        //保存用户信息
        userFeign.addUserInfoList(userInfoDTO);
    }

    /**
     * 获取单条的人员信息
     */
    public UserInfoEntity getUserInfoByID(String keyId) {
        GetUserInfoDTO form = new GetUserInfoDTO();
        form.setKeyId(keyId);
        String result = userFeign.getUserInfoDetail(form);
        ResponseResult<UserInfoEntity> responseResult = JSONObject.parseObject(result, new TypeReference<>() {
        });
        return responseResult.getData();
    }


    public List<BaseSelectDtoListResultData> getUserBindSelectByRoleId(String keyId){
        BaseReceiveDTO baseReceiveDTO = new BaseReceiveDTO();
        baseReceiveDTO.setKeyId(keyId);
        return userFeign.getUserBindSelectByRoleId(baseReceiveDTO).getData();
    }

}
