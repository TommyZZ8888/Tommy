package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class BatchScheduleQTDtoListResultData {

    private Integer code;

    @ApiModelProperty("一个产品")
    private List<BatchScheduleQTDto> data;

    private String msg;
}
