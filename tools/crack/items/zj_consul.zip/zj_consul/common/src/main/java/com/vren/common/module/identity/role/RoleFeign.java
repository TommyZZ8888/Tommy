package com.vren.common.module.identity.role;

import com.vren.common.module.identity.role.domain.dto.GetRoleModuleListDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @ClassName:RoleFeign
 * @Author: vren
 * @Date: 2022/7/19 16:30
 */
@FeignClient(value = "UserApi")
public interface RoleFeign {

    @RequestMapping(value = "/api/user/Role/GetRoleLinkModuleList", method = RequestMethod.POST)
    String getRoleLinkModuleList(GetRoleModuleListDTO dto);

}
