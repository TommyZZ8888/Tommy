package com.vren.common.module.material.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductDetailOutline {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("材质")
    private String material;

}
