package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class FlowChartDtlDto {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("是否焊接")
    private Boolean isWeld;

    @ApiModelProperty("产品明细")
    private String productInfoDtlId;

    @ApiModelProperty("产品明细")
    private ProductInfoDtlDto productInfoDtl;

    @ApiModelProperty("工序卡信息")
    private String procedureInfoId;

    @ApiModelProperty("工序过程id")
    private String procedureInfoDtlId;

    @ApiModelProperty("工序")
    private ProcedureInfoDtlDto procedureInfoDtl;

    @ApiModelProperty("关联的工序流程图id")
    private String flowChartId;

    @ApiModelProperty("前序节点")
    private List<String> listFrontNode;

    @ApiModelProperty("后续节点")
    private List<String> listRearNode;

    @ApiModelProperty("生产任务的状态")
    private Integer productTaskState;

}
