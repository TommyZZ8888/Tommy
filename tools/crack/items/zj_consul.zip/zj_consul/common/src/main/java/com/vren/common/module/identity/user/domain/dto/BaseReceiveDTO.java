package com.vren.common.module.identity.user.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class BaseReceiveDTO {

    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    @ApiModelProperty("角色的keyId")
    private String keyId;

}
