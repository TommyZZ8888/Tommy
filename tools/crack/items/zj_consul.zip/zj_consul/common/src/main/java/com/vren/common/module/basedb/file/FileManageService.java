package com.vren.common.module.basedb.file;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.basedb.file.domian.dto.DelAttachmentDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName:FileManageService
 * @Author: vren
 * @Date: 2022/7/19 9:57
 */
@Service
public class FileManageService {


    @Autowired
    private FileManageFeign fileManageFeign;

    public Boolean delAttachment(List<String> keyIds) {
        DelAttachmentDTO delAttachmentDTO = new DelAttachmentDTO();
        delAttachmentDTO.setKeyIds(keyIds);
        String result = fileManageFeign.delAttachment(delAttachmentDTO);
        ResponseResult<Boolean> responseResult = JSON.parseObject(result, new TypeReference<>() {
        });
        return responseResult.getCode().equals(1);
    }
}
