package com.vren.common.module.system.log;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.common.module.system.log.domin.entity.UserOperateLogEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserOperateLogMapper extends MPJBaseMapper<UserOperateLogEntity> {

}