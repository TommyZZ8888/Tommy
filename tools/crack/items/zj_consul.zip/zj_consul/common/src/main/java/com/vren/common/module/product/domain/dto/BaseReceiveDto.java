package com.vren.common.module.product.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class BaseReceiveDto {
    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    @ApiModelProperty("产品id")
    private String keyId;
}
