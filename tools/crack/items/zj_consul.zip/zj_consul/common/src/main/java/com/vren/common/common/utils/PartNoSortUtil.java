package com.vren.common.common.utils;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.ArrayUtils;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

/**
 * @author 耿让
 */
public class PartNoSortUtil {

    /**
     * 件号最长格式 1-1-1
     */
    private static final int MAX_LENGTH = 3;

    public static <T> void sort(List<T> t){
        t.sort((o1, o2) -> {
            try {
                Method getPartNo1 = o1.getClass().getMethod("getPartNo",  null);
                getPartNo1.setAccessible(true);
                String p1 = getPartNo1.invoke(o1, (Object[]) null).toString();

                Method getPartNo2 = o2.getClass().getMethod("getPartNo",  null);
                getPartNo2.setAccessible(true);
                String p2 = getPartNo2.invoke(o2, (Object[]) null).toString();
                if (!checkPartNo(p1)){
                    return 1;
                }
                if (!checkPartNo(p2)){
                    return -1;
                }
                if (checkPartNo(p1)&&checkPartNo(p2)) {
                    //件号全部属于数字格式的
                    //当前数字个数
                    String[] split1 = p1.split("-");
                    String[] split2 = p2.split("-");
                    //需要补0的格式
                    int differentialValue1 = MAX_LENGTH - split1.length;
                    int differentialValue2 = MAX_LENGTH - split2.length;
                    int[] objects1 = Arrays.stream(split1).mapToInt(Integer::parseInt).toArray();
                    int[] objects2 = Arrays.stream(split2).mapToInt(Integer::parseInt).toArray();
                    int[] ints1;
                    //补0
                    if (differentialValue1 > 0) {
                        int[] ints = new int[differentialValue1];
                        ints1 = ArrayUtils.addAll(objects1, ints);
                    }else {
                        ints1 = objects1;
                    }
                    int[] ints2;
                    if (differentialValue2 > 0) {
                        int[] ints = new int[differentialValue2];
                        ints2 = ArrayUtils.addAll(objects2, ints);
                    }else {
                        ints2 = objects2;
                    }
                    for (int i = 0; i < MAX_LENGTH; i++) {
                        if (ints1[i] > ints2[i]) {
                            return 1;
                        } else if (ints1[i] < ints2[i]) {
                            return -1;
                        } //如果按一条件比较结果相等，就使用第二个条件进行比较。
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
            }
            return 0;
        });
    }

    public static boolean checkPartNo(String partNo){
        //件号规格校验
        char[] chars = partNo.toCharArray();
        if (!StringUtils.isNumeric(String.valueOf(chars[0]))||!StringUtils.isNumeric(String.valueOf(chars[chars.length-1]))){
            return false;
        }
        for (char c : chars) {
            if (!(StringUtils.isNumeric(String.valueOf(c))|| "-".equals(String.valueOf(c)))){
                return false;
            }
        }
        return true;
    }


}
