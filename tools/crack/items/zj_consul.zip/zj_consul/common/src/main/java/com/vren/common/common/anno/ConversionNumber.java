package com.vren.common.common.anno;

import com.vren.common.common.constant.CommonConstant;

import java.lang.annotation.*;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface ConversionNumber {
    //用于注解  序列化或者反序列化
    int value() default CommonConstant.REMOVE_THE_DECIMAL_POINT;
}
