package com.vren.common.common.constant;

/**
 * @ClassName:CommonConstant
 * @Description:
 * @Author: vren
 * @Date: 2021/12/13 17:03
 */
public class CommonConstant {

    public final static int REMOVE_THE_DECIMAL_POINT = 100;

}
