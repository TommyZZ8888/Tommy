package com.vren.common.module.basedb.dictdata;

import com.vren.common.module.basedb.dictdata.domain.dto.DictDataDTO;
import com.vren.common.module.basedb.dictdata.domain.dto.DictDataSingleDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Map;

@FeignClient(value = "BaseDBApi")
public interface DictDataFeign {

    @RequestMapping(value = "/api/basedb/DicData/GetDicDataForPage", method = RequestMethod.POST)
    String getDicDataForPage(DictDataDTO dto);

    @RequestMapping(value = "/api/basedb/DicData/GetDicDataByIdOrCode", method = RequestMethod.POST)
    String getDicDataByIdOrCode(DictDataSingleDTO dto);

    @RequestMapping(value = "/api/basedb/DicData/GetDicDataByIdOrCode", method = RequestMethod.POST)
    String test(Map<String, ?> data);
}
