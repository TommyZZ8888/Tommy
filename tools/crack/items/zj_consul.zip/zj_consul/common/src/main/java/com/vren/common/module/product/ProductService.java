package com.vren.common.module.product;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.product.domain.dto.BaseReceiveDto;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.product.domain.entity.BatchScheduleQTDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 耿让
 */
@Slf4j
@Service
public class ProductService {

    @Autowired
    private ProductFeign productFeign;

    /**
     *
     * @param dto
     * @return
     */
    public ResponseResult<Boolean> createProductPlan(ProductPlanCreateDTO dto){
        return productFeign.createProductPlan(dto);
    }

    public  List<BatchScheduleQTDto> getProductToQT(String keyId){
        BaseReceiveDto baseReceiveDto = new BaseReceiveDto();
        baseReceiveDto.setKeyId(keyId);
        return productFeign.getProductToQT(baseReceiveDto).getData();
    }


}
