package com.vren.common.module.material.entity;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class MaterialFirstLevelStorageFeignVO {
    @ApiModelProperty("材料名称")
    private String materialName;
    @ApiModelProperty("归属(项目名称/设备类型)")
    private String ascription;
    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("材料编号")
    private String materialNumber;


    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("牌号")
    private  String brand;

    @ApiModelProperty("材质")
    private String texture;


    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;



    @ApiModelProperty("入库日期")
    private Date storageDate;


    //页面上没有的字段

    private String id;


    @ApiModelProperty("生产厂家")
    private String manufacturer;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("执行标准")
    private String executiveStandards;


    @ApiModelProperty("生产日期")
    private Date manufactureDate;

    @ApiModelProperty("有效期")
    private Date validityTerm;



    @ApiModelProperty("焊材,型号")
    private String model;
    @ApiModelProperty("油漆,面积")
    private String area;
    @ApiModelProperty("油漆,颜色")
    private String colour;

    @ConversionNumber
    @ApiModelProperty("实际入库数量")
    private Long actualStockAmount;


    @ApiModelProperty("发票入库 (0,否  1 是)")
    private Integer invoiceWarehousing;

    @ConversionNumber
    @ApiModelProperty("发票包含数量")
    private  Long invoiceQuantity;



}
