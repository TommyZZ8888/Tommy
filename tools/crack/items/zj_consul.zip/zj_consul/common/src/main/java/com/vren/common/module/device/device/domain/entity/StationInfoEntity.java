package com.vren.common.module.device.device.domain.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.vren.common.common.anno.ConversionNumber;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @ClassName:GetStationInfoByDeviceIdEntity
 * @Author: vren
 * @Date: 2022/7/26 15:41
 */
@NoArgsConstructor
@Data
public class StationInfoEntity {


    @JSONField(name = "keyId")
    private String keyId;
    @JSONField(name = "stationCode")
    private String stationCode;
    @JSONField(name = "stationName")
    private String stationName;

    @JSONField(name = "peopleInCharge")
    private String peopleInCharge;

    @JSONField(name = "deptCode")
    private String deptCode;

    @JSONField(name = "deviceIds")
    private List<String> deviceIds;

    @JSONField(name = "deviceIdStr")
    private String deviceIdStr;
    
    @JSONField(name = "desc")
    private String desc;

    @JSONField(name = "theoryQty")
    @ConversionNumber
    private Long theoryQty;
}
