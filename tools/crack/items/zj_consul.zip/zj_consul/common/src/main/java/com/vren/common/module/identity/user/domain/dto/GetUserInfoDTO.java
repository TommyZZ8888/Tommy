package com.vren.common.module.identity.user.domain.dto;

import lombok.Data;

/**
 * @ClassName:GetUserInfoDTO
 * @Description:
 * @Author: vren
 * @Date: 2022/6/15 9:59
 */
@Data
public class GetUserInfoDTO {

    private String keyId;
}
