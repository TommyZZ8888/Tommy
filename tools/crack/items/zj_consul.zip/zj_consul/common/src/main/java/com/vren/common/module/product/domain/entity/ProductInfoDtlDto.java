package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 *  产品明细
 */
@Data
public class ProductInfoDtlDto {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("产品明细id")
    private String productDtlId;

    @ApiModelProperty("图号")
    private String drawingNo;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("类型")
    private String materialType;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("件数")
    private String partNumber;

    @ApiModelProperty("材质")
    private String materialTexture;

    @ApiModelProperty("代用材质")
    private String substituteMaterial;

    @ApiModelProperty("规格")
    private String spec;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("数量")
    private double qty;

    @ApiModelProperty("重量")
    private double weight;

    @ApiModelProperty("配合车间")
    private String coordinationWorkshop;

    @ApiModelProperty("开始车间")
    private String startWorkshop;

    @ApiModelProperty("卡片号")
    private String cardNo;

    @ApiModelProperty("备件数量")
    private double standbyQty;

    @ApiModelProperty("产品id")
    private String productInfoId;



}
