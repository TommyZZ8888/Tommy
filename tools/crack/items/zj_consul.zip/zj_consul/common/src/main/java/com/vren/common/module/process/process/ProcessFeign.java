package com.vren.common.module.process.process;

import com.vren.common.module.process.process.domain.dto.GetProductDetailDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * process 服务接口
 */
@FeignClient(value = "ProcessApi")
public interface ProcessFeign {

    @RequestMapping(value = "/api/process/process/GetProductDetailByKeyId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    String getProductDetailByKeyId(GetProductDetailDTO dto);
}
