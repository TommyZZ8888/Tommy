package com.vren.common.module.product;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.product.domain.dto.BaseReceiveDto;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.product.domain.entity.BatchScheduleQTDtoListResultData;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author 耿让
 */
@FeignClient(value = "product")
public interface ProductFeign {

    /**
     *  调用产品模块的创建生产计划的接口
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/product/Product/CreateProductPlan", method = RequestMethod.POST)
    ResponseResult<Boolean> createProductPlan(@RequestBody ProductPlanCreateDTO dto);

    @RequestMapping(value = "/api/product/Product/GetProductToQT",method = RequestMethod.POST)
    BatchScheduleQTDtoListResultData getProductToQT(@RequestBody BaseReceiveDto dto);

}
