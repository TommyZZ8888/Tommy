package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class BatchScheduleQTDto {

    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    @ApiModelProperty("产品id")
    private String keyId;

    @ApiModelProperty("所属计划id")
    private String planId;

    @ApiModelProperty("批次单台编号：产品的唯一性id")
    private String batchNo;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("关联工序流程图Id")
    private String flowChartId;

    @ApiModelProperty("位号")
    private String tagNo;

    @ApiModelProperty("类别")
    private String containerCategory;

    @ApiModelProperty("设备名称")
    private String productName;

    @ApiModelProperty("产品规格")
    private String productSpecificatons;

    @ApiModelProperty("主体材质")
    private String mainMaterial;

    private FlowChartDto flowChart;
}
