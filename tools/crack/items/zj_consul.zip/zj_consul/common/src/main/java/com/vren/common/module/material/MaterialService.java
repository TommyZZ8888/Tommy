package com.vren.common.module.material;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.material.dto.IdsDTO;
import com.vren.common.module.material.dto.MaterialFirstLevelStorageDTO;
import com.vren.common.module.material.dto.MaterialStockDTO;
import com.vren.common.module.material.dto.QueryProductDTO;
import com.vren.common.module.material.entity.MaterialNoticeVO;
import com.vren.common.module.material.entity.ProductInformationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MaterialService {
    @Autowired
    private MaterialFeign materialFeign;

   public List<MaterialNoticeVO> getMaterialStorageNoticeDetailList(){

       ResponseResult<List<MaterialNoticeVO>> result=materialFeign.getMaterialStorageNoticeDetailList();
       return result.getData();
   }

   public List<ProductInformationVO> selectByKeyIds(List<String> ids){
       IdsDTO idsDTO = new IdsDTO();
       idsDTO.setKeyIds(ids);
       return materialFeign.selectByKeyIds(idsDTO).getData();
   }


   public ProductInformationVO getProductInformationByName(String id, String productName,String manufacturingNumber){
       QueryProductDTO queryProductDTO = new QueryProductDTO();
       queryProductDTO.setId(id);
       queryProductDTO.setProductName(productName);
       queryProductDTO.setManufacturingNumber(manufacturingNumber);
       return materialFeign.getProductInformationByName(queryProductDTO).getData();
   }

    public ProductInformationVO getProductInformation(String id, String productName,String manufacturingNumber){
        QueryProductDTO queryProductDTO = new QueryProductDTO();
        queryProductDTO.setId(id);
        queryProductDTO.setProductName(productName);
        queryProductDTO.setManufacturingNumber(manufacturingNumber);
        return materialFeign.getProductInformation(queryProductDTO).getData();
    }

  public Boolean insertMaterialStock(MaterialStockDTO dto){
       return materialFeign.insertMaterialStock(dto).getData();

  }

  public MaterialStockDTO getMaterialStockById(MaterialFirstLevelStorageDTO dto){
       return materialFeign.getMaterialStockById(dto).getData();

    }

    public boolean canDeleteProject(String id){
       return materialFeign.canDeleteProject(id).getData();
    }
}
