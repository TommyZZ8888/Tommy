package com.vren.common.module.identity.user;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.identity.user.domain.dto.BaseReceiveDTO;
import com.vren.common.module.identity.user.domain.entity.BaseSelectDtoListResultData;
import com.vren.common.module.identity.user.domain.dto.GetUserInfoDTO;
import com.vren.common.module.identity.user.domain.dto.SaveUserInfoDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * 用户服务接口
 */
@FeignClient(value = "UserApi")
public interface UserFeign {

    @RequestMapping(value = "/api/user/user/GetUserInfoDetail", method = RequestMethod.POST)
    String getUserInfoDetail(GetUserInfoDTO data);

    @RequestMapping(value = "/api/user/user/GetUserBindSelect", method = RequestMethod.POST)
    String getUserBindSelect();

    /**
     *  根据角色id查询角色信息
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/user/User/GetUserBindSelectByRole", method = RequestMethod.POST)
    ResponseResult<List<BaseSelectDtoListResultData>> getUserBindSelectByRoleId(BaseReceiveDTO dto);

    /**
     *  调用批量保存用户的方法
     * @param saveUserInfoDTO 参数实体
     * @return
     */
    @RequestMapping(value = "/api/user/user/AddUserInfoList", method = RequestMethod.POST)
    String addUserInfoList(@RequestBody SaveUserInfoDTO saveUserInfoDTO);














}
