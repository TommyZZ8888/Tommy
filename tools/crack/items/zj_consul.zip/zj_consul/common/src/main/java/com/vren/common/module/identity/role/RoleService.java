package com.vren.common.module.identity.role;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.identity.role.domain.dto.GetRoleModuleListDTO;
import com.vren.common.module.identity.role.domain.entity.ModuleListEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName:RoleService
 * @Author: vren
 * @Date: 2022/7/19 16:34
 */
@Service
public class RoleService {

    @Autowired
    private RoleFeign roleFeign;

    public List<ModuleListEntity> getRoleLinkModuleList(String roleId) {
        GetRoleModuleListDTO dto = new GetRoleModuleListDTO();
        dto.setKeyId(roleId);
        String result = roleFeign.getRoleLinkModuleList(dto);
        ResponseResult<List<ModuleListEntity>> responseResult = JSON.parseObject(result, new TypeReference<>() {
        });
        return responseResult.getData();
    }
}
