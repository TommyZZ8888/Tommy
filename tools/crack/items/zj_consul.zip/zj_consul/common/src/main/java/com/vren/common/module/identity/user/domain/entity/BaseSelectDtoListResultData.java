package com.vren.common.module.identity.user.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class BaseSelectDtoListResultData {
    @ApiModelProperty("id")
    private String keyId;

    @ApiModelProperty("名称")
    private String value;

}
