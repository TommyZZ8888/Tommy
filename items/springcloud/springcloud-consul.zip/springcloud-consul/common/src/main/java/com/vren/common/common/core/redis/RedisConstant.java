package com.vren.common.common.core.redis;

public class RedisConstant {

    public final static String ALL_USER_LIST = "GetAllUsersList";
}
