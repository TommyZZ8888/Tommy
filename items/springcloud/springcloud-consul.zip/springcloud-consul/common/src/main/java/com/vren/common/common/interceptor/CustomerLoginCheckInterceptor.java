package com.vren.common.common.interceptor;

public interface CustomerLoginCheckInterceptor {
    void interceptor();
}
