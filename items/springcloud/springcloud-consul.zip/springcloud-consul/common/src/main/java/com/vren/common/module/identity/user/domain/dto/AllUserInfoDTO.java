package com.vren.common.module.identity.user.domain.dto;


import lombok.Data;


@Data
public class AllUserInfoDTO {



    private Integer pageIndex = 1;

    private Integer pageSize = 9999;


}
