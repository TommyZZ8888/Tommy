package com.vren.test.module.test.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface Test3Mapper {

}
