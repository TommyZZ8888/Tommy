package com.vren.test.module.test.mapper;

import com.vren.test.module.test.domain.entity.TestEntity;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface Test2Mapper {

}
