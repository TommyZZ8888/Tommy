package com.vren.test.module.test.domain.entity;


import lombok.Data;

@Data
public class Test3Entity {

    private String test3Id;

    private String testId;

    private String test3Name;
}
