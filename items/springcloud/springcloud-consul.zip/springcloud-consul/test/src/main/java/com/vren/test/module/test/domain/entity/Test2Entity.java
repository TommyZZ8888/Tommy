package com.vren.test.module.test.domain.entity;


import lombok.Data;

@Data
public class Test2Entity {

    private String test2Id;

    private String userId;

    private String name;
}
