package com.vren.common.module.project;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.dto.ProjectQueryDTO;
import com.vren.common.module.project.domain.entity.Project;
import com.vren.common.module.project.domain.entity.ProjectOutlineVO;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProjectService {


    @Autowired
    private ProjectFeign projectFeign;

    public List<ProjectOutlineVO> getOutline() {
        ResponseResult<List<ProjectOutlineVO>> result = projectFeign.getOutline();
        return result.getData();
    }

    public List<ProjectViewVO> queryDataList(ProjectDemandQueryDTO dto) {
        ResponseResult<List<ProjectViewVO>> result = projectFeign.getDataList(dto);
        return result.getData();
    }


    public ProjectVO getById(String id) {
        return projectFeign.getById(id).getData();
    }

    public Map<String, Project> getProjectDataMap() {
        ResponseResult<Map<String, Project>> result = projectFeign.getProjectDataMap(new ProjectQueryDTO());
        return result.getData();
    }

    public Map<String, Project> getProjectDataMapBySearch(ProjectQueryDTO dto) {
        ResponseResult<Map<String, Project>> result = projectFeign.getProjectDataMap(dto);
        return result.getData();
    }

    public Project getByName(String name) {
        return projectFeign.getProjectByName(name).getData();
    }
}
