package com.vren.common.module.material.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductByProjectIdVO {

    @ApiModelProperty("项目id")
    private String projectId;

}
