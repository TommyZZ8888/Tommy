package com.vren.common.module.process.process.domain.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName:GetProductDetailDTO
 * @Author: vren
 * @Date: 2022/8/17 10:01
 */
@NoArgsConstructor
@Data
public class GetProductDetailDTO {

    @JSONField(name = "token_UserId")
    private String tokenUserid;
    @JSONField(name = "token_UserName")
    private String tokenUsername;
    @JSONField(name = "token_ClientId")
    private String tokenClientid;
    @JSONField(name = "keyId")
    private String keyId;
}
