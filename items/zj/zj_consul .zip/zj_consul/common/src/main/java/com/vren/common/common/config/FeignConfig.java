package com.vren.common.common.config;

import com.vren.common.common.utils.InheritableThreadLocalHeader;
import com.vren.common.module.system.login.LoginServer;
import feign.Logger;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;

@Configuration
public class FeignConfig implements RequestInterceptor {

    @Value("${server.gatewayUrl}")
    private String gatewayUrl;

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }

    //转发header
    @Override
    public void apply(RequestTemplate requestTemplate) {
        try {
            String authorization = getAuthorization();
            if (authorization != null) {
                requestTemplate.header(LoginServer.AUTH_HEADER_KEY, authorization);
            }
            if (requestTemplate.feignTarget().url().equals(String.format("http://%s", requestTemplate.feignTarget().name()))) {
                requestTemplate.target(gatewayUrl);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getAuthorization() {
        HashMap<String, String> headers = InheritableThreadLocalHeader.get();
        String result = null;
        for (String key : headers.keySet()) {
            if (key.equalsIgnoreCase(LoginServer.AUTH_HEADER_KEY)) {
                result = headers.get(key);
                break;
            }
        }
        return result;
    }
}
