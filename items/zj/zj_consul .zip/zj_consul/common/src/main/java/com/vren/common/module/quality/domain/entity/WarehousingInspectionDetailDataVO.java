package com.vren.common.module.quality.domain.entity;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class WarehousingInspectionDetailDataVO {

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("入库编号")
    private String storageNo;
    @ConversionNumber
    @ApiModelProperty("实际入库数量")
    private Long actualStockAmount;

    @ConversionNumber
    @ApiModelProperty("实际入库重量")
    private Long actualStockWeight;
}
