package com.vren.common.module.device.device;

import com.vren.common.module.device.device.domain.dto.GetStationInfoByDeviceIdDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient("DeviceApi")
public interface DeviceFeign {

    @RequestMapping(value = "/api/device/Device/GetStationInfoByDeviceId", method = RequestMethod.POST)
    String getStationInfoByDeviceId(GetStationInfoByDeviceIdDTO dto);

    @RequestMapping(value = "/api/device/Device/GetStationListInfo", method = RequestMethod.POST)
    String getStationListInfo();

    @RequestMapping(value = "/api/device/Device/GetDeviceDropList", method = RequestMethod.POST)
    String getDeviceDropList();
}
