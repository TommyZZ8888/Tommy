package com.vren.common.module.project.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectQueryDTO extends PageParam {
    @ApiModelProperty("项目名称")
    private String projectName;
}
