package com.vren.common.module.process.process.domain.entity;

import com.vren.common.common.anno.ConversionNumber;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName:MaterialConsumEntity
 * @Description:
 * @Author: vren
 * @Date: 2021/12/27 9:36
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MaterialConsumEntity {

    private String name;

    private String brand;

    private String size;

    @ConversionNumber
    private int qty;

    private String type;

}
