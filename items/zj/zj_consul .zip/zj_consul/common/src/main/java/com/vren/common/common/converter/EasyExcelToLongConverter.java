package com.vren.common.common.converter;

import com.alibaba.excel.converters.Converter;
import com.alibaba.excel.converters.WriteConverterContext;
import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.GlobalConfiguration;
import com.alibaba.excel.metadata.data.ReadCellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.metadata.property.ExcelContentProperty;
import com.vren.common.common.anno.ConversionNumber;

import java.math.BigDecimal;

/**
 * @ClassName:EasyExcelToIntConverter
 * @Description:
 * @Author: vren
 * @Date: 2022/6/14 9:59
 * 导入时用
 */
public class EasyExcelToLongConverter implements Converter<Long> {
    @Override
    public Class<Long> supportJavaTypeKey() {
        return Long.class;
    }

    @Override
    public CellDataTypeEnum supportExcelTypeKey() {
        return CellDataTypeEnum.NUMBER;
    }

    @Override
    public Long convertToJavaData(ReadCellData cellData, ExcelContentProperty contentProperty, GlobalConfiguration globalConfiguration) {
        ConversionNumber annotation = contentProperty.getField().getAnnotation(ConversionNumber.class);
        if (cellData.getNumberValue() == null) {
            return null;
        }
        if (annotation == null) {
            return cellData.getNumberValue().longValue();
        }
        double parseDouble = cellData.getNumberValue().doubleValue() * annotation.value();
        return new Double(parseDouble).longValue();
    }

    @Override
    public WriteCellData<?> convertToExcelData(WriteConverterContext<Long> context) throws Exception {
        ConversionNumber annotation = context.getContentProperty().getField().getAnnotation(ConversionNumber.class);
        if (context.getValue()==null){
            return null;
        }
        WriteCellData<?> cellData = new WriteCellData<>(BigDecimal.valueOf(context.getValue()));
        if (annotation==null){
            return cellData;
        }
        double v = context.getValue().doubleValue() / annotation.value();
        return new WriteCellData<>(new BigDecimal(v));
    }


}
