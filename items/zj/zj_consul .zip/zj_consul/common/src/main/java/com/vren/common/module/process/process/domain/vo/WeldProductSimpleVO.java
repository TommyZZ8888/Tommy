package com.vren.common.module.process.process.domain.vo;

import lombok.Data;

/**
 * @ClassName:WeldProductSimpleVO
 * @Description:
 * @Author: vren
 * @Date: 2022/3/31 10:39
 */
@Data
public class WeldProductSimpleVO {

    private String lingHao;

    private String tuHao;

    private String productName;

    private String keyId;

    public void setLayerName(String layerName) {
        this.productName = layerName;
    }

}
