package com.vren.common.module.basedb.file;

import com.vren.common.module.basedb.file.domian.dto.DelAttachmentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @ClassName:FileManage
 * @Author: vren
 * @Date: 2022/7/19 9:50
 */
@FeignClient(value = "BaseDBApi")
public interface FileManageFeign {

    @RequestMapping(value = "/api/basedb/FileManage/DelAttachment", method = RequestMethod.POST)
    String delAttachment(DelAttachmentDTO dto);

}
