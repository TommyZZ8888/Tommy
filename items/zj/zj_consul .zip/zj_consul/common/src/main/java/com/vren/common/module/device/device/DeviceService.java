package com.vren.common.module.device.device;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.utils.FastJsonConversionNumber;
import com.vren.common.module.device.device.domain.dto.GetStationInfoByDeviceIdDTO;
import com.vren.common.module.device.device.domain.entity.DeviceData;
import com.vren.common.module.device.device.domain.entity.StationInfoEntity;
import com.vren.common.module.identity.user.domain.entity.UserInfoEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @ClassName:DeviceService
 * @Author: vren
 * @Date: 2022/7/26 15:38
 */
@Service
public class DeviceService {

    @Autowired
    private DeviceFeign deviceFeign;


    public StationInfoEntity getStationInfoByDeviceId(String keyId) {
        GetStationInfoByDeviceIdDTO dto = new GetStationInfoByDeviceIdDTO();
        dto.setKeyId(keyId);
        String info = deviceFeign.getStationInfoByDeviceId(dto);
        return FastJsonConversionNumber.parseObject(info, StationInfoEntity.class,"data");
    }

    public List<StationInfoEntity> getStationListInfo() {
        String info = deviceFeign.getStationListInfo();
        return FastJsonConversionNumber.parseObject2List(info, StationInfoEntity.class, "data");
    }
    public List<DeviceData> getDeviceDropList() {
        String info = deviceFeign.getDeviceDropList();
        ResponseResult<List<DeviceData>> responseResult = JSONObject.parseObject(info, new TypeReference<>() {
        });
        return responseResult.getData();
    }
}
