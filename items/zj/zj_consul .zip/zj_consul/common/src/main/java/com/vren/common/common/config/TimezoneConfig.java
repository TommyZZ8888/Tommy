//package com.vren.common.common.config;
//
//import org.springframework.context.annotation.Configuration;
//
//import javax.annotation.PostConstruct;
//import java.util.TimeZone;
//
///**
// * @author GR
// * time 2023-05-08-16-49
// **/
//@Configuration
//public class TimezoneConfig {
//
//    @PostConstruct
//    public void init(){
//        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
//    }
//}
