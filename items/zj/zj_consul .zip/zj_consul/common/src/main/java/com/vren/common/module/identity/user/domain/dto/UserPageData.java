package com.vren.common.module.identity.user.domain.dto;

import com.vren.common.common.domain.PageParam;
import lombok.Data;

@Data
public class UserPageData extends PageParam {
}
