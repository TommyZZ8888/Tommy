package com.vren.common.module.product;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.product.domain.dto.BaseReceiveDto;
import com.vren.common.module.product.domain.dto.GetProductTaskListDTO;
import com.vren.common.module.product.domain.dto.GetProdutPlanProgressListDTO;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.product.domain.entity.BatchScheduleQTDtoListResultData;
import com.vren.common.module.product.domain.entity.FlowChartDto;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.HashMap;
import java.util.List;

/**
 * @author 耿让
 */
@FeignClient(value = "ProductApi", url = "${server.gatewayUrl}")
public interface ProductFeign {

    /**
     * 调用产品模块的创建生产计划的接口
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/product/Product/CreateProductPlan", method = RequestMethod.POST)
    ResponseResult<Boolean> createProductPlan(@RequestBody ProductPlanCreateDTO dto);

    /**
     * 获取工序数据
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/product/Product/GetProductToQT", method = RequestMethod.POST)
    BatchScheduleQTDtoListResultData getProductToQT(@RequestBody BaseReceiveDto dto);

    @RequestMapping(value = "/api/product/Product/GetProductTaskList", method = RequestMethod.POST)
    HashMap<String, Object> getProductTaskList(@RequestBody GetProductTaskListDTO dto);

    @RequestMapping(value = "/api/product/Product/GetProductProgressDetail", method = RequestMethod.POST)
    ResponseResult<FlowChartDto> getProductProgressDetail(@RequestBody BaseReceiveDto dto);

    /**
     * 根据项目id查询进度
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/productNoToken/GetProdutPlanProgressList", method = RequestMethod.POST)
    ResponseResult<List<ProdutPlanProgressList>> getProdutPlanProgressList(@RequestBody GetProdutPlanProgressListDTO dto);
}
