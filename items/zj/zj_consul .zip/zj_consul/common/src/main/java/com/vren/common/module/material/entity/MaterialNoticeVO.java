package com.vren.common.module.material.entity;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class MaterialNoticeVO {
    @ApiModelProperty("材料入库通知单表id")
    private String id;

    @ApiModelProperty("检验物资类型")
    private Integer inspectionMaterialType;

    @ApiModelProperty("名称")
    private String materialName;

    @ApiModelProperty("制造编号")
    private String manufacturingNo;

    @ApiModelProperty("炉批号")
    private String furnaceBatchNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("标记")
    private String sign;

    @ApiModelProperty("数量")
    private Long count;

    @ApiModelProperty("供货状态")
    private Integer supplyStatus;

    @ApiModelProperty("生产厂家")
    private String manufacturer;

    @ApiModelProperty("出厂日期")
    private Date productionDate;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("附件材料到货附件")
    private String attachmentPath;

    /*2023.4.3新加是否复检*/
    @ApiModelProperty("是否复检 0 不复检 1复检")
    private Integer isRecheck;

    @ApiModelProperty("相应有关联的一级入库数据集合")
    private List<MaterialFirstLevelStorageFeignVO> list;

    @ApiModelProperty("入库通知单编号")
    private String warehousingNoticeNo;

    @ApiModelProperty("库存类型")
    private String stockType;

    @ApiModelProperty("单位二")
    private String unitTwo;
}
