package com.vren.common.module.device.device.domain.dto;

import lombok.Data;

/**
 * @ClassName:GetStationInfoByDeviceIdDTO
 * @Author: vren
 * @Date: 2022/7/26 15:40
 */
@Data
public class GetStationInfoByDeviceIdDTO {

    private String keyId;

}
