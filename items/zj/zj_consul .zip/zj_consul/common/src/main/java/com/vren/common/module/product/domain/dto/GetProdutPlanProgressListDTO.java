package com.vren.common.module.product.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class GetProdutPlanProgressListDTO {

    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    @ApiModelProperty("项目id")
    private String keyId;
}
