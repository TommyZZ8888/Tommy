package com.vren.common.module.identity.user.domain.entity;

import lombok.Data;

@Data
public class UserInfo {
    private String keyId;

    private String chName;
}
