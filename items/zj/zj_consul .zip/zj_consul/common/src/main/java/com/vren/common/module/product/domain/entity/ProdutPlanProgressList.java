package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProdutPlanProgressList {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("产品id")
    private String projectKeyId;

    @ApiModelProperty("产品需求计划id")
    private String productDemandKeyId;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("计划编号")
    private String scheduleNo;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("总进度")
    private int totalProgress;

}
