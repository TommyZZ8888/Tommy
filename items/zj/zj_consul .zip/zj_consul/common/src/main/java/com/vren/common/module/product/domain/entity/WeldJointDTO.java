package com.vren.common.module.product.domain.entity;

import lombok.Data;

/**
 * @author GR
 * time 2023-07-20-09-48
 **/
@Data
public class WeldJointDTO {

    private String token_UserId;

    private String token_UserName;

    private String token_ClientId;

    private String keyId;

    private String processCardNo;

    private String weldPosition;

    private String jointType;

    private String pqrNo;

    private String qualification;

    private String baseMetal;

    private String baseMetalSpec;

    private String jointImage;

    private String weldProcess;

    private String requirement;

    private String preheatTemperature;

    private String interchannelTemperature;

    private String heatTreatment;

    private String gas;

    private String gasFlow;

    private String backGasFlow;

    private String remark;

    private Integer jointState;

    private String creator;

    private String createTime;

    private String weldProductId;


}
