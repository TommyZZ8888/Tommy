package com.vren.common.module.process.process.domain.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName:ProductDetailEntity
 * @Author: vren
 * @Date: 2022/8/17 9:58
 */
@NoArgsConstructor
@Data
public class ProductDetailEntity {
    @JSONField(name = "productCode")
    private String productCode;
    @JSONField(name = "productName")
    private String productName;
    @JSONField(name = "partCode")
    private String partCode;
    @JSONField(name = "partName")
    private String partName;
    @JSONField(name = "partMCode")
    private String partMCode;
    @JSONField(name = "procedureCode")
    private String procedureCode;
    @JSONField(name = "procedureName")
    private String procedureName;
    @JSONField(name = "stepName")
    private String stepName;
}
