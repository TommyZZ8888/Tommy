package com.vren.common.module.basedb.dictdata.domain.dto;


import lombok.Data;


@Data
public class DictDataSingleDTO {


    private String dicCode;

}
