package com.vren.common.module.material;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.material.dto.*;
import com.vren.common.module.material.entity.MaterialNoticeVO;
import com.vren.common.module.material.entity.ProductDemandPlanVO;
import com.vren.common.module.material.entity.ProductInformationVO;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MaterialService {
    @Autowired
    private MaterialFeign materialFeign;

   public List<MaterialNoticeVO> getMaterialStorageNoticeDetailList(){
       ResponseResult<List<MaterialNoticeVO>> result=materialFeign.getMaterialStorageNoticeDetailList();
       return result.getData();
   }



   public ProductInformationVO getProductInformationByName(String id, String productName,String manufacturingNumber){
       QueryProductDTO queryProductDTO = new QueryProductDTO();
       queryProductDTO.setId(id);
       queryProductDTO.setProductName(productName);
       queryProductDTO.setManufacturingNumber(manufacturingNumber);
       return materialFeign.getProductInformationByName(queryProductDTO).getData();
   }

    public ProductInformationVO getProductInformation(String id, String productName,String manufacturingNumber){
        QueryProductDTO queryProductDTO = new QueryProductDTO();
        queryProductDTO.setId(id);
        queryProductDTO.setProductName(productName);
        queryProductDTO.setManufacturingNumber(manufacturingNumber);
        return materialFeign.getProductInformation(queryProductDTO).getData();
    }

    public Boolean insertMaterialStock(MaterialStockDTO dto) {
        return materialFeign.insertMaterialStock(dto).getData();
    }

    public Boolean insertMaterialStockForQuality(MaterialStockForQualityDTO dto) {
        return materialFeign.insertMaterialStockForQuality(dto).getData();
    }

    public MaterialStockDTO getMaterialStockById(MaterialFirstLevelStorageDTO dto) {
        return materialFeign.getMaterialStockById(dto).getData();
    }

    public boolean canDeleteProject(String id) {
        return materialFeign.canDeleteProject(id).getData();
    }

    public ProductDemandPlanVO getProductDemandPlanById(String id) {
        DeleteOrGetOneDTO build = DeleteOrGetOneDTO.builder().id(id).build();
        return materialFeign.getProductDemandPlanDetail(build).getData();
    }

    public String getProcess(List<ProdutPlanProgressList> productPlanProgressList) {
        return materialFeign.getProcess(productPlanProgressList).getData();
    }

    public boolean updateMaterialFirstLevelStorageById(String id, Long actualStockAmount) {
        return materialFeign.updateMaterialFirstLevelStorageById(id, actualStockAmount).getData();
    }

    public MaterialStockForQualityDTO getMaterialStockByIdForQuality(MaterialFirstLevelStorageDTO dto) {
        return materialFeign.getMaterialStockByIdForQuality(dto).getData();

    }
}
