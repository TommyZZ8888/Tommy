package com.vren.common.module.quality;

import com.vren.common.module.quality.domain.dto.ProductQualityDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author 耿让
 */
@Service
public class QualityService {

    @Autowired
    private QualityFeign qualityFeign;

    public Boolean insertProductQuality(ProductQualityDTO dto){
        return qualityFeign.insertProductQuality(dto).getData();
    }

    public boolean deleteProductQualityByProductDemand(String id){
        return qualityFeign.deleteProductQualityByProductDemand(id).getData();
    }


}
