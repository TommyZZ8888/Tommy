package com.vren.common.module.basedb.dictdata.domain.entity;


import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
public class DictDataEntity {

    @JSONField(name = "keyId")
    private String keyId;

    @JSONField(name = "dicCode")
    private String dicCode;

    @JSONField(name = "dicText")
    private String dicText;

    @JSONField(name = "desc")
    private String desc;

    @JSONField(name = "parentCode")
    private String parentCode;

    @JSONField(name = "subSystem")
    private String subSystem;
}
