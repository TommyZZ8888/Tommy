package com.vren.common.module.quality;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.quality.domain.dto.ProductQualityDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author 耿让
 */
@FeignClient(value = "quality")
public interface QualityFeign {


    /**
     * 新增产品质量质检记录
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/quality/productquality/insertProductQuality", method = RequestMethod.POST)
    ResponseResult<Boolean> insertProductQuality(@RequestBody ProductQualityDTO dto);
    //headers = {"content-type=application/json;charset=utf-8"}


    /**
     * 根据项目需求计划删除质检
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/api/quality/productquality/deleteProductQualityByProductDemand", method = RequestMethod.POST)
    ResponseResult<Boolean> deleteProductQualityByProductDemand(@RequestParam(value = "id") String id);

}
