package com.vren.common.module.project;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.dto.ProjectQueryDTO;
import com.vren.common.module.project.domain.entity.Project;
import com.vren.common.module.project.domain.entity.ProjectOutlineVO;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Map;

/**
 * @author 耿让
 */
@FeignClient(value = "project")
public interface ProjectFeign {


    /**
     * 调用project模块接口，查询项目基本信息，用于下拉框
     *
     * @return
     */
    @RequestMapping(value = "/api/project/project/getOutline", method = RequestMethod.POST)
    ResponseResult<List<ProjectOutlineVO>> getOutline();

    /**
     * 调用project模块接口，查询项目基本信息，用于主界面展示
     *
     * @author szp
     * @date 2022/10/9 11:20
     */
    @RequestMapping(value = "/api/project/project/getProjectData", method = RequestMethod.POST)
    ResponseResult<List<ProjectViewVO>> getDataList(@RequestBody ProjectDemandQueryDTO dto);

    /**
     * 根据id查询项目详情
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/api/project/project/getById", method = RequestMethod.POST)
    ResponseResult<ProjectVO> getById(@RequestParam(required = false, value = "id") @Valid @NotBlank(message = "ID不能为空") String id);

    /**
     * @author szp
     * @date 2023/4/23 9:52
     */
    @RequestMapping(value = "/api/project/project/getProjectDataMap", method = RequestMethod.POST)
    ResponseResult<Map<String, Project>> getProjectDataMap(@RequestBody ProjectQueryDTO dto);


    @RequestMapping(value = "/api/project/project/getByName", method = RequestMethod.POST)
    ResponseResult<Project> getProjectByName(@RequestParam(required = false, value = "name") @Valid @NotBlank(message = "name不能为空") String name);


}
