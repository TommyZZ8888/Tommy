package com.vren.common.module.quality.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductQualityDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("产品id")
    private String productId;
}
