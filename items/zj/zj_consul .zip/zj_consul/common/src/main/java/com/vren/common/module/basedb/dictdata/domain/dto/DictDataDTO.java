package com.vren.common.module.basedb.dictdata.domain.dto;


import com.alibaba.fastjson.annotation.JSONField;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;


@Data
public class DictDataDTO {



    private Integer pageIndex = 1;

    private Integer pageSize = 9999;

    private String parentCode;

}
