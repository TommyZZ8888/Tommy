package com.vren.common.module.material.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

/**
 * @Description MaterialStockForQualityDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/21
 */
@Data
public class MaterialStockForQualityDTO {


    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("设备表id")
    private String deviceId;

    @ApiModelProperty("物资退库表ID")
    private String materialReturnId;

    @ApiModelProperty("物资入库表ID")
    private String materialStorageId;

    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("物资类型:1板材、2型材（型材、管材、棒材）、3辅材（五金等）、4外购件、5锻材、6焊材、7油漆、8备品/备件、9余料")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    @NotBlank(message = "物资编号不能为空")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("重量")
    private Long weight;

    @ApiModelProperty("库存余量")
    private Long stockBalance;

    @ApiModelProperty("暂估入库数")
    private Integer estimatedStorageCount;

    @ApiModelProperty("预警值")
    private Integer warningStatus;

    @ApiModelProperty("单价")
    private Long univalence;

    @ApiModelProperty("执行标准（技术标准）")
    private String executiveStandards;

    @ApiModelProperty("规格")
    private String standards;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("面积")
    private Integer area;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("锁库数量")
    private Integer lockNumber;

    @ApiModelProperty("库存状态 1锁库、2未锁库")
    private Integer stockStatus;

    @ApiModelProperty("税前单价")
    private Long preTaxPrice;

    @ApiModelProperty("税额")
    private Long tax;

    @ApiModelProperty("入库时间")
    private Date stockInTime;

    @ApiModelProperty("实际入库数量")
    private Long actualReceiptQuantity;

    /*2023.3.28新增有效期字段 */

    @ApiModelProperty("有效期")
    private Date validityTerm;

    @ApiModelProperty("库存类型")
    private String stockType;

    @ApiModelProperty("单位二")
    private String unitTwo;

    @ApiModelProperty("第一尺寸")
    private Long firstSize;

    @ApiModelProperty("第二尺寸")
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    private Long thirdSize;

    @ApiModelProperty("含税单价")
    private Long unitPriceIncludingTax;

    @ApiModelProperty("含税总额")
    private Long totalAmountIncludingTax;

    @ApiModelProperty("税前总额")
    private Long totalAmountBeforeTax;

    @ApiModelProperty("数量")
    private Long count;
}
