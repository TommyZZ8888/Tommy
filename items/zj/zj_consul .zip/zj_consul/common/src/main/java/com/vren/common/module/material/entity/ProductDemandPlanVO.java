package com.vren.common.module.material.entity;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductDemandPlanVO {
    @ApiModelProperty("id")
    private String id;
    /**
     * 根据这个字段查询产品名称、项目名称、数量
     */
    @ApiModelProperty("产品信息表id")
    private String productInformationId;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("计划编号")
    private String scheduleNo;

    @ApiModelProperty("需求标书总价")
    @ConversionNumber
    private Long demandProposalTotal;

    @ApiModelProperty("编制人")
    private String compiler;

    @ApiModelProperty("校对人")
    private String proofreader;

    @ApiModelProperty("审核人")
    private String reviewer;

    @ApiModelProperty("批准人")
    private String checker;

    @ApiModelProperty("审核状态")
    private String reviewState;

    @ApiModelProperty("编制说明")
    private String preparationDescription;

    @ApiModelProperty("数量可编辑的范围")
    @ConversionNumber
    private Long count;

    @ApiModelProperty("总图号")
    private String totalFigureNo;
}
