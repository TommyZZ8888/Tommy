package com.vren.common.module.product;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.product.domain.dto.BaseReceiveDto;
import com.vren.common.module.product.domain.dto.GetProductTaskListDTO;
import com.vren.common.module.product.domain.dto.GetProdutPlanProgressListDTO;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.product.domain.entity.BatchScheduleQTDto;
import com.vren.common.module.product.domain.entity.FlowChartDto;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 耿让
 */
@Slf4j
@Service
public class ProductService {

    @Autowired
    private ProductFeign productFeign;

    /**
     * @param dto
     * @return
     */
    public ResponseResult<Boolean> createProductPlan(ProductPlanCreateDTO dto) {
        return productFeign.createProductPlan(dto);
    }

    public List<BatchScheduleQTDto> getProductToQT(String keyId) {
        BaseReceiveDto baseReceiveDto = new BaseReceiveDto();
        baseReceiveDto.setKeyId(keyId);
        return productFeign.getProductToQT(baseReceiveDto).getData();
    }

    public int getProductCount(String keyId) {
        GetProductTaskListDTO getProductTaskListDTO = new GetProductTaskListDTO();
        getProductTaskListDTO.setBatchId(keyId);
        getProductTaskListDTO.setPageIndex(1);
        getProductTaskListDTO.setPageSize(10);
        return (int) productFeign.getProductTaskList(getProductTaskListDTO).get("totalNumber");
    }

    public List<ProdutPlanProgressList> getProductPlanProgressList(String projectId) {
        GetProdutPlanProgressListDTO build = GetProdutPlanProgressListDTO.builder().keyId(projectId).build();
        return productFeign.getProdutPlanProgressList(build).getData();
    }

    public FlowChartDto getProductProgressDetail(String keyId) {
        BaseReceiveDto baseReceiveDto = new BaseReceiveDto();
        baseReceiveDto.setKeyId(keyId);
        return productFeign.getProductProgressDetail(baseReceiveDto).getData();
    }


}
