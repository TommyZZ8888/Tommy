package com.vren.common.module.identity.role.domain.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName:ModuleListEntity
 * @Author: vren
 * @Date: 2022/7/19 16:33
 */
@NoArgsConstructor
@Data
public class ModuleListEntity {

    @JSONField(name = "token_UserId")
    private String tokenUserId;
    @JSONField(name = "token_UserName")
    private String tokenUserName;
    @JSONField(name = "token_ClientId")
    private String tokenClientId;
    @JSONField(name = "keyId")
    private String keyId;
    @JSONField(name = "moduleCode")
    private String moduleCode;
    @JSONField(name = "moduleName")
    private String moduleName;
    @JSONField(name = "moduleUrl")
    private String moduleUrl;
    @JSONField(name = "mType")
    private Integer mType;
    @JSONField(name = "moduleSubType")
    private Integer moduleSubType;
    @JSONField(name = "desc")
    private String desc;
    @JSONField(name = "parentID")
    private String parentID;
    @JSONField(name = "seq")
    private Integer seq;
    @JSONField(name = "isShow")
    private Integer isShow;
    @JSONField(name = "icon")
    private String icon;
    @JSONField(name = "color")
    private String color;
}
