package com.vren.common.common.controller;

import lombok.extern.slf4j.Slf4j;

/**
 * @ClassName:BaseController
 * @Description:
 * @Author: vren
 * @Date: 2022/4/15 14:05
 */
@Slf4j
public class BaseController {
}
