package com.vren.common.module.material.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class ProjectIdDTO {

    @ApiModelProperty("项目id")
    private String projectId;
}
