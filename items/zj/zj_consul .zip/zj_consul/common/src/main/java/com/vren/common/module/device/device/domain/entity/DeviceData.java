package com.vren.common.module.device.device.domain.entity;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class DeviceData {
    @JSONField(name = "keyId")
    private String keyId;
    @JSONField(name = "value")
    private String value;
    @JSONField(name = "spotType")
    private String spotType;
    @JSONField(name = "deviceName")
    private String deviceName;
    @JSONField(name = "deviceState")
    private String deviceState;
}
