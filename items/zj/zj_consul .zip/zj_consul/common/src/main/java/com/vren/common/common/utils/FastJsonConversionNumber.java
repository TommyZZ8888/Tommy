package com.vren.common.common.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import com.vren.common.common.anno.ConversionNumber;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName:FastJsonConversionNumber
 * @Description:
 * @Author: vren
 * @Date: 2022/5/25 10:48
 */
public class FastJsonConversionNumber {


    public static <T> List<T> parseObject2List(String data, Class<T> clazz, String field) {
        JSONObject jsonObject = JSON.parseObject(data);
        if (jsonObject == null) return null;
        JSONArray jsonArray = jsonObject.getJSONArray(field);
        return parseArray(jsonArray, clazz);
    }

    public static <T> T parseObject(String data, Class<T> clazz, String field) {
        JSONObject jsonObject = JSON.parseObject(data);
        if (jsonObject == null) return null;
        String text = jsonObject.getString(field);
        return parseObject(text, clazz);
    }

    public static <T> T parseObject(String data, Class<T> clazz) {
        JSONObject tempObject = JSONObject.parseObject(data);
        Field[] fields = clazz.getDeclaredFields();
        T result = tempObject.toJavaObject(clazz);
        for (Field field : fields) {
            ConversionNumber conversionNumber = field.getAnnotation(ConversionNumber.class);
            JSONField jsonField = field.getAnnotation(JSONField.class);
            if (conversionNumber != null) {
                field.setAccessible(true);
                try {
                    double v;
                    if (jsonField != null) {
                        v = tempObject.getDouble(jsonField.name()) * conversionNumber.value();
                    } else {
                        v = tempObject.getDouble(field.getName()) * conversionNumber.value();
                    }
                    field.set(result, Double.valueOf(v).longValue());
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
        }
        return result;

    }


    public static <T> List<T> parseArray(JSONArray jsonArray, Class<T> clazz) {
        List<T> responseResult = new ArrayList<>();
        jsonArray.forEach(object -> {

            T result = parseObject(JSON.toJSONString(object), clazz);
            responseResult.add(result);
        });
        return responseResult;
    }
}
