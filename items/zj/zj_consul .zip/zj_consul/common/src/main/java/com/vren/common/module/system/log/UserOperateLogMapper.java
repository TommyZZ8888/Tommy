package com.vren.common.module.system.log;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.common.module.system.log.domin.entity.UserOperateLogEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface UserOperateLogMapper extends MPJBaseMapper<UserOperateLogEntity> {

    @Update("truncate table user_operate_log")
    void clearOperateLogTable();

}