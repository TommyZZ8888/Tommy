package com.vren.common.common.utils;

import org.apache.commons.lang.StringUtils;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 耿让
 */
public class PartNoSortUtil {

    /**
     * 件号最长格式 1-1-1
     */
    private static final int MAX_LENGTH = 3;

    private static final String REX = "[0-9]";

    public static <T> void sort(List<T> t) {
        t.sort((o1, o2) -> {
            try {
                Method getPartNo1 = o1.getClass().getMethod("getPartNo", null);
                getPartNo1.setAccessible(true);
                String p1 = getPartNo1.invoke(o1, (Object[]) null).toString();

                Method getPartNo2 = o2.getClass().getMethod("getPartNo", null);
                getPartNo2.setAccessible(true);
                String p2 = getPartNo2.invoke(o2, (Object[]) null).toString();
                //去除空格
                p1 = p1.trim();
                p2 = p2.trim();
                if (!checkPartNo(p1) && !checkPartNo(p2)) {
                    //第一处出现数字的地方
                    int str1 = findFirstIndexNumberOfStr(p1);
                    int str2 = findFirstIndexNumberOfStr(p2);
                    if (str1 == -1) {
                        return 1;
                    }
                    if (str2 == -1) {
                        return -1;
                    }
                    //数字前面的相等，比较数字
                    int i = p1.substring(0, str1).compareTo(p2.substring(0, str2));
                    if (i == 0) {
                        String s1 = p1.substring(str1);
                        String s2 = p2.substring(str1);
                        if (checkPartNo(s1) && checkPartNo(s2)) {
                            //件号全部属于数字格式的
                            //当前数字个数
                            return sortByNumber(s1, s2, MAX_LENGTH);
                        }
                        if (!checkPartNo(s1) && !checkPartNo(s2)) {
                            return s1.compareTo(s2);
                        }
                        if (!checkPartNo(s1)) {
                            return 1;
                        }
                        if (!checkPartNo(s2)) {
                            return -1;
                        }
                    } else {
                        return i;
                    }
                }
                if (!checkPartNo(p1)) {
                    return 1;
                }
                if (!checkPartNo(p2)) {
                    return -1;
                }
                if (checkPartNo(p1) && checkPartNo(p2)) {
                    return sortByNumber(p1, p2, MAX_LENGTH);
                }
                return 0;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return 0;
        });
    }

    public static int sortByNumber(String p1, String p2, int length) {
        String[] split1 = p1.split("-");
        String[] split2 = p2.split("-");
        //需要补0的格式
        int differentialValue1 = length - split1.length;
        int differentialValue2 = length - split2.length;
        int[] objects1 = Arrays.stream(split1).mapToInt(Integer::parseInt).toArray();
        int[] objects2 = Arrays.stream(split2).mapToInt(Integer::parseInt).toArray();
        int[] ints1;
        //补0
        if (differentialValue1 > 0) {
            int[] ints = new int[differentialValue1];
            ints1 = org.apache.commons.lang.ArrayUtils.addAll(objects1, ints);
        } else {
            ints1 = objects1;
        }
        int[] ints2;
        if (differentialValue2 > 0) {
            int[] ints = new int[differentialValue2];
            ints2 = org.apache.commons.lang.ArrayUtils.addAll(objects2, ints);
        } else {
            ints2 = objects2;
        }
        for (int i = 0; i < length; i++) {
            if (ints1[i] > ints2[i]) {
                return 1;
            } else if (ints1[i] < ints2[i]) {
                return -1;
            }
            //如果按一条件比较结果相等，就使用第二个条件进行比较。
        }
        return 0;
    }

    public static int findFirstIndexNumberOfStr(String str) {
        int i = -1;
        Matcher matcher = Pattern.compile(REX).matcher(str);
        if (matcher.find()) {
            i = matcher.start();
        }
        return i;
    }

    public static boolean checkPartNo(String partNo) {
        //件号规格校验
        char[] chars = partNo.toCharArray();
        if (!StringUtils.isNumeric(String.valueOf(chars[0])) || !StringUtils.isNumeric(String.valueOf(chars[chars.length - 1]))) {
            return false;
        }
        for (char c : chars) {
            if (!(StringUtils.isNumeric(String.valueOf(c)) || "-".equals(String.valueOf(c)))) {
                return false;
            }
        }
        return true;
    }


}
