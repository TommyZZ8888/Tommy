package com.vren.common.module.material.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Builder
public class DeleteOrGetOneDTO {

    @ApiModelProperty("产品需求计划id")
    private String id;
}
