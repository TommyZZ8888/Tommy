package com.vren.common.module.basedb.file.domian.dto;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.util.List;

/**
 * @ClassName:DelAttachmentDTO
 * @Author: vren
 * @Date: 2022/7/19 9:53
 */
@Data
public class DelAttachmentDTO {
    @JSONField(name = "token_UserId")
    private String tokenUserId;

    @JSONField(name = "token_UserName")
    private String tokenUserName;

    @JSONField(name = "token_ClientId")
    private String tokenClientId;

    private List<String> KeyIds;
}
