package com.vren.common.module.material;

import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.material.dto.*;
import com.vren.common.module.material.entity.MaterialNoticeVO;
import com.vren.common.module.material.entity.ProductDemandPlanVO;
import com.vren.common.module.material.entity.ProductInformationVO;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

@FeignClient(value = "material")
public interface MaterialFeign {

    @RequestMapping(value = "/api/material/storage/getMaterialStorageNoticeDetailList", method = RequestMethod.POST)
    ResponseResult<List<MaterialNoticeVO>> getMaterialStorageNoticeDetailList();


    /**
     * 根据产品id查询产品信息
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/material/productManagement/getProductInformationByName", method = RequestMethod.POST)
    ResponseResult<ProductInformationVO> getProductInformationByName(@RequestBody @Valid QueryProductDTO dto);


    /**
     * 根据产品需求计划id查询产品信息
     * ,headers = {"content-type=application/json;charset=utf-8"}
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/material/productDemandPlan/getProductInformationByName", method = RequestMethod.POST)
    ResponseResult<ProductInformationVO> getProductInformation(@RequestBody @Valid QueryProductDTO dto);


    @RequestMapping(value = "/api/material/stockmanagement/insertMaterialStock", method = RequestMethod.POST)
    ResponseResult<Boolean> insertMaterialStock(@RequestBody @Valid MaterialStockDTO dto);


    @RequestMapping(value = "/api/material/stockmanagement/insertMaterialStockForQuality", method = RequestMethod.POST)
    ResponseResult<Boolean> insertMaterialStockForQuality(@RequestBody @Valid MaterialStockForQualityDTO dto);


    @RequestMapping(value = "/api/material/storage/getMaterialStockById", method = RequestMethod.POST)
    ResponseResult<MaterialStockDTO> getMaterialStockById(@RequestBody @Valid MaterialFirstLevelStorageDTO dto);


    @RequestMapping(value = "/api/material/storage/getMaterialStockByIdForQuality", method = RequestMethod.POST)
    ResponseResult<MaterialStockForQualityDTO> getMaterialStockByIdForQuality(@RequestBody @Valid MaterialFirstLevelStorageDTO dto);

    /**
     * 根据项目id判断这个项目是否能够删除（项目下存在产品，则不能删除）
     * @param id
     * @return
     */
    @RequestMapping(value = "/api/material/productManagement/canDeleteProject", method = RequestMethod.POST)
    ResponseResult<Boolean> canDeleteProject(@RequestParam(value = "id") String id);


    /**
     * 根据id查询产品需求计划
     * @param dto
     * @return
     */
    @RequestMapping(value = "/api/material/productDemandPlan/getProductDemandPlanDetail", method = RequestMethod.POST)
    ResponseResult<ProductDemandPlanVO> getProductDemandPlanDetail(@RequestBody @Valid DeleteOrGetOneDTO dto);


    /**
     * 根据生产进度 计算 项目总进度
     * @param productPlanProgressList
     * @return
     */
    @RequestMapping(value = "/api/material/productDemandPlan/getProcess", method = RequestMethod.POST)
    ResponseResult<String> getProcess(@RequestBody List<ProdutPlanProgressList> productPlanProgressList);

    /**
     * 根据ID判断
     * @author szp
     * @date 2023/4/3 17:19
     */
    @RequestMapping(value = "/api/material/storage/updateMaterialFirstLevelStorageById", method = RequestMethod.POST)
    ResponseResult<Boolean> updateMaterialFirstLevelStorageById(@RequestParam(value = "id") String id, @RequestParam(value = "actualStockAmount") Long actualStockAmount);


}
