package com.vren.common.module.project.domain.dto;


import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectDemandQueryDTO extends PageParam {
    @ApiModelProperty("项目编号")
    private String projectNo;


    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目类型")
    private String projectType;

    @ApiModelProperty("客户名称")
    private String customerName;
}
