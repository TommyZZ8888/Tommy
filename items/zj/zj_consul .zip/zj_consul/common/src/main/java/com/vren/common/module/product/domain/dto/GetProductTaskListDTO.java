package com.vren.common.module.product.domain.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class GetProductTaskListDTO {

    @JsonProperty("pageIndex")
    private Integer pageIndex;
    @JsonProperty("pageSize")
    private Integer pageSize;
    @JsonProperty("planKeyId")
    private String planKeyId;
    @JsonProperty("batchId")
    private String batchId;
    @JsonProperty("flowChartId")
    private String flowChartId;
}
