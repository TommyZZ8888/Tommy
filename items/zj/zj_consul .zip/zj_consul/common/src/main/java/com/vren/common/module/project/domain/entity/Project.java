package com.vren.common.module.project.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 耿让
 */
@ApiModel
@Data
public class Project implements Serializable {

    @ApiModelProperty("不属于数据库字段，查询项目总数")
    @TableField(exist = false)
    private String count;

    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    /**
     *项目编号
     */
    private String projectNo;

    /**
     * 项目名称
     */
    private String projectName;

    /**
     * 项目类型
     */
    private String projectType;

    /**
     * 项目子类型（预留字段)
     */
    private String projectSubtype;

    /**
     *  客户名称(建设单位)
     */
    private String customerName;

    /**
     * 客户联系人
     */
    private String customerContact;

    /**
     * 客户联系电话
     */
    private String customerPhone;

    /**
     * 承/发包模式
     */
    private String contractingMode;

    /**
     * 签约时间
     */
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date signingTime;

    /**
     * 合同额
     */
    @ConversionNumber
    private Long contractAmount;

    /**
     * 合同开工时间
     */
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date contractCommencementTime;

    /**
     * 合同竣工时间
     */
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date contractCompletionTime;

    /**
     * 预计完工时间
     */
    @JsonFormat(pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date estimatedCompletionTime;

    /**
     * 进度
     */
    private String progress;



    /**
     * 红、黄、绿（正常）
     */
    private Integer warningStatus;

    /**
     *备注
     */
    private String remarks;

    /**
     * 项目所在省
     */
    private Long province;

    /**
     * 项目所在市
     */
    private Long city;

    /**
     * 项目所在区
     */
    private Long area;

    @ApiModelProperty("关联附件路径")
    private String attachmentPath;

    @ApiModelProperty("付款比例")
    private String paymentProportion;

    @ApiModelProperty("合同签订时间")
    private Date contractSigningTime;


}
