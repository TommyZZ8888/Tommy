package com.vren.common.common.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.support.SFunction;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.module.process.process.domain.vo.WeldProductSimpleVO;
import org.apache.commons.lang.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @ClassName:SearchUtil
 * @Description:
 * @Author: vren
 * @Date: 2022/4/22 9:27
 */
public class SearchUtil {

    public static List<String> getProjectIdsBySearch(List<WeldProductSimpleVO> weldProductSimpleList, String projectName, String tuHao, String lingHao) {
        List<String> projectIds = null;
        if (!StringUtils.isBlank(projectName)
                || !StringUtils.isBlank(lingHao)
                || !StringUtils.isBlank(tuHao)) {
            projectIds = weldProductSimpleList.stream().filter(item -> (StringUtils.isBlank(projectName) || item.getProductName().contains(projectName))
                    && (StringUtils.isBlank(tuHao) || item.getTuHao().contains(tuHao))
                    && (StringUtils.isBlank(lingHao) || item.getLingHao().contains(lingHao))).map(WeldProductSimpleVO::getKeyId).collect(Collectors.toList());
        }
        return projectIds;
    }


    public static <T> void timeRangeSearch(MPJLambdaWrapper<T> wrapper, SFunction<T, ?> column, Date createStartTime, Date createEndTime) {
        if (createStartTime != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
            wrapper.ge(column, simpleDateFormat.format(createStartTime));
        }
        if (createEndTime != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd 23:59:59");
            wrapper.le(column, simpleDateFormat.format(createEndTime));
        }
    }

    public static <T> void timeRangeSearch(QueryWrapper<T> wrapper, String column, Date createStartTime, Date createEndTime) {
        if (createStartTime != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
            wrapper.ge(column, simpleDateFormat.format(createStartTime));
        }
        if (createEndTime != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd 23:59:59");
            wrapper.le(column, simpleDateFormat.format(createEndTime));
        }
    }
}
