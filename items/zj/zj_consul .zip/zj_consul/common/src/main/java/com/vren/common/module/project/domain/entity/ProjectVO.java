package com.vren.common.module.project.domain.entity;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 *
 * @author szp
 * @date 2022/9/14 15:46
 */
@Data
public class ProjectVO {
    @ApiModelProperty("id")
    private String id;
    /**
     *项目编号
     */
    @ApiModelProperty("项目编号")
    private String projectNo;

    /**
     * 项目名称
     */
    @ApiModelProperty("项目名称")
    private String projectName;

    /**
     * 项目类型
     */
    @ApiModelProperty("项目类型")
    private String projectType;

    /**
     * 项目子类型（预留字段)
     */
   /* @ApiModelProperty("")
    private String projectSubtype;*/

    /**
     *  客户名称(建设单位)
     */
    @ApiModelProperty("客户名称")
    private String customerName;


    /**
     * 项目所在省
     */
    @ApiModelProperty("项目所在省")
    private Long province;

    @ApiModelProperty("项目所在省名称")
    private String provinceText;

    /**
     * 项目所在市
     */
    @ApiModelProperty("项目所在市")
    private Long city;

    @ApiModelProperty("项目所在市名称")
    private String cityText;

    /**
     * 项目所在区
     */
    @ApiModelProperty("项目所在区")
    private Long area;

    @ApiModelProperty("项目所在区名称")
    private String areaText;


    /**
     * 合同额
     */
    @ApiModelProperty("合同额")
    @ConversionNumber
    private Long contractAmount;

    /**
     * 合同开工时间
     */
    @ApiModelProperty("合同开工时间")
    private Date contractCommencementTime;

    /**
     * 合同竣工时间
     */
    @ApiModelProperty("合同竣工时间")
    private Date contractCompletionTime;

    /**
     * 预计完工时间
     */
    @ApiModelProperty("预计完工时间")
    private Date estimatedCompletionTime;

    /**
     * 进度
     */
    @ApiModelProperty("进度")
    private String progress;

    /**
     * 红、黄、绿（正常）
     */
    @ApiModelProperty("预警状态")
    private Integer warningStatus;

    @ApiModelProperty("预警状态描述")
    private String warningStatusText;

    @ApiModelProperty("付款比例")
    private String paymentProportion;

    @ApiModelProperty("合同签订时间")
    private Date contractSigningTime;

}
