package com.vren.common.module.product.domain.entity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author GR
 * time 2023-07-20-09-24
 **/
@Data
public class ProcedureInfoDTO {

    private String keyId;

    @ApiModelProperty("卡片号")
    private String cardNo;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("文件地址")
    private String filePath;

    @ApiModelProperty("工序类型")
    private Integer procedureType;

    @ApiModelProperty("产品信息id")
    private String productInfoId;

    private List<ProcedureInfoDtlDto> listDtl;
}
