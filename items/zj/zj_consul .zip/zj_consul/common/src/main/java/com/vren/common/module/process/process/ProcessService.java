package com.vren.common.module.process.process;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.process.process.domain.dto.GetProductDetailDTO;
import com.vren.common.module.process.process.domain.entity.ProductDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @ClassName:ProcessService
 * @Description:
 * @Author: vren
 * @Date: 2021/12/27 9:08
 */
@Service
@Slf4j
public class ProcessService {

    @Autowired
    private ProcessFeign processFeign;


    public ProductDetailEntity getProductDetailByKeyId(String stepId) {
        GetProductDetailDTO getProductDetailDTO = new GetProductDetailDTO();
        getProductDetailDTO.setKeyId(stepId);
        String productDetailByKeyId = processFeign.getProductDetailByKeyId(getProductDetailDTO);
        ResponseResult<ProductDetailEntity> responseResult = JSONObject.parseObject(productDetailByKeyId, new TypeReference<>() {
        });
        return responseResult.getData();
    }
}
