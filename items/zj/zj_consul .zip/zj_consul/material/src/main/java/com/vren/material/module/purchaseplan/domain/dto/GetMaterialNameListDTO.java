package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description GetMaterialNameListDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/8
 */
@Data
public class GetMaterialNameListDTO {

    @ApiModelProperty("采购合同id")
    private String contractListId;

    @ApiModelProperty("物资类型")
    private Integer materialType;
}
