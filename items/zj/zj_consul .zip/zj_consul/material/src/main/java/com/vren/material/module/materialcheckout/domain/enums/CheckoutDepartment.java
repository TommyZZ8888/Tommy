package com.vren.material.module.materialcheckout.domain.enums;

public enum CheckoutDepartment {

    ZBXL("Material_Dept_ZBXL","准备车间-下料"),
    ZBJJ("Material_Dept_ZBJJ","准备车间-机加工"),
    ZBJY("Material_Dept_ZBJY","准备车间-卷圆"),
    ZBCP("Material_Dept_ZBCP","准备车间-成品"),
    MHCJ("Material_Dept_MHCJ","铆焊车间"),
    YZKA("Material_Dept_YZKA","扬州康安"),
    YX("Material_Dept_YX","永轩"),
    FEH("Material_Dept_FEH","穆尔瀚防腐");
    CheckoutDepartment(String code, String name){
        this.code = code;
        this.name = name;
    }
    public String getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private String code;
    private String  name;
}
