package com.vren.material.module.materialremain;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.EnumUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.module.materialremain.domain.dto.EditMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.GetMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.QueryOneDTO;
import com.vren.material.module.materialremain.domain.entity.RemainingMaterial;
import com.vren.material.module.materialremain.domain.vo.MaterialRemainVO;
import com.vren.material.module.materialrenturn.domain.dto.GenerateSpareRecordDTO;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.domain.vo.MaterialRemainData;
import com.vren.material.module.purchasecontract.PurchaseContractService;
import com.vren.material.module.purchasecontract.domain.entity.Supplier;
import com.vren.material.module.stockmanagement.MaterialStockMapper;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.stockmanagement.domian.enums.MaterialTypeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class MaterialRemainService {

    @Autowired
    private MaterialRemainMapper materialRemainMapper;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private MaterialStockMapper materialStockMapper;

    @Autowired
    private PurchaseContractService purchaseContractService;


    public void insertByRemainMaterialEntity(RemainingMaterial remainingMaterial) {
        materialRemainMapper.insert(remainingMaterial);
    }


    public void insert(GenerateSpareRecordDTO dto) {
        //根据物资类型生成余料编号
        String no = "";
        switch (EnumUtil.getEnumByCode(MaterialType.class, dto.getMaterialType())) {
            case BOARD:
                no = "BC";
                break;
            case PROFILE:
                no = "XC";
                break;
            case FORGE_PIECE:
                no = "DJ";
                break;
            case PURCHASED_PARTS:
                no = "WG";
                break;
            case AUXILIARY_MATERIALS:
                no = "FC";
                break;
            case WELDING_MATERIALS:
                no = "HC";
                break;
            case PAINT:
                no = "YQ";
                break;
            default:
                no = "BH";
                break;
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String remainingMaterialNo = "YL" + no + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000);
        //余料编号不能重复
        QueryWrapper<RemainingMaterial> wrapper = new QueryWrapper<>();
        wrapper.select("1")
                .eq("remaining_material_no", remainingMaterialNo)
                .last("limit 1");
        while (materialRemainMapper.selectCount(wrapper) > 0) {
            remainingMaterialNo = "YL" + format.format(System.currentTimeMillis()) + (new Random().nextInt(90000) + 10000);
        }
        RemainingMaterial remainingMaterial = BeanUtil.copy(dto, RemainingMaterial.class);
        remainingMaterial.setRemainingMaterialNo(remainingMaterialNo);
        remainingMaterial.setProjectName(projectService.getById(dto.getProjectId()).getProjectName());
        remainingMaterial.setMaterialStockId(dto.getMaterialStockId());
        materialRemainMapper.insert(remainingMaterial);
    }

    public PageResult<MaterialRemainVO> getMaterialRemain(GetMaterialRemainDTO dto) {
        Page<Object> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(RemainingMaterial.class)
                .like(!CommonUtil.isNull(dto.getRemainingMaterialName()), RemainingMaterial::getRemainingMaterialName, dto.getRemainingMaterialName())
                .like(!CommonUtil.isNull(dto.getRemainingMaterialNo()), RemainingMaterial::getRemainingMaterialNo, dto.getRemainingMaterialNo())
                .like(StringUtils.isNoneBlank(dto.getSpecification()), RemainingMaterial::getSpecification, dto.getSpecification())
                .like(StringUtils.isNoneBlank(dto.getTexture()), RemainingMaterial::getTexture, dto.getTexture())
                .like(CommonUtil.isNotNull(dto.getFirstSize()),RemainingMaterial::getFirstSize,dto.getFirstSize())
                .like(StringUtils.isNoneBlank(dto.getProjectName()), RemainingMaterial::getProjectName, dto.getProjectName())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), RemainingMaterial::getMaterialType, dto.getMaterialType())
                .eq(!CommonUtil.isNull(dto.getStockStatus()), RemainingMaterial::getStockStatus, dto.getStockStatus());
        IPage<MaterialRemainVO> materialRemainVOIPage = materialRemainMapper.selectJoinPage(page, MaterialRemainVO.class, wrapper);
        materialRemainVOIPage.getRecords().stream().forEach(item -> {
            //设置项目名称
            if (item.getProjectId() != null) {
                item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            }
            //设置库存状态
            if (item.getStockStatus() != null && item.getStockStatus().equals(1)) {
                item.setStockStatusText("锁库");
            } else {
                item.setStockStatusText("未锁库");
            }
            if (!CommonUtil.isNull(item.getMaterialType())) {
                item.setMaterialTypeText(EnumUtil.getValue(MaterialTypeEnum.class, item.getMaterialType()));
            }
            String materialStockId = item.getMaterialStockId();
            MaterialStock materialStock = materialStockMapper.selectById(materialStockId);
            if (CommonUtil.isNotNull(materialStock)){
                item.setMaterialNumber(materialStock.getMaterialNumber());
                item.setPreTaxPrice(materialStock.getPreTaxPrice());
                item.setTotalAmountIncludingTax(materialStock.getTax());
                item.setTotalAmountIncludingTax(materialStock.getTotalAmountIncludingTax());
                String supplierId = materialStock.getSupplierId();
                item.setExecutiveStandard(materialStock.getExecutiveStandards());
                Supplier supplier = purchaseContractService.selectSupplierEntityById(supplierId);
                item.setSupplierName(Optional.ofNullable(supplier).orElse(new Supplier()).getSupplierName());
            }
        });
        return PageUtil.convert2PageResult(materialRemainVOIPage);
    }

    public MaterialRemainVO getMaterialRemainById(QueryOneDTO dto) {
        RemainingMaterial remainingMaterial = materialRemainMapper.selectById(dto.getId());
        MaterialRemainVO materialRemainVO = BeanUtil.copy(remainingMaterial, MaterialRemainVO.class);
        //设置项目名称
        ProjectVO projectVO = projectService.getById(materialRemainVO.getProjectId());
        if (projectVO != null) {
            materialRemainVO.setProjectName(projectVO.getProjectName());
        }
        //设置库存状态
        if (materialRemainVO.getStockStatus() != null && materialRemainVO.getStockStatus().equals(1)) {
            materialRemainVO.setStockStatusText("锁库");
        } else {
            materialRemainVO.setStockStatusText("未锁库");
        }
        return materialRemainVO;
    }

    public void editMaterialRemain(EditMaterialRemainDTO dto) {
        RemainingMaterial remainingMaterial = BeanUtil.copy(dto, RemainingMaterial.class);
        materialRemainMapper.updateById(remainingMaterial);
    }

    public String getAttachment(QueryOneDTO dto) {
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(RemainingMaterial::getAttachmentPath)
                .eq(!CommonUtil.isNull(dto.getId()), RemainingMaterial::getId, dto.getId());
        RemainingMaterial remainingMaterial = materialRemainMapper.selectOne(wrapper);
        return remainingMaterial.getAttachmentPath();
    }

    /**
     * 根据物资名称、材质和规格模糊查询 符合条件的余料
     * @param materialName
     * @param texture
     * @param specification
     * @return
     */
    public List<MaterialRemainData> getByNameAndSpecification(String materialName, String texture, String specification) {
        MPJLambdaWrapper<RemainingMaterial> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(RemainingMaterial.class)
                .like(!CommonUtil.isNull(materialName), RemainingMaterial::getRemainingMaterialName, materialName)
                .or()
                .like(!CommonUtil.isNull(texture), RemainingMaterial::getTexture, texture)
                .or()
                .like(!CommonUtil.isNull(specification), RemainingMaterial::getSpecification, specification);
        List<RemainingMaterial> remainingMaterials = materialRemainMapper.selectList(wrapper);
        return BeanUtil.copyList(remainingMaterials, MaterialRemainData.class);
    }

    /**
     * 更新余料数量，修改库存状态
     * @param materialStockId
     * @param lockStockNumber
     */
    public void updateStockAndLockNumber(String materialStockId, Long lockStockNumber) {
        UpdateWrapper<RemainingMaterial> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(materialStockId), "id", materialStockId)
                .setSql(!CommonUtil.isNull(lockStockNumber), "remaining_material_count = remaining_material_count - " + lockStockNumber)
                .setSql(!CommonUtil.isNull(lockStockNumber), "lock_number = lock_number + " + lockStockNumber)
                .set("stock_status", "2");
        materialRemainMapper.update(new RemainingMaterial(), wrapper);
    }
}
