package com.vren.material.module.materialcheckout.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialCheckoutDataDTO {
    @NotBlank(message = "项目id不能为空")
    @ApiModelProperty("项目id")
    private String projectId;
    @NotBlank(message = "物资编号不能为空")
    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("是否扫码入库")
    private Boolean isScan;
}