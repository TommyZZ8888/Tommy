package com.vren.material.module.projectdemandplan.domain.dto;

import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

@Data
public class BatchInsertOrUpdateWeldingMaterialDemandPlanDTO {
    @Size(min=1,message = "数量不能小于0")
    private List<WeldingMaterialDemandPlanDTO> list;
}
