package com.vren.material.module.purchasecontract.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class SupplierListDTO extends PageParam {

    @ApiModelProperty("分供方名称")
    private String supplierName;

    @ApiModelProperty("分供方编号")
    private String supplierNumber;

    @ApiModelProperty("联系人")
    private String contacts;

    @ApiModelProperty("企业地址")
    private String businessAddress;

}
