package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProjectIdAndNameVO {

    @ApiModelProperty("采购计划id")
    private String purchasePlanId;

    @ApiModelProperty("项目名称")
    private String projectNameAndBatch;

    @ApiModelProperty("合同id")
    private String contractListId;

    @ApiModelProperty("合同编号")
    private String contractListNo;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("供应商信息")
    private SupplierSelectVO supplierSelectVO;
}
