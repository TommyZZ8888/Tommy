package com.vren.material.module.materialcheckout.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialCheckoutRecordDeleteDTO {
    @ApiModelProperty("出库记录表id")
    private String id;
}
