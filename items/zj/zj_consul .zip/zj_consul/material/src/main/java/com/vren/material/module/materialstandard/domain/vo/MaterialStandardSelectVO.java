package com.vren.material.module.materialstandard.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-10-11-18
 **/
@Data
public class MaterialStandardSelectVO {

    @ApiModelProperty("执行标准")
    private String enforceStandards;

}
