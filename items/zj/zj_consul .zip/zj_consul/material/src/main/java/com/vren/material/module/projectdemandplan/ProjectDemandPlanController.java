package com.vren.material.module.projectdemandplan;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.material.module.productdemandplan.domain.dto.EditTimeAndLocationDTO;
import com.vren.material.module.projectdemandplan.domain.dto.*;
import com.vren.material.module.projectdemandplan.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@RestController
@RequestMapping("/projectdemandplan")
@Api(tags = {"项目需求计划"})
@OperateLog
public class ProjectDemandPlanController {

    @Autowired
    private ProjectDemandPlanService projectDemandPlanService;

    @RequestMapping(value = "/getProjectDataList", method = RequestMethod.POST)
    @ApiOperation("主界面展示及相应的项目需求计划")
    public ResponseResult<PageResult<ProjectDataVO>> getDataList(@RequestBody ProjectDemandQueryDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getDataList(dto));
    }

    @RequestMapping(value = "/getProjectName", method = RequestMethod.POST)
    @ApiOperation("获取项目名称下拉框")
    public ResponseResult<List<ProjectNameDataVO>> getProjectName(@RequestBody @Valid ProjectDemandQueryDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getProjectName(dto));
    }

    @RequestMapping(value = "/getDemandType", method = RequestMethod.POST)
    @ApiOperation("获取需求类型下拉框")
    public ResponseResult<List<DemandTypeVO>> getDemandType() {
        List<DemandTypeVO> list = projectDemandPlanService.getDemandType();
        return ResponseResult.success("获取成功", list);
    }

    @RequestMapping(value = "/addOrEditProjectDemandPlan", method = RequestMethod.POST)
    @ApiOperation("新增或修改项目需求计划")
    public ResponseResult<Boolean> addOrEditProjectDemandPlan(@RequestBody @Valid ProjectDemandPlanUpdateDTO dto) {
        projectDemandPlanService.addOrEditProjectDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/deleteProjectDemandPlanById", method = RequestMethod.POST)
    @ApiOperation("删除项目需求计划")
    public ResponseResult<Boolean> deleteProjectDemandPlan(@RequestBody @Valid ProjectDemandPlanDeleteDTO dto) {
        projectDemandPlanService.deleteProjectDemandPlan(dto);
        return ResponseResult.success("删除成功");
    }

    @RequestMapping(value = "/deleteOneProjectDemandPlanById", method = RequestMethod.POST)
    @ApiOperation("删除单个项目需求计划")
    public ResponseResult<Boolean> deleteOneProjectDemandPlan(@RequestBody @Valid ProjectDemandPlanDeleteOneDTO dto) {
        projectDemandPlanService.deleteOneProjectDemandPlan(dto);
        return ResponseResult.success("删除成功");
    }

    @RequestMapping(value = "/getMaterialType", method = RequestMethod.POST)
    @ApiOperation("获取物资类型下拉框")
    public ResponseResult<List<MaterialTypeVO>> getMaterialType() {
        List<MaterialTypeVO> list = projectDemandPlanService.getMaterialType();
        return ResponseResult.success("获取成功", list);
    }

    @RequestMapping(value = "/generateProjectDemandPlan", method = RequestMethod.POST)
    @ApiOperation("生成项目需求计划")
    public ResponseResult<Boolean> generateProjectDemandPlan(@RequestBody ProjectGenerateDemandQueryDTO dto) {
        projectDemandPlanService.generateProjectDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/generateBlankProjectDemandPlan", method = RequestMethod.POST)
    @ApiOperation("生成空项目需求计划")
    public ResponseResult<Boolean> generateBlankProjectDemandPlan(@RequestBody ProjectGenerateDemandQueryDTO dto) {
        projectDemandPlanService.generateBlankProjectDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialTypeDescriptionList", method = RequestMethod.POST)
    @ApiOperation("获得材料说明")
    public ResponseResult<List<MaterialTypeDescriptionViewVO>> generateProjectDemandPlan(@RequestBody MaterialTypeQueryDTO dto) {
        return ResponseResult.success("获得成功", projectDemandPlanService.getMaterialEntityViewVOList(dto));
    }

    @RequestMapping(value = "/editMaterialType", method = RequestMethod.POST)
    @ApiOperation("修改材料说明")
    public ResponseResult<Boolean> editMaterialType(@RequestBody @Valid MaterialTypeEditDTO dto) {
        projectDemandPlanService.editMaterialType(dto);
        return ResponseResult.success("修改成功");
    }

    //***************************************************子界面***********************************************************************
    @Autowired
    private ImportService importService;

    @ApiOperation("产品汇总excel导入")
    @RequestMapping(value = "/productDemandPlanTotalUpload", method = RequestMethod.POST)
    public ResponseResult<Boolean> upload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        importService.productTotalImport(file, dto);
        return ResponseResult.success("导入成功");
    }


    @ApiOperation("焊材excel导入")
    @RequestMapping(value = "/productDemandPlanWeldingMaterialsUpload", method = RequestMethod.POST)
    public ResponseResult<Boolean> weldingMaterialsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        projectDemandPlanService.weldingMaterialsUpload(file, dto);
        return ResponseResult.success("导入成功");
    }

    @ApiOperation("油漆excel导入")
    @RequestMapping(value = "/productDemandPlanPaintUpload", method = RequestMethod.POST)
    public ResponseResult<Boolean> paintUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        projectDemandPlanService.paintUpload(file, dto);
        return ResponseResult.success("导入成功");
    }

    /************************************************************************************************************************************************/
    @ApiOperation("产品汇总excel导出")
    @RequestMapping(value = "/productDemandPlanTotalExport", method = RequestMethod.POST)
    public void export(HttpServletResponse response, @RequestBody @Valid ProductDemandPlanTotalImportDTO dto) {
        projectDemandPlanService.export(response, dto);

    }


    @RequestMapping(value = "/addPaintDemandPlan", method = RequestMethod.POST)
    @ApiOperation("(子界面)批量新增油漆需求计划")
    public ResponseResult<Boolean> addPaintDemandPlan(@RequestBody @Valid BatchInsertOrUpdatePaintDemandPlanDTO dto) {
        projectDemandPlanService.addPaintDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/addWeldingMaterialDemandPlan", method = RequestMethod.POST)
    @ApiOperation("(子界面)批量新增焊材需求计划")
    public ResponseResult<Boolean> addWeldingMaterialDemandPlan(@RequestBody @Valid BatchInsertOrUpdateWeldingMaterialDemandPlanDTO dto) {
        projectDemandPlanService.addWeldingMaterialDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/getProductDemandPlanTotalList", method = RequestMethod.POST)
    @ApiOperation("获取(子界面五大类)材料汇总数据")
    public ResponseResult<PageResult<ProductTotalVO>> getProductDataList(@RequestBody @Valid ProductDemandPlanTotalQueryDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getProductDataList(dto));
    }


    @RequestMapping(value = "/getWeldingDemandPlanList", method = RequestMethod.POST)
    @ApiOperation("获取(子界面)焊材数据")
    public ResponseResult<PageResult<WeldingMaterialsVO>> getWeldingDemandPlanList(@RequestBody @Valid WeldingMaterialDemandQueryPlanDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getWeldingDemandPlanList(dto));
    }


    @RequestMapping(value = "/getPaintDemandPlanList", method = RequestMethod.POST)
    @ApiOperation("获取(子界面)油漆数据")
    public ResponseResult<PageResult<PaintVO>> getPaintDemandPlanList(@RequestBody @Valid PaintDemandPlanQueryDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getPaintDemandPlanList(dto));
    }


    @RequestMapping(value = "/getPaintDemandPlanVO", method = RequestMethod.POST)
    @ApiOperation("查看(子界面)油漆单条数据")
    public ResponseResult<PaintDemandPlanViewVO> getPaintDemandPlanVO(@RequestBody @Valid PaintDemandPlanQueryOneDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getPaintDemandPlanVO(dto));
    }

    @RequestMapping(value = "/getWeldingMaterialDemandPlanVO", method = RequestMethod.POST)
    @ApiOperation("查看(子界面)焊材单条数据")
    public ResponseResult<WeldingMaterialDemandPlanViewVO> getWeldingMaterialDemandPlanVO(@RequestBody @Valid WeldingMaterialDemandPlanQueryOneDTO dto) {
        return ResponseResult.success("获取成功", projectDemandPlanService.getWeldingMaterialDemandPlanVO(dto));
    }

    @RequestMapping(value = "/paintEditPaintTimeAndLocation", method = RequestMethod.POST)
    @ApiOperation("（子界面）油漆需求计划批量更新交货时间和交货地点")
    public ResponseResult<Boolean> paintEditTimeAndLocation(@RequestBody @Valid EditTimeAndLocationDTO dto) {
        projectDemandPlanService.paintEditTimeAndLocation(dto);
        return ResponseResult.success("操作成功", true);
    }

    @RequestMapping(value = "/weldingMaterialEditTimeAndLocation", method = RequestMethod.POST)
    @ApiOperation("（子界面）焊材需求计划批量更新交货时间和交货地点")
    public ResponseResult<Boolean> weldingMaterialEditTimeAndLocation(@RequestBody @Valid EditTimeAndLocationDTO dto) {
        projectDemandPlanService.weldingMaterialEditTimeAndLocation(dto);
        return ResponseResult.success("操作成功", true);
    }

    @RequestMapping(value = "/editWeldingMaterial", method = RequestMethod.POST)
    @ApiOperation("焊材需求计划(子界面)修改焊材数据")
    public ResponseResult<Boolean> editWeldingMaterial(@RequestBody @Valid WeldingMaterialUpdateDTO dto) {
        projectDemandPlanService.editWeldingMaterial(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/editPaint", method = RequestMethod.POST)
    @ApiOperation("油漆需求计划(子界面)修改油漆数据")
    public ResponseResult<Boolean> editPaint(@RequestBody @Valid PaintUpdateDTO dto) {
        projectDemandPlanService.editPaint(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/deleteProductDemandPlanTotalById", method = RequestMethod.POST)
    @ApiOperation("产品汇总(子界面)单个删除数据")
    public ResponseResult<Boolean> deleteProductDemandPlanTotal(@RequestBody @Valid ProductDemandPlanTotalDeleteDTO dto) {
        projectDemandPlanService.deleteProductDemandPlanTotal(dto);
        return ResponseResult.success("删除成功");
    }

    @RequestMapping(value = "/deletePaintDemandPlanById", method = RequestMethod.POST)
    @ApiOperation("油漆需求计划(子界面)单个删除数据")
    public ResponseResult<Boolean> deletePaintDemandPlan(@RequestBody @Valid PaintDemandPlanDeleteDTO dto) {
        projectDemandPlanService.deletePaintDemandPlan(dto);
        return ResponseResult.success("删除成功");
    }

    @RequestMapping(value = "/deleteWeldingMaterialDemandPlanById", method = RequestMethod.POST)
    @ApiOperation("焊材需求计划(子界面)单个删除数据")
    public ResponseResult<Boolean> deleteWeldingMaterialDemandPlan(@RequestBody @Valid WeldingMaterialDemandPlanDelteDTO dto) {
        projectDemandPlanService.deleteWeldingMaterialDemandPlan(dto);
        return ResponseResult.success("删除成功");
    }


    @ApiOperation("焊材excel导出")
    @RequestMapping(value = "/weldingExport", method = RequestMethod.POST)
    public void weldingExport(HttpServletResponse response, @RequestBody @Valid ProductDemandPlanTotalImportDTO dto) {
        projectDemandPlanService.weldingExport(response, dto);

    }

    @ApiOperation("油漆excel导出")
    @RequestMapping(value = "/paintExport", method = RequestMethod.POST)
    public void paintExport(HttpServletResponse response, @RequestBody @Valid ProductDemandPlanTotalImportDTO dto) {
        projectDemandPlanService.paintExport(response, dto);
    }


    /**
     * 锁库操作
     */
    @RequestMapping(value = "/getLockStockData", method = RequestMethod.POST)
    @ApiOperation("点击锁库按钮，匹配可以锁库的数据")
    public ResponseResult<List<LockStockData>> getLockStockData(@RequestBody @Valid QueryLockStockDataDTO dto) {
        return ResponseResult.success("操作成功", projectDemandPlanService.getLockStockData(dto));
    }


    @RequestMapping(value = "/lockStock", method = RequestMethod.POST)
    @ApiOperation("锁库")
    public ResponseResult<Boolean> lockStock(@RequestBody @Valid LockStockMoreDTO dto) {
        projectDemandPlanService.lockStock(dto);
        return ResponseResult.success("操作成功", true);
    }

    @RequestMapping(value = "/selectLockStock", method = RequestMethod.POST)
    @ApiOperation("查询锁库情况")
    public ResponseResult<List<LockStockVO>> getLockStock(@RequestBody @Valid QueryLockStockDTO dto) {
        return ResponseResult.success("操作成功", projectDemandPlanService.getLockStock(dto));
    }

    /**
     * 锁余料操作
     */
    @RequestMapping(value = "/getMaterialRemainData", method = RequestMethod.POST)
    @ApiOperation("点击锁余料按钮，匹配可以锁余料的数据")
    public ResponseResult<List<MaterialRemainData>> getMaterialRemainData(@RequestBody @Valid QueryMaterialRemainDataDTO dto) {
        return ResponseResult.success("操作成功", projectDemandPlanService.getMaterialRemainData(dto));
    }

    @RequestMapping(value = "/lockRemain", method = RequestMethod.POST)
    @ApiOperation("锁余料")
    public ResponseResult<Boolean> lockRemain(@RequestBody @Valid LockRemainMoreDTO dto) {
        projectDemandPlanService.lockRemain(dto);
        return ResponseResult.success("操作成功", true);
    }

    @ApiOperation("项目需求计划excel导出")
    @RequestMapping(value = "/projectDemandPlanExport", method = RequestMethod.POST)
    public void projectDemandPlanExport(HttpServletResponse response, @RequestBody @Valid ProjectDemandPlanExport dto) {
        projectDemandPlanService.projectDemandPlanExport(response, dto);

    }

    @RequestMapping(value = "/easyGenerateProjectDemandPlan", method = RequestMethod.POST)
    @ApiOperation("(不依赖产品需求计划)生成项目需求计划")
    public ResponseResult<Boolean> easyGenerateProjectDemandPlan(@RequestBody EasyGenerateProjectDemandPlanDTO dto) {
        projectDemandPlanService.easyGenerateProjectDemandPlan(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/getProjectDemandPlanInfoByProjectIds", method = RequestMethod.POST)
    @ApiOperation("(根据项目id获取项目需求计划")
    public ResponseResult<List<ProjectDemandPlanInfoVO>> easyGenerateProjectDemandPlan(@RequestBody ProjectDemanPlanInfoQueryDTO dto) {
        return ResponseResult.success("操作成功", projectDemandPlanService.selectByProjectIds(dto));
    }


    @RequestMapping(value = "/updateSpecificationX", method = RequestMethod.POST)
    @ApiOperation("更新板材型材规格的X为*")
    public ResponseResult<Boolean> updateSpecificationX() {
        projectDemandPlanService.updateSpecificationX();
        return ResponseResult.success("操作成功");
    }
}
