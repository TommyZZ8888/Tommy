package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class EasyGenerateProjectDemandPlanDTO {
    @ApiModelProperty("项目id")
    @NotBlank(message = "项目id不能为空")
    private String projectId;

    @ApiModelProperty("物资类型")
    private String[] materialTypeList;
}
