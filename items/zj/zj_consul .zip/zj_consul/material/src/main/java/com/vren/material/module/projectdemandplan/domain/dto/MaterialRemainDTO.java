package com.vren.material.module.projectdemandplan.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class MaterialRemainDTO {

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("需求数量")
    @ConversionNumber
    private Long count;

    @ConversionNumber
    @ApiModelProperty("库存数量(项目需求详情下面的锁库数量)")
    private Long stockAmount;

    @ApiModelProperty("余料数量")
    @ConversionNumber
    private Long remainingMaterialCount;

    @ApiModelProperty("锁库数量（前端手动填写的锁库数量）")
    @ConversionNumber
    private Long lockStockNumber;

    @ApiModelProperty("采购计划明细id")
    private String purchaseDemandPlanDetailId;

    @ApiModelProperty("库存表id")
    private String materialStockId;

}
