package com.vren.material.module.materialcheckout.domain.enums;

public enum ApprovalStatus {
    UNAUDITED(0,"未审批"),
    APPROVALED(1,"审批通过"),
    APPROVALING(2,"审批失败"),
    UNAPPROVALED(3,"待审批")
    ;
    ApprovalStatus(Integer code, String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
