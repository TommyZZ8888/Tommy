package com.vren.material.module.order;

import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.module.project.ProjectService;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.common.utils.SystemConfig;
import com.vren.material.common.utils.WordDataListUtil;
import com.vren.material.module.order.domain.dto.*;
import com.vren.material.module.order.domain.entity.Order;
import com.vren.material.module.order.domain.entity.OrderDetail;
import com.vren.material.module.order.domain.enums.StateEnum;
import com.vren.material.module.order.domain.vo.*;
import com.vren.material.module.order.mapper.OrderDetailMapper;
import com.vren.material.module.order.mapper.OrderMapper;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.purchasecontract.PurchaseContractService;
import com.vren.material.module.purchasecontract.domain.dto.GetOneOrDeleteDTO;
import com.vren.material.module.purchasecontract.domain.entity.ContractList;
import com.vren.material.module.purchasecontract.domain.entity.Supplier;
import com.vren.material.module.purchasecontract.domain.vo.ContractListVO;
import com.vren.material.module.purchasecontract.domain.vo.SupplierVO;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.dto.DeletePurchasePlaDetailDTO;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import com.vren.material.module.purchaseplan.domain.vo.PurchasePlanDetailVO;
import com.vren.material.module.storage.StorageService;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @author GR
 */
@Service
@Slf4j
public class OrderService {

    private final OrderMapper orderMapper;

    private final OrderDetailMapper orderDetailMapper;

    private final ProjectService projectService;

    private final PurchaseContractService purchaseContractService;

    private final PurchasePlanService purchasePlanService;

    private final StorageService storageService;


    @Autowired
    public OrderService(OrderMapper orderMapper, OrderDetailMapper orderDetailMapper, ProjectService projectService, PurchaseContractService purchaseContractService, PurchasePlanService purchasePlanService, StorageService storageService) {
        this.orderMapper = orderMapper;
        this.orderDetailMapper = orderDetailMapper;
        this.projectService = projectService;
        this.purchaseContractService = purchaseContractService;
        this.purchasePlanService = purchasePlanService;
        this.storageService = storageService;
    }


    public Order selectById(String orderId) {
        return orderMapper.selectById(orderId);
    }

    public boolean selectByContractListId(String contractListId) {
        MPJLambdaWrapper<Order> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(Order::getId).eq(Order::getContractListId, contractListId).last("limit 1");
        return orderMapper.selectOne(wrapper) != null;
    }

    public List<Order> selectListByContractListId(String contractListId) {
        MPJLambdaWrapper<Order> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(Order.class)
                .eq(Order::getContractListId, contractListId);
        return orderMapper.selectList(wrapper);
    }

    public List<Order> selectListByContractListIdList(List<String> contractListIdList) {
        MPJLambdaWrapper<Order> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(Order.class)
                .in(Order::getContractListId, contractListIdList);
        return orderMapper.selectList(wrapper);
    }

    public List<OrderDetail> selectDetailListByOrderId(String orderId) {
        MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(OrderDetail.class)
                .eq(OrderDetail::getOrderId, orderId);
        return orderDetailMapper.selectList(wrapper);
    }


    public PageResult<OrderVO> queryOrder(QueryOrderDTO dto) {
        Page<OrderVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<Order> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(Order.class)
                .like(!CommonUtil.isNull(dto.getProjectId()), Order::getProjectId, dto.getProjectId())
                .eq(!CommonUtil.isNull(dto.getSupplierId()), Order::getSupplierId, dto.getSupplierId())
                .like(!CommonUtil.isNull(dto.getOrderNumber()), Order::getOrderNumber, dto.getOrderNumber())
                .orderByDesc(Order::getCreateTime);
        IPage<OrderVO> orderVOIPage = orderMapper.selectJoinPage(page, OrderVO.class, wrapper);
        orderVOIPage.getRecords().forEach(
                item -> {
                    if (!CommonUtil.isNull(item.getProjectId())) {
                        String projectName = this.joinProjectName(item.getProjectId());
                        item.setProjectName(String.valueOf(projectName));
                    }
                    if (!CommonUtil.isNull(item.getSupplierId())) {
                        Supplier supplier = purchaseContractService.getSupplierById(item.getSupplierId());
                        if (!CommonUtil.isNull(supplier)) {
                            item.setSupplierName(supplier.getSupplierName());
                            item.setContacts(supplier.getContacts());
                            item.setSupplierContactNumber(supplier.getContactNumber());
                        }
                    }
                    if (!CommonUtil.isNull(item.getContractListId())) {
                        GetOneOrDeleteDTO getOneOrDeleteDTO = new GetOneOrDeleteDTO();
                        getOneOrDeleteDTO.setId(item.getContractListId());
                        item.setContractNo(purchaseContractService.getContractListById(getOneOrDeleteDTO).getContractNo());
                    }
                    item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));

                    item.setStateText("未开始审核");
                    if (item.getState() != null) {
                        item.setStateText(EnumUtil.getValue(StateEnum.class, item.getState()));
                    }
                }
        );
        return PageUtil.convert2PageResult(orderVOIPage);
    }

    public String getOrderNumber() {
        //2023/07/31：采购订单编号：RCGDD+日期+2随机
        int nextInt = new Random().nextInt(90) + 10;
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        String date = format.format(new Date());
        return "RCGDD" + date + nextInt;
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean addOrder(AddOrderDTO dto) {
        if (CommonUtil.listIsNotEmpty(dto.getOrderDetailDTOS())) {
            dto.getOrderDetailDTOS().forEach(item -> {
                if (item.getOrderQuantity() + item.getGeneratedOrderQuantity() > item.getOrderLimit()) {
                    throw new RuntimeException("订单数量总和不能大于订单限额！");
                }
            });
        }

        String orderNumber = getOrderNumber();
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq("order_number", orderNumber)
                .last(" limit 1");
        while (orderMapper.selectCount(queryWrapper) > 0) {
            orderNumber = getOrderNumber();
            queryWrapper.eq("order_number", orderNumber);
        }

        //新增一条订单信息
        Order order = BeanUtil.copy(dto, Order.class);
        //设置物资类型，根据合同清单id在采购表中查询
        String contractListId = dto.getContractListId();
        ContractList contractList = purchaseContractService.selectContractListEntityById(contractListId);
        Integer contractListMaterialType = contractList.getMaterialType();
        List<PurchasePlan> purchasePlans = purchasePlanService.getPurchasePlanListByContractListId(contractListId, contractListMaterialType);
        Integer materialType;
        String projectIdList;
        if (CommonUtil.listIsNotEmpty(purchasePlans)) {
            materialType = purchasePlans.get(0).getMaterialType();
            order.setMaterialType(materialType);
            List<String> collect = purchasePlans.stream().map(PurchasePlan::getProjectId).distinct().collect(Collectors.toList());
            projectIdList = JSON.toJSONString(collect);
        } else {
            throw new RuntimeException("该采购合同下面不存在采购信息！");
        }
        //设置供应商id，根据合同清单id查询供应商id
        ContractListVO contractListVO = purchaseContractService.selectContractLisById(dto.getContractListId());
        if (!CommonUtil.isNull(contractListVO.getSupplierId())) {
            order.setSupplierId(contractListVO.getSupplierId());
        }
        //设置需方，默认是中建五洲工程装备有限公司
        order.setDemander("中建五洲工程装备有限公司");
        //设置项目id,根据合同清单id查询
        order.setProjectId(projectIdList);
        order.setOrderNumber(orderNumber);
        order.setContractListId(contractListVO.getId());
        order.setContractNo(contractListVO.getContractNo());
        int insert = orderMapper.insert(order);
        if (insert > 0) {
            //新增订单明细
            List<OrderDetail> orderDetails = BeanUtil.copyList(dto.getOrderDetailDTOS(), OrderDetail.class);
            orderDetails.forEach(item -> item.setOrderId(order.getId()));
            Integer someColumn = orderDetailMapper.insertBatchSomeColumn(orderDetails);
            if (someColumn > 0) {
                //订单明细新增了，根据物资类型和采购计划详情id更新采购计划详情表中的 已生成订单数量字段
                //已生成订单数量  =   已生成订单数量  +  订单数量
                //更新已生成订单数量，true表示增加已生成订单数量
                purchasePlanService.updateGeneratedOrderQuantity(order.getMaterialType(), orderDetails, true);
                return true;
            }
        }
        return false;
    }

    public OrderVO queryOrderById(GetOneOrDeleteDTO dto) {
        Order order = orderMapper.selectById(dto.getId());
        OrderVO orderVO = BeanUtil.copy(order, OrderVO.class);
        if (!CommonUtil.isNull(orderVO.getProjectId())) {
            List<String> list = JSON.parseArray(orderVO.getProjectId(), String.class);
            StringBuilder projectName = new StringBuilder();
            for (String projectId : list) {
                projectName.append(projectService.getById(projectId).getProjectName()).append("，");
            }
            projectName = new StringBuilder(projectName.substring(0, projectName.length() - 1));
            orderVO.setProjectName(String.valueOf(projectName));
        }
        if (!CommonUtil.isNull(orderVO.getContractListId())) {
            GetOneOrDeleteDTO getOneOrDeleteDTO = new GetOneOrDeleteDTO();
            getOneOrDeleteDTO.setId(orderVO.getContractListId());
            orderVO.setContractNo(purchaseContractService.getContractListById(getOneOrDeleteDTO).getContractNo());
        }
        if (!CommonUtil.isNull(orderVO.getSupplierId())) {
            Supplier supplier = purchaseContractService.getSupplierById(orderVO.getSupplierId());
            if (!CommonUtil.isNull(supplier)) {
                orderVO.setSupplierName(supplier.getSupplierName());
                orderVO.setContacts(supplier.getContacts());
                orderVO.setSupplierContactNumber(supplier.getContactNumber());
            }
        }
        orderVO.setStateText("未开始审核");
        if (orderVO.getState() != null) {
            orderVO.setStateText(EnumUtil.getValue(StateEnum.class, orderVO.getState()));
        }
        orderVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, orderVO.getMaterialType()));
        return orderVO;
    }

    public boolean editOrder(EditOrderDTO dto) {
        //审核中，审核过的订单不可编辑和删除
        Order order = BeanUtil.copy(dto, Order.class);
        Integer state = orderMapper.selectById(dto.getId()).getState();
        if (!CommonUtil.isNull(state)) {
            if (state.equals(StateEnum.UNDER_REVIEW.getCode())) {
                throw new RuntimeException("审核中的订单不可编辑!");
            } else {
                throw new RuntimeException("审核后的订单不可编辑！");
            }
        }
        return orderMapper.updateById(order) > 0;
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean deleteOrder(GetOneOrDeleteDTO dto) {
        //根据id删除订单，同时删除更新采购详情里面的 已生成订单的数量
        Order order = orderMapper.selectById(dto.getId());
        Integer state = order.getState();
        if (!CommonUtil.isNull(state)) {
            if (state.equals(StateEnum.UNDER_REVIEW.getCode())) {
                throw new RuntimeException("审核中的订单不可删除!");
            } else {
                throw new RuntimeException("审核后的订单不可删除！");
            }
        }
        int delete = orderMapper.deleteById(dto.getId());
        if (delete > 0) {
            //查询订单详情数据
            MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(OrderDetail.class)
                    .eq(OrderDetail::getOrderId, dto.getId());
            List<OrderDetail> orderDetails = orderDetailMapper.selectList(wrapper);
            if (!CommonUtil.listIsNotEmpty(orderDetails)) {
                //订单下面没有详情，直接删除
                return true;
            }
            List<String> list = orderDetails.stream().map(OrderDetail::getId).collect(Collectors.toList());
            //删除详情
            orderDetailMapper.deleteBatchIds(list);
            //更新已生成订单数量，false表示减少已生成订单数量
            purchasePlanService.updateGeneratedOrderQuantity(order.getMaterialType(), orderDetails, false);
            return true;
        }
        return false;
    }


    public PageResult<OrderDetailVO> queryOrderDetail(QueryOrderDetailDTO dto) {
        Page<OrderDetailVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(OrderDetail.class)
                .eq(OrderDetail::getOrderId, dto.getId());
        IPage<OrderDetailVO> orderDetailVOIPage = orderDetailMapper.selectJoinPage(page, OrderDetailVO.class, wrapper);
        orderDetailVOIPage.getRecords().forEach(item -> {
            String id = item.getId();
            Long orderQuantity = item.getOrderQuantity();
            //设置项目名称
            item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            //采购计划详情数据填充，根据采购计划详情id和物资类型查询
            DeletePurchasePlaDetailDTO purchasePlaDetailDTO = new DeletePurchasePlaDetailDTO();
            purchasePlaDetailDTO.setMaterialType(dto.getMaterialType());
            purchasePlaDetailDTO.setId(item.getPurchasePlanDetailId());
            PurchasePlanDetailVO planDetailVO = purchasePlanService.getPurchasePlanDetailById(purchasePlaDetailDTO);
            if (!CommonUtil.isNull(planDetailVO)) {
                BeanUtil.copyProperties(planDetailVO, item);
            }
            item.setId(id);
            item.setOrderId(dto.getId());
            item.setOrderQuantity(orderQuantity);
        });
        return PageUtil.convert2PageResult(page);
    }


    public OrderDetailVO queryOrderDetailById(QueryDTO dto) {
        OrderDetail orderDetail = orderDetailMapper.selectById(dto.getId());
        DeletePurchasePlaDetailDTO purchasePlaDetailDTO = new DeletePurchasePlaDetailDTO();
        purchasePlaDetailDTO.setMaterialType(dto.getMaterialType());
        purchasePlaDetailDTO.setId(orderDetail.getPurchasePlanDetailId());
        PurchasePlanDetailVO planDetailVO = purchasePlanService.getPurchasePlanDetailById(purchasePlaDetailDTO);
        OrderDetailVO orderDetailVO = BeanUtil.copy(orderDetail, OrderDetailVO.class);
        BeanUtil.copyProperties(planDetailVO, orderDetailVO);
        orderDetailVO.setId(dto.getId());
        orderDetailVO.setOrderQuantity(orderDetail.getOrderQuantity());
        orderDetailVO.setOrderId(orderDetail.getOrderId());
        orderDetailVO.setProjectName(projectService.getById(orderDetailVO.getProjectId()).getProjectName());
        //订单限额
        //采购订单材料下单数量增加系数（配置文件可配）原数量5*（1+30%）=6.5，向下取整
        double limit = orderDetailVO.getPurchaseAmount() * SystemConfig.getOrderLimit() / 100 + orderDetailVO.getPurchaseAmount();
        orderDetailVO.setOrderLimit(Math.round(limit / 100));
        return orderDetailVO;
    }

    public boolean editOrderDetail(EditOrderDetailDTO dto) {
        OrderDetail orderDetail = orderDetailMapper.selectById(dto.getId());
        if (dto.getOrderQuantity() - orderDetail.getOrderQuantity() + dto.getGeneratedOrderQuantity() > dto.getPurchaseAmount()) {
            throw new RuntimeException("订单数量总和不能大于合同里面的采购数量！");
        }
        Order order = orderMapper.selectById(orderDetail.getOrderId());
        Integer state = order.getState();
        if (!CommonUtil.isNull(state)) {
            if (state.equals(StateEnum.UNDER_REVIEW.getCode())) {
                throw new RuntimeException("审核中的订单详情不可编辑!");
            } else {
                throw new RuntimeException("审核后的订单不详情可编辑！");
            }
        }
        //只能更新订单数量，更新订单数量的同时，更新采购详情里面的已生成订单数量
        //更新前的订单数量

        boolean update = purchasePlanService.updateGeneratedOrderQuantity(dto.getMaterialType(), orderDetail, dto.getOrderQuantity());
        if (update) {
            UpdateWrapper<OrderDetail> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("id", dto.getId())
                    .set("order_quantity", dto.getOrderQuantity());
            return orderDetailMapper.update(new OrderDetail(), updateWrapper) > 0;
        } else {
            return false;
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean deleteOrderDetail(DeleteOrderDetailDTO dto) {
        String orderId = orderDetailMapper.selectById(dto.getId()).getOrderId();
        Integer state = orderMapper.selectById(orderId).getState();
        if (!CommonUtil.isNull(state)) {
            if (state.equals(StateEnum.UNDER_REVIEW.getCode())) {
                throw new RuntimeException("审核中的订单详情不可删除!");
            } else {
                throw new RuntimeException("审核后的订单不详情可删除！");
            }
        }
        //删除订单详情，同时更新采购计划详情里面的已生成订单数量
        int delete = orderDetailMapper.deleteById(dto.getId());
        if (delete > 0) {
            OrderDetail orderDetail = BeanUtil.copy(dto, OrderDetail.class);
            List<OrderDetail> orderDetails = Collections.singletonList(orderDetail);
            purchasePlanService.updateGeneratedOrderQuantity(dto.getMaterialType(), orderDetails, false);
            return true;
        }
        return false;
    }

    public List<String> getPurchasePlanDetails(String orderId) {
        MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(OrderDetail::getPurchasePlanDetailId)
                .eq(OrderDetail::getOrderId, orderId);
        List<OrderDetail> orderDetails = orderDetailMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(orderDetails)) {
            List<OrderDetail> collect = orderDetails.stream().filter(item -> !CommonUtil.isNull(item.getPurchasePlanDetailId())).collect(Collectors.toList());
            if (CommonUtil.listIsNotEmpty(collect)) {
                return collect.stream().map(OrderDetail::getPurchasePlanDetailId).collect(Collectors.toList());
            }
        }
        return null;

    }

    public boolean addOrderDetail(AddOrderDetailDTO dto) {
        Order order = orderMapper.selectById(dto.getOrderId());
        Integer state = order.getState();
        if (!CommonUtil.isNull(state)) {
            if (state.equals(StateEnum.UNDER_REVIEW.getCode())) {
                throw new RuntimeException("审核中的订单详情不可编辑!");
            } else {
                throw new RuntimeException("审核后的订单不详情可编辑！");
            }
        }
        //新增订单明细
        List<OrderDetail> orderDetails = BeanUtil.copyList(dto.getOrderDetailDTOS(), OrderDetail.class);
        orderDetails.forEach(item -> item.setOrderId(dto.getOrderId()));
        Integer someColumn = orderDetailMapper.insertBatchSomeColumn(orderDetails);
        if (someColumn > 0) {
            //订单明细新增了，根据物资类型和采购计划详情id更新采购计划详情表中的 已生成订单数量字段
            //已生成订单数量  =   已生成订单数量  +  订单数量
            //更新已生成订单数量，true表示增加已生成订单数量
            purchasePlanService.updateGeneratedOrderQuantity(order.getMaterialType(), orderDetails, true);
            return true;
        }
        return false;
    }

    public void exportOrder(HttpServletResponse response, QueryDTO dto) throws IOException {
        //订单
        Order order = orderMapper.selectById(dto.getId());
        MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(OrderDetail.class)
                .eq(OrderDetail::getOrderId, dto.getId());
        //订单详情
        List<OrderDetail> orderDetails = orderDetailMapper.selectList(wrapper);
        //采购计划详情
        ArrayList<OrderExportVO> orderExportVOS = new ArrayList<>();
        AtomicLong num = new AtomicLong();
        AtomicReference<Long> sum = new AtomicReference<>(0L);
        AtomicReference<Long> orderedSum = new AtomicReference<>(0L);
        AtomicReference<Long> orderSum = new AtomicReference<>(0L);
        orderDetails.forEach(item -> {
            DeletePurchasePlaDetailDTO purchasePlaDetailDTO = new DeletePurchasePlaDetailDTO();
            purchasePlaDetailDTO.setMaterialType(dto.getMaterialType());
            purchasePlaDetailDTO.setId(item.getPurchasePlanDetailId());
            PurchasePlanDetailVO planDetailVO = purchasePlanService.getPurchasePlanDetailById(purchasePlaDetailDTO);
            OrderExportVO exportVO = BeanUtil.copy(item, OrderExportVO.class);
            Long orderQuantity = exportVO.getOrderQuantity();
            BeanUtil.copyProperties(planDetailVO, exportVO);
            exportVO.setOrderQuantity(orderQuantity);
            exportVO.setAutoincrementId(num.incrementAndGet());
            if (!CommonUtil.isNull(exportVO.getPurchaseAmount())) {
                sum.updateAndGet(v -> v + exportVO.getPurchaseAmount());
            }
            if (!CommonUtil.isNull(exportVO.getGeneratedOrderQuantity())) {
                //累计已供货数量 使用入库管理的中 数量
                List<MaterialFirstLevelStorage> storage = storageService.getByMaterialNumber(planDetailVO.getWarehousingNo());
                if (CommonUtil.listIsNotEmpty(storage)) {
                    long quantity = storage.stream().mapToLong(MaterialFirstLevelStorage::getCount).sum();
                    exportVO.setGeneratedOrderQuantity(quantity / 100);
                    orderedSum.updateAndGet(v -> v + exportVO.getGeneratedOrderQuantity());
                } else {
                    exportVO.setGeneratedOrderQuantity(0L);
                }
            }
            if (!CommonUtil.isNull(exportVO.getOrderQuantity())) {
                exportVO.setOrderQuantity(exportVO.getOrderQuantity() / 100);
                orderSum.updateAndGet(v -> v + exportVO.getOrderQuantity());
            }
            if (!CommonUtil.isNull(exportVO.getExecutiveStandards()) && !CommonUtil.isNull(exportVO.getTexture())) {
                exportVO.setTextureAndStandards(exportVO.getTexture() + "、" + exportVO.getExecutiveStandards());
            } else if (!CommonUtil.isNull(exportVO.getTexture())) {
                exportVO.setTextureAndStandards(exportVO.getTexture());
            } else {
                exportVO.setTextureAndStandards(exportVO.getExecutiveStandards());
            }
            //不含税单价
            if (!CommonUtil.isNull(exportVO.getPreTaxPrice())) {
                exportVO.setPreTaxPriceExport(exportVO.getPreTaxPrice().doubleValue() / 100);
                exportVO.setTotalPriceExcludingTaxExport(exportVO.getPreTaxPriceExport() * exportVO.getOrderQuantity());
            }
            orderExportVOS.add(exportVO);
        });
        HashMap<String, Object> map = new HashMap<>();
        map.put("demander", order.getDemander());
        //合同名称
        ContractListVO contractListVO = purchaseContractService.selectContractLisById(order.getContractListId());
        if (!CommonUtil.isNull(contractListVO)) {
            map.put("contractNo", contractListVO.getContractNo());
        }
        map.put("orderNumber", order.getOrderNumber());
        //项目名称拼接起来
        if (!CommonUtil.isNull(order.getProjectId())) {
            String projectName = this.joinProjectName(order.getProjectId());
            map.put("projectName", projectName);
        }
        map.put("deliveryAddress", order.getDeliveryAddress());
        map.put("receivingContact", order.getReceivingContact());
        map.put("contactNumber", order.getContactNumber());
        map.put("sum", sum.get());
        map.put("orderedSum", orderedSum.get());
        map.put("orderSum", orderSum.get());
        //供应商信息
        if (!CommonUtil.isNull(order.getSupplierId())) {
            SupplierVO supplierVO = purchaseContractService.selectSupplierById(order.getSupplierId());
            map.put("supplierName", supplierVO.getSupplierName());
            map.put("contacts", supplierVO.getContacts());
            map.put("supplierContactNumber", supplierVO.getContactNumber());
        }
        map.put("orderContent", order.getOrderContent());
        AttachmentExport build = null;
        if (!CommonUtil.isNull(order.getAttachment())) {
            //从图片资源服务器获得图片
            String httpUrl = "http://172.16.16.105/webfile" + order.getAttachment();
            URL url = new URL(httpUrl);
            build = AttachmentExport.builder().attachment(url).build();
        }
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/orderTemplate.xlsx");
        ExcelExportService exportService = new ExcelExportService(order.getOrderNumber(), response, resourceAsStream);
        exportService.fill(new FillWrapper("list", orderExportVOS), "订单");
        exportService.fill(map, "订单");
        if (!CommonUtil.isNull(build)) {
            exportService.fill(build, "订单");
        }
        exportService.export();
    }

    /**
     * 根据项目id拼接项目名称
     * @param projectIdString 项目id 的json
     * @return 项目名称的拼接
     */
    public String joinProjectName(String projectIdString) {
        List<String> list = JSON.parseArray(projectIdString, String.class);
        StringBuilder projectName = new StringBuilder();
        if (CommonUtil.listIsNotEmpty(list)) {
            for (String projectId : list) {
                projectName.append(projectService.getById(projectId).getProjectName()).append("，");
            }
            projectName = new StringBuilder(projectName.substring(0, projectName.length() - 1));
        }
        return String.valueOf(projectName);
    }

    public boolean startOrderWorkFlow(StartOrderWorkFlowDTO dto) {
        //送审，更新订单状态
        UpdateWrapper<Order> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", "0")
                .set("instance_code", dto.getInstanceCode())
                .eq("id", dto.getKeyId());
        return orderMapper.update(new Order(), updateWrapper) > 0;
    }


    public boolean updateOrderWorkFlow(StartOrderWorkFlowDTO dto) {
        UpdateWrapper<Order> updateWrapper = new UpdateWrapper<>();
        if ("true".equals(dto.getResult())) {
            updateWrapper.set("state", "1");
        } else {
            updateWrapper.set("state", "2");
        }
        updateWrapper.eq("id", dto.getKeyId());
        return orderMapper.update(new Order(), updateWrapper) > 0;
    }

    public boolean endOrderWorkFlow(StartOrderWorkFlowDTO dto) {
        //dto.getResult();
        return true;
    }

    public OrderInProcessVO getOrderInProcess(GetOneOrDeleteDTO dto) {
        //根据订单id，查询订单及详情
        Order order = orderMapper.selectById(dto.getId());
        OrderInProcessVO processVO = BeanUtil.copy(order, OrderInProcessVO.class);
        //设置项目名称
        if (!CommonUtil.isNull(processVO.getProjectId())) {
            processVO.setProjectName(this.joinProjectName(processVO.getProjectId()));
        }
        //设置供应商信息
        if (!CommonUtil.isNull(processVO.getSupplierId())) {
            Supplier supplier = purchaseContractService.getSupplierById(processVO.getSupplierId());
            processVO.setSupplierName(supplier.getSupplierName());
            processVO.setSupplierContactNumber(supplier.getContactNumber());
            processVO.setContacts(supplier.getContacts());
        }
        //物资类型
        processVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, processVO.getMaterialType()));
        //订单详情
        MPJLambdaWrapper<OrderDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(OrderDetail.class)
                .eq(OrderDetail::getOrderId, dto.getId());
        List<OrderDetail> orderDetails = orderDetailMapper.selectList(wrapper);
        List<OrderDetailVO> orderDetailVOS = BeanUtil.copyList(orderDetails, OrderDetailVO.class);
        orderDetailVOS.forEach(item -> {
            String id = item.getId();
            //设置项目名称
            item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            //采购计划详情数据填充，根据采购计划详情id和物资类型查询
            DeletePurchasePlaDetailDTO purchasePlaDetailDTO = new DeletePurchasePlaDetailDTO();
            purchasePlaDetailDTO.setMaterialType(order.getMaterialType());
            purchasePlaDetailDTO.setId(item.getPurchasePlanDetailId());
            PurchasePlanDetailVO planDetailVO = purchasePlanService.getPurchasePlanDetailById(purchasePlaDetailDTO);
            if (!CommonUtil.isNull(planDetailVO)) {
                BeanUtil.copyProperties(planDetailVO, item);
            }
            item.setId(id);
        });
        processVO.setOrderDetailVOS(orderDetailVOS);
        return processVO;
    }

    public Boolean isRelateToOrder(String id) {
        //根据合同清单判断该合同下是否存在订单
        QueryWrapper<Order> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq("contract_list_id", id)
                .last("limit 1");
        return orderMapper.selectCount(queryWrapper) > 0;
    }


    public void exportOrderWord(HttpServletResponse response, QueryDTO dto) {
        GetOneOrDeleteDTO queryDto = new GetOneOrDeleteDTO();
        queryDto.setId(dto.getId());
        OrderVO orderVO = queryOrderById(queryDto);
        PurchaseOrderWordExportVO purchaseOrderWordExportVO = BeanUtil.copy(orderVO, PurchaseOrderWordExportVO.class);
        purchaseOrderWordExportVO.setAttachment("");

        QueryOrderDetailDTO queryOrderDetailDTO = new QueryOrderDetailDTO();
        queryOrderDetailDTO.setId(dto.getId());
        queryOrderDetailDTO.setMaterialType(dto.getMaterialType());
        queryOrderDetailDTO.setPageSize(500);
        PageResult<OrderDetailVO> orderDetailVOPageResult = queryOrderDetail(queryOrderDetailDTO);
        List<OrderDetailVO> orderDetailVOList = orderDetailVOPageResult.getList();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        List<PurchaseOrderDetailVO> collect = orderDetailVOList.stream().map(item -> PurchaseOrderDetailVO.builder()
                .serialNum("")
                .materialName(item.getMaterialName())
                .size(item.getSize())
                .texture(item.getTexture())
                .useMaterialUnit(item.getUseMaterialUnit())
                .purchaseAmount(NumberConvertUtil.intConvertToString(item.getPurchaseAmount(), 100))
                .arrivalAmount(NumberConvertUtil.intConvertToString(item.getArrivalAmount(), 100))
                .deliveryTime(simpleDateFormat.format(item.getDeliveryTime()))
                .orderQuantity(NumberConvertUtil.longConvertToString(item.getOrderQuantity(), 100))
                .build()).collect(Collectors.toList());

        Map<String, Object> data = WordDataListUtil.getDataMap(purchaseOrderWordExportVO);
        List<Map<String, String>> dataMapList = WordDataListUtil.getDataMapList(collect);
        data.put("list", dataMapList);

        ClassPathResource pathResource = new ClassPathResource("static/template/word/采购订单.docx");
        FileUtils.easyPoiExport(pathResource.getPath(), "tempDir", "采购订单.docx", data, response);
    }


}
