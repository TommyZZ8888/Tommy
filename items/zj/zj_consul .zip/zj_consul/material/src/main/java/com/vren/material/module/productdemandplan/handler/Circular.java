package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

@Component
public class Circular implements ComputerHandler {

    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        if (CommonUtil.isNull(data.getFirstSize()) || CommonUtil.isNull(data.getSecondSize())) {
            throw new RuntimeException(data.getMaterialName() + "的第一尺寸和第二尺寸不能为空");
        }
        //圆形计算公式IF(OR(E28="方形",E28="圆形"),F28^2*G28*J28/1000000*C28,
        double result = Math.pow(data.getFirstSize().doubleValue() / 100, 2) * (data.getSecondSize().doubleValue() / 100) * (data.getProportion().doubleValue() / 100) / 1000000 * (data.getCount().doubleValue() / 100);
        String specification = "δ" + decimalFormat.format(data.getSecondSize().doubleValue() / 100) + "Xφ" + decimalFormat.format(data.getFirstSize().doubleValue() / 100);
        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (result < 0) {
            throw new RuntimeException("您输入的尺寸有误！");
        }
        productDemandPlanDetails.setWeight((long) (result * 100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("Xφ") + 2);
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("Xφ"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);

        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("Xφ") + 2);
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("Xφ"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);

        }
    }

    @Override
    public void analysis(ProjectDemandPlanExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("Xφ") + 2);
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("Xφ"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);

        }
    }

    @Override
    public void execution(BoardImportDTO data) {
        //圆形计算重量：和方形计算一样 第一尺寸^2*第二尺寸*比重/1000000*数量  规格：δ第二尺寸Xφ第一尺寸
        //圆形计算     重量为：长^2*厚度*比重/1000000*数量
        //规格               δ厚度Xφ长度
        double thickness = !CommonUtil.isNull(data.getThickness()) ? Double.parseDouble(data.getThickness()) : 0.0;
        double length = !CommonUtil.isNull(data.getLength()) ? Double.parseDouble(data.getLength()) : 0.0;
        double width = !CommonUtil.isNull(data.getWidth()) ? Double.parseDouble(data.getWidth()) : 0.0;
        double proportion = !CommonUtil.isNull(data.getProportion()) ? Double.parseDouble(data.getProportion()) : 0.0;
        double count = !CommonUtil.isNull(data.getCount()) ? Double.parseDouble(data.getCount()) : 0.0;

        //计算重量
        double weight = Math.pow(length, 2) * thickness * proportion / 1000000 * count;
        //生成规格
        String specification = "δ" + NumberConvertUtil.doubleToString(thickness) + "Xφ" + NumberConvertUtil.doubleToString(length);

        //设置重量和规格
        data.setWeight((long) (weight * 100));
        data.setSpecification(specification);

    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        if (specification != null) {
            String width = specification.substring(specification.indexOf("Xφ") + 2);
            String thickness = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("Xφ"));
            map.put("width", width);
            map.put("thickness", thickness);
        }
        return map;
    }
}
