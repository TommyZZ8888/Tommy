package com.vren.material.module.purchasecontractprojectinfo;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.purchasecontractprojectinfo.domain.entity.PurchaseContractProjectInfoEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @Description PurchaseContractProjectInfoMapper
 * @Author 张卫刚
 * @Date Created on 2023/9/1
 */
@Mapper
public interface PurchaseContractProjectInfoMapper extends MPJBaseMapper<PurchaseContractProjectInfoEntity> {

}
