package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class GeneratePurchasePlanDTO {

    @ApiModelProperty("项目id")
    @NotBlank(message = "项目id不能为空")
    private String projectId;

}
