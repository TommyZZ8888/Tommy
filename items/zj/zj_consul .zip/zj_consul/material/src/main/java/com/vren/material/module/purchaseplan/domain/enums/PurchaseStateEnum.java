package com.vren.material.module.purchaseplan.domain.enums;

/**
 * @author 耿让
 *  采购状态枚举类
 */
public enum PurchaseStateEnum {

    SUPPLIER_RESOURCE_PREPARATION(1,"供方资源筹备"),
    ANNOUNCEMENT_ENROLLMENT(2,"公告报名"),
    ASSESSMENT(3,"资审"),
    BID(4,"投标"),
    BID_EVALUATION(5,"评标"),
    CALIBRATION(6,"定标"),
    DRAFT_CONTRACT(7,"合同拟稿"),
    CONTRACT_REVIEW(8,"合同评审"),
    CONTRACT_SIGNATURE(9,"合同签章"),
    CONTRACT_SIGNING(10,"合同签订");

    private Integer code;

    private String name;

    PurchaseStateEnum(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
