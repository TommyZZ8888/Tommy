package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;
import java.util.List;

/**
 * @Author GR
 * @Time 2023-04-10-14-25
 **/
@Data
public class AddOrderDTO {

    @ApiModelProperty("订单编号")
//    @NotBlank(message = "订单编号不能为空")
    private String orderNumber;

    @ApiModelProperty("合同清单id")
    @NotBlank(message = "合同不能为空")
    private String contractListId;

    @ApiModelProperty("需方:中建五洲工程装备有限公司")
    private String demander;

    @ApiModelProperty("送货地址")
    @NotBlank(message = "送货地址不能为空")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    @NotBlank(message = "收货联系人不能为空")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    @NotBlank(message = "联系电话不能为空")
    private String contactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

    private List<OrderDetailDTO> orderDetailDTOS;

    @ApiModelProperty("到货日期")
    private Date arrivalTime;

    @ApiModelProperty("合同编号")
    private String contractNo;

}
