package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * @time 2023-04-19-17-10
 **/
@Data
public class MaterialNameInCheckoutDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
