package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;


@Data
public class GenerateContractDTO {


    @ApiModelProperty("项目Id列表")
    private List<String> projectIds;

    @ApiModelProperty("采购名称")
    private String purchaseName;

    @ApiModelProperty("项目需求计划id")
    private List<String> projectDemandPlanIdList;
}
