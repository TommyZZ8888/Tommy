package com.vren.material.module.purchaseplan.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  油漆采购计划
 */
@TableName("purchase_plan_details_paint")
@Data
public class PurchasePlanDetailsPaint {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("采购计划表ID")
    private String purchasePlanId;

    @ApiModelProperty("油漆需求计划表id")
    private String paintDemandPlanId;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("颜色")
    private String color;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("面积")
    @ConversionNumber
    private Long purchaseArea;

    @ApiModelProperty("技术标准")
    private String executiveStandards;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long proposalPrice;

    @ApiModelProperty("税前单价")
    @ConversionNumber(value = 10000)
    private Long preTaxPrice;

    @ApiModelProperty("税额")
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("市场最高价")
    @ConversionNumber
    private Long highestMarketPrice;

    @ApiModelProperty("市场最低价")
    @ConversionNumber
    private Long lowestMarketPrice;

    @ApiModelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("市场含税单价")
    @ConversionNumber(value = 10000)
    private Long marketUnitPriceTax;

    @ApiModelProperty("市场加权均价")
    @ConversionNumber
    private Long marketWeightedAverage;

    @ApiModelProperty("建议控制价")
    @ConversionNumber
    private Long proposedControlPrice;

    @ApiModelProperty("商务核准价格")
    @ConversionNumber
    private Long businessApprovedPrice;

    @ApiModelProperty("最终批准价格")
    @ConversionNumber
    private Long finalApprovalPriceField;

    @ApiModelProperty("标书加权均价")
    @ConversionNumber
    private Long weightedAverageBidPrice;

    @ApiModelProperty("干膜厚（μm） ")
    @ConversionNumber
    private Long dryFilmThickness;

    @ApiModelProperty("油漆用量（kg）（含2.0损耗）")
    @ConversionNumber
    private Long amountOfPaint;

    @ApiModelProperty("理论用量/涂布率（kg/㎡）")
    @ConversionNumber(value = 10000)
    private Long theoreticalDosage;

    @ApiModelProperty("损耗系数")
    @ConversionNumber
    private Long lossFactor;

    @ApiModelProperty("体积固含量(%)")
    @ConversionNumber
    private Long volumeSolidContent;

    @ApiModelProperty("密度（kg/L)")
    @ConversionNumber
    private Long density;

    @ApiModelProperty("含税油漆单价（元/kg）")
    @ConversionNumber(value = 10000)
    private Long unitPricePaintIncludingTax;

    @ApiModelProperty("稀释剂量kg（25%）")
    @ConversionNumber
    private Long dilutionDose;

    @ApiModelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    @ConversionNumber
    private Long totalUnitPriceIncludingTax;

    @ApiModelProperty("含税稀释剂单价（元/kg）\t")
    @ConversionNumber
    private Long unitPriceDiluentIncludingTax;

    @ApiModelProperty("含税平方总价（元）")
    @ConversionNumber
    private Long totalSquarePriceIncludingTax;

    @ApiModelProperty("包装规格")
    private String packageSpecification;

    @ApiModelProperty("税率%")
    @ConversionNumber
    private Long taxRate;

    @ApiModelProperty("备注（锌粉含量）")
    @ConversionNumber
    private String remarksZincPowderContent;

    @ApiModelProperty("是否删除")
    @TableField(fill = FieldFill.INSERT)
    private Boolean isDeleted;


    @ApiModelProperty("已生成订单数量")
    @ConversionNumber
    private Long generatedOrderQuantity;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long bidPrice;

    @ApiModelProperty("标书最低价")
    @ConversionNumber
    private Long lowestBidPrice;

    @ApiModelProperty("标书最高价")
    @ConversionNumber
    private Long highestBidPrice;

    @ApiModelProperty("标书品牌")
    private String bidBrand;

    @ApiModelProperty("付款条件")
    private String paymentTerms;

    @ApiModelProperty("序号")
    private Integer serialNumber;

    private String contractListId;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

}