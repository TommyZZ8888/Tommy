package com.vren.material.module.productmanagement.domain.dto;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author GR
 * time 2023-07-24-10-18
 **/
@Data
public class ImportProductDTO {

    @ApiModelProperty("产品名称")
    @ExcelProperty(value = "产品名称", index = 0)
    private String productName;

    @ApiModelProperty("位号")
    @ExcelProperty(value = "位号", index = 1)
    private String tagNo;

    @ApiModelProperty(value = "产品规格")
    @ExcelProperty(value = "产品规格", index = 2)
    private String productSpecificatons;

    @ApiModelProperty("总图号")
    @ExcelProperty(value = "总图号", index = 3)
    private String totalFigureNo;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量", index = 4)
    @ConversionNumber
    private Long number;

    @ApiModelProperty("容器类别")
    @ExcelProperty(value = "容器类别", index = 5)
    private String containerCategory;

    @ApiModelProperty("使用单位")
    @ExcelProperty(value = "使用单位", index = 6)
    private String useUnit;

    @ApiModelProperty("制造编号(生产编号)")
    @ExcelProperty(value = "制造编号", index = 7)
    private String manufacturingNumber;

    @ApiModelProperty("吨")
    @ExcelIgnore
    @ConversionNumber
    private Long weight;

    @ApiModelProperty("吨")
    @ExcelProperty(value = "重量(t)", index = 8)
    @ConversionNumber
    private Double weightExport;


    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    @ExcelIgnore
    private Integer isProductionScheduling;

    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    @ExcelProperty(value = "排产状态", index = 9)
    private String isProductionSchedulingText;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    @ExcelIgnore
    private Integer isProductionPlan;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    @ExcelProperty(value = "生产状态", index = 10)
    private String isProductionPlanText;

    @ApiModelProperty("创建时间")
    @ExcelProperty(value = "创建时间", index = 11)
    private Date createTime;

}
