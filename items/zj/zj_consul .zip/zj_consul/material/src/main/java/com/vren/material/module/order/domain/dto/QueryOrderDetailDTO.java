package com.vren.material.module.order.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Author GR
 * @Time 2023-04-11-15-21
 **/
@Data
public class QueryOrderDetailDTO extends PageParam {

    @ApiModelProperty("物资类型")
    @NotNull(message = "物资类型不能为空")
    private Integer materialType;

    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

}
