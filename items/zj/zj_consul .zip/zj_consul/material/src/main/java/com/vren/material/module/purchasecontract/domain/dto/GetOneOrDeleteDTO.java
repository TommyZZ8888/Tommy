package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GetOneOrDeleteDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("contractListNo")
    private String contractListNo;
}
