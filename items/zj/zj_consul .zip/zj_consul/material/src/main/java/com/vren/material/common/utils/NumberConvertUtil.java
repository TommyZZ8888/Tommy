package com.vren.material.common.utils;

import com.vren.common.common.utils.CommonUtil;

import java.math.BigDecimal;

/**
 * @Description NumberConvertUtil
 * @Author 张卫刚
 * @Date Created on 2023/9/6
 */
public class NumberConvertUtil {

    /**
     * 转string时，去除小数点后的0
     * @param number
     * @return
     */
    public static String doubleToString(Double number) {
        BigDecimal bd = new BigDecimal(String.valueOf(number));
        return bd.stripTrailingZeros().toPlainString();
    }

    public static String longConvertToString(Long num, long divideNum) {
        if (CommonUtil.isNull(num)) {
            return "";
        }
        return String.valueOf(num / divideNum);
    }

    public static String intConvertToString(Integer num, long divideNum) {
        if (CommonUtil.isNull(num)) {
            return "";
        }
        return String.valueOf(num / divideNum);
    }
}
