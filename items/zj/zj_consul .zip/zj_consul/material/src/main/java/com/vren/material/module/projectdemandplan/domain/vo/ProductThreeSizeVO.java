package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description ProductThreeSizeVO
 * @Author 张卫刚
 * @Date Created on 2023/9/11
 */
@Data
public class ProductThreeSizeVO {

    @ApiModelProperty("第一尺寸")
    private String firstSize;

    @ApiModelProperty("第二尺寸")
    private String secondSize;

    @ApiModelProperty("第三尺寸")
    private String thirdSize;
}
