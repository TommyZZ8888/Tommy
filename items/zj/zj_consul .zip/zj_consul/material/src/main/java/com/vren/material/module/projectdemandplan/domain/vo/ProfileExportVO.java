package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 型材导出VO
 * @author szp
 * @date 2023/1/29 16:45
 */
@Data
public class ProfileExportVO {

        @ExcelProperty("序号")
        @ApiModelProperty("自增序号")
        private Integer autoincrementId;

        @ExcelIgnore
        @ApiModelProperty("物资类型")
        private String materialType;

        @ExcelProperty("用料类型")
        @ApiModelProperty("用料类型")
        private String ingredientsType;

        @ExcelProperty("件号")
        @ApiModelProperty("件号")
        private String partNo;

        @ExcelProperty("材料名称")
        @ApiModelProperty("材料名称")
        private String materialName;

        @ExcelProperty("材质")
        @ApiModelProperty("材质")
        private String texture;

        @ExcelIgnore
        @ApiModelProperty("第一尺寸")
        private String firstSize;

        @ExcelIgnore
        @ApiModelProperty("第二尺寸")
        private String secondSize;

        @ExcelIgnore
        @ApiModelProperty("第三尺寸")
        private String thirdSize;

        @ExcelProperty("厚度")
        @ApiModelProperty("第一尺寸")
        @ConversionNumber
        private String firstSizeExport;

        @ExcelProperty("宽度")
        @ApiModelProperty("第二尺寸")
        @ConversionNumber
        private String secondSizeExport;

        @ExcelProperty("长度")
        @ApiModelProperty("第三尺寸")
        @ConversionNumber
        private String thirdSizeExport;

        @ExcelIgnore
        @ApiModelProperty("规格")
        private String specification;

        @ExcelIgnore
        @ConversionNumber
        @ApiModelProperty("备件数量")
        private Long sparePartsQuantity;

        @ExcelProperty("备件数量")
        @ConversionNumber
        @ApiModelProperty("备件数量")
        private Double sparePartsQuantityExport;

        @ExcelIgnore
        @ApiModelProperty("数量")
        @ConversionNumber
        private Long count;

        @ExcelIgnore
        @ApiModelProperty("重量")
        @ConversionNumber
        private Long weight;

        @ExcelProperty("数量")
        @ApiModelProperty("数量")
        @ConversionNumber
        private Double countExport;

        @ExcelProperty("重量(KG)")
        @ApiModelProperty("重量")
        @ConversionNumber
        private Double weightExport;

        @ExcelProperty("执行标准")
        @ApiModelProperty("执行标准")
        private String enforceStandards;

        @ExcelProperty(value = "交货时间",converter = DateConverter.class)
        @ApiModelProperty("交货时间")
        private Date deliveryTime;

        @ExcelProperty("交货地点")
        @ApiModelProperty("交货地点")
        private String deliveryLocation;

        @ExcelProperty("备注")
        @ApiModelProperty("备注")
        private String remarks;

        @ExcelProperty("制造编号&件号")
        @ApiModelProperty("制造编号&件号")
        private String manufacturingNumberPartNo;

        @ExcelIgnore
        @ApiModelProperty("是否常规计算")
        private Boolean isCalculate;

        @ExcelProperty("是否常规计算")
        @ApiModelProperty("是否常规计算")
        private String isCalculateText;
        //新增比重
        @ExcelIgnore
        @ApiModelProperty("比重")
        @ConversionNumber
        private Long proportion;

        @ExcelProperty("比重")
        @ApiModelProperty("比重")
        @ConversionNumber
        private Double proportionExport;

        @ExcelIgnore
        @ConversionNumber
        @ApiModelProperty("标书价")
        private Long bidPrice;

        @ExcelProperty("标书价")
        @ConversionNumber
        @ApiModelProperty("标书价")
        private Double bidPriceExport;

        @ExcelProperty("单位")
        @ApiModelProperty("单位")
        private String unit;
}
