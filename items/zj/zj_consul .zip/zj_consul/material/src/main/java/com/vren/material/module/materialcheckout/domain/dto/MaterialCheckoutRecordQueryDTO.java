package com.vren.material.module.materialcheckout.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@Data
public class MaterialCheckoutRecordQueryDTO extends PageParam {
    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("领料单记录id")
    private String materialCheckoutRecordId;

    @ApiModelProperty("审批状态")
    private Integer approvalStatus;
    @ApiModelProperty("审核状态 未审核 0  审核成功 1  审核失败 2  待审核3")
    private Integer auditStatus;
    @ApiModelProperty("出库开始时间")
    private Date checkoutStartDate;
    @ApiModelProperty("出库结束时间")
    private Date checkoutEndDate;

    @ApiModelProperty("出库状态 1 已出库 0未出库 ")
    private Integer checkoutStatus;
}
