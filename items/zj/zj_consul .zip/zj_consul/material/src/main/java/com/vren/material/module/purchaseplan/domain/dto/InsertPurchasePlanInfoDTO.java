package com.vren.material.module.purchaseplan.domain.dto;

import com.vren.material.module.purchaseplan.domain.dto.UpdateContractIdDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description InsertPurchasePlanInfoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class InsertPurchasePlanInfoDTO {

    @ApiModelProperty("采购计划明细列表")
    private List<UpdateContractIdDTO> list;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
