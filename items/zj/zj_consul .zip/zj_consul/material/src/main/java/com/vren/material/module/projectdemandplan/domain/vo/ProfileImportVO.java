package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
/**
 * 型材导入VO
 * @author szp
 * @date 2023/2/2 9:40
 */
@Data
public class ProfileImportVO {

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;

    private String partNo;

    private String materialName;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long thickness;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long width;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long length;


    private String texture;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long count;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long  weight;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    private String deliveryTime;


    private String deliveryLocation;


    private String remarks;

    //新增的导出列的字段
    @ApiModelProperty("规格")
    private String specification;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("标书价")
    private Long bidPrice;


    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("单位")
    private String unit;
    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;
}
