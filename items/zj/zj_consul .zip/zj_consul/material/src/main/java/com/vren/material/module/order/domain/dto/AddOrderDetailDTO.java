package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * @Author GR
 * @Time 2023-04-12-14-34
 **/
@Data
public class AddOrderDetailDTO {

    @ApiModelProperty("订单id")
    private String orderId;

    @Size(min = 1,message = "参数不能为空")
    @ApiModelProperty("订单详情")
    private List<OrderDetailDTO> orderDetailDTOS;

}
