package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author 耿让
 * 批量删除
 */
@Data
public class BatchDeleteDTO {

    @Size(min = 1,message = "id不能为空")
    @ApiModelProperty("id，（多个id，集合）")
    private List<String> ids;

}
