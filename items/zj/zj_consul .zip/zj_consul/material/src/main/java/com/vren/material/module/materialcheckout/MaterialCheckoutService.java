package com.vren.material.module.materialcheckout;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.Project;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.common.enums.FactoryEnum;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.common.utils.SystemConfig;
import com.vren.material.common.utils.WordDataListUtil;
import com.vren.material.module.materialcheckout.domain.dto.*;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutDetail;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutRecord;
import com.vren.material.module.materialcheckout.domain.enums.*;
import com.vren.material.module.materialcheckout.domain.vo.*;
import com.vren.material.module.materialcheckout.mapper.MaterialCheckoutDetailMapper;
import com.vren.material.module.materialcheckout.mapper.MaterialCheckoutRecordMapper;
import com.vren.material.module.materialrenturn.domain.dto.MaterialNameInCheckoutDTO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNameInCheckoutVO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNumberSelectVO;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.purchasecontract.domain.dto.StartContractListWorkFlow;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.stockmanagement.MaterialStockMapper;
import com.vren.material.module.stockmanagement.StockManagementService;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.storage.domain.entity.MaterialFirstLevelStorage;
import com.vren.material.module.storage.domain.enums.WarehousingMaterialType;
import com.vren.material.module.storage.mapper.MaterialFirstLevelStorageMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MaterialCheckoutService {
    @Autowired
    private MaterialStockMapper materialStockMapper;

    @Autowired
    private MaterialCheckoutRecordMapper materialCheckoutRecordMapper;

    @Autowired
    private MaterialCheckoutDetailMapper materialCheckoutDetailMapper;


    @Autowired
    private ProjectService projectService;

    @Autowired
    private MaterialFirstLevelStorageMapper materialFirstLevelStorageMapper;

    @Autowired
    private UserService userService;

    @Autowired
    private StockManagementService stockManagementService;


    /**
     * 生成入库单号
     * @author szp
     * @date 2023/4/4 10:22
     */
    private String generateMaterialRequisitionNo() {
        long time = System.currentTimeMillis();
        Date dates = new Date(time);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String times = sdf.format(dates);
//        int random = new Random().nextInt(89999) + 10000;
        int random = new Random().nextInt(89) + 10;
        String s = "LLD" + times + random;
        QueryWrapper<MaterialCheckoutRecord> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1").eq("material_requisition_no", s).last("limit 1");
        int count = 0;
        while (materialCheckoutRecordMapper.selectCount(queryWrapper) > 0) {
//            random = new Random().nextInt(89999) + 10000;
            random = new Random().nextInt(89) + 10;
            count++;
            if (count > 50) {
                break;
            }
        }
        return "LLD" + times + random;
    }

    @Autowired
    private PurchasePlanService purchasePlanService;

    public void addOrEditMaterialCheckout(MaterialCheckoutRecordAddDTO dto) {
        if (CommonUtil.isNull(dto.getId())) {
            //查库存
            MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(MaterialStock.class)
                    .eq(MaterialStock::getProjectId, dto.getProjectId());
            List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
            if (!CommonUtil.listIsNotEmpty(materialStocks)) {
                throw new ErrorException("该项目下没有库存不能生成领料单");
            }

            MaterialCheckoutRecord copy = BeanUtil.copy(dto, MaterialCheckoutRecord.class);
            copy.setMaterialRequisitionNo(this.generateMaterialRequisitionNo());
            copy.setApprovalStatus(ApprovalStatus.UNAUDITED.getCode());
            copy.setCompile(ThreadLocalUser.get().getUserId());
            copy.setSponsor(ThreadLocalUser.get().getUserId());
            copy.setRequisitionDepartment(EnumUtil.getValue(CheckoutDepartment.class, dto.getRequisitionDepartment()));
            copy.setAuditStatus(0);

            materialCheckoutRecordMapper.insert(copy);
            return;
        }
        MaterialCheckoutRecord copy = BeanUtil.copy(dto, MaterialCheckoutRecord.class);
        copy.setCompile(ThreadLocalUser.get().getUserId());
        copy.setSponsor(ThreadLocalUser.get().getUserId());
        copy.setRequisitionDepartment(EnumUtil.getValue(CheckoutDepartment.class, dto.getRequisitionDepartment()));
        materialCheckoutRecordMapper.updateById(copy);

    }


    public void deleteMaterialCheckout(MaterialCheckoutRecordDeleteDTO dto) {
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getId());
        if (CommonUtil.isNull(materialCheckoutRecord.getApprovalStatus()) && materialCheckoutRecord.getApprovalStatus() == 3) {
            throw new ErrorException("送审中,无法删除");
        }
        materialCheckoutRecordMapper.deleteById(dto.getId());

        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
            for (MaterialCheckoutDetail materialCheckoutDetail : materialCheckoutDetails) {
                materialCheckoutDetailMapper.deleteById(materialCheckoutDetail);
            }
        }
    }

    public void addMaterialCheckoutDetail(MaterialCheckoutDetailAddDTO dto) {
        if (dto.getStockBalance() < dto.getApplyQuantity()) {
            throw new RuntimeException("申领数量不能大于库存余量");
        }
        if (dto.getApplyQuantity() < dto.getActualPickedQuantity()) {
            throw new RuntimeException("实领数量不能大于申领数量");
        }
        //未领取
        //非辅材：不含税总额=（总重量/采购数量）*不含税单价*入库数量；
        //辅材+容器厂锻件：不含税总额=不含税单价*数量
        MaterialStock materialStock1 = stockManagementService.selectBySpecificationAndMaterial(dto.getSpecification(), dto.getTexture(), dto.getMaterialType());
        long weight = materialStock1.getWeight();
        long singleWeight = weight / materialStock1.getEstimatedStorageCount();
        long unitPriceIncludingTax = dto.getPreTaxPrice() + (dto.getTax() * 100);
        if (dto.getActualPickedQuantity() > 0) {
            dto.setWeight(singleWeight * dto.getActualPickedQuantity());
            long totalAmountBeforeTax = dto.getPreTaxPrice() * dto.getActualPickedQuantity() / 10000 * singleWeight;
            long totalAmountIncludingTax = unitPriceIncludingTax * dto.getActualPickedQuantity() / 10000 * singleWeight;

            if (WarehousingMaterialType.AUXILIARY_MATERIALS.getCode().equals(dto.getMaterialType())
                    || (FactoryEnum.PRESSURE_VESSEL.getCode().equals(SystemConfig.getFactoryNum()) && WarehousingMaterialType.FORGE_PIECE.getCode().equals(dto.getMaterialType()))) {
                totalAmountBeforeTax = dto.getActualPickedQuantity() > 0 ? dto.getPreTaxPrice() * dto.getActualPickedQuantity() / 10000 : totalAmountBeforeTax;
                totalAmountIncludingTax = dto.getActualPickedQuantity() > 0 ? unitPriceIncludingTax * dto.getActualPickedQuantity() / 10000 : totalAmountIncludingTax;
            }
            if (WarehousingMaterialType.WELDING_MATERIALS.getCode().equals(dto.getMaterialType())) {
                totalAmountBeforeTax = (dto.getPreTaxPrice() * dto.getActualPickedQuantity()) / 10000;
                totalAmountIncludingTax = (unitPriceIncludingTax * dto.getActualPickedQuantity()) / 10000;
            }
            dto.setMoney(totalAmountBeforeTax);
            dto.setMaterialTotalPrice(totalAmountIncludingTax);
        }

        if (CommonUtil.isNull(dto.getId())) {
            MaterialCheckoutDetail copy = BeanUtil.copy(dto, MaterialCheckoutDetail.class);
            //未领取
            copy.setReceiveState(ReceiveState.UNRECEIVE.getCode());
            copy.setMaterialNumber(dto.getMaterialNumber().split("-")[0]);
            MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(MaterialCheckoutDetail.class)
                    .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getMaterialCheckoutRecordId())
                    .eq(MaterialCheckoutDetail::getMaterialNumber, dto.getMaterialNumber());
            List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
            if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
                throw new ErrorException("不能重复添加同材料编号的材料");
            }
            materialCheckoutDetailMapper.insert(copy);
            return;
        }
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getId());
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getMaterialCheckoutRecordId());
        String projectId = materialCheckoutRecord.getProjectId();
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        for (MaterialCheckoutDetail materialCheckoutDetail : materialCheckoutDetails) {
            MPJLambdaWrapper<MaterialStock> materialStockMPJLambdaWrapper = new MPJLambdaWrapper<>();
            materialStockMPJLambdaWrapper.selectAll(MaterialStock.class)
                    .eq(MaterialStock::getProjectId, projectId)
                    .eq(MaterialStock::getMaterialName, materialCheckoutDetail.getMaterialName());
            MaterialStock materialStock = materialStockMapper.selectOne(materialStockMPJLambdaWrapper);

            long l = materialStock.getStockBalance() - materialCheckoutDetail.getActualPickedQuantity();
            if (l < 0) {
                throw new ErrorException("已领数量超过库存,建议小于" + materialStock.getStockBalance());
            }
        }
        MaterialCheckoutDetail copy = BeanUtil.copy(dto, MaterialCheckoutDetail.class);
        //未领取
        copy.setReceiveState(ReceiveState.UNRECEIVE.getCode());
        materialCheckoutDetailMapper.updateById(copy);
    }


    public PageResult<MaterialCheckoutRecordVO> getMaterialCheckoutList(MaterialCheckoutRecordQueryDTO dto) {
        MPJLambdaWrapper<MaterialCheckoutRecord> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutRecord.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()), MaterialCheckoutRecord::getProjectId, dto.getProjectId())
                .eq(!CommonUtil.isNull(dto.getApprovalStatus()), MaterialCheckoutRecord::getApprovalStatus, dto.getApprovalStatus())
                .eq(!CommonUtil.isNull(dto.getAuditStatus()), MaterialCheckoutRecord::getAuditStatus, dto.getAuditStatus())
                .orderByDesc(MaterialCheckoutRecord::getCreateTime);
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(wrapper);
        List<MaterialCheckoutRecordVO> materialCheckoutRecordVOS = BeanUtil.copyList(materialCheckoutRecords, MaterialCheckoutRecordVO.class);
        Map<String, Project> projectDataMap = projectService.getProjectDataMap();
        List<MaterialCheckoutRecordVO> collect = materialCheckoutRecordVOS.stream().peek(item -> {
            if (!CommonUtil.isNull(item.getProjectId())) {
                Set<String> strings = projectDataMap.keySet();
                if (strings.contains(item.getProjectId())) {
                    item.setProjectName(projectDataMap.get(item.getProjectId()).getProjectName());
                }
            }
            item.setTaxMethodText(EnumUtil.getValue(TaxMethod.class, item.getTaxMethod()));
            item.setApprovalStatusText(EnumUtil.getValue(ApprovalStatus.class, item.getApprovalStatus()));
            item.setAuditStatusText(EnumUtil.getValue(AuditStatus.class, item.getAuditStatus()));
            if (!CommonUtil.isNull(item.getCompile())) {
                item.setCompile(userService.getUserInfoByID(item.getCompile()).getCHName());
            }
            if (!CommonUtil.isNull(item.getChecker())) {
                item.setChecker(userService.getUserInfoByID(item.getChecker()).getCHName());
            }
            if (!CommonUtil.isNull(item.getApprover())) {
                item.setApprover(userService.getUserInfoByID(item.getApprover()).getCHName());
            }
            if (!CommonUtil.isNull(item.getIssuedBy())) {
                item.setIssuedBy(userService.getUserInfoByID(item.getIssuedBy()).getCHName());
            }
            if (!CommonUtil.isNull(item.getSponsor())) {
                item.setSponsor(userService.getUserInfoByID(item.getSponsor()).getCHName());
            }
            //根据id查询 出库详情，判断是否已经出库
            MPJLambdaWrapper<MaterialCheckoutDetail> checkoutDetailMPJLambdaWrapper = new MPJLambdaWrapper<>();
            checkoutDetailMPJLambdaWrapper.select(MaterialCheckoutDetail::getReceiveState)
                    .eq(!CommonUtil.isNull(item.getId()), MaterialCheckoutDetail::getMaterialCheckoutRecordId, item.getId());
            List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(checkoutDetailMPJLambdaWrapper);
            if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
                Integer receiveState = materialCheckoutDetails.get(0).getReceiveState();
                if (CommonUtil.isNull(receiveState)) {
                    item.setCheckOut(false);
                } else {
                    item.setCheckOut(!receiveState.equals(ReceiveState.UNRECEIVE.getCode()));
                }
            } else {
                item.setCheckOut(false);
            }
        }).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<MaterialCheckoutDetailVO> getMaterialCheckoutDetailList(MaterialCheckoutDetailQueryDTO dto) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getId())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialCheckoutDetail::getMaterialType, dto.getMaterialType());

        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        List<MaterialCheckoutDetailVO> materialCheckoutDetailVOS = BeanUtil.copyList(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        List<MaterialCheckoutDetailVO> collect = materialCheckoutDetailVOS.stream().peek(item -> {
            item.setMaterialTypeText(EnumUtil.getValue(WarehousingMaterialType.class, item.getMaterialType()));
            item.setReceiveStateText(EnumUtil.getValue(ReceiveState.class, item.getReceiveState()));
        }).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);

    }

    public void deleteMaterialCheckoutDetail(MaterialCheckoutDetailDeleteDTO dto) {
        materialCheckoutDetailMapper.deleteById(dto.getId());
    }

    public MaterialCheckoutDetailVO getMaterialCheckoutDetailById(MaterialCheckoutDetailDTO dto) {
        MaterialCheckoutDetail materialCheckoutDetail = materialCheckoutDetailMapper.selectById(dto.getId());
        MaterialCheckoutDetailVO materialCheckoutDetailVO = BeanUtil.copy(materialCheckoutDetail, MaterialCheckoutDetailVO.class);
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(materialCheckoutDetail.getMaterialCheckoutRecordId());
        //根据物资编号填充库存余量（从库存表查询）
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(materialCheckoutDetailVO.getMaterialNumber()), MaterialStock::getMaterialNumber, materialCheckoutDetailVO.getMaterialNumber())
                .eq(!CommonUtil.isNull(materialCheckoutRecord.getProjectId()), MaterialStock::getProjectId, materialCheckoutRecord.getProjectId());
        MaterialStock materialStock = materialStockMapper.selectOne(wrapper);
        materialCheckoutDetailVO.setStockBalance(materialStock.getStockBalance());
        materialCheckoutDetailVO.setMaterialStockId(materialStock.getId());
        LinkedList<Long> taxRateAndPrice = purchasePlanService.getTaxRateAndPrice(materialCheckoutDetailVO.getMaterialNumber(), materialCheckoutDetailVO.getMaterialType());
        if (!CommonUtil.isNull(taxRateAndPrice)) {
            materialCheckoutDetailVO.setUnitPriceWithTax(taxRateAndPrice.get(2));
        }
        return materialCheckoutDetailVO;
    }

    public List<TaxMethodVO> getTaxMethodVOList() {
        ArrayList<TaxMethodVO> list = new ArrayList<>();
        for (TaxMethod value : TaxMethod.values()) {
            TaxMethodVO taxMethodVO = new TaxMethodVO();
            taxMethodVO.setCode(value.getCode());
            taxMethodVO.setValue(value.getName());
            list.add(taxMethodVO);
        }
        return list;
    }

    public MaterialCheckoutDataVO getMaterialCheckoutDataList(MaterialCheckoutDataDTO dto) {
        String[] split = dto.getMaterialNumber().split("-");
        String s = split[0];
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(MaterialStock::getProjectId, dto.getProjectId())
                .eq(MaterialStock::getMaterialNumber, s);
        MaterialStock materialStocks = materialStockMapper.selectOne(wrapper);
        MaterialCheckoutDataVO copy = BeanUtil.copy(materialStocks, MaterialCheckoutDataVO.class);
        //已领数量 ，根据项目id和物资编号 将所有的已经领用数量加起来
        MPJLambdaWrapper<MaterialCheckoutRecord> recordMPJLambdaWrapper = new MPJLambdaWrapper<>();
        recordMPJLambdaWrapper.select(MaterialCheckoutRecord::getId)
                .eq(!CommonUtil.isNull(copy.getProjectId()), MaterialCheckoutRecord::getProjectId, copy.getProjectId());
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(recordMPJLambdaWrapper);
        List<String> collect = materialCheckoutRecords.stream().map(MaterialCheckoutRecord::getId).collect(Collectors.toList());
        MPJLambdaWrapper<MaterialCheckoutDetail> detailMPJLambdaWrapper = new MPJLambdaWrapper<>();
        detailMPJLambdaWrapper.select(MaterialCheckoutDetail::getPickedQuantity)
                .in(CommonUtil.listIsNotEmpty(collect), MaterialCheckoutDetail::getMaterialCheckoutRecordId, collect)
                .eq(!CommonUtil.isNull(copy.getMaterialNumber()), MaterialCheckoutDetail::getMaterialNumber, copy.getMaterialNumber());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(detailMPJLambdaWrapper);
        long sum = materialCheckoutDetails.stream().mapToLong(MaterialCheckoutDetail::getPickedQuantity).sum();
        //已领数量
        copy.setPickedQuantity(sum);
        //根据  查找 税率、税前单价和含税单价
        LinkedList<Long> taxRateAndPrice = purchasePlanService.getTaxRateAndPrice(copy.getMaterialNumber(), copy.getMaterialType());
        //2023/03/22 价税合计金额 = 含税单价*实领数量     金额 = 税前单价*实领数量
        if (CommonUtil.listIsNotEmpty(taxRateAndPrice)) {
            copy.setTaxRate(taxRateAndPrice.get(0));
            copy.setPreTaxPrice(taxRateAndPrice.get(1));
            copy.setUnitPriceWithTax(taxRateAndPrice.get(2));
        }
        //已领数量数据放到库存表中
        MaterialFirstLevelStorage materialFirstLevelStorage = materialFirstLevelStorageMapper.selectById(materialStocks.getMaterialStorageId());
        if (!CommonUtil.isNull(materialFirstLevelStorage)) {
            //采购数量 =出库限额
            Long purchaseAmount = materialFirstLevelStorage.getPurchaseAmount();
            //限额数量=出库限额-已领数量
            copy.setQuantityRequired(purchaseAmount - sum);
            copy.setIssueLimit(purchaseAmount);
        }
        if (dto.getIsScan()) {
            if (CommonUtil.isNull(copy)) {
                String projectName = projectService.getById(dto.getProjectId()).getProjectName();
                throw new RuntimeException("【" + projectName + "】项目下不存在该物资，不可领取");
            }
        }
        return copy;
    }

    public List<MaterialNumberVO> getMaterialNameList(MaterialCheckoutRecordQueryDTO dto) {
        MPJLambdaWrapper<MaterialStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()), MaterialStock::getProjectId, dto.getProjectId());
        List<MaterialStock> materialStocks = materialStockMapper.selectList(wrapper);
        List<MaterialNumberVO> materialNumberVOList = materialStocks.stream().map(item -> {
            MaterialNumberVO materialNumberVO = new MaterialNumberVO();
            /*展示格式为 物资编号-材料名称-材料规格 */
            materialNumberVO.setMaterialNumber(item.getMaterialNumber() + "-" + item.getMaterialName() + "-" + item.getSpecification());
            return materialNumberVO;
        }).collect(Collectors.toList());
        MPJLambdaWrapper<MaterialCheckoutDetail> mpjLambdaWrapper = new MPJLambdaWrapper<>();
        mpjLambdaWrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getMaterialCheckoutRecordId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(mpjLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
            List<MaterialNumberVO> collect = materialCheckoutDetails.stream().map(item -> {
                MaterialNumberVO materialNumberVO = new MaterialNumberVO();
                materialNumberVO.setMaterialNumber(item.getMaterialNumber() + "-" + item.getMaterialName() + "-" + item.getSpecification());
                return materialNumberVO;
            }).collect(Collectors.toList());
            materialNumberVOList.removeAll(collect);
        }
        return materialNumberVOList;
    }

    @Transactional(rollbackFor = Exception.class)
    public void materialCheckout(MaterialCheckoutDTO dto) {
        /**
         *  根据出库记录表id更新  出库详情表的receive_state
         *  根据关联的出库详情  更新库存表的库存余量
         */
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getId());
        String projectId = materialCheckoutRecord.getProjectId();
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(!CommonUtil.isNull(dto.getId()), MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        if (!CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
            throw new RuntimeException("该出库单下面不存在出库记录,不可出库");
        }
        materialCheckoutDetails.forEach(item -> {
            //出库详情
            //更新库存余量  :   根据物资编号更新库存余量
            String materialNumber = item.getMaterialNumber();
            //生成领料单，库存余量减少；库存余量 = 库存余量 - 实领数量
            UpdateWrapper<MaterialStock> updateWrapper = new UpdateWrapper<>();
            //2023/02/28 根据物资编号和项目id
            updateWrapper.eq(!CommonUtil.isNull(materialNumber), "material_number", materialNumber)
                    .eq(!CommonUtil.isNull(projectId), "project_id", projectId)
                    .setSql(!CommonUtil.isNull(item.getActualPickedQuantity()), "stock_balance = stock_balance - " + item.getActualPickedQuantity());
            int update = materialStockMapper.update(new MaterialStock(), updateWrapper);
            QueryWrapper<MaterialStock> materialStockQueryWrapper = new QueryWrapper<>();
            materialStockQueryWrapper.select("stock_balance")
                    .eq(!CommonUtil.isNull(materialNumber), "material_number", materialNumber)
                    .eq(!CommonUtil.isNull(projectId), "project_id", projectId);
            MaterialStock materialStock = materialStockMapper.selectOne(materialStockQueryWrapper);
            if (!CommonUtil.isNull(materialStock)) {
                if (materialStock.getStockBalance() < 0) {
                    throw new RuntimeException("库存余量不足，出库失败！");
                }
            }
            if (update > 0) {
                //库存余量更新成功，更新库存详情的领取状态
                item.setReceiveState(ReceiveState.RECEIVED.getCode());
                //2023/02/28  根据项目id和物资编号  更新所有的已领数量  （累加）
                //  新增的时候，查询所有已领数量，累加起来
                UpdateWrapper<MaterialCheckoutDetail> detailUpdateWrapper = new UpdateWrapper<>();
                detailUpdateWrapper.eq("material_checkout_record_id", dto.getId())
                        .eq("material_number", materialNumber)
                        .set("picked_quantity", item.getPickedQuantity() + item.getActualPickedQuantity());
                materialCheckoutDetailMapper.update(new MaterialCheckoutDetail(), detailUpdateWrapper);
                materialCheckoutDetailMapper.updateById(item);
            }
            materialCheckoutRecord.setCheckoutTime(new Date());
            materialCheckoutRecord.setCheckoutStatus(1);
            materialCheckoutRecord.setIssuedBy(ThreadLocalUser.get().getUserId());
            materialCheckoutRecordMapper.updateById(materialCheckoutRecord);
        });
    }

    /**
     * 根据项目id和领料单编号查询  出库详情
     * @param projectId
     * @param materialRequisitionNo
     * @return
     */
    public List<MaterialCheckoutDetailVO> selectCheckoutDetailProjectIdAndNo(String projectId, String materialRequisitionNo, String materialName, String specification) {
        //查询出库记录表id
        MPJLambdaWrapper<MaterialCheckoutRecord> checkoutRecordMPJLambdaWrapper = new MPJLambdaWrapper<>();
        checkoutRecordMPJLambdaWrapper.select(MaterialCheckoutRecord::getId)
                .eq(MaterialCheckoutRecord::getCheckoutStatus, 1)
                .eq(!CommonUtil.isNull(projectId), MaterialCheckoutRecord::getProjectId, projectId)
                .like(!CommonUtil.isNull(materialRequisitionNo), MaterialCheckoutRecord::getMaterialRequisitionNo, materialRequisitionNo);
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(checkoutRecordMPJLambdaWrapper);
        if (materialCheckoutRecords.size() == 0) {
            throw new RuntimeException("该项目下没有相关的出库记录");
        }
        List<String> collect = materialCheckoutRecords.stream().map(MaterialCheckoutRecord::getId).collect(Collectors.toList());
        //根据出库记录表id，在出库记录详情中查询结果
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .like(!CommonUtil.isNull(materialName), MaterialCheckoutDetail::getMaterialName, materialName)
                .like(!CommonUtil.isNull(specification), MaterialCheckoutDetail::getSpecification, specification)
                .in(CommonUtil.listIsNotEmpty(collect), MaterialCheckoutDetail::getMaterialCheckoutRecordId, collect);
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        List<MaterialCheckoutDetailVO> materialCheckoutDetailVOS = BeanUtil.copyList(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        materialCheckoutDetailVOS.forEach(item -> {
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
        });
        return materialCheckoutDetailVOS;
    }

    public List<MaterialCheckoutDetailVO> selectCheckoutDetailByMaterialName(String projectId, Integer materialType, String materialName, String materialNumber) {
        //通过项目id查询所有的领料单id
        MPJLambdaWrapper<MaterialCheckoutRecord> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(MaterialCheckoutRecord::getId).eq(!CommonUtil.isNull(projectId), MaterialCheckoutRecord::getProjectId, projectId);
        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(wrapper);
        List<String> list = materialCheckoutRecords.stream().map(MaterialCheckoutRecord::getId).collect(Collectors.toList());

        MPJLambdaWrapper<MaterialCheckoutDetail> queryWrapper = new MPJLambdaWrapper<>();
        queryWrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(!CommonUtil.isNull(materialType), MaterialCheckoutDetail::getMaterialType, materialType)
                .eq(!CommonUtil.isNull(materialName), MaterialCheckoutDetail::getMaterialName, materialName)
                .eq(!CommonUtil.isNull(materialNumber), MaterialCheckoutDetail::getMaterialNumber, materialNumber)
                .in(CommonUtil.listIsNotEmpty(list), MaterialCheckoutDetail::getMaterialCheckoutRecordId, list);
        List<MaterialCheckoutDetail> materialCheckoutDetail = materialCheckoutDetailMapper.selectList(queryWrapper);
        return BeanUtil.copyList(materialCheckoutDetail, MaterialCheckoutDetailVO.class);
    }

    public MaterialCheckoutDetailVO selectCheckoutByMaterialNumber(String materialNumber) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(MaterialCheckoutDetail::getMaterialNumber, materialNumber);
        MaterialCheckoutDetail materialCheckoutDetails = materialCheckoutDetailMapper.selectOne(wrapper);
        if (CommonUtil.isNull(materialCheckoutDetails)) {
            throw new RuntimeException("不存在该物资");
        }
        MaterialCheckoutDetailVO materialCheckoutDetailVO = BeanUtil.copy(materialCheckoutDetails, MaterialCheckoutDetailVO.class);
        materialCheckoutDetailVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, materialCheckoutDetailVO.getMaterialType()));
        return materialCheckoutDetailVO;
    }

    public PageResult<MaterialCheckoutRecordVO> getMaterialOutboundList(MaterialCheckoutRecordQueryDTO dto) {
        MPJLambdaWrapper<MaterialCheckoutRecord> wrapper = new MPJLambdaWrapper<>();
        SearchUtil.timeRangeSearch(wrapper, MaterialCheckoutRecord::getCheckoutTime, dto.getCheckoutStartDate(), dto.getCheckoutEndDate());
        wrapper.selectAll(MaterialCheckoutRecord.class)
                .eq(!CommonUtil.isNull(dto.getProjectId()), MaterialCheckoutRecord::getProjectId, dto.getProjectId())
                .eq(MaterialCheckoutRecord::getAuditStatus, ApprovalStatus.APPROVALED.getCode())
                .eq(MaterialCheckoutRecord::getApprovalStatus, AuditStatus.APPROVALED.getCode())
                .eq(!CommonUtil.isNull(dto.getCheckoutStatus()), MaterialCheckoutRecord::getCheckoutStatus, dto.getCheckoutStatus())
                .orderByDesc(MaterialCheckoutRecord::getUpdateTime);

        List<MaterialCheckoutRecord> materialCheckoutRecords = materialCheckoutRecordMapper.selectList(wrapper);
        Map<String, Project> projectDataMap = projectService.getProjectDataMap();

        List<MaterialCheckoutRecordVO> materialCheckoutRecordVOS = BeanUtil.copyList(materialCheckoutRecords, MaterialCheckoutRecordVO.class);
        List<MaterialCheckoutRecordVO> collect = materialCheckoutRecordVOS.stream().peek(item -> {
            if (!CommonUtil.isNull(item.getProjectId())) {
                Set<String> strings = projectDataMap.keySet();
                if (strings.contains(item.getProjectId())) {
                    item.setProjectName(projectDataMap.get(item.getProjectId()).getProjectName());
                }
            }
            if (!CommonUtil.isNull(item.getCompile())) {
                item.setCompile(userService.getUserInfoByID(item.getCompile()).getCHName());
            }
            if (!CommonUtil.isNull(item.getChecker())) {
                item.setChecker(userService.getUserInfoByID(item.getChecker()).getCHName());
            }
            if (!CommonUtil.isNull(item.getApprover())) {
                item.setApprover(userService.getUserInfoByID(item.getApprover()).getCHName());
            }
            if (!CommonUtil.isNull(item.getIssuedBy())) {
                item.setIssuedBy(userService.getUserInfoByID(item.getIssuedBy()).getCHName());
            }
            if (!CommonUtil.isNull(item.getSponsor())) {
                item.setSponsor(userService.getUserInfoByID(item.getSponsor()).getCHName());
            }
            item.setTaxMethodText(EnumUtil.getValue(TaxMethod.class, item.getTaxMethod()));
            //根据id查询 出库详情，判断是否已经出库
            MPJLambdaWrapper<MaterialCheckoutDetail> checkoutDetailMPJLambdaWrapper = new MPJLambdaWrapper<>();
            checkoutDetailMPJLambdaWrapper.select(MaterialCheckoutDetail::getReceiveState)
                    .eq(!CommonUtil.isNull(item.getId()), MaterialCheckoutDetail::getMaterialCheckoutRecordId, item.getId());
            List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(checkoutDetailMPJLambdaWrapper);
            if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
                Integer receiveState = materialCheckoutDetails.get(0).getReceiveState();
                if (CommonUtil.isNull(receiveState)) {
                    item.setCheckOut(false);
                } else {
                    if (receiveState.equals(ReceiveState.UNRECEIVE.getCode())) {
                        item.setCheckOut(false);
                    } else {
                        item.setCheckOut(true);
                    }
                }
            } else {
                item.setCheckOut(false);
            }
        }).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }


    /**/
    public boolean startCheckoutWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<MaterialCheckoutRecord> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("audit_status", "3")
                .set("instance_code", dto.getInstanceCode())
                .eq("id", dto.getKeyId());
        return materialCheckoutRecordMapper.update(new MaterialCheckoutRecord(), updateWrapper) > 0;
    }

    //audit_status   approval_status
    public boolean updateCheckoutWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<MaterialCheckoutRecord> updateWrapper = new UpdateWrapper<>();
        if ("true".equals(dto.getResult())) {
            updateWrapper.set("approval_status", "1");
            updateWrapper.set("approver", ThreadLocalUser.get().getUserId());
            updateWrapper.set("checkout_status", "0");
        } else {
            updateWrapper.set("approval_status", "2");
        }
        updateWrapper.eq("id", dto.getKeyId());
        return materialCheckoutRecordMapper.update(new MaterialCheckoutRecord(), updateWrapper) > 0;
    }

    public boolean reviewCheckoutWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<MaterialCheckoutRecord> updateWrapper = new UpdateWrapper<>();
        if ("true".equals(dto.getResult())) {
            updateWrapper.set("audit_status", "1");
            updateWrapper.set("checker", ThreadLocalUser.get().getUserId());
            updateWrapper.set("approval_status", "3");
        } else {
            updateWrapper.set("audit_status", "2");
        }
        updateWrapper.eq("id", dto.getKeyId());
        return materialCheckoutRecordMapper.update(new MaterialCheckoutRecord(), updateWrapper) > 0;
    }

    public boolean endCheckoutWorkFlow(StartContractListWorkFlow dto) {
        return true;
    }

    public Boolean materialCheckoutIsCheck(MaterialCheckoutDTO dto) {
        boolean flag = false;
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .eq(CommonUtil.isNull(dto.getId()), MaterialCheckoutDetail::getMaterialCheckoutRecordId, dto.getId());
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(materialCheckoutDetails)) {
            flag = true;
        }
        return flag;
    }

    public MaterialCheckoutRecordVO getMaterialCheckoutById(MaterialCheckoutQuerySingleDTO dto) {
        MaterialCheckoutRecord materialCheckoutRecord = materialCheckoutRecordMapper.selectById(dto.getId());
        MaterialCheckoutRecordVO copy = BeanUtil.copy(materialCheckoutRecord, MaterialCheckoutRecordVO.class);
        if (!CommonUtil.isNull(copy.getApprovalStatus())) {
            copy.setApprovalStatusText(EnumUtil.getValue(ApprovalStatus.class, copy.getApprovalStatus()));
        }
        ProjectVO projectVO = projectService.getById(copy.getProjectId());
        String projectName = projectVO.getProjectName();
        copy.setProjectName(projectName);
        if (!CommonUtil.isNull(copy.getTaxMethod())) {
            copy.setTaxMethodText(EnumUtil.getValue(TaxMethod.class, copy.getTaxMethod()));
        }
        return copy;
    }


    public List<MaterialNameInCheckoutVO> getMaterialInCheckout(MaterialNameInCheckoutDTO dto) {
        //根据项目id和类型 查询出库回显
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialCheckoutDetail.class)
                .select(MaterialCheckoutRecord::getProjectId)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialCheckoutDetail::getMaterialType, dto.getMaterialType())
                .leftJoin(MaterialCheckoutRecord.class, MaterialCheckoutRecord::getId, MaterialCheckoutDetail::getMaterialCheckoutRecordId)
                .eq(!CommonUtil.isNull(dto.getProjectId()), MaterialCheckoutRecord::getProjectId, dto.getProjectId());
        List<MaterialNameInCheckoutVO> list = materialCheckoutDetailMapper.selectJoinList(MaterialNameInCheckoutVO.class, wrapper);
        list = list.stream().distinct().collect(Collectors.toList());
        return list;
    }


    public List<MaterialNumberSelectVO> getMaterialNumberSelect(String projectId, Integer materialType) {
        MPJLambdaWrapper<MaterialCheckoutDetail> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(MaterialCheckoutDetail::getId, MaterialCheckoutDetail::getMaterialNumber)
                .select(MaterialCheckoutRecord::getProjectId)
                .eq(!CommonUtil.isNull(materialType), MaterialCheckoutDetail::getMaterialType, materialType)
                .eq(!CommonUtil.isNull(projectId), MaterialCheckoutRecord::getProjectId, projectId)
                .leftJoin(MaterialCheckoutRecord.class, MaterialCheckoutRecord::getId, MaterialCheckoutDetail::getMaterialCheckoutRecordId);
        List<MaterialCheckoutDetail> materialCheckoutDetails = materialCheckoutDetailMapper.selectJoinList(MaterialCheckoutDetail.class, wrapper);
        return BeanUtil.copyList(materialCheckoutDetails, MaterialNumberSelectVO.class);
    }


    public void exportMaterialCheckoutWord(HttpServletResponse response, @RequestBody MaterialCheckoutQuerySingleDTO dto) {
        MaterialCheckoutRecordVO materialCheckoutRecordVO = getMaterialCheckoutById(dto);

        MaterialCheckoutDetailQueryDTO queryDTO = new MaterialCheckoutDetailQueryDTO();
        queryDTO.setId(materialCheckoutRecordVO.getId());
        queryDTO.setPageSize(500);
        PageResult<MaterialCheckoutDetailVO> materialCheckoutDetailListPage = getMaterialCheckoutDetailList(queryDTO);
        List<MaterialCheckoutDetailVO> checkoutDetailListPageList = materialCheckoutDetailListPage.getList();
        List<MaterialCheckoutDetailListVO> collect = checkoutDetailListPageList.stream().map(item -> MaterialCheckoutDetailListVO.builder()
                .materialName(item.getMaterialName())
                .specification(item.getSpecification())
                .measuringUnit(item.getMeasuringUnit())
                .actualPickedQuantity(NumberConvertUtil.longConvertToString(item.getActualPickedQuantity(), 100))
                .money(NumberConvertUtil.longConvertToString(item.getMoney(), 100))
                .applyQuantity(NumberConvertUtil.longConvertToString(item.getApplyQuantity(), 100))
                .materialTotalPrice(NumberConvertUtil.longConvertToString(item.getMaterialTotalPrice(), 100))
                .preTaxPrice(NumberConvertUtil.longConvertToString(item.getPreTaxPrice(), 10000))
                .tax(NumberConvertUtil.longConvertToString(item.getTax(), 100))
                .taxRate(NumberConvertUtil.longConvertToString(item.getTaxRate(), 100))
                .pickedQuantity(NumberConvertUtil.longConvertToString(item.getPickedQuantity(), 100))
                .quantityRequired(NumberConvertUtil.longConvertToString(item.getPickedQuantity(), 100)).build()).collect(Collectors.toList());

        MaterialCheckoutWordExportVO exportVO = BeanUtil.copy(materialCheckoutRecordVO, MaterialCheckoutWordExportVO.class);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = simpleDateFormat.format(materialCheckoutRecordVO.getRequisitionTime());
        exportVO.setRequisitionTime(date);
        Map<String, Object> dataMap = WordDataListUtil.getDataMap(exportVO);
        List<Map<String, String>> dataMapList = WordDataListUtil.getDataMapList(collect);
        dataMap.put("list", dataMapList);

        ClassPathResource resource = new ClassPathResource("static/template/word/物资限额领料单.docx");
        FileUtils.easyPoiExport(resource.getPath(), "tempDir", exportVO.getProjectName() + exportVO.getMaterialRequisitionNo() + ".docx", dataMap, response);
    }


    public void exportEngineeringMaterialConsumption(HttpServletResponse response, MaterialCheckoutRecordWordExportDTO dto) {
        MaterialCheckoutRecordQueryDTO materialCheckoutRecordQueryDTO = BeanUtil.copy(dto, MaterialCheckoutRecordQueryDTO.class);
        materialCheckoutRecordQueryDTO.setPageSize(500);
        materialCheckoutRecordQueryDTO.setCheckoutStatus(1);
        PageResult<MaterialCheckoutRecordVO> materialOutboundList = getMaterialOutboundList(materialCheckoutRecordQueryDTO);
        List<MaterialCheckoutRecordVO> materialOutboundListList = materialOutboundList.getList();

        List<MaterialCheckoutDetailWordExportVO> collect = new ArrayList<>();
        materialOutboundListList.stream().peek(item -> {
            MaterialCheckoutDetailQueryDTO materialCheckoutDetailQueryDTO = new MaterialCheckoutDetailQueryDTO();
            materialCheckoutDetailQueryDTO.setId(item.getId());
            materialCheckoutDetailQueryDTO.setPageSize(500);
            PageResult<MaterialCheckoutDetailVO> materialCheckoutDetailListPage = getMaterialCheckoutDetailList(materialCheckoutDetailQueryDTO);

            List<MaterialCheckoutDetailVO> materialCheckoutDetailList = materialCheckoutDetailListPage.getList();
            materialCheckoutDetailList.forEach(detail -> {
                MaterialCheckoutDetailWordExportVO vo = new MaterialCheckoutDetailWordExportVO();
                vo.setSerialNum("").setMaterialName(detail.getMaterialName())
                        .setSpecification(detail.getSpecification())
                        .setMeasuringUnit(detail.getMeasuringUnit())
                        .setPickedQuantity(NumberConvertUtil.longConvertToString(detail.getPickedQuantity(), 100))
                        .setPreTaxPrice(NumberConvertUtil.longConvertToString(detail.getPreTaxPrice(), 10000))
                        .setMoney(NumberConvertUtil.longConvertToString(detail.getMoney(), 100));
                collect.add(vo);
            });
        }).collect(Collectors.toList());
        List<Map<String, String>> dataMapList = WordDataListUtil.getDataMapList(collect);
        Map<String, Object> map = new HashMap<>(1);
        map.put("list", dataMapList);
        ClassPathResource pathResource = new ClassPathResource("static/template/word/工程材料耗用表.docx");
        FileUtils.easyPoiExport(pathResource.getPath(), "tempDir", "工程材料耗用表.docx", map, response);
    }
}
