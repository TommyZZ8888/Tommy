package com.vren.material.module.materialrenturn.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-14-14-03
 **/
@Data
public class MaterialNumberSelectVO {

    @ApiModelProperty("出库详情表id")
    private String id;

    @ApiModelProperty("物资编号")
    private String materialNumber;

}
