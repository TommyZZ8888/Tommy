package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  焊材导出vo
 */
@Data
public class WeldingMaterialsExportVO {

    @ExcelIgnore
    @ApiModelProperty("id")
    private String id;

    @ExcelProperty("序号")
    @ApiModelProperty("id")
    @ConversionNumber
    private Long idExport;

    @ExcelProperty("材料名称")
    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    @ExcelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    @ExcelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    @ExcelProperty("规格")
    private String size;


    @ApiModelProperty("单位")
    @ExcelProperty("单位")
    private String unit;

    @ExcelIgnore
    @ApiModelProperty("数量")
    private Integer count;

    @ExcelIgnore
    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ExcelProperty("总重")
    @ApiModelProperty("总重(根据重量和个数计算)")
    private Double totalWeight;


    @ApiModelProperty("技术标准")
    @ExcelProperty("技术标准")
    private String technicalStandards;


    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "交货时间", converter = DateConverter.class)
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    @ExcelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;

    @ApiModelProperty("序号")
    @ExcelIgnore
    private Integer serialNumber;
}
