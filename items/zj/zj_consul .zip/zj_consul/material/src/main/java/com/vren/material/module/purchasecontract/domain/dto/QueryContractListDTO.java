package com.vren.material.module.purchasecontract.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class QueryContractListDTO extends PageParam {

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("采购状态")
    private Integer purchaseStatus;

    @ApiModelProperty("项目需求计划编号")
    private String demandPlanNumber;

    @ApiModelProperty("供应商")
    private String supplierId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("合同编号")
    private String contractNo;
}
