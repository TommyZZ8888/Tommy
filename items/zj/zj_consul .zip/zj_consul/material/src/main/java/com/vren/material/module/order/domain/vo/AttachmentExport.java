package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.net.URL;

/**
 * @author GR
 * @time 2023-04-13-11-30
 **/
@Data
@Builder
public class AttachmentExport {

    @ApiModelProperty("附件")
    private URL attachment;
}
