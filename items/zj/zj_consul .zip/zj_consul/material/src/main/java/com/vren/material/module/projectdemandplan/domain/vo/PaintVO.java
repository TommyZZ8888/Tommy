package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class PaintVO {
    @ApiModelProperty("id")
    private String id;



    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("颜色")
    private String colour;
    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;
    @ConversionNumber
    @ApiModelProperty("面积")
    private Long area;

    @ApiModelProperty("执行标准")
    private String executiveStandards;
    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("材料类型")
    private Integer materialType;
    @ApiModelProperty("材料类型描述")
    private String materialTypeText;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;

    @ApiModelProperty("序号")
    private Integer serialNumber;
}
