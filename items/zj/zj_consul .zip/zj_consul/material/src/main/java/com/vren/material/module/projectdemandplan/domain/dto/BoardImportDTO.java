package com.vren.material.module.projectdemandplan.domain.dto;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-05-10-13-45
 **/
@Data
public class BoardImportDTO {

    @ApiModelProperty("序号")
    @ExcelProperty(value = "序号", index = 0)
    private String orderNumber;

//    @ApiModelProperty("件号")
//    @ExcelProperty(value = "件号",index = 1)
//    private String partNo;

    @ApiModelProperty("制造编号&件号")
    @ExcelProperty(value = "制造编号&件号", index = 1)
    private String manufacturingNumberPartNo;

    @ApiModelProperty("材料名称")
    @ExcelProperty(value = "材料名称", index = 2)
    private String materialName;

    @ApiModelProperty("厚度")
    @ExcelProperty(value = "厚度", index = 3)
    private String thickness;

    @ApiModelProperty("宽度")
    @ExcelProperty(value = "宽度", index = 4)
    private String width;

    @ApiModelProperty("长度")
    @ExcelProperty(value = "长度", index = 5)
    private String length;

    @ApiModelProperty("材质")
    @ExcelProperty(value = "材质", index = 6)
    private String texture;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量", index = 7)
    private String count;

    @ApiModelProperty("重量")
    @ExcelProperty(value = "重量", index = 8)
    private String weightImport;

    @ApiModelProperty("执行标准")
    @ExcelProperty(value = "执行标准", index = 9)
    private String enforceStandards;

    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "交货时间", index = 10)
    private String deliveryTime;

    @ApiModelProperty("交货地点")
    @ExcelProperty(value = "交货地点", index = 11)
    private String deliveryLocation;

    @ApiModelProperty("备注")
    @ExcelProperty(value = "备注", index = 12)
    private String remarks;

    @ApiModelProperty("比重")
    @ExcelProperty(value = "比重", index = 13)
    private String proportion;

    @ApiModelProperty("用料类型")
    @ExcelProperty(value = "用料类型", index = 14)
    private String ingredientsType;

    @ApiModelProperty("是否需要进行计算")
    @ExcelProperty(value = "是否常规计算", index = 15)
    private String isCalculate;

    @ApiModelProperty("标书价")
    @ExcelProperty(value = "标书价", index = 16)
    private String bidPrice;

    @ApiModelProperty("备件数量")
    @ExcelProperty(value = "备件数量", index = 17)
    private String sparePartsQuantity;

    @ApiModelProperty("单位")
    @ExcelProperty(value = "单位", index = 18)
    private String unit;

    @ApiModelProperty("规格")
    @ExcelIgnore
    private String specification;

    @ApiModelProperty("重量")
    @ExcelIgnore
    private Long weight;

}
