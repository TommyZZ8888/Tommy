package com.vren.material.module.productdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-25-09-13
 **/
@Data
public class MaterialTypeAndRemarkVO {

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("备注")
    private String remarks;

}
