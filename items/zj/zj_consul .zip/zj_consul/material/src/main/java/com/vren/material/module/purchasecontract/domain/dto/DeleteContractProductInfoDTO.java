package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @Description DeleteContractProductInfoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/5
 */
@Data
public class DeleteContractProductInfoDTO {

    @ApiModelProperty("产品详细id")
    private String id;

    @ApiModelProperty("物资类型")
    private Integer materialType;
}
