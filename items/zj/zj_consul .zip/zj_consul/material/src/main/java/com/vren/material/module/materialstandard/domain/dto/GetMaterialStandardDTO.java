package com.vren.material.module.materialstandard.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-10-10-50
 **/
@Data
public class GetMaterialStandardDTO extends PageParam {

    @ApiModelProperty("类型")
    private String materialType;

    @ApiModelProperty("材质")
    private String texture;

}
