package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author GR
 * @time 2023-04-13-15-38
 **/
@Data
public class QueryDTO {

    @ApiModelProperty("物资类型")
    @NotNull(message = "物资类型不能为空")
    private Integer materialType;

    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

}
