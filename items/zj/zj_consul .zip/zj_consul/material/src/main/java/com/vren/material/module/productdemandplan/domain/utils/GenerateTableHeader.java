package com.vren.material.module.productdemandplan.domain.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 耿让
 */
public class GenerateTableHeader {


    public static List<List<String>> generate(String param1,String param2,String param3,String param4){
        List<List<String>> headTitles = new ArrayList<>();

        ArrayList<String> a = new ArrayList<>();
        a.add(param1);
        a.add(" ");
        a.add(param2);
        a.add("序号");
        a.add("序号");

        ArrayList<String> b = new ArrayList<>();
        b.add(param1);
        b.add(" ");
        b.add(param2);
        b.add("件号");
        b.add("件号");

        ArrayList<String> c = new ArrayList<>();
        c.add(param1);
        c.add(" ");
        c.add(param2);
        c.add("材料名称");
        c.add("材料名称");

        ArrayList<String> d = new ArrayList<>();
        d.add(param1);
        d.add(" ");
        d.add(param2);
        d.add("规格(mm)");
        d.add("厚度");

        ArrayList<String> e= new ArrayList<>();
        e.add(param1);
        e.add(" ");
        e.add(param2);
        e.add("规格(mm)");
        e.add("宽度");

        ArrayList<String> f = new ArrayList<>();
        f.add(param1);
        f.add(" ");
        f.add(param2);
        f.add("规格(mm)");
        f.add("长度");

        ArrayList<String> g = new ArrayList<>();
        g.add(param1);
        g.add(" ");
        g.add(" ");
        g.add("材质");
        g.add("材质");

        ArrayList<String> h = new ArrayList<>();
        h.add(param1);
        h.add(" ");
        h.add(" ");
        h.add("数量("+param4+")");
        h.add("数量("+param4+")");

        ArrayList<String> i = new ArrayList<>();
        i.add(param1);
        i.add(" ");
        i.add(" ");
        i.add("重量（KG）");
        i.add("重量（KG）");

        ArrayList<String> j = new ArrayList<>();
        j.add(param1);
        j.add(" ");
        j.add(param3);
        j.add("执行标准");
        j.add("执行标准");

        ArrayList<String> k = new ArrayList<>();
        k.add(param1);
        k.add(" ");
        k.add(param3);
        k.add("交货时间");
        k.add("交货时间");

        ArrayList<String> l = new ArrayList<>();
        l.add(param1);
        l.add(" ");
        l.add(param3);
        l.add("交货地点");
        l.add("交货地点");

        ArrayList<String> m = new ArrayList<>();
        m.add(param1);
        m.add(" ");
        m.add(param3);
        m.add("备注");
        m.add("备注");

        headTitles.add(a);
        headTitles.add(b);
        headTitles.add(c);
        headTitles.add(d);
        headTitles.add(e);
        headTitles.add(f);
        headTitles.add(g);
        headTitles.add(h);
        headTitles.add(i);
        headTitles.add(j);
        headTitles.add(k);
        headTitles.add(l);
        headTitles.add(m);

        return headTitles;
    }

}
