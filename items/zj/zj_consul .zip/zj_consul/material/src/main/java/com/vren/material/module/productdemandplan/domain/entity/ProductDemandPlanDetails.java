package com.vren.material.module.productdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
@Api
@TableName("product_demand_plan_details")
public class ProductDemandPlanDetails {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("产品需求计划id")
    private String productDemandPlanId;

    @ApiModelProperty("产品ID")
    private String productInformationId;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;

    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("第四尺寸/外购标准")
    private String fourthSizeOutsourcingStandards;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("重量")
    @ConversionNumber
    private Long weight;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long demandProposalPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("材质")
    private String material;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;

    @ApiModelProperty("项目需求计划id")
    private String projectDemandPlanId;

}