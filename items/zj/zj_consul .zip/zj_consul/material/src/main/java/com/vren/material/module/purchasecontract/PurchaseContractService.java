package com.vren.material.module.purchasecontract;

import com.alibaba.excel.support.ExcelTypeEnum;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelUtil;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.identity.user.domain.entity.UserInfoEntity;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.Project;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.material.common.enums.FactoryEnum;
import com.vren.material.common.utils.BarCodeUtils;
import com.vren.material.common.utils.StreamFilter;
import com.vren.material.common.utils.SystemConfig;
import com.vren.material.common.utils.WriteCellUtil;
import com.vren.material.module.order.OrderService;
import com.vren.material.module.order.domain.entity.Order;
import com.vren.material.module.order.domain.entity.OrderDetail;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.projectdemandplan.ProjectDemandPlanService;
import com.vren.material.module.projectdemandplan.domain.dto.IdDTO;
import com.vren.material.module.projectdemandplan.domain.entity.ProjectDemandPlan;
import com.vren.material.module.projectdemandplan.domain.enums.DemandType;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.purchasecontract.domain.dto.*;
import com.vren.material.module.purchasecontract.domain.entity.ContractList;
import com.vren.material.module.purchasecontract.domain.entity.PurchaseStatusRecord;
import com.vren.material.module.purchasecontract.domain.entity.Supplier;
import com.vren.material.module.purchasecontract.domain.vo.*;
import com.vren.material.module.purchasecontract.mapper.ContractListMapper;
import com.vren.material.module.purchasecontract.mapper.PurchaseStatusRecordMapper;
import com.vren.material.module.purchasecontract.mapper.SupplierMapper;
import com.vren.material.module.purchasecontractprojectinfo.PurchaseContractProjectInfoService;
import com.vren.material.module.purchasecontractprojectinfo.domain.entity.PurchaseContractProjectInfoEntity;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsPaint;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsProductTotal;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsWeldingMaterials;
import com.vren.material.module.purchaseplan.domain.enums.PurchaseStateEnum;
import com.vren.material.module.purchaseplan.domain.vo.PurchasePlanDetailVO;
import com.vren.material.module.storage.domain.vo.WarehousingMaterialTypeVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class PurchaseContractService {

    @Autowired
    private ContractListMapper contractListMapper;

    @Autowired
    private PurchasePlanService purchasePlanService;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private PurchaseStatusRecordMapper purchaseStatusRecordMapper;

    @Autowired
    private UserService userService;


    @Autowired
    private ProjectDemandPlanService projectDemandPlanService;

    @Autowired
    private SupplierMapper supplierMapper;

    @Autowired
    private OrderService orderService;

    @Autowired
    private PurchaseContractProjectInfoService purchaseContractProjectInfoService;

    public ContractList selectContractListEntityById(String contractListId) {
        return contractListMapper.selectById(contractListId);
    }


    public List<ContractList> selectContractListEntityByContractNo(String contractListNo) {
        MPJLambdaWrapper<ContractList> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ContractList.class)
                .eq(ContractList::getContractNo, contractListNo)
                .eq(ContractList::getPurchaseStatus, 10);
        return contractListMapper.selectList(wrapper);
    }

    public Supplier selectSupplierEntityById(String supplierId) {
        return supplierMapper.selectById(supplierId);
    }


    public void editContractList(EditContractListDTO dto) {
        ContractList contractList = BeanUtil.copy(dto, ContractList.class);
        contractList.setStartTime(dto.getSTime());
        contractList.setEndTime(dto.getETime());
        contractList.setSupplierId(dto.getSupplier());
        Integer purchaseStatus = contractListMapper.selectById(dto.getId()).getPurchaseStatus();
        //更新采购合同时，不填合同编号不需要校重，否则就要校验
        QueryWrapper<ContractList> queryWrapper = new QueryWrapper<>();
        if (!CommonUtil.isNull(dto.getContractNo())) {
            queryWrapper.select("1").eq("contract_no", dto.getContractNo())
                    .notIn("id", dto.getId()).last(" limit 1 ");
            if (contractListMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("合同编号不能重复");
            }
            contractListMapper.updateById(contractList);
        } else {
            contractListMapper.updateById(contractList);
        }
        //如果采购状态更新，新增采购状态记录
        if (!CommonUtil.isNull(dto.getPurchaseStatus())) {
            if (!dto.getPurchaseStatus().equals(purchaseStatus)) {
                //采购状态变更了
                PurchaseStatusRecord purchaseStatusRecord = new PurchaseStatusRecord();
                purchaseStatusRecord.setContractListId(dto.getId());
                //操作人
//            log.info("用户id：{}",ThreadLocalUser.get().getUserId());
                purchaseStatusRecord.setOperator(ThreadLocalUser.get().getUserId());
                purchaseStatusRecord.setOperationTime(new Date());
                purchaseStatusRecord.setBeforeChange(purchaseStatus);
                purchaseStatusRecord.setAfterChange(dto.getPurchaseStatus());
                int insert = purchaseStatusRecordMapper.insert(purchaseStatusRecord);
                if (insert > 0) {
                    log.info("新增了一条采购状态操作记录");
                }
            }
        }
    }

    public ContractListVO getContractListById(GetOneOrDeleteDTO dto) {
        ContractListVO contractListVO = selectContractLisById(dto.getId());
        //时间格式
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        if (!CommonUtil.isNull(contractListVO.getStartTime())) {
            contractListVO.setSTime(format.format(contractListVO.getStartTime()));
        }
        if (!CommonUtil.isNull(contractListVO.getEndTime())) {
            contractListVO.setETime(format.format(contractListVO.getEndTime()));
        }
        //设置采购状态
        contractListVO.setPurchaseStatusText(EnumUtil.getValue(PurchaseStateEnum.class, contractListVO.getPurchaseStatus()));
        return contractListVO;
    }

    public ContractListVO selectContractLisById(String id) {
        ContractList contractList = contractListMapper.selectById(id);
        return BeanUtil.copy(contractList, ContractListVO.class);
    }

    public List<PurchaseStatusRecordVO> getPurchaseStatesRecord(GetPurchaseStatusRecordDTO dto) {
        /**
         * 根据合同清单id查询采购状态变化的记录情况
         * 根据操作时间排序
         */
        MPJLambdaWrapper<PurchaseStatusRecord> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchaseStatusRecord.class)
                .eq(!CommonUtil.isNull(dto.getContractListId()), PurchaseStatusRecord::getContractListId, dto.getContractListId())
                .orderByAsc(PurchaseStatusRecord::getOperationTime);
        List<PurchaseStatusRecord> purchaseStatusRecords = purchaseStatusRecordMapper.selectList(wrapper);
        List<PurchaseStatusRecordVO> purchaseStatusRecordVOS = BeanUtil.copyList(purchaseStatusRecords, PurchaseStatusRecordVO.class);
        purchaseStatusRecordVOS.stream().forEach(item -> {
            //设置操作人姓名
            UserInfoEntity userInfoByID = userService.getUserInfoByID(item.getOperator());
            if (!CommonUtil.isNull(userInfoByID)) {
                item.setOperatorName(userInfoByID.getCHName());
            }
            //设置采购状态的名称
            item.setBeforeChangeText(EnumUtil.getValue(PurchaseStateEnum.class, item.getBeforeChange()));
            item.setAfterChangeText(EnumUtil.getValue(PurchaseStateEnum.class, item.getAfterChange()));
        });
        return purchaseStatusRecordVOS;
    }


    public List<PurchasePlanDetailVO> getPurchasePlanDetail(PurchasePlanDetailDTO dto) {
        return purchasePlanService.getPurchasePlanDetail(dto.getPurchasePlanId(), dto.getMaterialType());
    }

    public List<PurchasePlanNumberInSelectVO> getPurchasePlanNumberInSelect(PurchasePlanNumberInSelectDTO dto) {
        //根据选择的项目和物资类型查询采购计划编号   purchasePlanNumber
        List<String> list = purchasePlanService.getPurchasePlanNumberInSelect(dto.getProjectIds(), dto.getMaterialType());
        ArrayList<PurchasePlanNumberInSelectVO> vos = new ArrayList<>();
        for (String purchasePlanNumber : list) {
            PurchasePlanNumberInSelectVO build = PurchasePlanNumberInSelectVO.builder().purchasePlanNumber(purchasePlanNumber).build();
            vos.add(build);
        }
        return vos;
    }

    public List<ContractNoAndIdVO> getContractNoAndId() {
        MPJLambdaWrapper<ContractList> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ContractList.class)
                .eq(ContractList::getPurchaseStatus, "10");
        List<ContractList> contractLists = contractListMapper.selectList(wrapper).stream().filter(StreamFilter.distinctByKey(ContractList::getContractNo)).collect(Collectors.toList());
        return BeanUtil.copyList(contractLists, ContractNoAndIdVO.class);
    }

    public List<ProjectInPurchasePlanVO> getProjectInPurchasePlan() {
        return purchasePlanService.getProjectInPurchasePlan();
    }


    public void export(HttpServletResponse response, ExportDTO dto) throws IOException {
        // 导出文件名称 ：  合同名称 +  项目名称 +  批次  +    物资类型    （询价单）
        String contractName = contractListMapper.selectById(dto.getContractListId()).getContractName();
        PurchaseContractProjectInfoEntity purchaseContractProjectInfoEntity = purchaseContractProjectInfoService.selectById(dto.getPurchaseContractProjectInfoId());
        String projectName = Optional.ofNullable(purchaseContractProjectInfoEntity).orElse(new PurchaseContractProjectInfoEntity()).getProjectName();

        if (MaterialType.PAINT.getCode().equals(dto.getMaterialType())) {
            List<PurchasePlanDetailsPaint> paints = purchasePlanService.getPaintByContractListId(dto.getContractListId());
            List<ContractProductPaintExportVO> list = BeanUtil.copyList(paints, ContractProductPaintExportVO.class);
            AtomicInteger num = new AtomicInteger();
            list.forEach(item -> {
                item.setNumber(num.incrementAndGet());
                if (!CommonUtil.isNull(item.getPurchaseArea())) {
                    item.setPurchaseAreaExport(item.getPurchaseArea().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDryFilmThickness())) {
                    item.setDryFilmThicknessExport(item.getDryFilmThickness().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getAmountOfPaint())) {
                    item.setAmountOfPaintExport(item.getAmountOfPaint().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTheoreticalDosage())) {
                    item.setTheoreticalDosageExport(item.getTheoreticalDosage().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getLossFactor())) {
                    item.setLossFactorExport(item.getLossFactor().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getVolumeSolidContent())) {
                    item.setVolumeSolidContentExport(item.getVolumeSolidContent().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDensity())) {
                    item.setDensityExport(item.getDensity().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getUnitPriceDiluentIncludingTax())) {
                    item.setUnitPriceDiluentIncludingTaxExport(item.getUnitPriceDiluentIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getUnitPricePaintIncludingTax())) {
                    item.setUnitPricePaintIncludingTaxExport(item.getUnitPricePaintIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDilutionDose())) {
                    item.setDilutionDoseExport(item.getDilutionDose().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTotalUnitPriceIncludingTax())) {
                    item.setTotalUnitPriceIncludingTaxExport(item.getTotalUnitPriceIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTotalSquarePriceIncludingTax())) {
                    item.setTotalSquarePriceIncludingTaxExport(item.getTotalSquarePriceIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTaxRate())) {
                    item.setTaxRateExport(item.getTaxRate().doubleValue() / 100);
                }
            });
            long sum = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseArea())).mapToLong(ContractProductPaintExportVO::getPurchaseArea).sum();
            HashMap<String, Object> data = new HashMap<>();
            data.put("sum", sum / 100);
            InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/paintList.xlsx");
            ExcelExportService exportService = new ExcelExportService(contractName + "-" + projectName + EnumUtil.getValue(MaterialType.class, dto.getMaterialType()) + "询价单", response, resourceAsStream);
            exportService.fill(data, "询价单");
            list.stream().peek(item -> {
                try {
                    BufferedImage image = BarCodeUtils.getBarCodeImage(item.getWarehousingNo());
                    item.setBarcode(WriteCellUtil.fillImage(image, "", 5, 5, 5, 5));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }).collect(Collectors.toList());
            exportService.fill(new FillWrapper("list", list), "询价单");
            exportService.export();
        } else {
            List<ContractProductDetailsExportVO> list = null;
            //根据合同id，项目id 查询所有的产品采购详情
            if (MaterialType.WELDING_MATERIALS.getCode().equals(dto.getMaterialType())) {
                List<PurchasePlanDetailsWeldingMaterials> weld = purchasePlanService.getWeldByContractListId(dto.getContractListId());
                list = BeanUtil.copyList(weld, ContractProductDetailsExportVO.class);
            } else {
                List<PurchasePlanDetailsProductTotal> productTotals = purchasePlanService.getProductTotalByContractListId(dto.getContractListId());
                list = BeanUtil.copyList(productTotals, ContractProductDetailsExportVO.class);
            }
            AtomicInteger num = new AtomicInteger();

            list.forEach(item -> {
                item.setNumber(num.incrementAndGet());
                //辅材第二个空填写重量，其他第一单位重量
                //需要处理的四个字段  useMaterialUnit   purchaseAmountExport  unitTwo   purchaseAmount
                if (MaterialType.AUXILIARY_MATERIALS.getCode().equals(item.getMaterialType())) {
                    //第一单位 放数量和用料单位
                    if (!CommonUtil.isNull(item.getPurchaseAmount())) {
                        item.setPurchaseAmountExport((double) (item.getPurchaseAmount() / 100));
                    }
                    item.setUseMaterialUnit(item.getUseMaterialUnit());
                } else {
                    if (!CommonUtil.isNull(item.getPurchaseWeight())) {
                        item.setPurchaseAmountExport(item.getPurchaseWeight().doubleValue() / 100);
                    }
                    String unitOne = item.getUseMaterialUnit();
                    item.setUseMaterialUnit(item.getUnitTwo());
                    //第二单位填写数量
                    if (!CommonUtil.isNull(item.getPurchaseAmount())) {
                        item.setPurchaseAmountExportTwo((double) (item.getPurchaseAmount() / 100));
                    }
                    item.setUnitTwo(unitOne);
                }
                if (FactoryEnum.PRESSURE_VESSEL.getCode().equals(SystemConfig.getFactoryNum()) && MaterialType.FORGE_PIECE.getCode().equals(item.getMaterialType())) {
                    long purchaseWeight = item.getPurchaseWeight() == null ? 0 : item.getPurchaseWeight();
                    item.setPurchaseAmountExportTwo(((double) purchaseWeight / 100));
                    long purchaseAmount = item.getPurchaseAmount() == null ? 0 : item.getPurchaseAmount();
                    item.setPurchaseAmountExport(((double) purchaseAmount / 100));
                }
                //几个金额倍率转换
                if (!CommonUtil.isNull(item.getPreTaxPrice())) {
                    item.setPreTaxPriceExport(item.getPreTaxPrice().doubleValue() / 10000);
                }
                if (!CommonUtil.isNull(item.getUnitPriceWithTax())) {
                    item.setUnitPriceWithTaxExport(item.getUnitPriceWithTax().doubleValue() / 10000);
                }
                if (!CommonUtil.isNull(item.getTotalPriceExcludingTax())) {
                    item.setTotalPriceExcludingTaxExport(item.getTotalPriceExcludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTotalPriceIncludingTax())) {
                    item.setTotalPriceIncludingTaxExport(item.getTotalPriceIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTaxRate())) {
                    item.setTaxRateExport(item.getTaxRate().doubleValue() / 100);
                }

                if (MaterialType.WELDING_MATERIALS.getCode().equals(dto.getMaterialType())) {
                    item.setUseMaterialUnit(item.getUnitTwo());
                    item.setUnitTwo("");
                    item.setPurchaseAmountExportTwo(null);
                } else {
                    //解析长度、宽度与厚度
                    if (!CommonUtil.isNull(item.getIngredientsType())) {
                        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                        Class<? extends ComputerHandler> clazz = computerType.getClazz();
                        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                        Map<String, String> map = bean.analysis(item.getSize(), item.getIngredientsType());
                        if (!CommonUtil.isNull(map)) {
                            String thickness = CommonUtil.isNull(map.get("thickness")) ? null : map.get("thickness");
                            String length = CommonUtil.isNull(map.get("length")) ? null : map.get("length");
                            String width = CommonUtil.isNull(map.get("width")) ? null : map.get("width");
                            item.setThickness(thickness);
                            item.setLength(length);
                            item.setWidth(width);
                        }
                    }
                }
            });
            Double sum = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseAmountExport())).mapToDouble(ContractProductDetailsExportVO::getPurchaseAmountExport).sum();
            Double sumWeight = list.stream().filter(item -> !CommonUtil.isNull(item.getPurchaseAmount())).mapToDouble(ContractProductDetailsExportVO::getPurchaseAmount).sum();
            HashMap<String, Object> data = new HashMap<>();
            data.put("sum", sum);
            data.put("sumWeight", sumWeight / 100);
            InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/detailedList.xlsx");
            ExcelExportService exportService = new ExcelExportService(contractName + "-" + projectName + EnumUtil.getValue(MaterialType.class, dto.getMaterialType()) + "询价单", response, resourceAsStream);
            exportService.fill(data, "清单");

            list.stream().peek(item -> {
                try {
                    if (StringUtils.isBlank(item.getWarehousingNo())) {
                        return;
                    }
                    BufferedImage image = BarCodeUtils.getBarCodeImage(item.getWarehousingNo());
                    item.setBarcode(WriteCellUtil.fillImage(image, "", 5, 5, 5, 5));
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }).collect(Collectors.toList());
            exportService.fill(new FillWrapper("list", list), "清单");
            exportService.export();
        }
    }


    public void productTotalImport(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        LinkedList<ContractProductDetailsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ContractProductDetailsImportVO.class, "清单");
        file.getInputStream().close();
        for (int i = 0; i < 1; i++) {
            list.poll();
        }
        list.removeLast();

        list.forEach(item -> {
            PurchasePlanDetailsProductTotal purchasePlanDetailsProductTotal = purchasePlanService.selectProductTotalByWarehousingNo(item.getWarehousingNo());
            Integer materialType = purchasePlanDetailsProductTotal.getMaterialType();
            if (MaterialType.AUXILIARY_MATERIALS.getCode().equals(materialType)) {
                if (!CommonUtil.isNull(item.getPurchaseAmountExport())) {
                    item.setPurchaseAmount((item.getPurchaseAmountExport()));
                }
            } else if (FactoryEnum.PRESSURE_VESSEL.getCode().equals(SystemConfig.getFactoryNum()) && MaterialType.FORGE_PIECE.getCode().equals(materialType)) {
                String unitOne = item.getUseMaterialUnit();
                item.setUseMaterialUnit(item.getUnitTwo());
                item.setPurchaseWeight(item.getPurchaseAmountExportTwo());
                item.setUnitTwo(unitOne);
                item.setPurchaseAmount(item.getPurchaseAmountExport());
            } else {
                if (!CommonUtil.isNull(item.getPurchaseAmountExport())) {
                    item.setPurchaseWeight(item.getPurchaseAmountExport());
                }
                String unitTwo = item.getUnitTwo();
                item.setUnitTwo(item.getUseMaterialUnit());
                if (!CommonUtil.isNull(item.getPurchaseAmountExportTwo())) {
                    item.setPurchaseAmount(item.getPurchaseAmountExportTwo());
                }
                item.setUseMaterialUnit(unitTwo);
            }
        });

        //2023/03/28  导入时，根据长度、厚度和宽度生成规格，   规格、材质、执行标准、单位、数量都在导入的时候可编辑
        List<PurchasePlanDetailsProductTotal> productTotals = BeanUtil.copyList(list, PurchasePlanDetailsProductTotal.class);
        productTotals.forEach(productTotal -> productTotal.setContractListId(dto.getContractListId()));
        purchasePlanService.batchUpdateProductTotal(productTotals);
    }

    public void weldImport(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        LinkedList<ContractProductDetailsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ContractProductDetailsImportVO.class, "清单");
        file.getInputStream().close();
        for (int i = 0; i < 1; i++) {
            list.poll();
        }
        list.removeLast();
        list.forEach(item -> {
            if (!CommonUtil.isNull(item.getPurchaseAmountExport())) {
                item.setPurchaseAmount(item.getPurchaseAmountExport());
            }
            if (!CommonUtil.isNull(item.getPurchaseAmountExport())) {
                item.setPurchaseWeight(item.getPurchaseAmountExport());
            }
            item.setUnitTwo(item.getUseMaterialUnit());
        });
        List<PurchasePlanDetailsWeldingMaterials> welds = BeanUtil.copyList(list, PurchasePlanDetailsWeldingMaterials.class);
        welds.forEach(weld -> weld.setContractListId(dto.getContractListId()));
        purchasePlanService.batchUpdateWeld(welds);
    }

    public void paintImport(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        LinkedList<ContractProductPaintImportVO> list = ExcelUtil.readSheet(file.getInputStream(), ContractProductPaintImportVO.class, "询价单");
        file.getInputStream().close();
        list.removeLast();
        List<PurchasePlanDetailsPaint> paints = BeanUtil.copyList(list, PurchasePlanDetailsPaint.class);
        paints.forEach(item -> {
            if (!CommonUtil.isNull(item.getPreTaxPrice()) && !CommonUtil.isNull(item.getUnitPricePaintIncludingTax())) {
                item.setTax(item.getUnitPricePaintIncludingTax() - item.getPreTaxPrice());
            }
            //根据模板文件进行计算
            //油漆用量
            if (!CommonUtil.isNull(item.getDryFilmThickness()) && !CommonUtil.isNull(item.getVolumeSolidContent()) && !CommonUtil.isNull(item.getDensity())) {
                double theoreticalDosage = ((item.getDryFilmThickness().doubleValue() / 100) / 1000 / (item.getVolumeSolidContent().doubleValue() / 100)) * (item.getDensity().doubleValue() / 100);
                if (!CommonUtil.isNull(item.getPurchaseArea()) && !CommonUtil.isNull(item.getLossFactor())) {
                    double amountOfPaint = (item.getPurchaseArea().doubleValue() / 100) * theoreticalDosage * (item.getLossFactor().doubleValue() / 100);
                    double dilutionDose = amountOfPaint * 25;
                    if (!CommonUtil.isNull(item.getUnitPricePaintIncludingTax())) {
                        double totalUnitPriceIncludingTax = (amountOfPaint * (item.getUnitPricePaintIncludingTax().doubleValue() / 100)) / (item.getPurchaseArea().doubleValue() / 100);
                        double totalSquarePriceIncludingTax = amountOfPaint * (item.getUnitPricePaintIncludingTax().doubleValue() / 100);
                        item.setTotalUnitPriceIncludingTax((long) (totalUnitPriceIncludingTax * 100));
                        item.setTotalSquarePriceIncludingTax((long) (totalSquarePriceIncludingTax * 100));
                    }
                    item.setDilutionDose((long) (dilutionDose * 100));
                    item.setAmountOfPaint((long) (amountOfPaint * 100));
                }
                //计算值太小*10000
                item.setTheoreticalDosage((long) (theoreticalDosage * 10000));
            }
            item.setContractListId(dto.getContractListId());
        });
        purchasePlanService.batchUpdatePaint(paints);
    }

    public void importPurchaseContractDetail(MultipartFile file, ImportPurchaseContractDetailDTO dto) throws IOException {
        switch (EnumUtil.getEnumByCode(MaterialType.class, dto.getMaterialType())) {
            case WELDING_MATERIALS:
                //焊材
                weldImport(file, dto);
                break;
            case PAINT:
                //油漆
                paintImport(file, dto);
                break;
            default:
                productTotalImport(file, dto);
                break;
        }
    }

    public PageResult<SupplierVO> getSupplierList(SupplierListDTO dto) {
        Page<Supplier> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<Supplier> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(Supplier.class)
                .like(!CommonUtil.isNull(dto.getSupplierName()), Supplier::getSupplierName, dto.getSupplierName())
                .like(!CommonUtil.isNull(dto.getSupplierNumber()), Supplier::getSupplierNumber, dto.getSupplierNumber())
                .like(!CommonUtil.isNull(dto.getContacts()), Supplier::getContacts, dto.getContacts())
                .like(!CommonUtil.isNull(dto.getBusinessAddress()), Supplier::getBusinessAddress, dto.getBusinessAddress())
                .orderByDesc(Supplier::getCreateTime);
        IPage<SupplierVO> supplierVOIPage = supplierMapper.selectJoinPage(page, SupplierVO.class, wrapper);
        return PageUtil.convert2PageResult(supplierVOIPage);
    }

    public boolean addOrEditSupplier(UpdateSupplierDTO dto) {
        Supplier supplier = BeanUtil.copy(dto, Supplier.class);
        //分供方编号不能重复
        QueryWrapper<Supplier> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(dto.getSupplierNumber()), "supplier_number", dto.getSupplierNumber())
                .isNotNull("supplier_number")
                .last(" limit 1");
        QueryWrapper<Supplier> wrapper = new QueryWrapper<>();
        wrapper.select("1")
                .eq(!CommonUtil.isNull(dto.getSupplierNumber()), "supplier_name", dto.getSupplierName())
                .isNotNull("supplier_name")
                .last(" limit 1");
        if (!CommonUtil.isNull(dto.getId())) {
            //更新
            queryWrapper.notIn("id", dto.getId());
            wrapper.notIn("id", dto.getId());
            Long count = supplierMapper.selectCount(queryWrapper);
            Long countNum = supplierMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("分供方编号不能重复");
            }
            if (countNum > 0) {
                throw new RuntimeException("分供方名称不能重复");
            }
            return supplierMapper.updateById(supplier) > 0;
        } else {
            //新增
            Long count = supplierMapper.selectCount(queryWrapper);
            Long countNum = supplierMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("分供方编号不能重复");
            }
            if (countNum > 0) {
                throw new RuntimeException("分供方名称不能重复");
            }
            return supplierMapper.insert(supplier) > 0;
        }
    }

    public SupplierVO getSupplierById(GetOneOrDeleteDTO dto) {
        Supplier supplier = this.getSupplierById(dto.getId());
        return BeanUtil.copy(supplier, SupplierVO.class);
    }

    public Supplier getSupplierById(String id) {
        return supplierMapper.selectById(id);
    }

    public boolean deleteSupplier(GetOneOrDeleteDTO dto) {
        return supplierMapper.deleteById(dto.getId()) > 0;
    }

    public List<SupplierSelectVO> getSupplierSelectVO() {
        MPJLambdaWrapper<Supplier> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(Supplier::getId, Supplier::getSupplierName);
        List<Supplier> suppliers = supplierMapper.selectList(wrapper);
        return BeanUtil.copyList(suppliers, SupplierSelectVO.class);
    }

    public ResponseResult<String> importSupplier(MultipartFile file) throws IOException {
        LinkedList<ImportSupplier> importSuppliers = ExcelUtil.readSheet(file.getInputStream(), ImportSupplier.class, "供应商");
        List<Supplier> suppliers = BeanUtil.copyList(importSuppliers, Supplier.class);
        AtomicBoolean flag = new AtomicBoolean(false);
        suppliers.forEach(
                item -> {
                    if (CommonUtil.isNull(item.getSupplierName())) {
                        flag.set(true);
                    }
                }
        );
        if (flag.get()) {
            return ResponseResult.error("分供方名称为空,导入失败", "分供方名称为空,导入失败");
        }
        MPJLambdaWrapper<Supplier> wrapper = new MPJLambdaWrapper<>();
        if (CommonUtil.listIsNotEmpty(suppliers)) {
            List<String> collect = suppliers.stream().map(Supplier::getSupplierName).collect(Collectors.toList());
            wrapper.select(Supplier::getSupplierName)
                    .in(CommonUtil.listIsNotEmpty(collect), Supplier::getSupplierName, collect);
            List<Supplier> list = supplierMapper.selectList(wrapper);
            if (CommonUtil.listIsNotEmpty(list)) {
                List<String> stringList = list.stream().map(Supplier::getSupplierName).collect(Collectors.toList());
                return ResponseResult.error("分供方名称" + stringList + "已存在,导入失败", "分供方名称" + stringList + "已存在,导入失败");
            }
            if (supplierMapper.insertBatchSomeColumn(suppliers) > 0) {
                return ResponseResult.success("导入成功", "导入成功");
            }
        } else {
            return ResponseResult.error("模板数据为空", "模板数据为空");
        }
        return ResponseResult.error("导入失败", "导入成功");
    }

    public void downloadTemplateFile(HttpServletResponse response) {
        OutputStream outputStream = null;
        InputStream resourceAsStream = null;
        try {
            resourceAsStream = this.getClass().getResourceAsStream("/static/template/供应商模板.xlsx");
            response.setContentType("application/vnd.ms-excel");
            String fileName = URLEncoder.encode("供应商模板", StandardCharsets.UTF_8).replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName + ExcelTypeEnum.XLSX.getValue());
            outputStream = response.getOutputStream();
            byte[] bytes = new byte[1024];
            int len;
            while ((len = resourceAsStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, len);
            }
            outputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (!CommonUtil.isNull(outputStream)) {
                    outputStream.close();
                }
                if (!CommonUtil.isNull(resourceAsStream)) {
                    resourceAsStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public SupplierAndProjectVO getSupplierAndProject(GetOneOrDeleteDTO dto) {
        List<ContractList> contractLists = selectContractListEntityByContractNo(dto.getContractListNo());
        List<ProjectIdAndNameVO> collect = new ArrayList<>();
        for (ContractList contract : contractLists) {
            List<PurchasePlan> purchasePlanList;
            List<String> purchasePlanDetailsIds = new ArrayList<>();
            List<Order> orderList = orderService.selectListByContractListId(contract.getId());
            for (Order order : orderList) {
                List<OrderDetail> orderDetails = orderService.selectDetailListByOrderId(order.getId());
                purchasePlanDetailsIds.addAll(orderDetails.stream().filter(item -> StringUtils.isNotBlank(item.getPurchasePlanDetailId())).map(OrderDetail::getPurchasePlanDetailId).collect(Collectors.toList()));
            }
            if (CommonUtil.listIsNotEmpty(purchasePlanDetailsIds)) {
                purchasePlanList = purchasePlanService.getPurchasePlanListByDetailIds(purchasePlanDetailsIds, contract.getMaterialType());
            } else {
                purchasePlanList = purchasePlanService.getPurchasePlanListByContractListId(contract.getId(), contract.getMaterialType());
            }

            List<ProjectIdAndNameVO> projectIdAndNameVOS = purchasePlanList.stream().filter(CommonUtil::isNotNull).map(item -> {
                ProjectIdAndNameVO vo = new ProjectIdAndNameVO();
                vo.setPurchasePlanId(item.getId());
                vo.setProjectNameAndBatch(item.getProjectName() + "-" + item.getBatch());
                vo.setContractListId(contract.getId());
                vo.setContractListNo(contract.getContractNo());
                vo.setMaterialType(contract.getMaterialType());
                vo.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));

                Supplier supplier = supplierMapper.selectById(contract.getSupplierId());
                SupplierSelectVO supplierSelectVO = new SupplierSelectVO();
                supplierSelectVO.setId(Optional.ofNullable(supplier).orElse(new Supplier()).getId());
                supplierSelectVO.setSupplierName(Optional.ofNullable(supplier).orElse(new Supplier()).getSupplierName());
                vo.setSupplierSelectVO(supplierSelectVO);
                return vo;
            }).collect(Collectors.toList());
            collect.addAll(projectIdAndNameVOS);
        }
        SupplierAndProjectVO supplierAndProjectVO = new SupplierAndProjectVO();
        supplierAndProjectVO.setProjects(collect);
        return supplierAndProjectVO;
    }


    public SupplierVO selectSupplierById(String id) {
        Supplier supplier = supplierMapper.selectById(id);
        return BeanUtil.copy(supplier, SupplierVO.class);
    }

    public boolean startContractListWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<ContractList> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", "0")
                .set("instance_code", dto.getInstanceCode())
                .eq("id", dto.getKeyId());
        return contractListMapper.update(new ContractList(), updateWrapper) > 0;
    }

    public boolean updateContractListWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<ContractList> updateWrapper = new UpdateWrapper<>();
        if ("true".equals(dto.getResult())) {
            updateWrapper.set("state", "1");
        } else {
            updateWrapper.set("state", "2");
        }
        updateWrapper.eq("id", dto.getKeyId());
        return contractListMapper.update(new ContractList(), updateWrapper) > 0;
    }

    public boolean endContractListWorkFlow(StartContractListWorkFlow dto) {
        return true;
    }

    public String getContractNoByMaterialNumber(String materialNumber, Integer materialType) {
        String contractListId = purchasePlanService.getContractListIdByMaterialNumber(materialNumber, materialType);
        if (!CommonUtil.isNull(contractListId)) {
            MPJLambdaWrapper<ContractList> wrapper = new MPJLambdaWrapper<>();
            wrapper.select(ContractList::getContractNo)
                    .eq(ContractList::getId, contractListId);
            return contractListMapper.selectOne(wrapper).getContractNo();
        }
        return null;
    }


    public PageResult<ContractProductDetailsExportVO> getPurchaseContractListDetail(ContractListDetailDTO dto) {
        if (MaterialType.PAINT.getCode().equals(dto.getMaterialType())) {
            //使用油漆清单模板
            List<PurchasePlanDetailsPaint> paints = purchasePlanService.getPaintByContractListId(dto.getContractListId());
            List<ContractProductPaintExportVO> list = BeanUtil.copyList(paints, ContractProductPaintExportVO.class);
            AtomicInteger num = new AtomicInteger();
            list.forEach(item -> {
                item.setNumber(num.incrementAndGet());
                //数量倍数转换
                if (!CommonUtil.isNull(item.getPurchaseArea())) {
                    item.setPurchaseAreaExport(item.getPurchaseArea().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDryFilmThickness())) {
                    item.setDryFilmThicknessExport(item.getDryFilmThickness().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getAmountOfPaint())) {
                    item.setAmountOfPaintExport(item.getAmountOfPaint().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTheoreticalDosage())) {
                    item.setTheoreticalDosageExport(item.getTheoreticalDosage().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getLossFactor())) {
                    item.setLossFactorExport(item.getLossFactor().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getVolumeSolidContent())) {
                    item.setVolumeSolidContentExport(item.getVolumeSolidContent().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDensity())) {
                    item.setDensityExport(item.getDensity().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getUnitPriceDiluentIncludingTax())) {
                    item.setUnitPriceDiluentIncludingTaxExport(item.getUnitPriceDiluentIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getUnitPricePaintIncludingTax())) {
                    item.setUnitPricePaintIncludingTaxExport(item.getUnitPricePaintIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getDilutionDose())) {
                    item.setDilutionDoseExport(item.getDilutionDose().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTotalUnitPriceIncludingTax())) {
                    item.setTotalUnitPriceIncludingTaxExport(item.getTotalUnitPriceIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTotalSquarePriceIncludingTax())) {
                    item.setTotalSquarePriceIncludingTaxExport(item.getTotalSquarePriceIncludingTax().doubleValue() / 100);
                }
                if (!CommonUtil.isNull(item.getTaxRate())) {
                    item.setTaxRateExport(item.getTaxRate().doubleValue() / 100);
                }
            });
            return new PageResult<>();
        } else {
            List<ContractProductDetailsExportVO> list = null;
            if (MaterialType.WELDING_MATERIALS.getCode().equals(dto.getMaterialType())) {
                List<PurchasePlanDetailsWeldingMaterials> weld = purchasePlanService.getWeldByContractListId(dto.getContractListId());
                list = BeanUtil.copyList(weld, ContractProductDetailsExportVO.class);
            } else {
                List<PurchasePlanDetailsProductTotal> productTotals = purchasePlanService.getProductTotalByContractListId(dto.getContractListId());
                list = BeanUtil.copyList(productTotals, ContractProductDetailsExportVO.class);
            }
            AtomicInteger num = new AtomicInteger();
            list.forEach(item -> {
                item.setNumber(num.incrementAndGet());
                //辅材第二个空填写重量，其他第一单位重量
                //需要处理的四个字段  useMaterialUnit   purchaseAmountExport  unitTwo   purchaseAmount
                if (MaterialType.AUXILIARY_MATERIALS.getCode().equals(item.getMaterialType())) {
                    if (!CommonUtil.isNull(item.getUseMaterialUnit())) {
                        item.setUnitTwo("");
                    }
                    if (!CommonUtil.isNull(item.getPurchaseWeight())) {
                        item.setPurchaseAmountExportTwo(item.getPurchaseWeight().doubleValue());
                    }
                    //第一单位 放数量和用料单位
                    if (!CommonUtil.isNull(item.getPurchaseAmount())) {
                        item.setPurchaseAmountExport((double) (item.getPurchaseAmount()));
                    }
                } else {
                    if (!CommonUtil.isNull(item.getPurchaseWeight())) {
                        item.setPurchaseAmountExport(item.getPurchaseWeight().doubleValue());
                    }
                    //第二单位填写数量
                    if (!CommonUtil.isNull(item.getPurchaseAmount())) {
                        item.setPurchaseAmountExportTwo((double) (item.getPurchaseAmount()));
                    }
                    if (!FactoryEnum.PRESSURE_VESSEL.getCode().equals(SystemConfig.getFactoryNum()) || !MaterialType.FORGE_PIECE.getCode().equals(item.getMaterialType())) {
                        String unitOne = item.getUseMaterialUnit();
                        item.setUseMaterialUnit(item.getUnitTwo());
                        item.setUnitTwo(unitOne);
                    }
                }
                //几个金额倍率转换
                if (!CommonUtil.isNull(item.getPreTaxPrice())) {
                    item.setPreTaxPriceExport(item.getPreTaxPrice().doubleValue());
                }
                if (!CommonUtil.isNull(item.getUnitPriceWithTax())) {
                    item.setUnitPriceWithTaxExport(item.getUnitPriceWithTax().doubleValue());
                }
                if (!CommonUtil.isNull(item.getTotalPriceExcludingTax())) {
                    item.setTotalPriceExcludingTaxExport(item.getTotalPriceExcludingTax().doubleValue());
                }
                if (!CommonUtil.isNull(item.getTotalPriceIncludingTax())) {
                    item.setTotalPriceIncludingTaxExport(item.getTotalPriceIncludingTax().doubleValue());
                }
                if (!CommonUtil.isNull(item.getTaxRate())) {
                    item.setTaxRateExport(item.getTaxRate().doubleValue() / 100);
                }

                if (MaterialType.WELDING_MATERIALS.getCode().equals(item.getMaterialType())) {
                } else {
                    //用料类型
                    //解析长度、宽度与厚度
                    if (!CommonUtil.isNull(item.getIngredientsType())) {
                        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                        Class<? extends ComputerHandler> clazz = computerType.getClazz();
                        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                        Map<String, String> map = bean.analysis(item.getSize(), item.getIngredientsType());
                        if (!CommonUtil.isNull(map)) {
                            String thickness = CommonUtil.isNull(map.get("thickness")) ? null : map.get("thickness");
                            String length = CommonUtil.isNull(map.get("length")) ? null : map.get("length");
                            String width = CommonUtil.isNull(map.get("width")) ? null : map.get("width");
                            item.setThickness(thickness);
                            item.setLength(length);
                            item.setWidth(width);
                        }
                    }
                }
                PurchasePlan purchasePlan = purchasePlanService.selectByPurchasePlanId(item.getPurchasePlanId());
                item.setProjectName(Optional.ofNullable(purchasePlan).orElse(new PurchasePlan()).getProjectName());
                String value = EnumUtil.getValue(MaterialType.class, item.getMaterialType());
                item.setMaterialTypeText(value);
            });
            if (StringUtils.isNotBlank(dto.getMaterialName())) {
                list = list.stream().filter(o -> o.getMaterialName().equals(dto.getMaterialName())).collect(Collectors.toList());
            }
            return PageUtil.convert2PageResult(list, dto);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    public void generateContract(GenerateContractDTO dto) {
        List<String> projectIds = dto.getProjectIds();
        List<String> projectNames = new ArrayList<>();
        for (String projectId : projectIds) {
            ProjectVO projectVO = projectService.getById(projectId);
            projectNames.add(Optional.ofNullable(projectVO).orElse(new ProjectVO()).getProjectName());
        }

        List<String> purchasePlanNoList = new ArrayList<>();
        List<String> purchasePlanIdList = new ArrayList<>();
        List<String> projectDemandPlanNoList = new ArrayList<>();
        List<String> projectDemandPlanIdList = dto.getProjectDemandPlanIdList();
        List<ProjectDemandPlan> projectDemandPlanList = new ArrayList<>();
        for (String projectDemandPlanId : projectDemandPlanIdList) {
            ProjectDemandPlan projectDemandPlan = projectDemandPlanService.selectOneById(projectDemandPlanId);
            projectDemandPlanList.add(projectDemandPlan);
            projectDemandPlanNoList.add(Optional.ofNullable(projectDemandPlan).orElse(new ProjectDemandPlan()).getPlanNo());

            Integer demandType = projectDemandPlan.getDemandType();
            String value = EnumUtil.getValue(DemandType.class, demandType);
            String code = EnumUtil.getCode(MaterialType.class, value);

            PurchasePlan purchasePlan = purchasePlanService.selectByProjectIdAndType(projectDemandPlan.getProjectId(), projectDemandPlan.getProjectDemandPlanBatch(), Integer.valueOf(code));
            purchasePlanNoList.add(Optional.ofNullable(purchasePlan).orElse(new PurchasePlan()).getPurchasePlanNumber());
            purchasePlanIdList.add(Optional.ofNullable(purchasePlan).orElse(new PurchasePlan()).getId());
        }

        PurchaseContractProjectInfoEntity entity = PurchaseContractProjectInfoEntity.builder()
                .purchasePlanNo(purchasePlanNoList.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(",")))
                .projectDemandPlanNo(projectDemandPlanNoList.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(",")))
                .projectName(projectNames.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(","))).build();
        purchaseContractProjectInfoService.insert(entity);
        for (String purchasePlanId : purchasePlanIdList.stream().filter(StringUtils::isNotBlank).collect(Collectors.toList())) {
            PurchasePlan purchasePlan = purchasePlanService.selectById(purchasePlanId);
            purchasePlan.setPurchaseContractProjectInfoId(entity.getPurchaseContractProjectInfoId());
            purchasePlanService.updateById(purchasePlan);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    public void deleteContract(DeleteContractListDTO dto) {
        purchaseContractProjectInfoService.deleteById(dto.getPurchaseContractProjectInfoId());

        MPJLambdaWrapper<ContractList> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.selectAll(ContractList.class)
                .eq(ContractList::getPurchaseContractProjectInfoId, dto.getPurchaseContractProjectInfoId());
        List<ContractList> contractLists = contractListMapper.selectList(lambdaWrapper);
        contractLists.forEach(item -> {
            DeleteContractInfoDTO contractInfoDTO = DeleteContractInfoDTO.builder().id(item.getId()).materialType(item.getMaterialType()).build();
            deleteContractInfo(contractInfoDTO);
        });
    }


    public void insertOrUpdateContractInfo(InsertContractInfoDTO dto) {
        ContractList contract = contractListMapper.selectById(dto.getId());
        if (CommonUtil.isNull(contract)) {
            ContractList contractList = BeanUtil.copy(dto, ContractList.class);
            contractList.setPurchaseStatus(dto.getPurchaseStatus());
            contractListMapper.insert(contractList);
            return;
        }
        contract.setSignTime(dto.getSignTime())
                .setArrivalTime(dto.getArrivalTime())
                .setContractNo(dto.getContractNo())
                .setPurchaseStatus(dto.getPurchaseStatus())
                .setContractName(dto.getContractName())
                .setPurchaser(dto.getPurchaser())
                .setMaterialType(dto.getMaterialType())
                .setSupplierId(dto.getSupplierId());
        contractListMapper.updateById(contract);
    }


    @Transactional(rollbackFor = Exception.class)
    public void deleteContractInfo(DeleteContractInfoDTO dto) {
        boolean alreadyCreateOrder = orderService.selectByContractListId(dto.getId());
        if (alreadyCreateOrder) {
            throw new ErrorException("已创建订单，不可删除");
        }
        contractListMapper.deleteById(dto.getId());
        purchasePlanService.deletePurchaseDetailByContractIdAndMaterialType(dto);
    }


    public PageResult<ContractInfoListVO> list(QueryContractListDTO dto) {
        IPage<ContractInfoListVO> contractInfoListVOIPage = purchaseContractProjectInfoService.selectByCondition(dto);
        List<ContractInfoListVO> records = contractInfoListVOIPage.getRecords();
        records.forEach(item -> {
            List<String> projectIdList = new ArrayList<>();
            String projectName = item.getProjectName();
            String[] split = projectName.split(",");
            for (String str : split) {
                Project project = projectService.getByName(str);
                projectIdList.add(Optional.ofNullable(project).orElse(new Project()).getId());
            }
            item.setProjectIdList(projectIdList);
            MPJLambdaWrapper<ContractList> lambdaWrapper = new MPJLambdaWrapper<>();
            lambdaWrapper.selectAll(ContractList.class)
                    .eq(ContractList::getPurchaseContractProjectInfoId, item.getPurchaseContractProjectInfoId())
                    .eq(StringUtils.isNotBlank(dto.getSupplierId()), ContractList::getSupplierId, dto.getSupplierId())
                    .eq(CommonUtil.isNotNull(dto.getMaterialType()), ContractList::getMaterialType, dto.getMaterialType())
                    .like(StringUtils.isNotBlank(dto.getContractNo()), ContractList::getContractNo, dto.getContractNo());
            List<ContractInfoVO> contractInfoVOS = contractListMapper.selectJoinList(ContractInfoVO.class, lambdaWrapper);
            contractInfoVOS.forEach(o -> {
                o.setPurchaseContractProjectInfoId(item.getPurchaseContractProjectInfoId());
                o.setSignTime(o.getSignTime());
                Supplier supplier = supplierMapper.selectById(o.getSupplierId());
                o.setSupplierName(Optional.ofNullable(supplier).orElse(new Supplier()).getSupplierName());
                o.setPurchaseStatesText(EnumUtil.getValue(PurchaseStateEnum.class, o.getPurchaseStatus()));
                o.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, o.getMaterialType()));
                ContractListDetailDTO contractListDetailDTO = new ContractListDetailDTO();
                contractListDetailDTO.setContractListId(o.getId());
                contractListDetailDTO.setMaterialType(o.getMaterialType());
                contractListDetailDTO.setPageSize(500);
                List<PurchasePlan> purchasePlanList = purchasePlanService.getPurchasePlanListByContractListId(o.getId(), o.getMaterialType());
                List<String> purchasePlanNos = new ArrayList<>();
                for (PurchasePlan purchasePlan : purchasePlanList) {
                    purchasePlanNos.add(Optional.ofNullable(purchasePlan).orElse(new PurchasePlan()).getPurchasePlanNumber());
                }
                o.setPurchasePlanNo(purchasePlanNos.stream().filter(StringUtils::isNotBlank).collect(Collectors.joining(",")));
            });
            item.setContractInfoVOList(contractInfoVOS);
        });
        if ((StringUtils.isBlank(dto.getProjectName()) && StringUtils.isBlank(dto.getDemandPlanNumber()))
                && (StringUtils.isNotBlank(dto.getSupplierId())) || StringUtils.isNotBlank(dto.getContractNo()) || CommonUtil.isNotNull(dto.getMaterialType())) {
            records = records.stream().filter(result -> CommonUtil.listIsNotEmpty(result.getContractInfoVOList())).collect(Collectors.toList());
        }
        return PageUtil.convert2PageResult(records, dto);
    }


    public ContractInfoVO selectContractInfo(IdDTO dto) {
        ContractList contractList = contractListMapper.selectById(dto.getId());
        ContractInfoVO copy = BeanUtil.copy(contractList, ContractInfoVO.class);
        copy.setPurchaseStatesText(EnumUtil.getValue(PurchaseStateEnum.class, copy.getPurchaseStatus()));
        Supplier supplier = supplierMapper.selectById(copy.getSupplierId());
        copy.setSupplierName(Optional.ofNullable(supplier).orElse(new Supplier()).getSupplierName());
        copy.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, contractList.getMaterialType()));
        return copy;
    }


    public List<WarehousingMaterialTypeVO> getContractMaterialType() {
        ArrayList<WarehousingMaterialTypeVO> list = new ArrayList<>();
        for (MaterialType materialType : MaterialType.values()) {
            WarehousingMaterialTypeVO warehousingMaterialTypeVO = new WarehousingMaterialTypeVO();
            warehousingMaterialTypeVO.setCode(materialType.getCode());
            warehousingMaterialTypeVO.setValue(materialType.getName());
            list.add(warehousingMaterialTypeVO);
        }
        return list;
    }


}
