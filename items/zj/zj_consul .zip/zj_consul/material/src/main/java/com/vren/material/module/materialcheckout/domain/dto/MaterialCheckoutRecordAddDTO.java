package com.vren.material.module.materialcheckout.domain.dto;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
public class MaterialCheckoutRecordAddDTO {

    private String id;
    @NotBlank(message = "项目id不能为空")
    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("领料单表格编号")
    private String pickingFromNo;
    @ApiModelProperty("拨出单位")
    private String spareUnit;
    @ApiModelProperty("限额领料计划编号")
    private String quotaPickingPlanNo;

    @ApiModelProperty("领料单编号")
    private String materialRequisitionNo;

    @ApiModelProperty("领用部门")
    private String requisitionDepartment;

    @ApiModelProperty("领用时间")
    private Date requisitionTime;

    @ApiModelProperty("出库时间")
    private Date checkoutTime;

    @ApiModelProperty("编制人")
    private String compile;

    @ApiModelProperty("审核人")
    private String checker;

    @ApiModelProperty("审批人")
    private String approver;

    @ApiModelProperty("发料人")
    private String issuedBy;

    @ApiModelProperty("领料人")
    private String picker;

    @ApiModelProperty("发起人")
    private String sponsor;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("验收单编号")
    private String acceptanceCertificateNo;

    @ApiModelProperty("一般计税0 简易计税 1 ")
    private Integer taxMethod;

    @ApiModelProperty("是否超额领料")
    private Boolean excessIssue;

}
