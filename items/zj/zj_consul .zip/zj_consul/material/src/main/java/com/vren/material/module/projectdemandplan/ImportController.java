package com.vren.material.module.projectdemandplan;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.projectdemandplan.domain.dto.ProductDemandPlanTotalImportDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;

/**
 * @author GR
 * time 2023-05-10-11-04
 **/
@RestController
@RequestMapping("/projectImport")
@Api(tags = {"项目需求计划——导入"})
@OperateLog
public class ImportController {

    private final ImportService importService;

    @Autowired
    public ImportController(ImportService importService) {
        this.importService = importService;
    }

    @ApiOperation("产品汇总excel导入")
    @RequestMapping(value = "/productDemandPlanTotalUpload", method = RequestMethod.POST)
    public ResponseResult<Boolean> upload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        importService.productTotalImport(file, dto);
        return ResponseResult.success("导入成功");
    }
}
