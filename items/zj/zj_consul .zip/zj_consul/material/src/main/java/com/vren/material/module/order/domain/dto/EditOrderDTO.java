package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author GR
 * @Time 2023-04-11-14-00
 **/
@Data
public class EditOrderDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("订单编号")
    private String orderNumber;

    @ApiModelProperty("需方")
    private String demander;

    @ApiModelProperty("送货地址")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    private String contactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

}
