package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProductDemandPlanTotalDeleteDTO {
    @ApiModelProperty("产品需求计划汇总ID")
    private String id;
}
