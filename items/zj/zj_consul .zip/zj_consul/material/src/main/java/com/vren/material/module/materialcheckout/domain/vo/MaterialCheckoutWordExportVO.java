package com.vren.material.module.materialcheckout.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description MaterialCheckoutWordExportVO
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */
@Data
public class MaterialCheckoutWordExportVO {

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("拨出单位")
    private String spareUnit;

    @ApiModelProperty("发料仓库")
    private String issuingWarehouse;

    @ApiModelProperty("领用部门")
    private String requisitionDepartment;

    @ApiModelProperty("验收单编号")
    private String acceptanceCertificateNo;

    @ApiModelProperty("限额领料计划编号")
    private String quotaPickingPlanNo;

    @ApiModelProperty("领料单编号")
    private String materialRequisitionNo;

    @ApiModelProperty("领用时间")
    private String requisitionTime;

    @ApiModelProperty("一般计税 0 简易计税 1 ")
    private String taxMethodText;


}
