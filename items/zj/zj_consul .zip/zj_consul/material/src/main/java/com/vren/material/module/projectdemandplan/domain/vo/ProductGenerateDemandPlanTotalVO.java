package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Data
public class ProductGenerateDemandPlanTotalVO {
    @ApiModelProperty("id")
    private String  id;
    @ApiModelProperty("计划编号")
    private String planNo;

    @ApiModelProperty("项目需求计划表id")
    private String projectDemandPlanId;



    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("材料材质ID")
    private String materialTextureId;

    @ApiModelProperty("规格")
    private String specification;
    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("标书价")
    private String bidPrice;

}
