package com.vren.material.module.projectdemandplan;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.vren.common.common.utils.*;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.projectdemandplan.domain.NumberValidationUtils;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.dto.ImportDTO;
import com.vren.material.module.projectdemandplan.domain.dto.ProductDemandPlanTotalImportDTO;
import com.vren.material.module.projectdemandplan.domain.dto.SparePartsImportDTO;
import com.vren.material.module.projectdemandplan.domain.entity.MaterialTypeDescription;
import com.vren.material.module.projectdemandplan.domain.entity.ProductDemandPlanTotal;
import com.vren.material.module.projectdemandplan.domain.entity.ProjectDemandPlan;
import com.vren.material.module.projectdemandplan.domain.enums.DemandType;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.mapper.MaterialTypeDescriptionMapper;
import com.vren.material.module.projectdemandplan.mapper.ProductDemandPlanTotalMapper;
import com.vren.material.module.projectdemandplan.mapper.ProjectDemandPlanMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author GR
 * time 2023-05-10-11-04
 **/
@Service
@Slf4j
public class ImportService {

    private final ProductDemandPlanTotalMapper productDemandPlanTotalMapper;

    private final ProjectDemandPlanMapper projectDemandPlanMapper;

    private final MaterialTypeDescriptionMapper materialTypeDescriptionMapper;

    private final ProjectDemandPlanService projectDemandPlanService;

    public ImportService(ProductDemandPlanTotalMapper productDemandPlanTotalMapper, ProjectDemandPlanMapper projectDemandPlanMapper
            , MaterialTypeDescriptionMapper materialTypeDescriptionMapper, ProjectDemandPlanService projectDemandPlanService) {
        this.productDemandPlanTotalMapper = productDemandPlanTotalMapper;
        this.projectDemandPlanMapper = projectDemandPlanMapper;
        this.materialTypeDescriptionMapper = materialTypeDescriptionMapper;
        this.projectDemandPlanService = projectDemandPlanService;
    }


    /**
     * 项目需求计划，按照物种基本类型导入
     * 导入数据，先解析尺寸，然后重新计算重量
     * 导入的数据，覆盖掉这个类型下面的原有数据
     * 板材和型材导入的数据相同
     * 锻件、辅材和外购件导入的内容相同
     * @param file 文件
     * @param dto  物资类型，项目需求计划
     */
    @Transactional(rollbackFor = Exception.class)
    public String productTotalImport(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        String msg = null;
        DemandType type = EnumUtil.getEnumByCode(DemandType.class, dto.getDemandType());
        switch (type) {
            case BOARD:
            case PROFILE:
                //型材
                //板材
                msg = boardlImport(file, dto);
                break;
            case FORGE_PIECE:
            case AUXILIARY_MATERIALS:
            case PURCHASED_PARTS:
                //外购件
                //辅材
                //锻件
                msg = forgePieceImport(file, dto);
                break;
            case SPARE_PARTS:
                msg = sparePartsImport(file, dto);
                break;
            default:
                break;
        }
        return msg;
    }


    public String sparePartsImport(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        LinkedList<SparePartsImportDTO> list = ExcelUtil.readSheet(file.getInputStream(), SparePartsImportDTO.class, "备件");
        file.getInputStream().close();
        assert list != null;
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        if (CommonUtil.isNull(projectDemandPlan)) {
            return "项目需求计划不存在!";
        }
        String planNo = list.get(1).getEnforceStandards().substring(5);
        projectDemandPlan.setPlanNo(newPlanNo(planNo, dto.getProjectDemandPlanId(), dto.getDemandType()));
        projectDemandPlanMapper.updateById(projectDemandPlan);

        ArrayList<ProductDemandPlanTotal> demandPlanTotals = new ArrayList<>();
        for (int i = 3; i < list.size(); i++) {
            ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
            SparePartsImportDTO importDTO = list.get(i);
            //赋值属性
            BeanUtil.copyProperties(importDTO, productDemandPlanTotal);
            //序号
            if (!CommonUtil.isNull(importDTO.getSerialNumber())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getSerialNumber())) {
                    productDemandPlanTotal.setSerialNumber(Integer.parseInt(importDTO.getSerialNumber()));
                } else {
                    return "数值格式错误！";
                }
            }
            productDemandPlanTotal.setMaterialType(MaterialType.SPARE_PARTS.getCode());
            productDemandPlanTotal.setCount(importDTO.getCount());
            productDemandPlanTotal.setSparePartsQuantity(0L);
            productDemandPlanTotal.setIsCalculate(false);

            if (!CommonUtil.isNull(importDTO.getDeliveryTime())) {
                SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format2 = new SimpleDateFormat("yyyy/MM/dd");
                if (importDTO.getDeliveryTime().contains("/")) {
                    Date deliveryTime = format2.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                } else {
                    Date deliveryTime = format1.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                }
            }
            productDemandPlanTotal.setProjectDemandPlanId(dto.getProjectDemandPlanId());
            demandPlanTotals.add(productDemandPlanTotal);
        }
        QueryWrapper<ProductDemandPlanTotal> deleteWrapper = new QueryWrapper<>();
        deleteWrapper.eq("project_demand_plan_id", dto.getProjectDemandPlanId());
        deleteWrapper.eq("material_type", MaterialType.SPARE_PARTS.getCode());
        productDemandPlanTotalMapper.delete(deleteWrapper);
        productDemandPlanTotalMapper.insertBatchSomeColumn(demandPlanTotals);
        return "导入成功";
    }


    public String forgePieceImport(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        LinkedList<ImportDTO> list;
        if (dto.getDemandType().equals(DemandType.FORGE_PIECE.getCode())) {
            //锻件
            list = ExcelUtil.readSheet(file.getInputStream(), ImportDTO.class, "锻件");
        } else if (dto.getDemandType().equals(DemandType.AUXILIARY_MATERIALS.getCode())) {
            //辅材
            list = ExcelUtil.readSheet(file.getInputStream(), ImportDTO.class, "辅材");
        } else if (dto.getDemandType().equals(DemandType.PURCHASED_PARTS.getCode())) {
            //外购件
            list = ExcelUtil.readSheet(file.getInputStream(), ImportDTO.class, "外购件");
        } else {
            return "导入失败";
        }
        file.getInputStream().close();
        //更新制造编号和计划编号
        assert list != null;
        String manufacturingNumber = list.get(1).getOrderNumber().substring(5);
        String planNo = list.get(1).getEnforceStandards().substring(5);
        log.info("制造标号：{}，计划编号:{}", manufacturingNumber, planNo);
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        if (CommonUtil.isNull(projectDemandPlan)) {
            return "项目需求计划不存在!";
        }
        projectDemandPlan.setManufacturingNumber(manufacturingNumber);
        projectDemandPlan.setPlanNo(newPlanNo(planNo, dto.getProjectDemandPlanId(), dto.getDemandType()));
        projectDemandPlanMapper.updateById(projectDemandPlan);

        //导入文件的数据
//        log.info("导入文件的数据:{}", list);
        //清除 项目需求计划已有类型的数据

        //导入数据最后几行
        int size = 0;
        for (int i = 3; i < list.size(); i++) {
            if (CommonUtil.isNull(list.get(i).getOrderNumber())) {
                size = i;
                break;
            }
        }
        //新增数据，不需要计算
        ArrayList<ProductDemandPlanTotal> demandPlanTotals = new ArrayList<>();
        for (int i = 3; i < size; i++) {
            ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
            ImportDTO importDTO = list.get(i);
            //赋值属性
            BeanUtil.copyProperties(importDTO, productDemandPlanTotal);
            //序号
            if (!CommonUtil.isNull(importDTO.getOrderNumber())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getOrderNumber())) {
                    productDemandPlanTotal.setSerialNumber(Integer.parseInt(importDTO.getOrderNumber()));
                } else {
                    return "数值格式错误！";
                }
            }
            //重量，String转数字
            if (!CommonUtil.isNull(importDTO.getWeight())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getWeight())) {
                    productDemandPlanTotal.setWeight((long) (Double.parseDouble(importDTO.getWeight()) * 100));
                } else {
                    return "数值格式错误！";
                }
            }
            //物资类型(板材和型材使用同一个方法)
            //根据参数设置类型
            if (dto.getDemandType().equals(DemandType.FORGE_PIECE.getCode())) {
                //锻件
                productDemandPlanTotal.setMaterialType(MaterialType.FORGE_PIECE.getCode());
            }
            if (dto.getDemandType().equals(DemandType.AUXILIARY_MATERIALS.getCode())) {
                //辅材
                productDemandPlanTotal.setMaterialType(MaterialType.AUXILIARY_MATERIALS.getCode());
            }
            if (dto.getDemandType().equals(DemandType.PURCHASED_PARTS.getCode())) {
                //外购件
                productDemandPlanTotal.setMaterialType(MaterialType.PURCHASED_PARTS.getCode());
            }
            //数量，String转数字
            if (!CommonUtil.isNull(importDTO.getCount())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getCount())) {
                    productDemandPlanTotal.setCount((long) (Double.parseDouble(importDTO.getCount()) * 100));
                } else {
                    productDemandPlanTotal.setCount(0L);
                }
            }
            //设置件号为制造编号/件号
            if (!CommonUtil.isNull(importDTO.getManufacturingNumberPartNo())) {
                productDemandPlanTotal.setPartNo(importDTO.getManufacturingNumberPartNo());
            }
            //备件数量
            if (StringUtils.isNotBlank(importDTO.getSparePartsQuantity())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getSparePartsQuantity())) {
                    productDemandPlanTotal.setSparePartsQuantity((long) (Double.parseDouble(importDTO.getSparePartsQuantity()) * 100));
                }
            } else {
                productDemandPlanTotal.setSparePartsQuantity(0L);
            }
            productDemandPlanTotal.setIsCalculate(false);
            //交货时间，String转时间
            if (!CommonUtil.isNull(importDTO.getDeliveryTime())) {
                SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format2 = new SimpleDateFormat("yyyy/MM/dd");
                if (importDTO.getDeliveryTime().contains("/")) {
                    Date deliveryTime = format2.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                } else {
                    Date deliveryTime = format1.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                }

            }
            productDemandPlanTotal.setProjectDemandPlanId(dto.getProjectDemandPlanId());
            log.info("项目需求计划实体数据：{}", productDemandPlanTotal);
            //项目需求计划id
            demandPlanTotals.add(productDemandPlanTotal);
        }
        QueryWrapper<ProductDemandPlanTotal> deleteWrapper = new QueryWrapper<>();
        deleteWrapper.eq("project_demand_plan_id", dto.getProjectDemandPlanId());
        if (dto.getDemandType().equals(DemandType.FORGE_PIECE.getCode())) {
            //板材类型
            deleteWrapper.eq("material_type", MaterialType.FORGE_PIECE.getCode());
        }
        if (dto.getDemandType().equals(DemandType.AUXILIARY_MATERIALS.getCode())) {
            deleteWrapper.eq("material_type", MaterialType.AUXILIARY_MATERIALS.getCode());
        }
        if (dto.getDemandType().equals(DemandType.PURCHASED_PARTS.getCode())) {
            deleteWrapper.eq("material_type", MaterialType.PURCHASED_PARTS.getCode());
        }
        productDemandPlanTotalMapper.delete(deleteWrapper);
        productDemandPlanTotalMapper.insertBatchSomeColumn(demandPlanTotals);
        //备注更新
        String remarks = "";
        for (int i = size + 1; i < list.size(); i++) {
            String partNo = list.get(i).getManufacturingNumberPartNo();
            if (StringUtils.isNotBlank(partNo)) {
                remarks += partNo + "\n";
            }
        }
        //根据项目id、物资类型和项目需求计划批次  更新说明
        UpdateWrapper<MaterialTypeDescription> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("project_id", projectDemandPlan.getProjectId())
                .eq("project_demand_plan_batch", projectDemandPlan.getProjectDemandPlanBatch())
                .set("remarks", remarks);
        if (dto.getDemandType().equals(DemandType.PURCHASED_PARTS.getCode())) {
            //锻件
            updateWrapper.eq("material_type", MaterialType.PURCHASED_PARTS.getName());
        }
        if (dto.getDemandType().equals(DemandType.AUXILIARY_MATERIALS.getCode())) {
            //锻件
            updateWrapper.eq("material_type", MaterialType.AUXILIARY_MATERIALS.getName());
        }
        if (dto.getDemandType().equals(DemandType.FORGE_PIECE.getCode())) {
            //锻件
            updateWrapper.eq("material_type", MaterialType.FORGE_PIECE.getName());
        }
        materialTypeDescriptionMapper.update(new MaterialTypeDescription(), updateWrapper);

        return "导入成功";
    }

    public String newPlanNo(String planNo, String id, Integer demandType) {
        //查询计划编号是否存在，如果不存在，则继续使用，否则就在原有编号基础上后面赘上随机数
        QueryWrapper<ProjectDemandPlan> wrapper = new QueryWrapper<>();
        wrapper.select("1")
                .eq(!CommonUtil.isNull(planNo), "plan_no", planNo)
                .ne("id", id)
//                .ne("demand_type",demandType)
                .last(" limit 1");
        Long count = projectDemandPlanMapper.selectCount(wrapper);
        if (count > 0) {
            int nextInt = new Random().nextInt(1000);
            return planNo + nextInt;
        }
        return planNo;

    }

    public String boardlImport(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException, ParseException {
        LinkedList<BoardImportDTO> list;
        if (dto.getDemandType().equals(DemandType.BOARD.getCode())) {
            list = ExcelUtil.readSheet(file.getInputStream(), BoardImportDTO.class, "板材");
        } else if (dto.getDemandType().equals(DemandType.PROFILE.getCode())) {
            //型材
            list = ExcelUtil.readSheet(file.getInputStream(), BoardImportDTO.class, "一台管材型材");
        } else {
            return "";
        }
        file.getInputStream().close();
        //更新制造编号和计划编号
        String manufacturingNumber = list.get(1).getOrderNumber().substring(5);
        String planNo = list.get(1).getIngredientsType().substring(5);
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        if (CommonUtil.isNull(projectDemandPlan)) {
            return "项目需求计划不存在!";
        }
        projectDemandPlan.setManufacturingNumber(manufacturingNumber);
        projectDemandPlan.setPlanNo(newPlanNo(planNo, dto.getProjectDemandPlanId(), dto.getDemandType()));
        projectDemandPlanMapper.updateById(projectDemandPlan);

        //清除 项目需求计划已有类型的数据
        QueryWrapper<ProductDemandPlanTotal> deleteWrapper = new QueryWrapper<>();
        deleteWrapper.eq("project_demand_plan_id", dto.getProjectDemandPlanId());
        if (dto.getDemandType().equals(DemandType.BOARD.getCode())) {
            //板材类型
            deleteWrapper.eq("material_type", MaterialType.BOARD.getCode());
        }
        if (dto.getDemandType().equals(DemandType.PROFILE.getCode())) {
            deleteWrapper.eq("material_type", MaterialType.PROFILE.getCode());
        }
        productDemandPlanTotalMapper.delete(deleteWrapper);

        //合计 在数据中出现的行数
        int size = 0;
        for (int i = 4; i < list.size(); i++) {
            if (CommonUtil.isNull(list.get(i).getOrderNumber())) {
                size = i;
                break;
            }
        }
        //新增数据，根据厚度、宽度和长度重新计算重量
        ArrayList<ProductDemandPlanTotal> demandPlanTotals = new ArrayList<>();
        for (int i = 4; i < size; i++) {
            ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
            BoardImportDTO importDTO = list.get(i);
            //计算重量、生成规格
            if (!"是".equals(importDTO.getIsCalculate())) {
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, importDTO.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                bean.execution(importDTO);
                BeanUtil.copyProperties(importDTO, productDemandPlanTotal);
                if (!CommonUtil.isNull(importDTO.getWeightImport())) {
                    if (NumberValidationUtils.isRealNumber(importDTO.getWeightImport())) {
                        productDemandPlanTotal.setWeight((long) (Double.parseDouble(importDTO.getWeightImport()) * 100));
                    } else {
                        return "数值格式错误！";
                    }
                } else {
                    productDemandPlanTotal.setWeight(0L);
                }
            } else {
                BeanUtil.copyProperties(importDTO, productDemandPlanTotal);
                //厚度就是规格，重量就是重量
                productDemandPlanTotal.setSpecification(importDTO.getThickness());
                if (NumberValidationUtils.isRealNumber(importDTO.getWeightImport())) {
                    productDemandPlanTotal.setWeight((long) (Double.parseDouble(importDTO.getWeightImport()) * 100));
                } else {
                    return "数值格式错误！";
                }
            }
            if ("是".equals(importDTO.getIsCalculate())) {
                productDemandPlanTotal.setIsCalculate(true);
            } else {
                productDemandPlanTotal.setIsCalculate(false);
            }
            //序号
            if (!CommonUtil.isNull(importDTO.getOrderNumber())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getOrderNumber())) {
                    productDemandPlanTotal.setSerialNumber(Integer.parseInt(importDTO.getOrderNumber()));
                } else {
                    return "数值格式不正确";
                }
            }
            //物资类型(板材和型材使用同一个方法)
            //根据参数设置类型
            if (dto.getDemandType().equals(DemandType.BOARD.getCode())) {
                //板材类型
                productDemandPlanTotal.setMaterialType(MaterialType.BOARD.getCode());
            }
            if (dto.getDemandType().equals(DemandType.PROFILE.getCode())) {
                productDemandPlanTotal.setMaterialType(MaterialType.PROFILE.getCode());
            }
            //数量，String转数字
            if (!CommonUtil.isNull(importDTO.getCount())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getCount())) {
                    productDemandPlanTotal.setCount((long) (Double.parseDouble(importDTO.getCount()) * 100));
                } else {
                    return "数值格式错误！";
                }
            }
            //备件数量
            if (!CommonUtil.isNull(importDTO.getSparePartsQuantity())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getSparePartsQuantity())) {
                    productDemandPlanTotal.setSparePartsQuantity((long) (Double.parseDouble(importDTO.getSparePartsQuantity()) * 100));
                } else {
                    return "数值格式错误！";
                }
            }
            //设置件号为制造编号/件号
            if (!CommonUtil.isNull(importDTO.getManufacturingNumberPartNo())) {
                productDemandPlanTotal.setPartNo(importDTO.getManufacturingNumberPartNo());
            }
            //标书价，String转数字
            if (!CommonUtil.isNull(importDTO.getBidPrice())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getBidPrice())) {
                    productDemandPlanTotal.setBidPrice((long) (Double.parseDouble(importDTO.getBidPrice()) * 100));
                } else {
                    return "数值格式错误！";
                }
            }
            //交货时间，String转时间
            if (!CommonUtil.isNull(importDTO.getDeliveryTime())) {
                SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format2 = new SimpleDateFormat("yyyy/MM/dd");
                if (importDTO.getDeliveryTime().contains("/")) {
                    Date deliveryTime = format2.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                } else {
                    Date deliveryTime = format1.parse(importDTO.getDeliveryTime());
                    productDemandPlanTotal.setDeliveryTime(deliveryTime);
                }
            }
            if (!CommonUtil.isNull(importDTO.getProportion())) {
                if (NumberValidationUtils.isRealNumber(importDTO.getProportion())) {
                    productDemandPlanTotal.setProportion((long) (Double.parseDouble(importDTO.getProportion()) * 100));
                } else {
                    return "数值格式错误";
                }
            }
            //是否进行计算，isCalculate
            if (!CommonUtil.isNull(importDTO.getIsCalculate())) {
                productDemandPlanTotal.setIsCalculate("是".equals(importDTO.getIsCalculate()));
            }
            productDemandPlanTotal.setProjectDemandPlanId(dto.getProjectDemandPlanId());
            long width = StringUtils.isBlank(importDTO.getWidth()) ? 0 : (long) (Double.parseDouble(importDTO.getWidth()) * 100);
            long thickness = StringUtils.isBlank(importDTO.getThickness()) ? 0 : (long) (Double.parseDouble(importDTO.getThickness()) * 100);
            long length = StringUtils.isBlank(importDTO.getLength()) ? 0 : (long) (Double.parseDouble(importDTO.getLength()) * 100);
            productDemandPlanTotal.setProjectDemandPlanId(dto.getProjectDemandPlanId());
            productDemandPlanTotal.setWidth(width);
            productDemandPlanTotal.setThickness(thickness);
            productDemandPlanTotal.setLength(length);
            demandPlanTotals.add(productDemandPlanTotal);
        }
        productDemandPlanTotalMapper.insertBatchSomeColumn(demandPlanTotals);
        //备注更新
        String remarks = "";
        for (int i = size + 1; i < list.size(); i++) {
            String partNo = list.get(i).getManufacturingNumberPartNo();
            if (StringUtils.isNotBlank(partNo)) {
                remarks += partNo + "\n";
            }
        }
        log.info("备注数据：{}", remarks);
        //根据项目id、物资类型和项目需求计划批次  更新说明
        UpdateWrapper<MaterialTypeDescription> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("project_id", projectDemandPlan.getProjectId())
                .eq("project_demand_plan_batch", projectDemandPlan.getProjectDemandPlanBatch())
                .set("remarks", remarks);
        if (dto.getDemandType().equals(DemandType.BOARD.getCode())) {
            //板材
            updateWrapper.eq("material_type", MaterialType.BOARD.getName());
        }
        if (dto.getDemandType().equals(DemandType.PROFILE.getCode())) {
            //型材
            updateWrapper.eq("material_type", MaterialType.PROFILE.getName());
        }
        materialTypeDescriptionMapper.update(new MaterialTypeDescription(), updateWrapper);
        return "导入成功";
    }
}
