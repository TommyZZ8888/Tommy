package com.vren.material.common.enums;

/**
 * @Description FactoryEnum
 * @Author 张卫刚
 * @Date Created on 2023/9/11
 */
public enum FactoryEnum {

    TOWER(1,"塔筒制造分公司"),
    STEEL(2,"钢结构制造分公司"),
    PRESSURE_VESSEL(3,"压力容器制造分公司"),
    METAL_DECORATION(4,"金属装饰事业部"),
    FIRST_DIVISION(5,"第一事业部"),
    SECOND_DIVISION(6,"第二事业部"),;


    private Integer code;
    private String  name;

    FactoryEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

}
