package com.vren.material.module.productmanagement.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 * 产品信息
 */
@Data
public class ProductInformationExport {

    @ApiModelProperty("产品名称")
    @ExcelProperty("产品名称")
    private String productName;

    @ApiModelProperty("位号")
    @ExcelProperty("位号")
    private String tagNo;

    @ApiModelProperty("产品规格")
    @ExcelProperty("产品规格")
    private String productSpecificatons;

    @ApiModelProperty("总图号")
    @ExcelProperty("总图号")
    private String totalFigureNo;

    @ApiModelProperty("数量")
    @ExcelProperty("数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("容器类别")
    @ExcelProperty("容器类别")
    private String containerCategory;

    @ApiModelProperty("使用单位")
    @ExcelProperty("使用单位")
    private String useUnit;

    @ApiModelProperty("制造编号(生产编号)")
    @ExcelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("吨")
    @ExcelIgnore
    @ConversionNumber
    private Long weight;

    @ApiModelProperty("吨")
    @ExcelProperty("重量(t)")
    @ConversionNumber
    private Double weightExport;


    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    @ExcelIgnore
    private Integer isProductionScheduling;

    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    @ExcelProperty("排产状态")
    private String isProductionSchedulingText;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    @ExcelIgnore
    private Integer isProductionPlan;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    @ExcelProperty("生产状态")
    private String isProductionPlanText;

    @ApiModelProperty("创建时间")
    @ExcelProperty("创建时间")
    private Date createTime;

}
