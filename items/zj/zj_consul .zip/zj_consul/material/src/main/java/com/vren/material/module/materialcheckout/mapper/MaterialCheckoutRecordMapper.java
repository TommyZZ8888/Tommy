package com.vren.material.module.materialcheckout.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialcheckout.domain.entity.MaterialCheckoutRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MaterialCheckoutRecordMapper extends MPJBaseMapper<MaterialCheckoutRecord> {
}
