package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description ContractInfoVO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class ContractInfoVO {

    @ApiModelProperty("采购合同id")
    private String id;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目需求编号")
    private String projectDemandPlanNo;

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNo;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("合同名称")
    private String contractName;

    @ApiModelProperty("经办人")
    private String purchaser;

    @ApiModelProperty("到货时间")
    private String arrivalTime;

    private String supplierId;

    @ApiModelProperty("供货商")
    private String supplierName;

    @ApiModelProperty("采购状态")
    private Integer purchaseStatus;

    @ApiModelProperty("采购状态描述")
    private String purchaseStatesText;

    private Date endTime;

    @ApiModelProperty("签订时间")
    private Date signTime;

    private String purchaseContractProjectInfoId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型描述")
    private String materialTypeText;

}
