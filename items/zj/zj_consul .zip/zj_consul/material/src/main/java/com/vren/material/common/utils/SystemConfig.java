package com.vren.material.common.utils;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @Description SystemConfig
 * @Author 张卫刚
 * @Date Created on 2023/9/11
 */
@ConfigurationProperties(prefix = "material")
@Component
public class SystemConfig {

    private static Integer factoryNum;

    private static Integer orderLimit;

    public static Integer getFactoryNum() {
        return factoryNum;
    }

    public void setFactoryNum(Integer factoryNum) {
        SystemConfig.factoryNum = factoryNum;
    }

    public static Integer getOrderLimit() {
        return orderLimit;
    }

    public void setOrderLimit(Integer orderLimit) {
        SystemConfig.orderLimit = orderLimit;
    }
}
