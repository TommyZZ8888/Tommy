package com.vren.material.module.purchasecontract.domain.dto;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


/**
 * @Description InsertContractInfoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class DeleteContractListDTO {

    @ApiModelProperty("采购合同主表id")
    private String purchaseContractProjectInfoId;

}
