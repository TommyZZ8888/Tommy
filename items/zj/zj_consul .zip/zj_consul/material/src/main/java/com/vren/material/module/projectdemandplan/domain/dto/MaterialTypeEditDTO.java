package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialTypeEditDTO {
    @ApiModelProperty("id")
    @NotBlank(message = "材料说明id不为空")
    private String id;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("附件地址")
    private String attachmentFilePath;
}
