package com.vren.material.module.productmanagement.domain.enums;


public enum ProductionPlanEnum {

    IS(1, "生产状态"),
    NOT(0, "非生产状态");


    private Integer code;

    private String name;

    ProductionPlanEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
