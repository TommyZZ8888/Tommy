package com.vren.material.module.order.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.order.domain.entity.OrderDetail;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface OrderDetailMapper extends MPJBaseMapper<OrderDetail> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<OrderDetail> entities);

}
