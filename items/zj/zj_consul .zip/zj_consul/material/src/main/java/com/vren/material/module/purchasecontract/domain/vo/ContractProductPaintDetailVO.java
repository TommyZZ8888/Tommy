package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


@Data
public class ContractProductPaintDetailVO {

    @ExcelIgnore
    private String id;

    @ApiModelProperty("序号")
    private Integer number;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型描述")
    private String materialTypeText;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("干膜厚（μm） ")
    @ConversionNumber
    private Long dryFilmThickness;

    @ApiModelProperty("技术标准")
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseArea;

    @ApiModelProperty("油漆用量（kg）（含2.0损耗）")
    @ConversionNumber
    private Long amountOfPaint;

    @ApiModelProperty("理论用量/涂布率（kg/㎡）")
    @ConversionNumber(value = 10000)
    private Long theoreticalDosage;

    @ApiModelProperty("损耗系数")
    @ConversionNumber
    private Long lossFactor;

    @ApiModelProperty("体积固含量(%)")
    @ConversionNumber
    private Long volumeSolidContent;

    @ApiModelProperty("密度（kg/L)")
    @ConversionNumber
    private Long density;


    @ApiModelProperty("含税油漆单价（元/kg）")
    @ConversionNumber(value = 10000)
    private Long unitPricePaintIncludingTax;

    @ApiModelProperty("稀释剂量kg（25%）")
    @ConversionNumber
    private Long dilutionDose;

    @ApiModelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    @ConversionNumber
    private Long totalUnitPriceIncludingTax;

    @ApiModelProperty("含税稀释剂单价（元/kg）")
    @ConversionNumber
    private Long unitPriceDiluentIncludingTax;

    @ApiModelProperty("含税平方总价（元）")
    @ConversionNumber
    private Long totalSquarePriceIncludingTax;

    @ApiModelProperty("包装规格")
    private String packageSpecification;

    @ApiModelProperty("税率%")
    @ConversionNumber
    private Long taxRate;

    @ApiModelProperty("备注（锌粉含量）")
    @ConversionNumber
    private String remarksZincPowderContent;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("采购计划表ID")
    private String purchasePlanId;

    @ApiModelProperty("油漆需求计划表id")
    private String paintDemandPlanId;

    @ApiModelProperty("项目名称")
    private String projectName;
}
