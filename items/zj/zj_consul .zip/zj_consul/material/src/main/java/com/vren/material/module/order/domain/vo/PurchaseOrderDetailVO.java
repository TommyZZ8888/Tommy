package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description PurchaseOrderDetailVO
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */

@Data
@Builder
@AllArgsConstructor
@Accessors(chain = true)
public class PurchaseOrderDetailVO {

    @ApiModelProperty("序号")
    private String serialNum;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("产品——材质")
    private String texture;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    private String purchaseAmount;

    @ApiModelProperty("到货数量")
    private String arrivalAmount;

    @ApiModelProperty("已生成订单数量")
    private String orderQuantity;

    @ApiModelProperty("交货时间")
    private String deliveryTime;

}
