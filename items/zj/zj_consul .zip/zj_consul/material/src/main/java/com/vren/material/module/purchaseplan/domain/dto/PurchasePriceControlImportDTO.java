package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Description PurchasePriceControlImportDTO
 * @Author 张卫刚
 * @Date Created on 2023/8/30
 */

@Data
public class PurchasePriceControlImportDTO {
    @ApiModelProperty("采购计划Id")
    @NotBlank(message = "采购计划Id不能为空")
    private String purchasePlanId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
