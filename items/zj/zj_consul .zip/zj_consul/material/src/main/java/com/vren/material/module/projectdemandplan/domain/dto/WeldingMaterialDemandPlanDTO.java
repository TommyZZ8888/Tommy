package com.vren.material.module.projectdemandplan.domain.dto;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.Date;

@Data
public class WeldingMaterialDemandPlanDTO {
    @ApiModelProperty("项目需求计划id")
    @NotBlank(message = "项目需求计划id不能为空")
    private String projectDemandPlanId;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("技术标准")
    private String technicalStandards;

    @ApiModelProperty("备注")
    private String remarks;

    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;


    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;
}
