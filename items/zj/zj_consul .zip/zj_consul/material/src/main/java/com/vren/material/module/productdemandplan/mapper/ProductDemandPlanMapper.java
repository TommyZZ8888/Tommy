package com.vren.material.module.productdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlan;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 * 产品需求计划
 */
@Mapper
public interface ProductDemandPlanMapper extends MPJBaseMapper<ProductDemandPlan> {

}
