package com.vren.material.module.purchasecontract.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  采购状态记录表
 */
@TableName("purchase_status_record")
@Data
public class PurchaseStatusRecord {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("操作者")
    private String operator;

    @ApiModelProperty("操作时间")
    private Date operationTime;

    @ApiModelProperty("操作前的状态")
    private Integer beforeChange;

    @ApiModelProperty("操作后的状态")
    private Integer afterChange;
}
