package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class SupplierSelectVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("分供方名称")
    private String supplierName;


}
