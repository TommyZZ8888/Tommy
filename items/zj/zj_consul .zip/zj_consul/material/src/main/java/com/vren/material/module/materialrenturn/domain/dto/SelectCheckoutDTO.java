package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class SelectCheckoutDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("（领料单编号）出库编号")
    private String materialRequisitionNo;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String specification;
}
