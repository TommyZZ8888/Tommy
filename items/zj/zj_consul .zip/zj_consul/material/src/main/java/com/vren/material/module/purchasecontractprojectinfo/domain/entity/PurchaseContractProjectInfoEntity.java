package com.vren.material.module.purchasecontractprojectinfo.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description PurchaseContractProjectInfo
 * @Author 张卫刚
 * @Date Created on 2023/9/1
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@TableName("purchase_contract_project_info")
public class PurchaseContractProjectInfoEntity {

    @TableId(type=IdType.ASSIGN_UUID)
    private String purchaseContractProjectInfoId;

    /**
     * 项目需求计划编号
     */
    private String projectDemandPlanNo;

    /**
     * 采购计划编号
     */
    private String purchasePlanNo;

    /**
     * 采购状态
     */
    private Integer purchaseState;

    /**
     * 项目名称
     */
    private String projectName;
}
