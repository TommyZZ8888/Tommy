package com.vren.material.module.productmanagement.domain.enums;


public enum ProductionSchedulingEnum {

    IS(1,"排产状态"),
    NOT(0,"非排产状态");


    private Integer code;

    private String name;

    ProductionSchedulingEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
}
