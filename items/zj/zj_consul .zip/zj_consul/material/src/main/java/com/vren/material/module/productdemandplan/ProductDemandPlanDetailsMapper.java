package com.vren.material.module.productdemandplan;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

/**
 * @author 耿让
 * 产品需求计划详情
 */
@Mapper
public interface ProductDemandPlanDetailsMapper extends MPJBaseMapper<ProductDemandPlanDetails> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<ProductDemandPlanDetails> entities);

    /**
     * 批量更新交货时间和交货地点
     *
     * @param ids
     * @param deliveryTime
     * @param deliveryLocation
     * @return
     */
    Integer editTimeAndLocation(@Param("ids") List<String> ids, @Param("deliveryTime") Date deliveryTime, @Param("deliveryLocation") String deliveryLocation);

    /**
     * 查询有且仅有的关联id
     *
     * @author szp
     * @date 2023/7/17 11:03
     */
    @Select("SELECT DISTINCT p2.id  FROM product_demand_plan_details p1 LEFT JOIN product_demand_plan p2 ON p1.product_demand_plan_id = p2.id WHERE p1.material_type IN( #{materialTypeList} )AND p2.id IN (#{idList})")
    List<String> selectLinkIdList(@Param("materialTypeList") List<String> materialTypeList, @Param("idList") List<String> idList);
}
