package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
@TableName("product_demand_plan_total")
public class ProductDemandPlanTotal {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("项目需求计划表id")
    @TableField(value = "project_demand_plan_id")
    private String projectDemandPlanId;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("规格")
    private String specification;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("备注")
    private String remarks;

    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("库存类型")
    private Integer stockType;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("采购到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Integer purchaseNum;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;

    @ApiModelProperty("制造编号&件号")
    private String manufacturingNumberPartNo;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;

    @ApiModelProperty("序号")
    private Integer serialNumber;

    @ApiModelProperty("宽度")
    @ConversionNumber
    private Long width;

    @ApiModelProperty("长度")
    @ConversionNumber
    private Long length;

    @ApiModelProperty("厚度")
    @ConversionNumber
    private Long thickness;

}