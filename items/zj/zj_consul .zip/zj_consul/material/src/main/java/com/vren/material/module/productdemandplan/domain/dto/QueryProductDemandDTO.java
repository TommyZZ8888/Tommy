package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-05-09-17-45
 **/
@Data
public class QueryProductDemandDTO extends PageParam {

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

}
