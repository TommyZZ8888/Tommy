package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @ClassName:Default
 * @Author: vren
 * @Date: 2022/10/19 15:43
 */
@Component
public class Default implements ComputerHandler {
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        if (CommonUtil.isNull(data.getFirstSize())||CommonUtil.isNull(data.getSecondSize())){
            throw new RuntimeException(data.getMaterialName()+"的第一和第二尺寸不能为空");
        }
        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setWeight(0L);
        productDemandPlanDetails.setSpecification(data.getFirstSize()/100 + "   " + data.getSecondSize()/100);
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {

    }

    @Override
    public void analysis(ProfileExportVO vo) {

    }
    @Override
    public void analysis(ProjectDemandPlanExportVO vo) {

    }

    @Override
    public void execution(BoardImportDTO data) {

    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        return null;
    }
}
