package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 */
@Data
public class SupplierAndProjectVO {

    @ApiModelProperty("项目信息下拉框")
    private List<ProjectIdAndNameVO> projects;





}
