package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 查看详情展示VO
 * @author szp
 * @date 2022/10/14 15:35
 */
@Data
public class PaintDemandPlanViewVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("库存表ID")
    private String materialStockId;

    @ApiModelProperty("项目需求计划表id")
    private String projectDemandPlanId;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("颜色")
    private String colour;
    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;
    @ConversionNumber
    @ApiModelProperty("面积")
    private Long area;

    @ApiModelProperty("执行标准")
    private String executiveStandards;
    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("库存类型")
    private Integer stockType;


    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;
}
