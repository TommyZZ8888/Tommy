package com.vren.material.module.purchasecontract.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
@TableName("supplier")
public class Supplier {

    @TableId(type = IdType.ASSIGN_UUID)
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("分供方名称")
    private String supplierName;

    @ApiModelProperty("分供方ID")
    private String supplierId;

    @ApiModelProperty("分供方编号")
    private String supplierNumber;

    @ApiModelProperty("账号")
    private String accountNumber;

    @ApiModelProperty("统一社会信用代码")
    private String unifiedSocialCreditCode;

    @ApiModelProperty("注册资本")
    private Double registeredCapital;

    @ApiModelProperty("联系人")
    private String contacts;

    @ApiModelProperty("联系电话")
    private String contactNumber;

    @ApiModelProperty("企业地址")
    private String businessAddress;

    @ApiModelProperty("准入机构")
    private String admittedInstitutions;

    @ApiModelProperty("创建时间")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty("更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

}
