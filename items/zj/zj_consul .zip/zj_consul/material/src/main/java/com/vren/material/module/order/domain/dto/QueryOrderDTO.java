package com.vren.material.module.order.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author GR
 * @Time 2023-04-10-13-42
 **/
@Data
public class QueryOrderDTO extends PageParam {

    @ApiModelProperty("订单编号")
    private String orderNumber;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("供应商id")
    private String supplierId;


}
