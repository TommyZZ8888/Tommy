package com.vren.material.module.order.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Author GR
 * @Time 2023-04-11-15-20
 **/
@Data
public class OrderDetailVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("订单id")
    private String orderId;

    @ApiModelProperty("采购计划详情id")
    private String purchasePlanDetailId;

    @ApiModelProperty("订单数量")
    @ConversionNumber
    private Long orderQuantity;

    /**
     *  采购详情信息
     */

    /**
     * 油漆
     */

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型code")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("油漆——颜色")
    private String color;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Integer purchaseAmount;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("油漆——面积")
    @ConversionNumber
    private Long purchaseArea;

    @ApiModelProperty("技术标准")
    private String executiveStandards;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("到货数量")
    private Integer arrivalAmount;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long proposalPrice;

    @ApiModelProperty("税前单价")
    @ConversionNumber(value = 10000)
    private Long preTaxPrice;

    @ApiModelProperty("税额")
    @ConversionNumber
    private Long tax;

    /**
     * 产品
     */

    @ApiModelProperty("产品——材质")
    private String texture;

    @ApiModelProperty("产品——采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    /**
     *  焊材
     */

    @ApiModelProperty("油漆——型号")
    private String model;

    @ApiModelProperty("油漆——牌号")
    private String brand;

    @ApiModelProperty("油漆——技术标准")
    private String technicalStandard;

    @ApiModelProperty("市场最高价")
    @ConversionNumber
    private Long highestMarketPrice;

    @ApiModelProperty("市场最低价")
    @ConversionNumber
    private Long lowestMarketPrice;

    @ApiModelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("市场含税单价")
    @ConversionNumber(value = 10000)
    private Long marketUnitPriceTax;

    @ApiModelProperty("市场加权均价")
    @ConversionNumber
    private Long marketWeightedAverage;

    @ApiModelProperty("建议控制价")
    @ConversionNumber
    private Long proposedControlPrice;

    @ApiModelProperty("商务核准价格")
    @ConversionNumber
    private Long businessApprovedPrice;

    @ApiModelProperty("最终批准价格")
    @ConversionNumber
    private Long finalApprovalPriceField;

    @ApiModelProperty("标书加权均价")
    private Long weightedAverageBidPrice;

    @ApiModelProperty("已生成订单数量")
    @ConversionNumber
    private Long generatedOrderQuantity;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("订单限额")
    private Long orderLimit;

    @ApiModelProperty("到货日期")
    private Date arrivalTime;

    @ApiModelProperty("合同编号")
    private String contractNo;

}
