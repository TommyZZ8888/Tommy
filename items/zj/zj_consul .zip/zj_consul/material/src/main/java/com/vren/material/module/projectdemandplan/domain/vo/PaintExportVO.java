package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  油漆导出VO
 */
@Data
public class PaintExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("自增序号")
    private Integer autoincrementId;

    @ExcelProperty("件号")
    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    @ExcelProperty("名称")
    private String materialName;

    @ApiModelProperty("规格")
    @ExcelProperty("规格")
    private String size;

    @ApiModelProperty("名称及规格")
    @ExcelIgnore
    private String materialNameAndSize;

    @ApiModelProperty("颜色")
    @ExcelProperty("颜色")
    private String colour;

    @ConversionNumber
    @ApiModelProperty("数量")
    @ExcelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("面积")
    @ExcelProperty("面积")
    private Long area;

    @ExcelProperty("总面积")
    @ApiModelProperty("总重(根据面积和个数计算)")
    private Double totalArea;

    @ApiModelProperty("执行标准")
    @ExcelIgnore
    private String executiveStandards;

    @ApiModelProperty("执行标准")
    @ExcelProperty("执行标准")
    private String enforceStandards;



    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "交货时间",converter = DateConverter.class)
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    @ExcelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;


    @ApiModelProperty("序号")
    @ExcelIgnore
    private Integer serialNumber;


}
