package com.vren.material.module.productmanagement.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductOutlineVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("制造编号【产品名称】")
    private String value;

    @ApiModelProperty("产品名称")
    private String  productName;

    @ApiModelProperty("制造编号(生产编号)")
    private String manufacturingNumber;

    @ApiModelProperty("容器类别")
    private String containerCategory;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

}
