package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author GR
 * @time 2023-04-13-17-20
 **/
@Data
public class OrderInProcessVO {

    @ApiModelProperty("订单编号")
    @NotBlank(message = "订单编号不能为空")
    private String orderNumber;

    @ApiModelProperty("合同清单id")
    @NotBlank(message = "合同不能为空")
    private String contractListId;

    @ApiModelProperty("需方:中建五洲工程装备有限公司")
    private String demander;

    @ApiModelProperty("送货地址")
    @NotBlank(message = "送货地址不能为空")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    @NotBlank(message = "收货联系人不能为空")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    @NotBlank(message = "联系电话不能为空")
    private String contactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("供应商名称")
    private String supplierName;

    @ApiModelProperty("供应商联系人")
    private String contacts;

    @ApiModelProperty("供应商联系电话")
    private String supplierContactNumber;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    private List<OrderDetailVO> orderDetailVOS;


}
