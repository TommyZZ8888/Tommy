package com.vren.material.module.order.domain.enums;

/**
 * @author GR
 * @time 2023-04-14-15-32
 **/
public enum StateEnum {

    UNDER_REVIEW(0,"正在审核"),
    APPROVAL(1,"通过审核"),
    FAILED_AUDIT(3,"未通过审核");

    private Integer code;

    private String name;

    StateEnum(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
