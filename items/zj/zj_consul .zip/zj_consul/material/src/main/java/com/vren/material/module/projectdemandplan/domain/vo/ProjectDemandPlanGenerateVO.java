package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 项目需求计划生成VO
 * @author szp
 * @date 2022/10/14 17:14
 */
@Data
public class ProjectDemandPlanGenerateVO {

    @ApiModelProperty("产品需求计划详情id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;



    @ApiModelProperty("件号")
    private String partNo;
    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("材质")
    private String material;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;
    @ApiModelProperty("材料名称")
    private String materialName;


    @ConversionNumber
    @ApiModelProperty("第一尺寸")
    private Long firstSize;
    @ConversionNumber
    @ApiModelProperty("第二尺寸")
    private Long secondSize;
    @ConversionNumber
    @ApiModelProperty("第三尺寸")
    private Long thirdSize;

    @ApiModelProperty("第四尺寸/外购标准")
    private String fourthSizeOutsourcingStandards;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;
    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;
    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ApiModelProperty("执行标准")
    private String enforceStandards;
    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long demandProposalPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;
    @ApiModelProperty("制造编号&件号")
    private String manufacturingNumberPartNo;
    @ApiModelProperty("产品需求计划id")
    private String productDemandPlanId;

}
