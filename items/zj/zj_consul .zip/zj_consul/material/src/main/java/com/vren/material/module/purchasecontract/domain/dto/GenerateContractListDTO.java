package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author 耿让
 */
@Data
public class GenerateContractListDTO {

    /**
     * 选择一个或多个项目，一个项目类型
     */
    @ApiModelProperty("项目id（多个）")
    private List<String> projectIds;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("合同名称")
    private String contractName;

    @ApiModelProperty("采购名称")
    @NotBlank(message = "采购名称不能为空")
    private String purchaseName;

}
