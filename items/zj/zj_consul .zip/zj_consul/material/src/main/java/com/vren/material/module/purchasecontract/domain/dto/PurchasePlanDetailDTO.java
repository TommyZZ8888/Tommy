package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author 耿让
 */
@Data
public class PurchasePlanDetailDTO {

    @ApiModelProperty("采购计划id")
    @NotBlank(message = "采购计划id不能为空")
    private String purchasePlanId;

    @ApiModelProperty("物资类型")
    @NotNull(message = "物资类型不能为空")
    private Integer materialType;

}
