package com.vren.material.common.utils;

import com.vren.common.common.utils.CommonUtil;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @Description WordDataUtil
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */
public class WordDataListUtil {

    public static List<Map<String, String>> getDataMapList(List<?> collect) {
        List<Map<String, String>> list = new ArrayList<>();
        AtomicInteger serialNum = new AtomicInteger();
        collect.forEach(item -> {
            Field[] declaredFields = item.getClass().getDeclaredFields();
            Map<String, String> map = new HashMap<>();
            for (Field declaredField : declaredFields) {
                try {
                    String name = declaredField.getName();
                    String methodName = name.substring(0, 1).toUpperCase() + name.substring(1); //将属性的首字符大写，方便构造get，set方法
                    Method m = item.getClass().getMethod("get" + methodName);
                    Object methodValue = CommonUtil.isNull(m.invoke(item)) ? "" : m.invoke(item);
                    String value = "" + methodValue;
                    if ("getSerialNum".equals(m.getName())) {
                        value = value + serialNum.incrementAndGet();
                    }
                    map.put(name, CommonUtil.isNull(value) ? "" : value);
                } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                    throw new RuntimeException(e);
                }
            }
            list.add(map);
        });

        return list;
    }


    public static Map<String, Object> getDataMap(Object clazz) {
        Field[] declaredFields = clazz.getClass().getDeclaredFields();
        Map<String, Object> map = new HashMap<>();
        for (Field declaredField : declaredFields) {
            try {
                String name = declaredField.getName();
                String methodName = name.substring(0, 1).toUpperCase() + name.substring(1); //将属性的首字符大写，方便构造get，set方法
                Method m = clazz.getClass().getMethod("get" + methodName);
                Object methodValue = CommonUtil.isNull(m.invoke(clazz)) ? "" : m.invoke(clazz);
                Object value = methodValue;
                map.put(name, value);
            } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        return map;
    }

}
