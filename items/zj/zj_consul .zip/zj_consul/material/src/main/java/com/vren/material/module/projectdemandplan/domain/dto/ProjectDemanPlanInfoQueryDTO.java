package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description ProjectDemanPlanNoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class ProjectDemanPlanInfoQueryDTO {

    @ApiModelProperty("项目id列表")
    private List<String> projectIds;
}
