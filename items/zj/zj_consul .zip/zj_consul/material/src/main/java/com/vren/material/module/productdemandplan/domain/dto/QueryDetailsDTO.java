package com.vren.material.module.productdemandplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class QueryDetailsDTO extends PageParam {

    @ApiModelProperty("产品需求计划id")
    @NotBlank(message = "产品需求计划id不能为空")
    private String productDemandPlanId;

    @ApiModelProperty("产品id")
    private String productInformationId;

    @ApiModelProperty("材料名称")
    private String materialName;


    @ApiModelProperty("物资类型")
    private String materialType;


    @ApiModelProperty("件号")
    private String partNo;


}
