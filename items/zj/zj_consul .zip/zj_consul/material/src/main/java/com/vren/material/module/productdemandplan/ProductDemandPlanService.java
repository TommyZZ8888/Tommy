package com.vren.material.module.productdemandplan;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.MyMergeHandler;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.material.dto.QueryProductDTO;
import com.vren.common.module.product.ProductService;
import com.vren.common.module.product.domain.dto.ProductPlanCreateDTO;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.quality.QualityService;
import com.vren.common.module.quality.domain.dto.ProductQualityDTO;
import com.vren.material.module.order.domain.enums.StateEnum;
import com.vren.material.module.productdemandplan.domain.dto.*;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTexture;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTypeEntity;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlan;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.domain.vo.*;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.productdemandplan.mapper.MaterialTextureMapper;
import com.vren.material.module.productdemandplan.mapper.MaterialTypeMapper;
import com.vren.material.module.productdemandplan.mapper.ProductDemandPlanMapper;
import com.vren.material.module.productmanagement.ProductManageService;
import com.vren.material.module.productmanagement.domain.dto.DeleteOrGetOneDTO;
import com.vren.material.module.productmanagement.domain.dto.*;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.productmanagement.domain.vo.ProductAndDemandVO;
import com.vren.material.module.productmanagement.domain.vo.ProductByProjectIdVO;
import com.vren.material.module.productmanagement.domain.vo.ProductDemandVO;
import com.vren.material.module.productmanagement.domain.vo.ProductInformationVO;
import com.vren.material.module.projectdemandplan.domain.entity.ProductDemandPlanTotal;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.mapper.ProductDemandPlanTotalMapper;
import com.vren.material.module.purchasecontract.domain.dto.StartContractListWorkFlow;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Service
@Slf4j
public class ProductDemandPlanService {

    @Autowired
    private UserService userService;

    @Autowired
    private QualityService qualityService;

    @Autowired
    private ProductService productService;

    @Autowired
    private MaterialTypeMapper materialTypeMapper;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProductManageService productManageService;

    @Autowired
    private ProductDemandPlanMapper productDemandPlanMapper;

    @Autowired
    private ProductDemandPlanDetailsMapper productDemandPlanDetailsMapper;


    @Autowired
    private ProductDemandPlanTotalMapper productDemandPlanTotalMapper;


    @Autowired
    private MaterialTextureMapper materialTextureMapper;


    public List<ProductDemandPlan> selectAllProductDemandPlan() {
        return productDemandPlanMapper.selectList(null);
    }


    public ProductDemandPlanDetails selectByProductDemandPlanDetailsId(String productDemandPlanDetailsId) {
        return productDemandPlanDetailsMapper.selectById(productDemandPlanDetailsId);
    }

    public ProductDemandPlanTotal selectByProductDemandPlanTotalId(String productDemandPlanTotalId) {
        return productDemandPlanTotalMapper.selectById(productDemandPlanTotalId);
    }


    public ProductDemandPlan selectById(String id) {
        return productDemandPlanMapper.selectById(id);

    }

    public PageResult<ProductDemandPlanVO> getProductDemandPlan(QueryDTO dto) {
        Page<ProductDemandPlanVO> page = PageUtil.convert2QueryPage(dto);

        //根据计划编号查询产品计划表
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlan.class)
                .like(!CommonUtil.isNull(dto.getScheduleNo()), ProductDemandPlan::getScheduleNo, dto.getScheduleNo())
                .eq(!CommonUtil.isNull(dto.getReviewState()), ProductDemandPlan::getReviewState, dto.getReviewState())
                .orderByDesc(ProductDemandPlan::getCreateTime);
        //项目名称不为空（项目id）
        if (!CommonUtil.isNull(dto.getProjectName())) {
            //根据项目id筛选查询结果
            //根据项目id查询所有的产品id
            List<String> productIds = productManageService.getProductIdByProjectId(dto.getProjectName());
            if (productIds.size() > 0) {
                wrapper.in(ProductDemandPlan::getProductInformationId, productIds);
            } else {
                //项目下面没有产品，查询结果为空
                return new PageResult<>();
            }
        }
        //产品名称不为空时
        if (!CommonUtil.isNull(dto.getProductName())) {
            wrapper.eq(ProductDemandPlan::getProductInformationId, dto.getProductName());
        }
        IPage<ProductDemandPlanVO> productDemandPlanVOIPage = productDemandPlanMapper.selectJoinPage(page, ProductDemandPlanVO.class, wrapper);
        productDemandPlanVOIPage.getRecords().stream().forEach(item -> {
            ProductInformationVO productInformationDetail = productManageService.getProductInformationDetail(item.getProductInformationId());
            //设置产品名称
            if (!CommonUtil.isNull(productInformationDetail)) {
                item.setProductName(productInformationDetail.getProductName());
                String projectName = projectService.getById(productInformationDetail.getProjectId()).getProjectName();
                item.setProjectName(projectName);
                item.setTotalFigureNo(productInformationDetail.getTotalFigureNo());
            }
            //通过产品id获取项目名称
            if (!CommonUtil.isNull(item.getCompiler())) {
                item.setCompiler(userService.getUserInfoByID(item.getCompiler()).getCHName());
            }
        });
        return PageUtil.convert2PageResult(productDemandPlanVOIPage);
    }


    public void addOrEditProductDemandPlan(UpdateProductDemanPlanDTO dto) {
        if (dto.getNumber() < 1) {
            throw new RuntimeException("数量不能小于1");
        }
        //2023/03/01 产品需求计划新增，加上需求数量，每次新增的数量累加起来不能大于产品实际数量
        // 某个产品需求计的总和  <  产品总数

        ProductDemandPlan productDemand = BeanUtil.copy(dto, ProductDemandPlan.class);
        String manufacturingNumber = productManageService.getProductInformationDetail(dto.getProductInformationId()).getManufacturingNumber();
        productDemand.setManufacturingNumber(manufacturingNumber);
        QueryWrapper<ProductDemandPlan> wrapper = new QueryWrapper<>();
        if (CommonUtil.isNull(dto.getId())) {
            //新增,计划编号不能重复
            wrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getScheduleNo()), "schedule_no", dto.getScheduleNo())
                    .last("limit 1");
            Long count = productDemandPlanMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("计划编号已经存在");
            }
            //2023/03/01  新增批次字段
            //已有的产品需求计划 数量加1  格式：  第i批次
            MPJLambdaWrapper<ProductDemandPlan> queryWrapper = new MPJLambdaWrapper<>();
            queryWrapper.select(ProductDemandPlan::getBatch)
                    .eq(!CommonUtil.isNull(dto.getProductInformationId()), ProductDemandPlan::getProductInformationId, dto.getProductInformationId());
            List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(queryWrapper);
            String batch = productDemandPlans.stream().map(ProductDemandPlan::getBatch).collect(Collectors.toList()).stream().max(Comparator.comparing(x -> x)).orElse(null);
            //2023/03/02
            //批次用最大的批次  加1
            String batchInsert;
            if (!CommonUtil.isNull(batch)) {
                int substring = Integer.parseInt(batch.substring(1, 2));
                batchInsert = "第" + (substring + 1) + "批次";
            } else {
                batchInsert = "第1批次";
            }
            productDemand.setBatch(batchInsert);
            //编制人为当前操作用户
            productDemand.setCompiler(ThreadLocalUser.get().getUserId());
            //默认 未生成项目需求计划
            productDemand.setFlagProjectDemandPlan(false);
            productDemandPlanMapper.insert(productDemand);
            String id = productDemand.getProductInformationId();
            this.addByProductId(id, batchInsert);
        } else {
            ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
            if (!CommonUtil.isNull(productDemandPlan.getState())) {
                if (StateEnum.UNDER_REVIEW.getCode().equals(productDemandPlan.getState())) {
                    throw new RuntimeException("产品需求计划正在审核中！");
                }
                if (StateEnum.APPROVAL.getCode().equals(productDemandPlan.getState()) || StateEnum.FAILED_AUDIT.getCode().equals(productDemandPlan.getState())) {
                    throw new RuntimeException("产品需求计划已完成审核！");
                }
            }
            //编辑，计划不能重复
            wrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getScheduleNo()), "schedule_no", dto.getScheduleNo())
                    .notIn("id", dto.getId())
                    .last("limit 1");
            Long count = productDemandPlanMapper.selectCount(wrapper);
            if (count > 0) {
                throw new RuntimeException("计划编号已经存在");
            }
            productDemandPlanMapper.updateById(productDemand);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteProductDemandPlan(String id, String batch) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(id);
        if (productDemandPlan.isFlagProjectDemandPlan()) {
            throw new RuntimeException("已生成项目需求计划，不可删除！");
        }
        if (!CommonUtil.isNull(productDemandPlan.getState())) {
            if (StateEnum.UNDER_REVIEW.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划正在审核中！");
            }
            if (StateEnum.APPROVAL.getCode().equals(productDemandPlan.getState()) || StateEnum.FAILED_AUDIT.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划已完成审核！");
            }
        }
        String productInformationId = productDemandPlan.getProductInformationId();
        if (productDemandPlanMapper.deleteById(id) > 0) {
            //产品需求计划删除成功，删除下面关联的详情
            QueryWrapper<ProductDemandPlanDetails> queryWrapper = new QueryWrapper<>();
            queryWrapper.in("product_information_id", productInformationId);
            productDemandPlanDetailsMapper.delete(queryWrapper);
            //产品需求计划删除成功，删除对应的物资类型（材料说明）
            QueryWrapper<MaterialTypeEntity> materialTypeEntityQueryWrapper = new QueryWrapper<>();
            materialTypeEntityQueryWrapper.in("product_information_id", productInformationId)
                    .eq(!CommonUtil.isNull(batch), "batch", batch);
            materialTypeMapper.delete(materialTypeEntityQueryWrapper);
        }
    }

    public ProductDemandPlanVO getProductDemandPlanDetail(String id) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(id);
        ProductDemandPlanVO productDemandPlanVO = BeanUtil.copy(productDemandPlan, ProductDemandPlanVO.class);
        //根据产品id获得产品名称
        ProductInformationVO productInformationDetail = productManageService.getProductInformationDetail(productDemandPlanVO.getProductInformationId());
        if (!CommonUtil.isNull(productInformationDetail)) {
            productDemandPlanVO.setProductName(productInformationDetail.getProductName());
        }
        //产品 所有批次数量， 产品数量
        List<ProductAndDemandVO> productOutlineWithDemand = productManageService.getProductAndDemand();
        List<ProductAndDemandVO> collect = productOutlineWithDemand.stream().filter(o -> o.getId().equals(productDemandPlanVO.getProductInformationId())).collect(Collectors.toList());
        if (collect.size() > 0) {
            productDemandPlanVO.setCount(collect.get(0).getNumber() - collect.get(0).getSum() + productDemandPlanVO.getNumber());
        }
        return productDemandPlanVO;
    }


    public PageResult<ProductDemandPlanDetailsWithTotalFigureNoVO> selectProductDemandPlanDetails(QueryDetailsDTO dto) {
        /*
          根据产品id和查询条件查询产品产品需求详情
          1.只传产品id，主界面跳转到子界面(pass)
          2.传查询条件，则是子界面的查询，此时产品id依旧是必传值
         */
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                //2023/03/01 根据产品需求计划id查询
                .eq(!CommonUtil.isNull(dto.getProductDemandPlanId()), ProductDemandPlanDetails::getProductDemandPlanId, dto.getProductDemandPlanId())
                .eq(!CommonUtil.isNull(dto.getProductInformationId()), ProductDemandPlanDetails::getProductInformationId, dto.getProductInformationId())
                .like(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanDetails::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanDetails::getPartNo, dto.getPartNo())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), ProductDemandPlanDetails::getMaterialType, dto.getMaterialType())
                .orderByAsc(ProductDemandPlanDetails::getPartNo);
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        //根据件号排序
        List<ProductDemandPlanDetailsWithTotalFigureNoVO> productDemandPlanDetailsVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsWithTotalFigureNoVO.class);
        productDemandPlanDetailsVOS.forEach(item -> {
            item.setTotalFigureNo(productManageService.getProductInformationDetail(dto.getProductInformationId()).getTotalFigureNo());
        });
        PartNoSortUtil.sort(productDemandPlanDetailsVOS);
        return PageUtil.convert2PageResult(productDemandPlanDetailsVOS, dto);
    }

    public List<MaterialTypeVO> getMaterialType() {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class);
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeEntities, MaterialTypeVO.class);
    }

    public MaterialTextureVO getMaterialTexture(String id) {
        MaterialTexture materialTexture = materialTextureMapper.selectById(id);
        return BeanUtil.copy(materialTexture, MaterialTextureVO.class);
    }


    /**
     * 批量删除产品需求计划
     * @param list
     */
    public void batchDeleteProductDemandPlan(List<String> list) {
        //根据产品信息id批量删除
        LambdaUpdateWrapper<ProductDemandPlan> wrapper = new LambdaUpdateWrapper<>();
        wrapper.in(ProductDemandPlan::getProductInformationId, list);
        productDemandPlanMapper.delete(wrapper);
    }

    public boolean isDeleteProductPlan(List<String> list) {
        QueryWrapper<ProductDemandPlan> wrapper = new QueryWrapper<>();
        wrapper.select("1")
                .in("product_information_id", list)
                .last("limit 1");
        return productDemandPlanMapper.selectCount(wrapper) > 0;
    }


    /**
     * 批量删除产品需求计划详情
     * @param list
     */
    public void batchDeleteProductDemandPlanDetails(List<String> list) {
        LambdaUpdateWrapper<ProductDemandPlanDetails> wrapper = new LambdaUpdateWrapper<>();
        //根据产品信息id批量删除
        wrapper.in(ProductDemandPlanDetails::getProductInformationId, list);
        productDemandPlanDetailsMapper.delete(wrapper);
    }

    public MaterialTypeVO getMaterialTypeById(GetMaterialTypeByProductId dto) {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialTypeEntity::getMaterialType, dto.getMaterialType())
                .eq(!CommonUtil.isNull(dto.getProductInformationId()), MaterialTypeEntity::getProductInformationId, dto.getProductInformationId())
                .eq(!CommonUtil.isNull(dto.getBatch()), MaterialTypeEntity::getBatch, dto.getBatch());
        MaterialTypeEntity materialTypeEntity = materialTypeMapper.selectOne(wrapper);
        return BeanUtil.copy(materialTypeEntity, MaterialTypeVO.class);
    }

    public void editMaterialType(UpdateMaterialTypeDTO dto) {
        UpdateWrapper<MaterialTypeEntity> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(dto.getProductInformationId()), "product_information_id", dto.getProductInformationId())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), "material_type", dto.getMaterialType())
                //2023.03.03 根据批次修改
                .eq(!CommonUtil.isNull(dto.getBatch()), "batch", dto.getBatch())
                .set("remarks", dto.getRemarks());
        materialTypeMapper.update(new MaterialTypeEntity(), wrapper);
    }

    public PageResult<MaterialTextureVO> selectAllMaterialTexture(QueryMaterialTextureDTO dto) {
        Page<MaterialTextureVO> page = PageUtil.convert2QueryPage(dto);
        /*
          查询材质表：代号和材料字段模糊，用料类型下拉等于
         */
        MPJLambdaWrapper<MaterialTexture> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTexture.class)
                .like(!CommonUtil.isNull(dto.getCode()), MaterialTexture::getCode, dto.getCode())
                .like(!CommonUtil.isNull(dto.getMaterial()), MaterialTexture::getMaterial, dto.getMaterial());
        IPage<MaterialTextureVO> materialTextureVOIPage = materialTextureMapper.selectJoinPage(page, MaterialTextureVO.class, wrapper);
        return PageUtil.convert2PageResult(materialTextureVOIPage);
    }

    public void addMaterialTexture(InsertOrUpdateMaterialTextureDTO dto) {
        MaterialTexture materialTexture = BeanUtil.copy(dto, MaterialTexture.class);
        QueryWrapper<MaterialTexture> queryWrapper = new QueryWrapper<>();
        if (CommonUtil.isNull(dto.getId())) {
            //新增
            //code不能重复
            queryWrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getCode()), "code", dto.getCode())
                    .last("limit 1");
            if (materialTextureMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("代号不能重复");
            }
            materialTextureMapper.insert(materialTexture);
        } else {
            //编辑
            queryWrapper.select("1")
                    .eq(!CommonUtil.isNull(dto.getCode()), "code", dto.getCode())
                    .notIn(!CommonUtil.isNull(dto.getId()), "id", dto.getId())
                    .last("limit 1");
            if (materialTextureMapper.selectCount(queryWrapper) > 0) {
                throw new RuntimeException("代号不能重复");
            }
            materialTextureMapper.updateById(materialTexture);
        }
    }

    public void batchDeleteMaterialTexture(BatchDeleteDTO dto) {
        //批量删除
        materialTextureMapper.deleteBatchIds(dto.getIds());
    }

    public void batchDeleteMaterialType(List<String> productInformationIds) {
        //根据产品id删除
        LambdaQueryWrapper<MaterialTypeEntity> wrapper = new LambdaQueryWrapper<>();
        wrapper.in(MaterialTypeEntity::getProductInformationId, productInformationIds);
        materialTypeMapper.delete(wrapper);
    }

    public List<MaterialTextureVO> selectAllMaterialTextureWithoutPage() {
        MPJLambdaWrapper<MaterialTexture> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTexture.class);
        List<MaterialTexture> materialTextures = materialTextureMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTextures, MaterialTextureVO.class);
    }


    @Transactional(rollbackFor = Exception.class)
    public void batchAddProductDemandPlanDetails(BatchInsertDetailDTO dto) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getList().get(0).getProductDemandPlanId());
        if (!CommonUtil.isNull(productDemandPlan.getState())) {
            if (StateEnum.UNDER_REVIEW.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划正在审核中！");
            }
            if (StateEnum.APPROVAL.getCode().equals(productDemandPlan.getState()) || StateEnum.FAILED_AUDIT.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划已完成审核！");
            }
        }

        ArrayList<ProductDemandPlanDetails> productDemandPlanDetailsList = new ArrayList<>();
        List<InsertDetailDTO> list = dto.getList();
        List<String> partNos = list.stream().map(InsertDetailDTO::getPartNo).collect(Collectors.toList());
        QueryWrapper<ProductDemandPlanDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(list.get(0).getProductDemandPlanId()), "product_demand_plan_id", list.get(0).getProductDemandPlanId())
                .in(CommonUtil.listIsNotEmpty(partNos), "part_no", partNos);
        Long count = productDemandPlanDetailsMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new RuntimeException("一个产品下面的件号不能重复");
        }
        list.forEach(item -> {
            item.setId(null);
            if ((item.getMaterialType().equals(MaterialType.BOARD.getName()) && !"复合板".equals(item.getMaterialName())) || (item.getMaterialType().equals(MaterialType.PROFILE.getName())) && !item.getIsCalculate()) {
                //需要计算
                //第一尺寸由String转为Long
                if (StringUtils.isNotBlank(item.getFirstSizeString())) {
                    Number number = Float.parseFloat(item.getFirstSizeString()) * 100;
                    int value = number.intValue();
                    Long firstSize = (long) value;
                    item.setFirstSize(firstSize);
                }

                //计算重量和规格
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                ProductDemandPlanDetails execution = bean.execution(item);
                productDemandPlanDetailsList.add(execution);
            } else {
                //如果是锻件、外购件和辅材类型，第一尺寸就是规格
                ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(item, ProductDemandPlanDetails.class);
                productDemandPlanDetails.setSpecification(item.getSpecification());
                if (item.getFirstSizeString() != null) {
                    productDemandPlanDetails.setSpecification(item.getFirstSizeString());
                }
                if (item.getSecondSize() != null) {
                    productDemandPlanDetails.setWeight(item.getSecondSize());
                }

                //设置 默认值  未生成项目需求计划
                productDemandPlanDetailsList.add(productDemandPlanDetails);
            }
        });


        //判断code是否在材质表存在，如果已经存在，则忽略；如果不存在，则直接新增
        //参数中的code
        List<MaterialTexture> materialTextures = BeanUtil.copyList(list, MaterialTexture.class);
        List<String> codeList = materialTextures.stream().map(MaterialTexture::getCode).distinct().collect(Collectors.toList());
        //表中已经存在的code
        List<MaterialTextureVO> materialTextureVOS = selectAllMaterialTextureWithoutPage();
        List<String> collect = materialTextureVOS.stream().map(MaterialTextureVO::getCode).collect(Collectors.toList());
        //当代号为空的时候，材质表不新增
        if (CommonUtil.listIsNotEmpty(codeList)) {
            collect.retainAll(codeList);
            codeList.removeAll(collect);
            //新增code为codeList的材质数据
            for (String code : codeList) {
                if (!CommonUtil.isNull(code)) {
                    List<MaterialTexture> textures = materialTextures.stream().filter(item -> item.getCode().equals(code)).collect(Collectors.toList());
                    int insert = materialTextureMapper.insert(textures.get(0));
                    log.info("材质表新增数据条数：{}", insert);
                }
            }
        }
        productDemandPlanDetailsMapper.insertBatchSomeColumn(productDemandPlanDetailsList);
        //需求标书总价
        long sum = productDemandPlanDetailsList.stream().map(demand -> CommonUtil.isNull(demand.getDemandProposalPrice()) ? 0 : demand.getDemandProposalPrice()).mapToLong(item -> item).sum();
        //产品需求计划详情里面有新增的，产品需求计划改为能再次生成项目需求计划
        //更新产品需求计划表中的   产品需求计划   是否生成项目需求计划  为false
        UpdateWrapper<ProductDemandPlan> updateWrapper = new UpdateWrapper<>();
        //2023/06/12  产品需求计划详情新增，更新需求标书总价
        updateWrapper.eq("id", list.get(0).getProductDemandPlanId())
                .set("flag_project_demand_plan", 0);
        updateWrapper.set(!CommonUtil.isNull(sum), "demand_proposal_total", sum);
        productDemandPlanMapper.update(new ProductDemandPlan(), updateWrapper);
    }


    public void insertProductDemandPlanDetails(BatchInsertDetailDTO dto) {
        ArrayList<ProductDemandPlanDetails> productDemandPlanDetailsList = new ArrayList<>();
        List<InsertDetailDTO> list = dto.getList();
        //判断参数中的件号，是否已经存在
        //根据产品信息id和参数中的件号，查询件号出现的次数
        //件号
        List<String> partNos = list.stream().map(InsertDetailDTO::getPartNo).collect(Collectors.toList());
        QueryWrapper<ProductDemandPlanDetails> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("1")
                .eq(!CommonUtil.isNull(list.get(0).getProductDemandPlanId()), "product_demand_plan_id", list.get(0).getProductDemandPlanId())
                .in(CommonUtil.listIsNotEmpty(partNos), "part_no", partNos);
        Long count = productDemandPlanDetailsMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new RuntimeException("一个产品下面的件号不能重复");
        }
        list.forEach(item -> {
            item.setId(null);
            ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(item, ProductDemandPlanDetails.class);
            productDemandPlanDetails.setSpecification(item.getSpecification());
            productDemandPlanDetailsList.add(productDemandPlanDetails);
        });

        //判断code是否在材质表存在，如果已经存在，则忽略；如果不存在，则直接新增
        List<MaterialTexture> materialTextures = BeanUtil.copyList(list, MaterialTexture.class);
        List<String> codeList = materialTextures.stream().map(MaterialTexture::getCode).distinct().collect(Collectors.toList());
        //表中已经存在的code
        List<MaterialTextureVO> materialTextureVOS = selectAllMaterialTextureWithoutPage();
        List<String> collect = materialTextureVOS.stream().map(MaterialTextureVO::getCode).collect(Collectors.toList());
        //当代号为空的时候，材质表不新增
        if (CommonUtil.listIsNotEmpty(codeList)) {
            collect.retainAll(codeList);
            codeList.removeAll(collect);
            //新增code为codeList的材质数据
            for (String code : codeList) {
                if (!CommonUtil.isNull(code)) {
                    List<MaterialTexture> textures = materialTextures.stream().filter(item -> item.getCode().equals(code)).collect(Collectors.toList());
                    materialTextureMapper.insert(textures.get(0));
                }
            }
        }
        productDemandPlanDetailsMapper.insertBatchSomeColumn(productDemandPlanDetailsList);
        long sum = productDemandPlanDetailsList.stream().map(demand -> CommonUtil.isNull(demand.getDemandProposalPrice()) ? 0 : demand.getDemandProposalPrice()).mapToLong(item -> item).sum();
        UpdateWrapper<ProductDemandPlan> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", list.get(0).getProductDemandPlanId())
                .set("flag_project_demand_plan", 0);
        updateWrapper.set(!CommonUtil.isNull(sum), "demand_proposal_total", sum);
        productDemandPlanMapper.update(new ProductDemandPlan(), updateWrapper);
    }


    public ProductDemandPlanDetailVO selectDetailsOne(DeleteOrGetOneDTO dto) {
        ProductDemandPlanDetails productDemandPlanDetails = productDemandPlanDetailsMapper.selectById(dto.getId());
        ProductDemandPlanDetailVO vo = BeanUtil.copy(productDemandPlanDetails, ProductDemandPlanDetailVO.class);
        //如果是型材和板材，第一尺寸就是数字；否则就是规格
        if ((vo.getMaterialType().equals(MaterialType.BOARD.getName()) && !"复合板".equals(vo.getMaterialName())) || (vo.getMaterialType().equals(MaterialType.PROFILE.getName()) && !vo.getIsCalculate())) {
            vo.setFirstSizeString(String.valueOf(vo.getFirstSize().doubleValue() / 100));
        } else {
            vo.setFirstSizeString(vo.getSpecification());
        }
        return vo;
    }

    public void editDetails(InsertDetailDTO dto) {
        ProductDemandPlanDetails select = productDemandPlanDetailsMapper.selectById(dto.getId());
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(select.getProductDemandPlanId());
        if (!CommonUtil.isNull(productDemandPlan.getState())) {
            if (StateEnum.UNDER_REVIEW.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划正在审核中！");
            }
            if (StateEnum.APPROVAL.getCode().equals(productDemandPlan.getState()) || StateEnum.FAILED_AUDIT.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划已完成审核！");
            }
            //已经生成过项目需求计划的，产品需求计划不可编辑

            if (!CommonUtil.isNull(select.getProjectDemandPlanId())) {
                throw new RuntimeException("已生成项目需求计划，不可编辑");
            }
        }

        /*
           12/06:编辑功能同新增那边一样
         */
        if (dto.getMaterialType().equals(MaterialType.BOARD.getName()) || dto.getMaterialType().equals(MaterialType.PROFILE.getName())) {
            if (!dto.getIsCalculate()) {
                //需要进行计算
                //第一尺寸由String转为Long
                Number number = Float.parseFloat(dto.getFirstSizeString()) * 100;
                int value = number.intValue();
                Long firstSize = (long) value;
                dto.setFirstSize(firstSize);
                //计算
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, dto.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                ProductDemandPlanDetails execution = bean.execution(dto);
                productDemandPlanDetailsMapper.updateById(execution);
            } else {
                //型材第一尺寸是规格，第二尺寸是重量
                ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(dto, ProductDemandPlanDetails.class);
                if (dto.getFirstSizeString() != null) {
                    productDemandPlanDetails.setSpecification(dto.getFirstSizeString());
                }
                if (dto.getSecondSize() != null) {
                    productDemandPlanDetails.setWeight(dto.getSecondSize());
                }
                productDemandPlanDetailsMapper.updateById(productDemandPlanDetails);
            }
        } else {
            //第一尺寸就是规格，第二尺寸就是重量
            //如果是锻件、外购件和辅材类型，第一尺寸就是规格
            ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(dto, ProductDemandPlanDetails.class);
            if (!CommonUtil.isNull(dto.getFirstSizeString())) {
                productDemandPlanDetails.setSpecification(dto.getFirstSizeString());
            }
            if (!CommonUtil.isNull(dto.getSecondSize())) {
                productDemandPlanDetails.setWeight(dto.getSecondSize());
            }
            productDemandPlanDetailsMapper.updateById(productDemandPlanDetails);
        }

    }

    public void deleteDetails(DeleteOrGetOneDTO dto) {
        ProductDemandPlanDetails select = productDemandPlanDetailsMapper.selectById(dto.getId());
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(select.getProductDemandPlanId());
        if (!CommonUtil.isNull(productDemandPlan.getState())) {
            if (StateEnum.UNDER_REVIEW.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划正在审核中！");
            }
            if (StateEnum.APPROVAL.getCode().equals(productDemandPlan.getState()) || StateEnum.FAILED_AUDIT.getCode().equals(productDemandPlan.getState())) {
                throw new RuntimeException("产品需求计划已完成审核！");
            }
            //已经生成过项目需求计划的，产品需求计划不可删除

            if (select.getIsCalculate()) {
                throw new RuntimeException("已生成项目需求计划，不可删除");
            }
        }
        //删除
        productDemandPlanDetailsMapper.deleteById(dto.getId());
    }

    public void editTimeAndLocation(EditTimeAndLocationDTO dto) {
        productDemandPlanDetailsMapper.editTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }

    /**
     * 根据产品信息表id 查询产品需求计划明细
     * 按照物资类型分为多个sheet页（自定义表头）
     * 板材  管材/型材  导出格式一样  （ProductDemandPlanDetailsExportVO）
     * 锻件  辅材   外购件  导出格式一样
     * 材质是组合件的不导出
     * 12/19 材质是组合件的正常导出；锻材、辅材、外购件导出材质为空；型材中第一尺寸填写的是规格，材料为角钢，对规格进行单独的解析
     */
    public void export(HttpServletResponse response, DeleteOrGetOneDTO dto) throws IOException {
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        //根据所有产品id所有的产品需求计划明细（pass）
        //2023/03/01 根据产品需求计划id查询产品需求计划详情
        MPJLambdaWrapper<ProductDemandPlanDetails> detailsWrapper = new MPJLambdaWrapper<>();
        detailsWrapper.selectAll(ProductDemandPlanDetails.class)
//                .eq(ProductDemandPlanDetails::getProductInformationId, dto.getId())
                .eq(ProductDemandPlanDetails::getProductDemandPlanId, dto.getId())
//                .ne(ProductDemandPlanDetails::getMaterial,"组合件")
//                .orderByAsc(ProductDemandPlanDetails::getProductInformationId)
                .orderByAsc(ProductDemandPlanDetails::getPartNo);
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(detailsWrapper);
        //复制到vo中
        List<ProductDemandPlanDetailsExportVO> vos = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsExportVO.class);
        //根据件号排序
        PartNoSortUtil.sort(vos);
        //通过产品信息表id获取制造编号和计划编号
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        //这里的物资类型根据产品id和对应批次,   里面的备注是需要的材料说明
        List<MaterialTypeVO> materialTypes = this.getMaterialTypeByProductId(productDemandPlan.getProductInformationId(), productDemandPlanMapper.selectById(dto.getId()).getBatch());
        List<WriteHandler> writeHandlers = new ArrayList<>();

        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        //将数据按照物资类型分组
        Map<String, List<ProductDemandPlanDetailsExportVO>> map = vos.stream().collect(Collectors.groupingBy(ProductDemandPlanDetailsExportVO::getMaterialType));

        for (MaterialTypeVO type : materialTypes) {
            String materialType = type.getMaterialType();
            if (map.get(materialType) != null) {
                //该类型存在数据不存,map获取结果可能为null
                if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 12))));
                } else if (materialType.equals(MaterialType.AUXILIARY_MATERIALS.getName()) || materialType.equals(MaterialType.PURCHASED_PARTS.getName())) {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 9))));
                } else {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 10))));
                }
            }
        }
        ProductInformationVO productInformationDetail = productManageService.getProductInformationDetail(productDemandPlan.getProductInformationId());
        String productName = productInformationDetail.getProductName();

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/template.xlsx");

        ExcelExportService excelExportService = new ExcelExportService("产品需求计划详情-" + productName + "-" + productDemandPlan.getScheduleNo() + "-" + productDemandPlan.getBatch(), response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //制造编号
        String param1 = productDemandPlan.getManufacturingNumber() != null ? productDemandPlan.getManufacturingNumber() : "";
        //计划编号
        String param2 = productDemandPlan.getScheduleNo() != null ? productDemandPlan.getScheduleNo() : "";
        for (int i = 0; i < materialTypes.size(); i++) {
            String materialType = materialTypes.get(i).getMaterialType();
            //自增序号，列表数据
            List<ProductDemandPlanDetailsExportVO> voList = map.get(materialType);
            List<RemarkVO> remarkVOS = new ArrayList<>();
            HashMap<String, Object> data = new HashMap<>();
            data.put("param3", materialType);
            if (voList != null) {
                AtomicInteger num = new AtomicInteger();
                for (ProductDemandPlanDetailsExportVO vo : voList) {
                    vo.setAutoincrementId(num.incrementAndGet());
                }
                for (ProductDemandPlanDetailsExportVO item : voList) {
                    //根据用料类型来设置厚度、宽度和长度
                    String ingredientsType = item.getIngredientsType();
                    if ("角钢".equals(item.getMaterialName())) {
                        try {
                            String specification = item.getSpecification();
                            //长度是第三尺寸
                            int indexOf = specification.indexOf("=");
                            item.setThirdSizeExport(decimalFormat.format(Double.valueOf(specification.substring(indexOf + 1))));
                            //厚度是第二尺寸
                            int end = 0;
                            //规格里面的逗号可能是中文，可能是英文
                            if (specification.contains(",")) {
                                end = specification.indexOf(",");
                            } else if (specification.contains("，")) {
                                end = specification.indexOf("，");
                            }
                            item.setSecondSizeExport(specification.substring(0, end));
                        } catch (Exception e) {
                            throw new RuntimeException("角钢的规格不符合规范");
                        }
                    }
                    if (!CommonUtil.isNull(ingredientsType)) {
                        //第三尺寸是长度
                        //第二尺寸是厚度
                        //第一尺寸是直径
                        if (ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                            //管形
                            item.setThirdSizeExport(decimalFormat.format(item.getThirdSize().doubleValue() / 100));
                            item.setSecondSizeExport(decimalFormat.format(item.getSecondSize().doubleValue() / 100));
                            item.setFirstSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                        } else if (ingredientsType.equals(ComputerType.SQUARE.getCode())) {
                            //方形
                            item.setThirdSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                            item.setSecondSizeExport(decimalFormat.format(item.getSecondSize().doubleValue() / 100));
                        } else if (ingredientsType.equals(ComputerType.RECTANGLE.getCode())) {
                            //矩形
                            item.setThirdSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                            item.setSecondSizeExport(decimalFormat.format(item.getThirdSize().doubleValue() / 100));
                            item.setFirstSizeExport(decimalFormat.format(item.getSecondSize().doubleValue() / 100));
                        } else if (ingredientsType.equals(ComputerType.STICK_SHAPE.getCode())) {
                            //棒形
                            item.setThirdSizeExport(decimalFormat.format(item.getSecondSize().doubleValue() / 100));
                            item.setFirstSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                        } else if (ingredientsType.equals(ComputerType.ANNULAR.getCode())) {
                            //环形：从规格中解析出来
                            String specification = item.getSpecification();
                            //长度
                            String firstSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
                            //宽度
                            String secondSize = specification.substring(specification.lastIndexOf("X") + 1);
                            //厚度
                            String thirdSize = specification.substring(1, specification.indexOf("X"));
                            //厚度
                            item.setSecondSizeExport(thirdSize);
                            //长度
                            item.setThirdSizeExport(decimalFormat.format(Double.valueOf(firstSize)));
                            //宽度
                            item.setFirstSizeExport(decimalFormat.format(Double.valueOf(secondSize)));

                        } else if (ingredientsType.equals(ComputerType.CIRCULAR.getCode())) {
                            //圆形
                            item.setSecondSizeExport(decimalFormat.format(item.getSecondSize().doubleValue() / 100));
                            item.setFirstSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                        } else if (ingredientsType.equals(ComputerType.DRUM.getCode())) {
                            //根据规格拆分
                            String specification = item.getSpecification();
                            //δ48X350X175   拆分规则如下
                            //厚度   直径  长度
                            int lastIndexOf = specification.lastIndexOf("X");
                            int indexOf = specification.indexOf("X");
                            item.setThirdSizeExport(decimalFormat.format(Double.valueOf(specification.substring(lastIndexOf + 1))));
                            item.setFirstSizeExport(decimalFormat.format(Double.valueOf(specification.substring(indexOf + 1, lastIndexOf))));
                            item.setSecondSizeExport(specification.substring(1, indexOf));
                        } else {
                            item.setThirdSizeExport(decimalFormat.format(item.getThirdSize().doubleValue() / 100));
                            item.setSecondSizeExport(decimalFormat.format(item.getSecondSize() / 100));
                            item.setFirstSizeExport(decimalFormat.format(item.getFirstSize().doubleValue() / 100));
                        }
                    }

                    if ("复合板".equals(item.getMaterialName())) {
                        String specification = item.getSpecification();
                        item.setFirstSizeExport("");
                        //规格第一列是second
                        item.setSecondSizeExport(specification);
                        item.setThirdSizeExport("");
                    }
                    //2023/01/30  数量 = 数量 +  备件数量
                    item.setCountExport((item.getCount().doubleValue() + item.getSparePartsQuantity().doubleValue()) / 100);
                    //2023/02/01  如果有备件，导出就在备注里面加上：备件+数量
                    if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                        if (item.getSparePartsQuantity() > 0) {
                            item.setRemarks(item.getRemarks() + "备件" + item.getSparePartsQuantity() / 100 + "件");
                        }
                    }
                    if (!CommonUtil.isNull(item.getWeight())) {
                        if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())) {
                            item.setWeightExport(item.getWeight().doubleValue() / 100);
                        } else {
                            item.setWeightExport(item.getWeight().doubleValue() / 100);
                        }
                    }
                }
                //计算列总和
                double total = voList.stream().filter(item -> !CommonUtil.isNull(item.getWeightExport())).mapToDouble(ProductDemandPlanDetailsExportVO::getWeightExport).sum();
                double count = voList.stream().filter(item -> !CommonUtil.isNull(item.getCountExport())).mapToDouble(ProductDemandPlanDetailsExportVO::getCountExport).sum() * 100;
                //数据库尺寸是扩大一百倍的，这里需要缩小
                //自定义参数数据
                data.put("param1", param1);
                data.put("param2", param2);
                data.put("total", total);
                data.put("count", count / 100);
                //备注数据:根据产品id查询
                String remarks = materialTypes.get(i).getRemarks();
                if (CommonUtil.isNull(remarks)) {
                    RemarkVO remarkVO = new RemarkVO();
                    remarkVOS.add(remarkVO);
                } else {
                    String[] split = remarks.split("\n");
                    for (int j = 0; j < split.length; j++) {
                        RemarkVO remarkVO = new RemarkVO();
                        remarkVO.setSeq(j + 1);
                        remarkVO.setContent(split[j]);
                        remarkVOS.add(remarkVO);
                    }
                }
            }

            if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                excelExportService.fill(new FillWrapper("list", voList), materialType);
            } else if (materialType.equals(MaterialType.AUXILIARY_MATERIALS.getName()) || materialType.equals(MaterialType.PURCHASED_PARTS.getName())) {
                List<ExportVO> exportVOS = BeanUtil.copyList(voList, ExportVO.class);
                exportVOS.forEach(item -> item.setMaterialNameAndSpecification(item.getMaterialName() + "-" + item.getSpecification()));
                excelExportService.fill(new FillWrapper("list", exportVOS), materialType);
            } else {
                List<ProductDemandPlanDetailsExportCopyVO> copyVOS = BeanUtil.copyList(voList, ProductDemandPlanDetailsExportCopyVO.class);
                excelExportService.fill(new FillWrapper("list", copyVOS), materialType);
            }
            //备注
            excelExportService.fill(new FillWrapper("remark", remarkVOS), materialType);
            //表头
            excelExportService.fill(data, materialType);
        }
        /*
          导出封面内容
         */
        //项目编号:根据产品需求计划id查询产品信息表，在产品信息表中获取项目id，获得项目信息
        String projectId = productInformationDetail.getProjectId();
        ProjectVO projectVO = projectService.getById(projectId);
        String projectNo = projectVO.getProjectNo();
        //项目名称
        String projectName = projectVO.getProjectName();
        HashMap<String, Object> data = new HashMap<>();
        data.put("param2", param2);
        data.put("organization", productDemandPlan.getCompiler());
        data.put("organizationTime", productDemandPlan.getPrepartation());
        data.put("engineer", productDemandPlan.getProofreader());
        data.put("process", productDemandPlan.getProofreadingTime());
        data.put("manager", productDemandPlan.getReviewer());
        data.put("reviewTime", productDemandPlan.getReviewTime());
        data.put("approval", productDemandPlan.getChecker());
        data.put("approvalTime", productDemandPlan.getCheckTime());
        data.put("projectNo", projectNo);
        data.put("projectName", projectName);
        excelExportService.fill(data, "封面");
        /*
          导出编制说明
         */
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
        String[] split = productDemandPlan.getPreparationDescription().split("\n");
        for (int i = 0; i < split.length; i++) {
            RemarkVO remarkVO = new RemarkVO();
            remarkVO.setSeq(i + 1);
            remarkVO.setContent(split[i]);
            remarkVOS.add(remarkVO);
        }
        excelExportService.fill(new FillWrapper("explain", remarkVOS), "编制说明");
        excelExportService.export();
    }

    public List<ProductDemandPlanDetailsVO> selectDetailsByProductId(GetManyById dto) {
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .eq(!CommonUtil.isNull(dto.getKeyId()), ProductDemandPlanDetails::getProductInformationId, dto.getKeyId());
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        List<ProductDemandPlanDetailsVO> productDemandServiceVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsVO.class);
        productDemandServiceVOS.forEach(item -> {
            if (CommonUtil.isNull(item.getCount())) {
                item.setCount(0L);
            }
            if (CommonUtil.isNull(item.getFirstSize())) {
                item.setFirstSize(0L);
            }
            if (CommonUtil.isNull(item.getSecondSize())) {
                item.setSecondSize(0L);
            }
            if (CommonUtil.isNull(item.getThirdSize())) {
                item.setThirdSize(0L);
            }
            if (CommonUtil.isNull(item.getDemandProposalPrice())) {
                item.setDemandProposalPrice(0L);
            }
            if (CommonUtil.isNull(item.getProportion())) {
                item.setProportion(0L);
            }
            if (CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantity(0L);
            }
            if (CommonUtil.isNull(item.getWeight())) {
                item.setWeight(0L);
            }
            item.setSpecificationText(item.getSpecification());
            //规格和备注
            //材料类型是板材规格是  δ + 厚度
            if (item.getMaterialType().equals(MaterialType.BOARD.getName())) {
                if (!CommonUtil.isNull(item.getIngredientsType())) {
                    //根据用料类型判断厚度
                    //环形和矩形的第三尺寸是厚度， 圆形、管形、管、方形和卷筒的第二尺寸厚度
                    //棒形没有厚度
                    String ingredientsType = item.getIngredientsType();
                    if (ingredientsType.equals(ComputerType.ANNULAR.getCode()) || ingredientsType.equals(ComputerType.RECTANGLE.getCode())) {
                        item.setSpecificationText("δ" + item.getThirdSize() / 100);
                    }
                    if (ingredientsType.equals(ComputerType.CIRCULAR.getCode()) ||
                            ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                            ingredientsType.equals(ComputerType.TUBE.getCode()) ||
                            ingredientsType.equals(ComputerType.SQUARE.getCode()) ||
                            ingredientsType.equals(ComputerType.DRUM.getCode())) {
                        item.setSpecificationText("δ" + item.getSecondSize() / 100);
                    }
                } else {
                    item.setSpecificationText("δ" + item.getThirdSize() / 100);
                }
            }
            //用料类型是棒形规格是直径 φ + 直径
            if (item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                item.setSpecificationText("φ" + item.getFirstSize() / 100);
            }
            //用料类型是管形规格是φ273×8
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                if (item.getSpecification().contains(",") && item.getSpecification().contains("φ")) {
                    //根据逗号拆分
                    int index = item.getSpecification().indexOf(",");
                    item.setSpecificationText(item.getSpecification().substring(0, index));
                }
            }
            //用料类型环形 第四尺寸放在备注
            if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())) {
                item.setRemarkText(item.getFourthSizeOutsourcingStandards() + "拼");
            }
            //用料类型是管形、棒形 长度放在备注
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                    item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                if (item.getSpecification().contains("L")) {
                    int indexOf = item.getSpecification().indexOf(",");
                    item.setRemarkText(item.getSpecification().substring(indexOf + 1));
                }
            }
            //材料类型是型材第一尺寸是str 长度放在备注
            if (item.getMaterialType().equals(MaterialType.PROFILE.getName()) && item.getIsCalculate()) {
                if (item.getSpecification().contains("L")) {
                    //后面  L=5000要去掉
                    int index = item.getSpecification().indexOf("L");
                    item.setSpecificationText(item.getSpecification().substring(0, index - 1));
                    item.setRemarkText(item.getSpecification().substring(index));
                }
            }

        });
        return productDemandServiceVOS;
    }

    public List<MaterialTypeVO> getMaterialTypeByProductIdAndBatch(GetMaterialTypeDTO dto) {
        return this.getMaterialTypeByProductId(dto.getProductInformationId(), dto.getBatch());
    }

    public List<MaterialTypeVO> getMaterialTypeByProductId(String productInformationId, String batch) {
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class)
                .eq(!CommonUtil.isNull(productInformationId), MaterialTypeEntity::getProductInformationId, productInformationId)
                .eq(!CommonUtil.isNull(batch), MaterialTypeEntity::getBatch, batch);
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeEntities, MaterialTypeVO.class);
    }

    public void addByProductId(String id, String batch) {
        ArrayList<MaterialTypeEntity> materialTypeEntities = new ArrayList<>();
        ArrayList<String> list = new ArrayList<>();
        list.add("板材");
        list.add("型材");
        list.add("锻件");
        list.add("外购件");
        list.add("辅材");
        //五种类型数据添加
        for (String s : list) {
            MaterialTypeEntity materialTypeEntity = new MaterialTypeEntity();
            materialTypeEntity.setProductInformationId(id);
            materialTypeEntity.setMaterialType(s);
            materialTypeEntity.setBatch(batch);
            materialTypeEntities.add(materialTypeEntity);
        }
        materialTypeMapper.insertBatchSomeColumn(materialTypeEntities);
    }


    public List<ProductDemandSelectVO> getProductDemandSelect(DeleteOrGetOneDTO dto) {
        //根据项目id，查询所有未生成过产品需求计划 的产品需求计划
        //查询项目下面的产品
        ProjectIdDTO projectIdDTO = new ProjectIdDTO();
        projectIdDTO.setProjectId(dto.getId());
        List<ProductByProjectIdVO> productByProjectId = productManageService.getProductByProjectId(projectIdDTO);
        if (CommonUtil.listIsNotEmpty(productByProjectId)) {
            //产品id
            Map<String, List<ProductByProjectIdVO>> collect = productByProjectId.stream().collect(Collectors.groupingBy(ProductByProjectIdVO::getId));
            //在产品需求计划中查询  属于该项目下的产品 并且 尚未生成项目需求计划的
            MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
            ArrayList<String> strings = new ArrayList<>(collect.keySet());
            wrapper.selectAll(ProductDemandPlan.class)
                    .eq(ProductDemandPlan::isFlagProjectDemandPlan, false)
                    .in(CommonUtil.listIsNotEmpty(strings), ProductDemandPlan::getProductInformationId, strings);
            List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
            ArrayList<ProductDemandSelectVO> productDemandSelectVOS = new ArrayList<>();
            productDemandPlans.forEach(
                    item -> {
                        StringBuffer buffer = new StringBuffer();
                        if (!CommonUtil.isNull(item.getManufacturingNumber())) {
                            buffer.append(item.getManufacturingNumber() + "_");
                        }
                        buffer.append(collect.get(item.getProductInformationId()).get(0).getProductName() + "_"
                                + item.getBatch() + "_" + (item.getNumber() / 100));
                        ProductDemandSelectVO build = ProductDemandSelectVO.builder().id(item.getId()).value(buffer.toString()).build();
                        productDemandSelectVOS.add(build);
                    }
            );
            return productDemandSelectVOS;
        } else {
            return new ArrayList<>();
        }
    }

    public List<SelectVO> getMaterialTypeSelect() {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        selectVOS.add(SelectVO.builder().id(1).materialType("板材").build());
        selectVOS.add(SelectVO.builder().id(2).materialType("型材").build());
        selectVOS.add(SelectVO.builder().id(3).materialType("锻件").build());
        selectVOS.add(SelectVO.builder().id(4).materialType("辅材").build());
        selectVOS.add(SelectVO.builder().id(5).materialType("外购件").build());

        return selectVOS;
    }

    public List<SelectVO> getMaterialType(GetMaterialTypeDTO dto) {
        ArrayList<SelectVO> selectVOS = new ArrayList<>();
        selectVOS.add(SelectVO.builder().id(1).materialType("板材").build());
        selectVOS.add(SelectVO.builder().id(2).materialType("型材").build());
        selectVOS.add(SelectVO.builder().id(3).materialType("锻件").build());
        selectVOS.add(SelectVO.builder().id(4).materialType("辅材").build());
        selectVOS.add(SelectVO.builder().id(5).materialType("外购件").build());
        return selectVOS;
    }

    public List<ProductDemandPlanSelectVO> getProductDemandPlanSelect() {
        //value 的值产品需求计划拼接
        //所有的产品需求计划
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(null);
        ArrayList<ProductDemandPlanSelectVO> productOutlineVOS = new ArrayList<>();
        productDemandPlans.forEach(item -> {
            ProductDemandPlanSelectVO productOutlineVO = new ProductDemandPlanSelectVO();
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            if (!CommonUtil.isNull(productInformation)) {
                productOutlineVO.setId(item.getId());
                productOutlineVO.setProjectId(productInformation.getProjectId());
                productOutlineVO.setProjectName(projectService.getById(productInformation.getProjectId()).getProjectName());
                String value = productInformation.getManufacturingNumber() + "【" + productInformation.getProductName() + "】" + "-" + item.getScheduleNo();
                productOutlineVO.setValue(value);
                productOutlineVO.setProductName(productInformation.getProductName());
                productOutlineVO.setManufacturingNumber(productInformation.getManufacturingNumber());
                productOutlineVO.setContainerCategory(productInformation.getContainerCategory());
                productOutlineVO.setBatch(item.getBatch());
                productOutlineVO.setScheduleNo(item.getScheduleNo());
                productOutlineVOS.add(productOutlineVO);
            }
        });
        return productOutlineVOS;
    }

    public List<ProductDemandPlanDetailsForProcessVO> selectDetailsByProductDemandPlanId(GetManyById dto) {
        //根据产品需求 查询产品需求明细，dto中的keyId是产品需求计划id
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getKeyId());
        Long count = productDemandPlan.getNumber() / 100;
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .eq(!CommonUtil.isNull(dto.getKeyId()), ProductDemandPlanDetails::getProductDemandPlanId, dto.getKeyId());
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        List<ProductDemandPlanDetailsForProcessVO> productDemandServiceVOS = BeanUtil.copyList(productDemandPlanDetails, ProductDemandPlanDetailsForProcessVO.class);
        productDemandServiceVOS.forEach(item -> {

            //产品需求明细里面的 重量、数量和备件数量 需要除以  产品需求数量
            if (CommonUtil.isNull(item.getCount())) {
                item.setCount(100L);
            } else {
                if (item.getCount() / count < 100) {
                    item.setCount(100L);
                }
                item.setCount(item.getCount() / count);
            }
            if (CommonUtil.isNull(item.getFirstSize())) {
                item.setFirstSize(0L);
            }
            if (CommonUtil.isNull(item.getSecondSize())) {
                item.setSecondSize(0L);
            }
            if (CommonUtil.isNull(item.getThirdSize())) {
                item.setThirdSize(0L);
            }
            if (CommonUtil.isNull(item.getDemandProposalPrice())) {
                item.setDemandProposalPrice(0L);
            }
            if (CommonUtil.isNull(item.getProportion())) {
                item.setProportion(0L);
            }
            if (CommonUtil.isNull(item.getSparePartsQuantity()) || item.getSparePartsQuantity() == 0) {
                item.setSparePartsQuantity(0L);
            } else {
                if (item.getSparePartsQuantity() / 100 < count) {
                    item.setSparePartsQuantity(1L);
                } else {
                    item.setSparePartsQuantity(item.getSparePartsQuantity() / 100 / count);
                }
            }
            if (CommonUtil.isNull(item.getWeight())) {
                item.setWeight(0L);
            } else {
                item.setWeight(item.getWeight() / count);
            }
            item.setSpecificationText(item.getSpecification());
            //规格和备注
            //材料类型是板材规格是  δ + 厚度
            if (item.getMaterialType().equals(MaterialType.BOARD.getName())) {
                if (!CommonUtil.isNull(item.getIngredientsType())) {
                    //根据用料类型判断厚度
                    //环形和矩形的第三尺寸是厚度， 圆形、管形、管、方形和卷筒的第二尺寸厚度
                    //棒形没有厚度
                    String ingredientsType = item.getIngredientsType();
                    if (ingredientsType.equals(ComputerType.ANNULAR.getCode()) || ingredientsType.equals(ComputerType.RECTANGLE.getCode())) {
                        item.setSpecificationText("δ" + item.getThirdSize() / 100);
                    }
                    if (ingredientsType.equals(ComputerType.CIRCULAR.getCode()) ||
                            ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                            ingredientsType.equals(ComputerType.TUBE.getCode()) ||
                            ingredientsType.equals(ComputerType.SQUARE.getCode()) ||
                            ingredientsType.equals(ComputerType.DRUM.getCode())) {
                        item.setSpecificationText("δ" + item.getSecondSize() / 100);
                    }
                } else {
                    item.setSpecificationText("δ" + item.getThirdSize() / 100);
                }
            }
            //用料类型是棒形规格是直径 φ + 直径
            if (item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                item.setSpecificationText("φ" + item.getFirstSize() / 100);
            }
            //用料类型是管形规格是φ273×8
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                if (item.getSpecification().contains(",") && item.getSpecification().contains("φ")) {
                    //根据逗号拆分
                    int index = item.getSpecification().indexOf(",");
                    item.setSpecificationText(item.getSpecification().substring(0, index));
                }
            }
            //用料类型环形 第四尺寸放在备注
            if (item.getIngredientsType().equals(ComputerType.ANNULAR.getCode())) {
                item.setRemarkText(item.getFourthSizeOutsourcingStandards() + "拼");
            }
            //用料类型是管形、棒形 长度放在备注
            if (item.getIngredientsType().equals(ComputerType.TUBULAR_SHAPE.getCode()) ||
                    item.getIngredientsType().equals(ComputerType.STICK_SHAPE.getCode())) {
                if (item.getSpecification().contains("L")) {
                    int indexOf = item.getSpecification().indexOf(",");
                    item.setRemarkText(item.getSpecification().substring(indexOf + 1));
                }
            }
            //材料类型是型材第一尺寸是str 长度放在备注
            if (item.getMaterialType().equals(MaterialType.PROFILE.getName()) && item.getIsCalculate()) {
                if (item.getSpecification().contains("L")) {
                    //后面  L=5000要去掉
                    try {
                        int index = item.getSpecification().lastIndexOf("L");
                        item.setSpecificationText(item.getSpecification().substring(0, index - 1));
                        item.setRemarkText(item.getSpecification().substring(index));
                    } catch (Exception e) {
                        item.setSpecificationText(item.getSpecification());
                    }
                }
            }
            if (item.getCount() < 100) {
                item.setCount(100L);
            }
        });
        return productDemandServiceVOS;
    }

    public PageResult<ProductDemandPlanNotProductionPlanVO> getProductDemandPlanNotProductionPlan(QueryProductDemandDTO dto) {
        //查询未处于生产计划的产品需求计划
        Page<ProductDemandPlanNotProductionPlanVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlan.class)
                .like(!CommonUtil.isNull(dto.getManufacturingNumber()), ProductDemandPlan::getManufacturingNumber, dto.getManufacturingNumber())
                .eq(ProductDemandPlan::getIsProductionPlan, 0)
                .orderByDesc(ProductDemandPlan::getCreateTime);
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
        //封装信息主要还是产品信息，只保留批次 和 计划编号
        ArrayList<ProductDemandPlanNotProductionPlanVO> productDemandPlanNotProductionPlanVOS = new ArrayList<>();
        productDemandPlans.forEach(item -> {
            ProductDemandPlanNotProductionPlanVO vo = new ProductDemandPlanNotProductionPlanVO();
            //获取产品信息
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            vo.setId(item.getId());
            vo.setProjectId(productInformation.getProjectId());
            vo.setProductName(productInformation.getProductName());
            vo.setTagNo(productInformation.getTagNo());
            vo.setProductSpecificatons(productInformation.getProductSpecificatons());
            vo.setTotalFigureNo(productInformation.getTotalFigureNo());
            vo.setNumber(item.getNumber());
            vo.setContainerCategory(productInformation.getContainerCategory());
            vo.setUseUnit(productInformation.getUseUnit());
            vo.setManufacturingNumber(productInformation.getManufacturingNumber());
            vo.setWeight(productInformation.getWeight());
            vo.setIsProductionPlan(item.getIsProductionPlan());
            vo.setIsProductionScheduling(item.getIsProductionScheduling());
            vo.setBatch(item.getBatch());
            vo.setScheduleNo(item.getScheduleNo());
            productDemandPlanNotProductionPlanVOS.add(vo);
        });
        return PageUtil.convert2PageResult(productDemandPlanNotProductionPlanVOS, dto);
    }

    /**
     * 根据产品需求计划创建生产计划（调用产品模块的接口），产品计划生成成功后，更改产品需求计划里面的生产状态
     * @param dto 产品需求计划id
     * @return 创建成功：true  失败：false
     */
    @Transactional(rollbackFor = Exception.class)
    public ResponseResult<Boolean> createProductPlan(CreateProductPlanDTO dto) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        if (CommonUtil.isNull(productDemandPlan)) {
            throw new RuntimeException("该产品需求计划不存在");
        }
        ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
        //生产计划的DTO
        ProductPlanCreateDTO productPlanCreateDTO = new ProductPlanCreateDTO();
        //生产计划关联到产品需求计划
        productPlanCreateDTO.setProjectKeyId(productDemandPlan.getProductInformationId());
        productPlanCreateDTO.setManufacturingNumber(productInformation.getManufacturingNumber());
        productPlanCreateDTO.setTagNo(productInformation.getTagNo());
        productPlanCreateDTO.setContainerCategory(productInformation.getContainerCategory());
        productPlanCreateDTO.setProductName(productInformation.getProductName());
        productPlanCreateDTO.setProductSpecificatons(productInformation.getProductSpecificatons());
        //主要材质，暂时不考虑
        productPlanCreateDTO.setMainMaterial(null);
        productPlanCreateDTO.setQuantity((int) (productDemandPlan.getNumber() / 100));
        productPlanCreateDTO.setWeight(Double.valueOf(productInformation.getWeight()));
        //用户：就是使用单位
        productPlanCreateDTO.setCustomer(productInformation.getUseUnit());
        //2023/03/09
        productPlanCreateDTO.setProductDemandKeyId(dto.getId());
        productPlanCreateDTO.setBatch(productDemandPlan.getBatch());
        productPlanCreateDTO.setScheduleNo(productDemandPlan.getScheduleNo());
        productPlanCreateDTO.setProjectId(productInformation.getProjectId());
        //调用产品模块的创建生产计划的接口
        ResponseResult<Boolean> productPlan = productService.createProductPlan(productPlanCreateDTO);
        if (productPlan.getData()) {
            //创建生产计划成功，更新产品需求计划对应的产品生产状态
            UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
            wrapper.eq("id", dto.getId())
                    .set("is_production_plan", 1);
            if (productDemandPlanMapper.update(new ProductDemandPlan(), wrapper) > 0) {
                return ResponseResult.success("操作成功", true);
            }
        } else {
            return productPlan;
        }
        return ResponseResult.error("创建生产计划失败", false);
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean changeProductScheduling(ProductSchedulingDTO dto) {
        UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq(!CommonUtil.isNull(dto.getId()), "id", dto.getId())
                .set(!CommonUtil.isNull(dto.getCode()), "is_production_scheduling", dto.getCode());
        int update = productDemandPlanMapper.update(new ProductDemandPlan(), wrapper);
        if (update > 0) {
            //之前productId 现在改成产品需求计划id，其他的保持不变
            ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
            ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
            //调用质量模块的接口，新增一条产品质量记录的信息
            ProductQualityDTO productQualityDTO = new ProductQualityDTO();
            productQualityDTO.setProjectId(productInformation.getProjectId());
            productQualityDTO.setProductId(dto.getId());
            Boolean quality = qualityService.insertProductQuality(productQualityDTO);
            if (quality) {
                log.info("新增了一条产品质量质检记录");
            }
        }
        return update > 0;
    }

    public boolean changeProductPlan(DeleteOrGetOneDTO dto) {
        //更新产品需求计划中的生产状态
        UpdateWrapper<ProductDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.set("is_production_plan", 0)
                .eq("id", dto.getId());
        if (productDemandPlanMapper.update(new ProductDemandPlan(), wrapper) > 0) {
            //生产模块删除数据  删除质量模块的 质检数据
            boolean demand = qualityService.deleteProductQualityByProductDemand(dto.getId());
            log.info("质量模块删除数据:{}", demand);
            return demand;
        }
        return false;
    }

    public List<ProductDemandInProductionSchedulingVO> getProductDemandInProductionScheduling() {
        MPJLambdaWrapper<ProductDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlan.class)
                .eq(ProductDemandPlan::getIsProductionScheduling, 1)
                .orderByDesc(ProductDemandPlan::getCreateTime);
        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectList(wrapper);
        ArrayList<ProductDemandInProductionSchedulingVO> list = new ArrayList<>();
        productDemandPlans.forEach(item -> {
            ProductInformation productInformation = productManageService.getById(item.getProductInformationId());
            if (!CommonUtil.isNull(productInformation)) {
                ProductDemandInProductionSchedulingVO demand = BeanUtil.copy(productInformation, ProductDemandInProductionSchedulingVO.class);
                demand.setId(item.getId());
                demand.setIsProductionPlan(item.getIsProductionPlan());
                demand.setIsProductionScheduling(item.getIsProductionScheduling());
                demand.setBatch(item.getBatch());
                demand.setScheduleNo(item.getScheduleNo());
                list.add(demand);
            }
        });
        return list;
    }

    public ProductDemandVO selectByKeyId(KeyIdDTO dto) {
        //根据产品需求计划id查询
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getKeyId());
        ProductInformation productInformation = productManageService.getById(productDemandPlan.getProductInformationId());
        ProductDemandVO productDemandVO = BeanUtil.copy(productInformation, ProductDemandVO.class);
        productDemandVO.setId(productDemandPlan.getId());
        productDemandVO.setBatch(productDemandPlan.getBatch());
        productDemandVO.setScheduleNo(productDemandPlan.getScheduleNo());
        productDemandVO.setProjectName(projectService.getById(productDemandVO.getProjectId()).getProjectName());
        return productDemandVO;
    }

    public com.vren.common.module.material.entity.ProductInformationVO getProductInformationByName(QueryProductDTO dto) {

        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        if (CommonUtil.isNull(productDemandPlan)) {
            throw new RuntimeException("获取产品信息失败");
        }
        dto.setId(productDemandPlan.getProductInformationId());
        ProductInformationVO productInformationVO = productManageService.getProductInformationByName(dto);
        if (!CommonUtil.isNull(productInformationVO)) {
            com.vren.common.module.material.entity.ProductInformationVO copy = BeanUtil.copy(productInformationVO, com.vren.common.module.material.entity.ProductInformationVO.class);
            copy.setBatch(productDemandPlan.getBatch());
            copy.setScheduleNo(productDemandPlan.getScheduleNo());
            return copy;
        }
        return new com.vren.common.module.material.entity.ProductInformationVO();

    }

    public String getProcess(List<ProdutPlanProgressList> productPlanProgressList) {
        //查询项目下面产品总数
        List<ProductInformationVO> productInformationVOS = productManageService.getProductByProject(productPlanProgressList.get(0).getProjectId());
        long sum = productInformationVOS.stream().mapToLong(ProductInformationVO::getNumber).sum();
        //产品需求计划中数量
        AtomicReference<Long> finish = new AtomicReference<>((long) 0);
        productPlanProgressList.forEach(
                item -> {
                    ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(item.getProductDemandKeyId());
                    if (!CommonUtil.isNull(productDemandPlan)) {
                        finish.set(finish.get() + productDemandPlan.getNumber() * item.getTotalProgress() / 100);
                    }
                }
        );
        DecimalFormat decimalFormat = new DecimalFormat("#.00");
        return decimalFormat.format(finish.get().doubleValue() / sum * 100);
    }

    public void updateSpecifications() {
        //根据板材和型材的规格,重新生成规格
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .eq(ProductDemandPlanDetails::getIsCalculate, "0")
                .isNotNull(ProductDemandPlanDetails::getIngredientsType);
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        productDemandPlanDetails.forEach(item -> {
            String ingredientsType = item.getIngredientsType();
            switch (ingredientsType) {
                case "环形":
                    if (CommonUtil.isNull(item.getFirstSize()) || CommonUtil.isNull(item.getSecondSize()) || CommonUtil.isNull(item.getThirdSize()) || CommonUtil.isNull(item.getFourthSizeOutsourcingStandards()) || CommonUtil.isNull(item.getProportion())) {
                        throw new RuntimeException(item.getMaterialName() + "的第一尺寸、第二尺寸、第三尺寸、第四尺寸和比重不能为空");
                    }
                    double width = 0.0;
                    double length = 0.0;
                    //扇角
                    double fanAngle = 0.0;
                    double area = 0.0;
                    //小弓高
                    double smallArchHeight = 0.0;
                    double weight = 0.0;

                    //扇角的计算
                    fanAngle = 2 * Math.PI / Integer.parseInt(item.getFourthSizeOutsourcingStandards()) / Math.PI * 180;
                    //小弓高的计算
                    smallArchHeight = item.getSecondSize().doubleValue() / 100 / 2 * (1 - Math.cos(fanAngle / 2 / 180 * Math.PI));
                    //小弓高四舍五入，保留一位小数
                    BigDecimal bigDecimal = new BigDecimal(smallArchHeight);
                    smallArchHeight = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();

                    if (Integer.parseInt(item.getFourthSizeOutsourcingStandards()) == 1) {
                        //拼数为1
                        //计算长度
                        length = (item.getFirstSize().doubleValue() / 100 + 10) * item.getCount().doubleValue() / 100;
                        //计算宽度
                        width = item.getFirstSize().doubleValue() / 100 + 0;
                    } else {
                        //拼数不为1
                        //计算长度
                        length = smallArchHeight + (item.getFirstSize().doubleValue() / 100 - item.getSecondSize().doubleValue() / 100) / 2 * Double.parseDouble(item.getFourthSizeOutsourcingStandards()) * item.getCount().doubleValue() / 100
                                + (smallArchHeight - item.getFirstSize().doubleValue() / 100 / 2 * (1 - Math.cos(Math.asin(item.getSecondSize().doubleValue() / 100 * Math.sin(fanAngle / 2 * Math.PI / 180) / (item.getFirstSize().doubleValue() / 100)))) + 2) * (Double.parseDouble(item.getFourthSizeOutsourcingStandards()) * item.getCount().doubleValue() / 100 - 1);
                        BigDecimal decimal = new BigDecimal(length);
                        length = decimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();
                        //计算宽度
                        width = item.getFirstSize().doubleValue() / 100 * Math.sin(fanAngle / 2 * Math.PI / 180) + 0;
                        width = (int) Math.ceil(width);
                    }

                    //宽度向上取整

                    //面积的计算
                    area = length * width / 1000000;
                    //重量的计算
                    weight = area * item.getThirdSize().doubleValue() / 100 * item.getProportion().doubleValue() / 100;


                    //规格  δ 厚度 X 长度 X 宽度
                    String specification = "δ" + decimalFormat.format(item.getThirdSize().doubleValue() / 100) + "X" + decimalFormat.format(length) + "X" + (int) width;
                    item.setSpecification(specification);
                    break;
                case "棒形":

                    String specificationText = "φ" + decimalFormat.format(item.getFirstSize().doubleValue() / 100) + ",L=" + decimalFormat.format(item.getSecondSize().doubleValue() / 100);
                    item.setSpecification(specificationText);
                    break;
                case "管形":
                    String specification1 = "φ" + decimalFormat.format(item.getFirstSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getSecondSize().doubleValue() / 100) + ",L=" + decimalFormat.format(item.getThirdSize().doubleValue() / 100);
                    item.setSpecification(specification1);
                    break;
                case "管":
                    String specification2 = "φ" + decimalFormat.format(item.getFirstSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getSecondSize().doubleValue() / 100) + ",L=" + decimalFormat.format(item.getThirdSize().doubleValue() / 100);
                    item.setSpecification(specification2);
                    break;
                case "方形":
                    String specification3 = "δ" + decimalFormat.format(item.getSecondSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getFirstSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getFirstSize().doubleValue() / 100);
                    item.setSpecification(specification3);
                    break;
                case "圆形":
                    String specification4 = "δ" + decimalFormat.format(item.getSecondSize().doubleValue() / 100) + "Xφ" + decimalFormat.format(item.getFirstSize().doubleValue() / 100);
                    item.setSpecification(specification4);
                    break;
                case "矩形":
                    String specification5 = "δ" + decimalFormat.format(item.getThirdSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getFirstSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getSecondSize().doubleValue() / 100);
                    item.setSpecification(specification5);
                    break;
                case "卷筒":
                    String specification6 = "δ" + decimalFormat.format(item.getSecondSize().doubleValue() / 100) + "X" + decimalFormat.format(item.getThirdSize().doubleValue() / 100) + "X" + decimalFormat.format((int) Math.floor(item.getFirstSize().doubleValue() / 100 * 3.1416 + item.getSecondSize().doubleValue() / 100 * 3.1416 + 1));
                    item.setSpecification(specification6);
                    break;
                default:
                    break;
            }
            productDemandPlanDetailsMapper.updateById(item);
        });
    }

    public List<ProductDemandPlanDetails> getDetailByIds(List<String> ids) {
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .in(CommonUtil.listIsNotEmpty(ids), ProductDemandPlanDetails::getId, ids);
        return productDemandPlanDetailsMapper.selectList(wrapper);
    }

    public boolean startProductDemandPlanWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<ProductDemandPlan> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("state", "0")
                .set("instance_code", dto.getInstanceCode())
                .eq("id", dto.getKeyId());
        return productDemandPlanMapper.update(new ProductDemandPlan(), updateWrapper) > 0;
    }

    public boolean updateProductDemandPlanWorkFlow(StartContractListWorkFlow dto) {
        UpdateWrapper<ProductDemandPlan> updateWrapper = new UpdateWrapper<>();
        if ("true".equals(dto.getResult())) {
            updateWrapper.set("state", "1");
        } else {
            updateWrapper.set("state", "2");
        }
        updateWrapper.eq("id", dto.getKeyId());
        return productDemandPlanMapper.update(new ProductDemandPlan(), updateWrapper) > 0;
    }

    public boolean endProductDemandPlanWorkFlow(StartContractListWorkFlow dto) {
        return true;
    }

    public List<MaterialTypeAndRemarkVO> getMaterialTypeByDemandId(KeyIdDTO dto) {
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getKeyId());
        MPJLambdaWrapper<MaterialTypeEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeEntity.class)
                .eq(!CommonUtil.isNull(productDemandPlan.getProductInformationId()), MaterialTypeEntity::getProductInformationId, productDemandPlan.getProductInformationId())
                .eq(!CommonUtil.isNull(productDemandPlan.getBatch()), MaterialTypeEntity::getBatch, productDemandPlan.getBatch());
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeEntities, MaterialTypeAndRemarkVO.class);
    }

    @Transactional(rollbackFor = Exception.class)
    public void copy(UpdateProductDemanPlanDTO dto) {
        if (dto.getNumber() < 1) {
            throw new RuntimeException("数量不能小于1");
        }
        ProductDemandPlan productDemandPlan = productDemandPlanMapper.selectById(dto.getId());
        ProductDemandPlan productDemand = BeanUtil.copy(productDemandPlan, ProductDemandPlan.class);
        String manufacturingNumber = productManageService.getProductInformationDetail(dto.getProductInformationId()).getManufacturingNumber();
        productDemand.setManufacturingNumber(manufacturingNumber);
        QueryWrapper<ProductDemandPlan> wrapper = new QueryWrapper<>();
        //新增,计划编号不能重复
        wrapper.select("1")
                .eq(!CommonUtil.isNull(dto.getScheduleNo()), "schedule_no", dto.getScheduleNo())
                .last("limit 1");
        Long count = productDemandPlanMapper.selectCount(wrapper);
        if (count > 0) {
            throw new RuntimeException("计划编号已经存在");
        }

        //编制人为当前操作用户
        productDemand.setProductInformationId(dto.getProductInformationId());
        productDemand.setPreparationDescription(dto.getPreparationDescription());
        productDemand.setScheduleNo(dto.getScheduleNo());
        productDemand.setNumber(CommonUtil.isNull(dto.getNumber()) ? productDemand.getNumber() : dto.getNumber());
        productDemand.setCompiler(ThreadLocalUser.get().getUserId());
        productDemand.setId(null);
        productDemand.setIsProductionScheduling(0);
        productDemand.setIsProductionPlan(0);
        productDemand.setFlagProjectDemandPlan(false);
        productDemandPlanMapper.insert(productDemand);

        //子列表数据
        QueryDetailsDTO queryDetailsDTO = new QueryDetailsDTO();
        queryDetailsDTO.setProductDemandPlanId(productDemandPlan.getId());
        queryDetailsDTO.setProductInformationId(productDemandPlan.getProductInformationId());
        queryDetailsDTO.setPageSize(500);
        PageResult<ProductDemandPlanDetailsWithTotalFigureNoVO> productDemandPlanDetailsWithTotalFigureNoVOPageResult = selectProductDemandPlanDetails(queryDetailsDTO);
        List<ProductDemandPlanDetailsWithTotalFigureNoVO> list = productDemandPlanDetailsWithTotalFigureNoVOPageResult.getList();

        List<InsertDetailDTO> insertDetailDTOS = BeanUtil.copyList(list, InsertDetailDTO.class);
        BatchInsertDetailDTO batchInsertDetailDTO = new BatchInsertDetailDTO();
        insertDetailDTOS.forEach(item -> {
            item.setProductDemandPlanId(productDemand.getId());
            item.setProductInformationId(productDemand.getProductInformationId());
            item.setSpecification(item.getSpecification());
        });
        batchInsertDetailDTO.setList(insertDetailDTOS);
        insertProductDemandPlanDetails(batchInsertDetailDTO);

        MPJLambdaWrapper<MaterialTypeEntity> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.selectAll(MaterialTypeEntity.class)
                .eq(MaterialTypeEntity::getProductInformationId, productDemandPlan.getProductInformationId())
                .eq(StringUtils.isNotBlank(productDemand.getBatch()), MaterialTypeEntity::getBatch, productDemand.getBatch());
        List<MaterialTypeEntity> materialTypeEntities = materialTypeMapper.selectList(lambdaWrapper);
        List<MaterialTypeEntity> materialTypeEntityList = BeanUtil.copyList(materialTypeEntities, MaterialTypeEntity.class);
        for (MaterialTypeEntity materialTypeEntity : materialTypeEntityList) {
            materialTypeEntity.setId(null);
            materialTypeEntity.setProductInformationId(productDemand.getProductInformationId());
            materialTypeMapper.insert(materialTypeEntity);
        }
    }

    public void update() {
        List<String> stringList = Arrays.asList("d63d4c4fe9cab80d62509e76f38affb2", "3c4b66a77deaf2aaaaa1057ad9935301",
                "a43dcb460d9fe58973b7b8b65d32afa4", "075139771188ad1e8f4ece04d0f9593c", "d1b056f2361433b62b849aed121897d1");
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanDetails.class)
                .in(ProductDemandPlanDetails::getProductDemandPlanId, stringList)
                .in(ProductDemandPlanDetails::getMaterialType, "板材", "型材");
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);
        productDemandPlanDetails.forEach(item -> {
            if ((item.getMaterialType().equals(MaterialType.BOARD.getName()) && !"复合板".equals(item.getMaterialName())) || (item.getMaterialType().equals(MaterialType.PROFILE.getName())) && !item.getIsCalculate()) {
                ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                Class<? extends ComputerHandler> clazz = computerType.getClazz();
                ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                InsertDetailDTO copy = BeanUtil.copy(item, InsertDetailDTO.class);
                ProductDemandPlanDetails execution = bean.execution(copy);
                item.setWeight(execution.getWeight());
                item.setSpecification(execution.getSpecification());
                productDemandPlanDetailsMapper.updateById(item);
            }
        });
    }


    @Transactional(rollbackFor = Exception.class)
    public void updateSpecificationX() {
        MPJLambdaWrapper<ProductDemandPlanDetails> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProductDemandPlanDetails::getId, ProductDemandPlanDetails::getSpecification, ProductDemandPlanDetails::getMaterialType)
                .in(ProductDemandPlanDetails::getMaterialType, MaterialType.BOARD.getName(), MaterialType.PROFILE.getName());
        List<ProductDemandPlanDetails> productDemandPlanDetails = productDemandPlanDetailsMapper.selectList(wrapper);

        productDemandPlanDetails.forEach(item -> {
            if (StringUtils.isNotBlank(item.getSpecification())) {
                String newSpecification = item.getSpecification().replaceAll("X", "*");
                item.setSpecification(newSpecification);
                productDemandPlanDetailsMapper.updateById(item);
            }
        });
    }
}
