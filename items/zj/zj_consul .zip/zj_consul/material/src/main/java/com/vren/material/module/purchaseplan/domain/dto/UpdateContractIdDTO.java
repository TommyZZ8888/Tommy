package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description UpdateContractIdDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class UpdateContractIdDTO {

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型code")
    private Integer materialType;
}
