package com.vren.material.module.projectdemandplan.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 *  锁库操作
 */
@Data
public class LockStockDTO {

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("锁库数量")
    @ConversionNumber
    private Long lockStockNumber;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("采购计划明细id")
    private String purchaseDemandPlanDetailId;


}
