package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class ContractProductPaintImportVO {


    @ApiModelProperty("材料名称")
    @ExcelProperty(value = "物资名称",index = 1)
    private String materialName;

    @ApiModelProperty("规格")
    @ExcelProperty(value = "规格型号",index = 2)
    private String size;

    @ApiModelProperty(value = "干膜厚（μm）")
    @ConversionNumber
    @ExcelProperty(value = "干膜厚（μm）",index = 3,converter = EasyExcelToLongConverter.class )
    private Long dryFilmThickness;

    @ApiModelProperty("技术标准")
    @ExcelProperty(value = "执行标准",index = 4)
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    @ExcelProperty(value = "单位",index = 5)
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelProperty(value = "数量",index = 6,converter = EasyExcelToLongConverter.class)
    private Long purchaseArea;

    @ApiModelProperty("油漆用量（kg）（含2.0损耗）")
    @ConversionNumber
    @ExcelProperty(value = "油漆用量（kg）（含2.0损耗）",index = 7,converter = EasyExcelToLongConverter.class)
    private Long amountOfPaint;

    @ApiModelProperty("理论用量/涂布率（kg/㎡")
    @ConversionNumber(value = 10000)
    @ExcelProperty(value = "理论用量/涂布率（kg/㎡）",index = 8,converter = EasyExcelToLongConverter.class)
    private Long theoreticalDosage;

    @ApiModelProperty("损耗系数")
    @ConversionNumber
    @ExcelProperty(value = "损耗系数",index = 9,converter = EasyExcelToLongConverter.class)
    private Long lossFactor;

    @ApiModelProperty("体积固含量(%)")
    @ConversionNumber
    @ExcelProperty(value = "体积固含量(%)",index = 10,converter = EasyExcelToLongConverter.class)
    private Long volumeSolidContent;

    @ApiModelProperty("密度（kg/L)")
    @ConversionNumber
    @ExcelProperty(value = "密度（kg/L)",index = 11,converter = EasyExcelToLongConverter.class)
    private Long density;

    @ApiModelProperty("含税油漆单价（元/kg）")
    @ConversionNumber(value = 10000)
    @ExcelProperty(value = "含税油漆单价（元/kg）",index = 12,converter = EasyExcelToLongConverter.class)
    private Long unitPricePaintIncludingTax;

    @ApiModelProperty("稀释剂量kg（25%）")
    @ConversionNumber
    @ExcelProperty(value = "稀释剂量kg（25%）",index = 13,converter = EasyExcelToLongConverter.class)
    private Long dilutionDose;

    @ApiModelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    @ConversionNumber
    @ExcelProperty(value = "含税总单价（元/㎡）含2.0损耗，含25%稀释剂",index = 14,converter = EasyExcelToLongConverter.class)
    private Long totalUnitPriceIncludingTax;

    @ApiModelProperty("含税稀释剂单价（元/kg）")
    @ConversionNumber
    @ExcelProperty(value = "含税稀释剂单价（元/kg）",index = 15,converter = EasyExcelToLongConverter.class)
    private Long unitPriceDiluentIncludingTax;

    @ApiModelProperty("含税平方总价（元）")
    @ConversionNumber
    @ExcelProperty(value = "含税平方总价（元）",index = 16,converter = EasyExcelToLongConverter.class)
    private Long totalSquarePriceIncludingTax;

    @ApiModelProperty("包装规格")
    @ExcelProperty(value = "包装规格",index = 17)
    private String packageSpecification;

    @ApiModelProperty("税率%")
    @ConversionNumber
    @ExcelProperty(value = "税率%",index = 18,converter = EasyExcelToLongConverter.class)
    private Long taxRate;

    @ApiModelProperty("备注（锌粉含量）")
    @ConversionNumber
    @ExcelProperty(value = "备注（锌粉含量）",index = 19)
    private String remarksZincPowderContent;

    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "到货时间",index = 20)
    private Date deliveryTime;

    @ApiModelProperty("备注")
    @ExcelProperty(value = "备注",index = 21)
    private String remarks;

    @ApiModelProperty("入库编号")
    @ExcelProperty(value = "入库编号",index = 22)
    private String warehousingNo;


}
