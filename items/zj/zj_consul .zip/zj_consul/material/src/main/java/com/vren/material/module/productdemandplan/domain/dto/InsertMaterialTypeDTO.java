package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class InsertMaterialTypeDTO {
    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("用料单位")
    private String materialUnit;

    @ApiModelProperty("备注")
    private String remarks;
}
