package com.vren.material.module.purchaseplan.domain.enums;

/**
 * @author 耿让
 *  计划类型
 */

public enum PlanTypeEnum {
    TOTAL(1,"总"),
    MONTHLY(2,"月度"),
    TEMPORARY_EMERGENCY_MATERIAL_PROCUREMENT_PLAN(3,"临时紧急物资采购计划");

    private Integer code;

    private String name;

    PlanTypeEnum(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
