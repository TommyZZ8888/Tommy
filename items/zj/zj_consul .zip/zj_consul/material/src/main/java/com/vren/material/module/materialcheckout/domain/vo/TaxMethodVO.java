package com.vren.material.module.materialcheckout.domain.vo;

import lombok.Data;

@Data
public class TaxMethodVO {
    private Integer code;
    private String value;
}
