package com.vren.material.module.projectdemandplan.domain.enums;

public enum DemandType {
    WELDING_MATERIALS(1, "焊材"),
    PAINT(2, "油漆"),
    BOARD(3, "板材"),
    PROFILE(4, "型材"),
    FORGE_PIECE(5, "锻件"),
    PURCHASED_PARTS(6, "外购件"),
    AUXILIARY_MATERIALS(7, "辅材"),
    SPARE_PARTS(8, "备件");

    DemandType(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;

    public static Integer getCodeByValue(String value){
        DemandType[] values = values();
        for (DemandType demandType : values) {
            if (value.equals(demandType.getName())) {
                return demandType.getCode();
            }
        }
        return null;
    }
}
