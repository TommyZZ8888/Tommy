package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName:Test
 * @Author: vren
 * @Date: 2022/10/19 15:33
 */
@Component
public class StickShape implements ComputerHandler {

    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        if (CommonUtil.isNull(data.getFirstSize()) || CommonUtil.isNull(data.getSecondSize())) {
            throw new RuntimeException(data.getMaterialName() + "的第一尺寸和第二尺寸不能为空");
        }
        //IF(E28="棒形",PI()*F28^2/4*G28*J28/1000000*C28,
        double result = Math.PI * Math.pow(data.getFirstSize().doubleValue() / 100, 2) / 4 * data.getSecondSize().doubleValue() / 100 * data.getProportion().doubleValue() / 100 / 1000000 * data.getCount().doubleValue() / 100;
        String specification = "φ" + decimalFormat.format(data.getFirstSize().doubleValue() / 100) + ",L=" + decimalFormat.format(data.getSecondSize().doubleValue() / 100);

        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (result < 0) {
            throw new RuntimeException("您输入的尺寸有误！");
        }
        productDemandPlanDetails.setWeight((long) (result * 100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("φ") + 1, specification.indexOf(","));
            String secondSize = specification.substring(specification.indexOf("L") + 2);
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("φ") + 1, specification.indexOf(","));
            String secondSize = specification.substring(specification.indexOf("L") + 2);
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
        }
    }

    @Override
    public void analysis(ProjectDemandPlanExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String firstSize = specification.substring(specification.indexOf("φ") + 1, specification.indexOf(","));
            String secondSize = specification.substring(specification.indexOf("L") + 2);
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
        }
    }

    @Override
    public void execution(BoardImportDTO data) {
        //长度是第二尺寸   宽度是第一尺寸  无第三尺寸

        //棒形计算重量： 圆周率*第一尺寸的平方/4*第二尺寸*比重/1000000*数量
        //规格：  φ第一尺寸,L=第二尺寸   （此处是直接字符串加数字拼接而成）
        //重量： 圆周率*宽度^2/4*长度*比重/1000000*数量
        //规格: φ宽度,L=长度

        //将厚度、长度、宽度、数量和比重都转为Double，没有倍数转换 ;  没有数据的就按照0.0算呗
        double thickness = !CommonUtil.isNull(data.getThickness()) ? Double.parseDouble(data.getThickness()) : 0.0;
        double length = !CommonUtil.isNull(data.getLength()) ? Double.parseDouble(data.getLength()) : 0.0;
        double width = !CommonUtil.isNull(data.getWidth()) ? Double.parseDouble(data.getWidth()) : 0.0;
        double proportion = !CommonUtil.isNull(data.getProportion()) ? Double.parseDouble(data.getProportion()) : 0.0;
        double count = !CommonUtil.isNull(data.getCount()) ? Double.parseDouble(data.getCount()) : 0.0;

        //计算重量
        double weight = Math.PI * Math.pow(width, 2) / 4 * length * proportion / 1000000 * count;
        //生成规格
        String specification = "φ" + NumberConvertUtil.doubleToString(width) + ",L=" + NumberConvertUtil.doubleToString(length);

        //设置重量和规格
        data.setWeight((long) (weight * 100));
        data.setSpecification(specification);

    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>(2);
        if (specification != null) {
            String width = specification.substring(specification.indexOf("φ") + 1, specification.indexOf(","));
            String length = specification.substring(specification.indexOf("L") + 2);
            map.put("width", width);
            map.put("length", length);
        }
        return map;
    }

}
