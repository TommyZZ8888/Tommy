package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 油漆导入VO
 */
@Data
public class PaintMaterialImportVO {
//    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;

    private String partNo;

    @ApiModelProperty("名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("颜色")
    private String colour;

    @ConversionNumber
    @ApiModelProperty("数量")
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long count;

    @ConversionNumber
    @ApiModelProperty("面积")
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long area;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    private String deliveryTime;


    private String deliveryLocation;


    private String remarks;

}
