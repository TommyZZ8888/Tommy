package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class PurchasedPartsExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("自增序号")
    private Integer autoincrementId;

    @ExcelIgnore
    @ApiModelProperty("物资类型")
    private String materialType;


    @ExcelProperty("件号")
    @ApiModelProperty("件号")
    private String partNo;

    @ExcelProperty("名称")
    @ApiModelProperty("名称")
    private String materialName;


    @ExcelProperty("材质")
    @ApiModelProperty("材质")
    private String texture;


    @ExcelProperty("规格")
    @ApiModelProperty("规格")
    private String specification;




    @ExcelIgnore
    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;

    @ExcelIgnore
    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ExcelProperty("备件数量")
    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Double sparePartsQuantityExport;

    @ExcelIgnore
    @ApiModelProperty("重量")
    @ConversionNumber
    private Long weight;

    @ExcelProperty("数量")
    @ApiModelProperty("数量")
    @ConversionNumber
    private Double countExport;

    @ExcelProperty("重量(KG)")
    @ApiModelProperty("重量")
    @ConversionNumber
    private Double weightExport;


    @ExcelProperty("执行标准")
    @ApiModelProperty("执行标准")
    private String enforceStandards;


    @ExcelProperty(value = "交货时间",converter = DateConverter.class)
    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ExcelProperty("交货地点")
    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;
    @ExcelProperty("制造编号&件号")
    @ApiModelProperty("制造编号&件号")
    private String manufacturingNumberPartNo;
}
