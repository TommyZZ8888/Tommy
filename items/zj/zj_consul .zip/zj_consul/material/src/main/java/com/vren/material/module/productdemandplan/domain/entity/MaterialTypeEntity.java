package com.vren.material.module.productdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@Api
@TableName("material_type")
public class MaterialTypeEntity {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("用料单位")
    private String materialUnit;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("产品信息id")
    private String productInformationId;

    @ApiModelProperty("批次")
    private String batch;
}