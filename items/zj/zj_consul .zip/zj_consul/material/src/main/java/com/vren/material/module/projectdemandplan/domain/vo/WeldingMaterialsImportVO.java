package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class WeldingMaterialsImportVO {

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long id;


    private String materialName;

    private String model;

    private String brand;

//    @ApiModelProperty("规格")
//    private String specification;

    @ApiModelProperty("规格")
    private String size;


    @ApiModelProperty("单位")
    private String unit;



    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    private Long  weight;

    @ApiModelProperty("执行标准")
    private String technicalStandards;

    private String deliveryTime;


    private String deliveryLocation;


    private String remarks;

    @ConversionNumber
    @ExcelProperty(converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("标书价")
    private Long bidPrice;

}
