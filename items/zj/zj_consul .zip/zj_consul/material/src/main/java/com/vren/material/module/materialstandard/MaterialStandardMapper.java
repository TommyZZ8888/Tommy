package com.vren.material.module.materialstandard;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialstandard.domain.entity.MaterialStandard;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author GR
 * time 2023-07-10-10-07
 **/
@Mapper
public interface MaterialStandardMapper extends MPJBaseMapper<MaterialStandard> {


}
