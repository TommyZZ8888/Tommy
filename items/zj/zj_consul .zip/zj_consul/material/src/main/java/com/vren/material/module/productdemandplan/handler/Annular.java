package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class Annular implements ComputerHandler {
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        //第四尺寸不需要倍数缩小
        if (CommonUtil.isNull(data.getFirstSize()) || CommonUtil.isNull(data.getSecondSize()) || CommonUtil.isNull(data.getThirdSize()) || CommonUtil.isNull(data.getFourthSizeOutsourcingStandards()) || CommonUtil.isNull(data.getProportion())) {
            throw new RuntimeException(data.getMaterialName() + "的第一尺寸、第二尺寸、第三尺寸、第四尺寸和比重不能为空");
        }
        double width = 0.0;
        double length = 0.0;
        //扇角
        double fanAngle = 0.0;
        double area = 0.0;
        //小弓高
        double smallArchHeight = 0.0;
        double weight = 0.0;

        //扇角的计算
        fanAngle = 2 * Math.PI / Integer.parseInt(data.getFourthSizeOutsourcingStandards()) / Math.PI * 180;
        //小弓高的计算
        smallArchHeight = data.getSecondSize().doubleValue() / 100 / 2 * (1 - Math.cos(fanAngle / 2 / 180 * Math.PI));
        //小弓高四舍五入，保留一位小数
        BigDecimal bigDecimal = new BigDecimal(smallArchHeight);
        smallArchHeight = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();

        if (Integer.parseInt(data.getFourthSizeOutsourcingStandards()) == 1) {
            //拼数为1
            length = (data.getFirstSize().doubleValue() / 100 + 10) * data.getCount().doubleValue() / 100;
            width = data.getFirstSize().doubleValue() / 100 + 0;
        } else {
            length = smallArchHeight + ((data.getFirstSize().doubleValue() / 100) - (data.getSecondSize().doubleValue() / 100)) / 2 * Double.parseDouble(data.getFourthSizeOutsourcingStandards()) * data.getCount().doubleValue() / 100
                    + (smallArchHeight - data.getFirstSize().doubleValue() / 100 / 2 * (1 - Math.cos(Math.asin((data.getSecondSize().doubleValue() / 100) * Math.sin(fanAngle / 2 * Math.PI / 180) / (data.getFirstSize().doubleValue() / 100)))) + 2) * (Double.parseDouble(data.getFourthSizeOutsourcingStandards()) * data.getCount().doubleValue() / 100 - 1);
            BigDecimal decimal = new BigDecimal(length);
            length = decimal.setScale(1, BigDecimal.ROUND_HALF_UP).doubleValue();
            //计算宽度
            width = data.getFirstSize().doubleValue() / 100 * Math.sin(fanAngle / 2 * Math.PI / 180) + 0;
            width = (int) Math.ceil(width);
        }
        area = length * width / 1000000;
        weight = area * data.getThirdSize().doubleValue() / 100 * data.getProportion().doubleValue() / 100;

        //规格  δ 厚度 X 长度 X 宽度
        String specification = "δ" + decimalFormat.format(data.getThirdSize().doubleValue() / 100) + "X" + decimalFormat.format(length) + "X" + (int) width;

        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (weight > 0) {
            productDemandPlanDetails.setWeight((long) (weight * 100));
        } else {
            productDemandPlanDetails.setWeight(0L);
        }
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            //长度
            String firstSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            //宽度
            String secondSize = specification.substring(specification.lastIndexOf("X") + 1);
            //厚度
            String thirdSize = specification.substring(1, specification.indexOf("X"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            //长度
            String firstSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            //宽度
            String secondSize = specification.substring(specification.lastIndexOf("X") + 1);
            //厚度
            String thirdSize = specification.substring(1, specification.indexOf("X"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void analysis(ProjectDemandPlanExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            //长度
            String firstSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            //宽度
            String secondSize = specification.substring(specification.lastIndexOf("X") + 1);
            //厚度
            String thirdSize = specification.substring(1, specification.indexOf("X"));
            vo.setFirstSize(firstSize);
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void execution(BoardImportDTO data) {
        //厚度就是第三尺寸
        //将环形材料切成板材，计算跟矩形一样，第四尺寸（拼数） 在计算扇角和长度宽度中，导入的数据只要通过长宽厚计算,  所有环形材料切到一块板上，所以不用考虑数量
        //环形的重量   长*宽/1000000*厚度*比重              规格：δ 厚度 X 长度 X 宽度
        double thickness = !CommonUtil.isNull(data.getThickness()) ? Double.parseDouble(data.getThickness()) : 0.0;
        double length = !CommonUtil.isNull(data.getLength()) ? Double.parseDouble(data.getLength()) : 0.0;
        double width = !CommonUtil.isNull(data.getWidth()) ? Double.parseDouble(data.getWidth()) : 0.0;
        double proportion = !CommonUtil.isNull(data.getProportion()) ? Double.parseDouble(data.getProportion()) : 0.0;
        double count = !CommonUtil.isNull(data.getCount()) ? Double.parseDouble(data.getCount()) : 0.0;

        //计算重量
        double weight = length * width * thickness / 1000000 * proportion;
        //生成规格
        String specification = "δ" + NumberConvertUtil.doubleToString(thickness) + "X" + NumberConvertUtil.doubleToString(length) + "X" + NumberConvertUtil.doubleToString(length);

        //设置重量和规格
        data.setWeight((long) (weight * 100));
        data.setSpecification(specification);

    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        if (specification != null) {
            //长度
            String length = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            //宽度
            String width = specification.substring(specification.lastIndexOf("X") + 1);
            //厚度
            String thickness = specification.substring(1, specification.indexOf("X"));
            map.put("width", width);
            map.put("length", length);
            map.put("thickness", thickness);
        }
        return map;
    }
}
