package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Description ProjectDemandPlanInfoVO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProjectDemandPlanInfoVO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目需求计划id")
    private String projectDemanPlanId;

    @ApiModelProperty("项目需求计划编号")
    private String projectDemanPlanNo;

    @ApiModelProperty("项目需求计划类型")
    private Integer projectDemandPlanType;

    @ApiModelProperty("项目需求计划批次")
    private String projectDemandPlanBatch;


}
