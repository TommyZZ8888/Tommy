package com.vren.material.module.productdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 耿让
 */
@Data
@Api
@TableName("product_demand_plan")
public class ProductDemandPlan {
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long number;

    @ApiModelProperty("产品信息表id")
    private String productInformationId;

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("计划编号")
    private String scheduleNo;

    @ApiModelProperty("编制说明")
    private String preparationDescription;



    @ApiModelProperty("需求标书总价")
    private BigDecimal demandProposalTotal;

    @ApiModelProperty("编制人")
    private String compiler;

    @ApiModelProperty("编制时间")
    private Date prepartation;

    @ApiModelProperty("校对人")
    private String proofreader;

    @ApiModelProperty("校对时间")
    private Date proofreadingTime;

    @ApiModelProperty("审核时间")
    private Date reviewTime;

    @ApiModelProperty("审核人")
    private String reviewer;

    @ApiModelProperty("审核状态")
    private String reviewState;

    @ApiModelProperty("批准人")
    private String checker;

    @ApiModelProperty("批准时间")
    private Date checkTime;

    @TableField(fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("是否处于排产：1排产状态、0非排产状态")
    private Integer isProductionScheduling;

    @ApiModelProperty("是否属于生产状态 1:生产状态 0:非生产状态")
    private Integer isProductionPlan;

    @ApiModelProperty("是否已生成项目需求计划")
    private boolean flagProjectDemandPlan;

    @ApiModelProperty("审核状态")
    private Integer state;

    @ApiModelProperty("流程code")
    private String instanceCode;

}