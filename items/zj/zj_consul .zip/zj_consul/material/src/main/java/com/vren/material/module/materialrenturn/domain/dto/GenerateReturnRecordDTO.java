package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @author 耿让
 *  生成退库记录DTO
 */
@Data
public class GenerateReturnRecordDTO {

    @ApiModelProperty("回库的数据")
    private List<GenerateReturnRecordDetailDTO> list;

}
