package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialTypeDescriptionVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("备注")
    private String remarks;
}
