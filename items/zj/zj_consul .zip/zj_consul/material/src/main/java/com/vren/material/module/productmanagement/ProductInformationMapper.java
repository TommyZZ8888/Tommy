package com.vren.material.module.productmanagement;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.productmanagement.domain.vo.ProductAndDemandVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * @author 耿让
 * 产品信息
 */
@Mapper
public interface ProductInformationMapper extends MPJBaseMapper<ProductInformation> {


    /**
     *  查询所有 需求批次的总数  产品数量  产品名称
     * @return
     */
    @Select("SELECT t.id,COALESCE(SUM(p.number),0)  sum,t.manufacturing_number,t.number,t.product_name FROM  product_information t\n" +
            "LEFT JOIN product_demand_plan p ON t.id = p.product_information_id GROUP BY t.id")
    List<ProductAndDemandVO> getProductAndDemand();

    Integer insertBatchSomeColumn(List<ProductInformation> entities);
}
