package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-14-14-24
 **/
@Data
public class MaterialNumberSelectDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
