package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.enums.BooleanEnum;
import com.alibaba.excel.enums.poi.HorizontalAlignmentEnum;
import com.alibaba.excel.enums.poi.VerticalAlignmentEnum;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class ContractProductPaintExportVO {

    @ExcelIgnore
    private String id;

    @ApiModelProperty("序号")
    @ExcelProperty("序号")
    private Integer number;

    @ApiModelProperty("材料名称")
    @ExcelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    @ExcelProperty("规格型号")
    private String size;

    @ApiModelProperty("干膜厚（μm） ")
    @ConversionNumber
    @ExcelIgnore
    private Long dryFilmThickness;

    @ApiModelProperty("干膜厚（μm） ")
    @ConversionNumber
    @ExcelProperty("干膜厚（μm）")
    private Double dryFilmThicknessExport;

    @ApiModelProperty("技术标准")
    @ExcelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    @ExcelProperty("单位")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelIgnore
    private Long purchaseArea;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelProperty("数量")
    private Double purchaseAreaExport;

    @ApiModelProperty("油漆用量（kg）（含2.0损耗）")
    @ConversionNumber
    @ExcelIgnore
    private Long amountOfPaint;

    @ApiModelProperty("油漆用量（kg）（含2.0损耗）")
    @ConversionNumber
    @ExcelProperty("油漆用量（kg）（含2.0损耗）")
    private Double amountOfPaintExport;

    @ApiModelProperty("理论用量/涂布率（kg/㎡）")
    @ConversionNumber
    @ExcelIgnore
    private Long theoreticalDosage;

    @ApiModelProperty("理论用量/涂布率（kg/㎡）")
    @ConversionNumber
    @ExcelProperty("理论用量/涂布率（kg/㎡）")
    private Double theoreticalDosageExport;

    @ApiModelProperty("损耗系数")
    @ConversionNumber
    @ExcelIgnore
    private Long lossFactor;

    @ApiModelProperty("损耗系数")
    @ConversionNumber
    @ExcelProperty("损耗系数")
    private Double lossFactorExport;

    @ApiModelProperty("体积固含量(%)")
    @ConversionNumber
    @ExcelIgnore
    private Long volumeSolidContent;

    @ApiModelProperty("体积固含量(%)")
    @ConversionNumber
    @ExcelProperty("体积固含量(%)")
    private Double volumeSolidContentExport;

    @ApiModelProperty("密度（kg/L)")
    @ConversionNumber
    @ExcelIgnore
    private Long density;

    @ApiModelProperty("密度（kg/L)")
    @ConversionNumber
    @ExcelProperty("密度（kg/L)")
    private Double densityExport;

    @ApiModelProperty("含税油漆单价（元/kg）")
    @ConversionNumber
    @ExcelIgnore
    private Long unitPricePaintIncludingTax;

    @ApiModelProperty("含税油漆单价（元/kg）")
    @ConversionNumber
    @ExcelProperty("含税油漆单价（元/kg）")
    private Double unitPricePaintIncludingTaxExport;

    @ApiModelProperty("稀释剂量kg（25%）")
    @ConversionNumber
    @ExcelIgnore
    private Long dilutionDose;

    @ApiModelProperty("稀释剂量kg（25%）")
    @ConversionNumber
    @ExcelProperty("稀释剂量kg（25%）")
    private Double dilutionDoseExport;

    @ApiModelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    @ConversionNumber
    @ExcelIgnore
    private Long totalUnitPriceIncludingTax;

    @ApiModelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    @ConversionNumber
    @ExcelProperty("含税总单价（元/㎡）含2.0损耗，含25%稀释剂")
    private Double totalUnitPriceIncludingTaxExport;

    @ApiModelProperty("含税稀释剂单价（元/kg）")
    @ConversionNumber
    @ExcelIgnore
    private Long unitPriceDiluentIncludingTax;

    @ApiModelProperty("含税稀释剂单价（元/kg）")
    @ConversionNumber
    @ExcelProperty("含税稀释剂单价（元/kg）")
    private Double unitPriceDiluentIncludingTaxExport;

    @ApiModelProperty("含税平方总价（元）")
    @ConversionNumber
    @ExcelIgnore
    private Long totalSquarePriceIncludingTax;

    @ApiModelProperty("含税平方总价（元）")
    @ConversionNumber
    @ExcelProperty("含税平方总价（元）")
    private Double totalSquarePriceIncludingTaxExport;

    @ApiModelProperty("包装规格")
    @ExcelProperty("包装规格")
    private String packageSpecification;

    @ApiModelProperty("税率%")
    @ConversionNumber
    @ExcelIgnore
    private Long taxRate;

    @ApiModelProperty("税率%")
    @ConversionNumber
    @ExcelProperty("税率%")
    private Double taxRateExport;

    @ApiModelProperty("备注（锌粉含量）")
    @ConversionNumber
    @ExcelProperty("备注（锌粉含量）")
    private String remarksZincPowderContent;

    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "到货时间",converter = DateConverter.class)
    private Date deliveryTime;

    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;

    @ApiModelProperty("入库编号")
    @ExcelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("物资类型")
    @ExcelIgnore
    private Integer materialType;

    @ApiModelProperty("物资类型描述")
    @ExcelIgnore
    private String materialTypeText;

    @ContentStyle(
            horizontalAlignment = HorizontalAlignmentEnum.LEFT, //水平居左
            verticalAlignment = VerticalAlignmentEnum.CENTER, //垂直居中
            wrapped = BooleanEnum.TRUE)//主要是为了导出时直接换行
    @ExcelProperty("条形码")
    @ColumnWidth(60)
    private WriteCellData<Void> barcode;

}
