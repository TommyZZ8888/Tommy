package com.vren.material.module.materialrenturn.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * @time 2023-04-19-17-16
 **/
@Data
public class MaterialNameInCheckoutVO {

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("执行标准")
    private String executiveStandard;

}
