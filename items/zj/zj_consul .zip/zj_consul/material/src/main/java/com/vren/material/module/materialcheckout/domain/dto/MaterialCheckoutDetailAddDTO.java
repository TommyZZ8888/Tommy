package com.vren.material.module.materialcheckout.domain.dto;



import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialCheckoutDetailAddDTO {
    @ApiModelProperty("材料出库细节表id")
    private String id;

    @ApiModelProperty("材料出库记录表id")
    @NotBlank(message = "材料出库记录表id不能为空")
    private String materialCheckoutRecordId;


    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("规格")
    private String specification;


    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("单价")
    private Long univalence;



    @ConversionNumber
    @ApiModelProperty("限额数量")
    private Long quantityRequired;

    @ConversionNumber
    @ApiModelProperty("已领数量")
    private Long pickedQuantity;

    @ConversionNumber
    @ApiModelProperty("申领数量")
    private Long applyQuantity;

    @ConversionNumber
    @ApiModelProperty("实领数量")
    private Long actualPickedQuantity;

    @ApiModelProperty("颜色")
    private String colour;
    @ConversionNumber(value = 10000)
    @ApiModelProperty("税前单价")
    private Long preTaxPrice;

    @ApiModelProperty("库存余量")
    @ConversionNumber
    private Long stockBalance;

    @ApiModelProperty("材质")
    private String texture;

    @ConversionNumber
    @ApiModelProperty("金额")
    private Long money;

    @ConversionNumber
    @ApiModelProperty("税率")
    private Long taxRate;

    @ConversionNumber
    @ApiModelProperty("税额")
    private Long tax;

    @ConversionNumber
    @ApiModelProperty("价税合计金额")
    private Long materialTotalPrice;

    @ConversionNumber
    @ApiModelProperty("出库限额")
    private Long issueLimit;
}
