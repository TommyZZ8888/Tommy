package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * @time 2023-04-13-15-44
 **/
@Data
public class StartOrderWorkFlowDTO {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("结果")
    private String result;

    @ApiModelProperty("是否撤销")
    private String isRevoke;

    @ApiModelProperty("流程code")
    private String instanceCode;

}
