package com.vren.material.module.purchaseplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description MaterialNameVO
 * @Author 张卫刚
 * @Date Created on 2023/9/8
 */
@Data
public class MaterialNameVO {

    @ApiModelProperty("材料名称")
    private String materialName;

}
