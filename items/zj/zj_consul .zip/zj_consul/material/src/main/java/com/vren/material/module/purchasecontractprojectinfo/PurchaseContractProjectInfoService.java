package com.vren.material.module.purchasecontractprojectinfo;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.material.module.purchasecontract.domain.dto.QueryContractListDTO;
import com.vren.material.module.purchasecontract.domain.vo.ContractInfoListVO;
import com.vren.material.module.purchasecontractprojectinfo.domain.entity.PurchaseContractProjectInfoEntity;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description PurchaseContractProjectInfoService
 * @Author 张卫刚
 * @Date Created on 2023/9/1
 */


@Service
public class PurchaseContractProjectInfoService {


    @Autowired
    private PurchaseContractProjectInfoMapper purchaseContractProjectInfoMapper;


    public PurchaseContractProjectInfoEntity selectById(String purchaseContractProjectInfoId) {
        return purchaseContractProjectInfoMapper.selectById(purchaseContractProjectInfoId);
    }

    public int updateById(PurchaseContractProjectInfoEntity purchaseContractProjectInfoEntity) {
        return purchaseContractProjectInfoMapper.updateById(purchaseContractProjectInfoEntity);
    }

    public int insert(PurchaseContractProjectInfoEntity purchaseContractProjectInfoEntity) {
        return purchaseContractProjectInfoMapper.insert(purchaseContractProjectInfoEntity);
    }

    public int deleteById(String purchaseContractProjectInfoId) {
        return purchaseContractProjectInfoMapper.deleteById(purchaseContractProjectInfoId);
    }

    public int deleteById(PurchaseContractProjectInfoEntity purchaseContractProjectInfoEntity) {
        return purchaseContractProjectInfoMapper.deleteById(purchaseContractProjectInfoEntity);
    }

    public List<PurchaseContractProjectInfoEntity> selectList() {
        return purchaseContractProjectInfoMapper.selectList(null);
    }

    public IPage<ContractInfoListVO> selectByCondition(QueryContractListDTO dto) {
        Page<PurchaseContractProjectInfoEntity> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<PurchaseContractProjectInfoEntity> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchaseContractProjectInfoEntity.class)
                .like(StringUtils.isNotBlank(dto.getProjectName()), PurchaseContractProjectInfoEntity::getProjectName, dto.getProjectName())
                .like(StringUtils.isNotBlank(dto.getPurchasePlanNumber()), PurchaseContractProjectInfoEntity::getPurchasePlanNo, dto.getPurchasePlanNumber())
                .like(StringUtils.isNotBlank(dto.getDemandPlanNumber()), PurchaseContractProjectInfoEntity::getProjectDemandPlanNo, dto.getPurchasePlanNumber())
                .eq(CommonUtil.isNotNull(dto.getPurchaseStatus()), PurchaseContractProjectInfoEntity::getPurchaseState, dto.getPurchaseStatus());
       return purchaseContractProjectInfoMapper.selectJoinPage(page, ContractInfoListVO.class, wrapper);
    }
}
