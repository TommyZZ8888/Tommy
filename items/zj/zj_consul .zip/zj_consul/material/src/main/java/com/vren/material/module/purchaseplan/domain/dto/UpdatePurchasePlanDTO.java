package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class UpdatePurchasePlanDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNumber;

    @ApiModelProperty("付款方式")
    private String paymentMethod;

    @ApiModelProperty("材料说明")
    private String materialDescription;

//    @ApiModelProperty("采购状态(1招标公告、2投标、3定标、4合同签订)")
//    private Integer purchaseStatus;
//
//    @ApiModelProperty("计划类型(1总、2月度、3临时紧急物资采购计划)")
//    private Integer scheduleType;
//
//    @ApiModelProperty("表单编号")
//    private String formNo;
//
//    @ApiModelProperty("单位名称（中建五洲工程装备有限公司）")
//    private String unitName;
//
//    @ApiModelProperty("项目名称")
//    private String projectName;
//
//    @ApiModelProperty("采购日期")
//    private Date purchaseDate;
//
//    @ApiModelProperty("标书/认价价格")
//    @ConversionNumber
//    private Long proposalPrice;
//
//    @ApiModelProperty("含税金额")
//    @ConversionNumber
//    private Long amountIncludingTax;
//
//    @ApiModelProperty("市场含税单价")
//    @ConversionNumber
//    private Long marketUnitPriceIncludingTax;
//
//    @ApiModelProperty("含税金额")
//    @ConversionNumber
//    private Long priceInTax;
//
//    @ApiModelProperty("标书品牌")
//    private String bidBrand;
//
//    @ApiModelProperty("付款条件")
//    private String paymentTerms;
//
//    @ApiModelProperty("到货时间")
//    private Date arrivalTime;
//
//    @ApiModelProperty("到货地点")
//    private String arrivalLocation;
//
//    @ApiModelProperty("备注")
//    private String remarks;
//
//    @ApiModelProperty("总重")
//    @ConversionNumber
//    private Long totalWeight;
//
//    @ApiModelProperty("总数量")
//    private Integer totalAmount;
//
//    @ApiModelProperty("采购说明（富文本）")
//    private String purchaseDescription;
//
//    @ApiModelProperty("技术要求（富文本）")
//    private String technicalRequirement;

}
