package com.vren.material.module.materialrenturn;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.module.project.ProjectService;
import com.vren.material.module.materialcheckout.MaterialCheckoutService;
import com.vren.material.module.materialcheckout.domain.vo.MaterialCheckoutDetailVO;
import com.vren.material.module.materialremain.MaterialRemainService;
import com.vren.material.module.materialremain.domain.entity.RemainingMaterial;
import com.vren.material.module.materialrenturn.domain.dto.*;
import com.vren.material.module.materialrenturn.domain.entity.MaterialReturn;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNameInCheckoutVO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNumberSelectVO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialReturnVO;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.stockmanagement.StockManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 耿让
 */
@Service
public class MaterialReturnService {

    @Autowired
    private MaterialReturnMapper materialReturnMapper;

    @Autowired
    private MaterialCheckoutService materialCheckoutService;


    @Autowired
    private StockManagementService stockManagementService;

    @Autowired
    private MaterialRemainService materialRemainService;

    @Autowired
    private ProjectService projectService;

    public List<MaterialCheckoutDetailVO> selectCheckoutByProjectIdAndNo(SelectCheckoutDTO dto) {
        /**
         *  根据项目名称和出库单编号，在出库记录中查询出库的物资
         *  2023/04/19  筛选条件增加  物资名称和规格
         */
        return materialCheckoutService.selectCheckoutDetailProjectIdAndNo(dto.getProjectId(), dto.getMaterialRequisitionNo(), dto.getMaterialName(), dto.getSpecification());
    }

    public void generateReturnRecord(GenerateReturnRecordDTO dto) {
        /**
         *  批量新增回库记录
         *  修改库存数量，根据物资编号，找到库存对应的    库存管理里面的物资编号要全程跟随物资
         *  如果不存在，则新建库存
         *  12.05：退库还是关联到项目下面
         */
        List<GenerateReturnRecordDetailDTO> list = dto.getList();
        //退库的数量，不能大于实领的数量
        list.stream().forEach(item -> {
            item.setReturnWeight(item.getReturnCount() / 100 * item.getWeight());
            if (item.getActualPickedQuantity() < item.getReturnCount()) {
                throw new RuntimeException("【" + item.getMaterialName() + "】退库的数量不能大于出库的数量");
            }
        });

        //退库的数据
        List<MaterialReturn> materialReturns = BeanUtil.copyList(list, MaterialReturn.class);
        materialReturns.stream().forEach(item -> {
            //设置创建时间，更新时间，退库类型
            item.setReturnType("退回库存");
        });
        Integer result = materialReturnMapper.insertBatchSomeColumn(materialReturns);
        if (result > 0) {
            /**
             * 根据项目id和物资编号更新库存数量，将物资退库表关联到物资表中
             */
            for (MaterialReturn item : materialReturns) {
                stockManagementService.updateStockByProjectIdAndNumber(item.getId(), item.getProjectId(), item.getMaterialNumber(), item.getReturnCount());
            }
        }
    }


    public void generateSpareRecord(GenerateSpareRecordDTO dto) {
        if (MaterialType.SPARE_PARTS.getCode().equals(dto.getMaterialType())) {
            throw new ErrorException("备件无法余料退库");
        }
        materialRemainService.insert(dto);

    }

    public PageResult<MaterialReturnVO> getReturnRecord(GetReturnRecordDTO dto) {
        Page<MaterialReturnVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<MaterialReturn> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialReturn.class)
                .like(!CommonUtil.isNull(dto.getMaterialName()), MaterialReturn::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialReturn::getMaterialType, dto.getMaterialType())
                .eq(!CommonUtil.isNull(dto.getReturnType()), MaterialReturn::getReturnType, dto.getReturnType())
                .like(!CommonUtil.isNull(dto.getSpecification()), MaterialReturn::getSpecification, dto.getSpecification())
                .like(!CommonUtil.isNull(dto.getTexture()), MaterialReturn::getTexture, dto.getTexture())
                .orderByDesc(MaterialReturn::getCreateTime);
        SearchUtil.timeRangeSearch(wrapper, MaterialReturn::getCreateTime, dto.getCreateTimeStart(), dto.getCreateTimeEnd());
        IPage<MaterialReturnVO> materialReturnVOIPage = materialReturnMapper.selectJoinPage(page, MaterialReturnVO.class, wrapper);
        materialReturnVOIPage.getRecords().forEach(item -> {
            //设置物资类型
            item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
            //设置项目名称
            if (item.getProjectId() != null) {
                item.setProjectName(projectService.getById(item.getProjectId()).getProjectName());
            }
        });
        return PageUtil.convert2PageResult(materialReturnVOIPage);
    }

    public void editReturnRecord(EditReturnRecordDTO dto) {
        //退库的数量，不能大于实领的数量
        //根据物资类型、物资名称和物资编号查询退库的数据
        //2023/04/04  根据物资类型、物资名称和物资编号查询退库的数据  加上项目，因为调拨的原因，不同项目下面可能有相同物资编号的物资
        List<MaterialCheckoutDetailVO> materialCheckoutDetailVO = materialCheckoutService.selectCheckoutDetailByMaterialName(dto.getProjectId(), dto.getMaterialType(), dto.getMaterialName(), dto.getMaterialNumber());
        if (CommonUtil.listIsNotEmpty(materialCheckoutDetailVO)) {
            long sum = materialCheckoutDetailVO.stream().mapToLong(MaterialCheckoutDetailVO::getActualPickedQuantity).sum();
            if (dto.getReturnCount() > sum) {
                throw new RuntimeException("退库的数量不能大于出库的数量");
            }
        } else {
            throw new RuntimeException("出库记录已被删除，退库数量不可更改");
        }
        MaterialReturn materialReturn = BeanUtil.copy(dto, MaterialReturn.class);
        Long returnCount = materialReturnMapper.selectById(dto.getId()).getReturnCount();
        int result = materialReturnMapper.updateById(materialReturn);
        //退库更新
        if (result > 0) {
            //更新退库
            /**
             * 根据项目id和物资编号更新库存数量，将物资退库表关联到物资表中
             */
            stockManagementService.updateStockByProjectIdAndNumber(materialReturn.getId(), materialReturn.getProjectId(), materialReturn.getMaterialNumber(), returnCount - materialReturn.getReturnCount());
        }
    }

    public MaterialReturnVO getReturnRecordById(QueryOneDTO dto) {
        MaterialReturn materialReturn = materialReturnMapper.selectById(dto.getId());
        MaterialReturnVO materialReturnVO = BeanUtil.copy(materialReturn, MaterialReturnVO.class);
        materialReturnVO.setProjectName(projectService.getById(materialReturnVO.getProjectId()).getProjectName());
        materialReturnVO.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, materialReturnVO.getMaterialType()));
        return materialReturnVO;
    }

    public MaterialCheckoutDetailVO selectCheckoutByMaterialNumber(MaterialNumberDTO dto) {
        /**
         * 在出库记录中，根据物资编号查找需要退库的信息
         */
        return materialCheckoutService.selectCheckoutByMaterialNumber(dto.getMaterialNumber());
    }

    public List<MaterialNameInCheckoutVO> getMaterialNameInCheckout(MaterialNameInCheckoutDTO dto) {
        return materialCheckoutService.getMaterialInCheckout(dto);
    }

    public List<MaterialNumberSelectVO> getMaterialNumberSelect(MaterialNumberSelectDTO dto) {
        return materialCheckoutService.getMaterialNumberSelect(dto.getProjectId(), dto.getMaterialType());
    }
}
