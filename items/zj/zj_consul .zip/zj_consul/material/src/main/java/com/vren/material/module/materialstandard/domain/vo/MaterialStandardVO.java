package com.vren.material.module.materialstandard.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-10-10-49
 **/
@Data
public class MaterialStandardVO {

    @ApiModelProperty("材料标准表")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("是否删除")
    private Boolean isDelete;
}
