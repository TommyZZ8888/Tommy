package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


@Data
public class ProjectDemandPlanVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;
    @ApiModelProperty("需求类型")
    private Integer demandType;
    @ApiModelProperty("需求类型描述")
    private String demandTypeText;
    @ApiModelProperty("附件路径")
    private String attachmentPath;
    @ApiModelProperty("计划编号")
    private String planNo;
    @ConversionNumber
    @ApiModelProperty("需求标书总价")
    private Long demandProposalTotal;

    @ApiModelProperty("编制人")
    private String compiler;


    @ApiModelProperty("校对人")
    private String proofreader;


    @ApiModelProperty("审核人")
    private String reviewer;

    @ApiModelProperty("编制说明")
    private String preparationDescription;

    @ApiModelProperty("批准人")
    private String checker;

    /*2023.03.31 vo对比补充数据 */

    @ApiModelProperty("制造编号")
    private String manufacturingNumber;

    @ApiModelProperty("编制时间")
    private  Date compileTime;

    @ApiModelProperty("校对时间")
    private Date proofreadingTime;

    @ApiModelProperty("批准时间")
    private Date checkTime;

    @ApiModelProperty("审核时间")
    private Date reviewTime;

    @ApiModelProperty("产品计划需求表id字符串")
    private String idListString;

    @ApiModelProperty("产品计划需求表id字符串数组")
    private String[] idList;

    @ApiModelProperty("产品计划需求表id字符串数组")
    private String[] idListArr;

}
