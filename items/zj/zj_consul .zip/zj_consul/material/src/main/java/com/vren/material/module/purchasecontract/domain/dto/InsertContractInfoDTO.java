package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Description InsertContractInfoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class InsertContractInfoDTO {

    @ApiModelProperty("采购合同id")
    private String id;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("合同名称")
    private String contractName;

    @ApiModelProperty("到货时间")
    private String arrivalTime;

    @ApiModelProperty("经办人")
    private String purchaser;

    @ApiModelProperty("供货商")
    private String supplierId;

    @ApiModelProperty("采购状态")
    private Integer purchaseStatus;

    @ApiModelProperty("签订时间")
    private Date signTime;

    private String purchaseContractProjectInfoId;

    @ApiModelProperty("物资类型")
    private Integer materialType;


    private String operator;

}
