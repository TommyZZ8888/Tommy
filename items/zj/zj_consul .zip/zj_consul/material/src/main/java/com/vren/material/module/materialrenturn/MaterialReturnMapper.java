package com.vren.material.module.materialrenturn;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.materialrenturn.domain.entity.MaterialReturn;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author 耿让
 */
@Mapper
public interface MaterialReturnMapper extends MPJBaseMapper<MaterialReturn> {
    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<MaterialReturn> entities);
}
