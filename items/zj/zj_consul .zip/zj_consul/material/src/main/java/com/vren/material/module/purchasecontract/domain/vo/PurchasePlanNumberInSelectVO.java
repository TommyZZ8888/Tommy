package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author 耿让
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PurchasePlanNumberInSelectVO {

    @ApiModelProperty("采购计划编号")
    public String purchasePlanNumber;

}
