package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;


/**
 * @Description PurchaseOrderWordExportVO
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@Data
@NoArgsConstructor
public class PurchaseOrderWordExportVO {

    @ApiModelProperty("需方")
    private String demander;

    @ApiModelProperty("订单编号")
    private String orderNumber;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("送货地址")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    private String contactNumber;

    @ApiModelProperty("供应商名称")
    private String supplierName;

    @ApiModelProperty("供应商联系人")
    private String contacts;

    @ApiModelProperty("供应商联系电话")
    private String supplierContactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

}
