package com.vren.material.module.purchaseplan.domain.enums;

/**
 * @author 耿让
 *  到货状态
 */

public enum ArrivalStatusEnum {

    NON_ARRIVAL(1,"未到货"),
    PARTIAL_ARRIVAL(2,"部分到货"),
    ARRIVED(3,"已到货");

    private Integer code;

    private String name;

    ArrivalStatusEnum(Integer code,String name){
        this.name=name;
        this.code=code;
    }
    public String getName() {
        return name;
    }
    public Integer getCode() {
        return code;
    }
}
