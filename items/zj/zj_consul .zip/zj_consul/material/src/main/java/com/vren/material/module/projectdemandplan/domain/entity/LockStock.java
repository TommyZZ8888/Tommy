package com.vren.material.module.projectdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@TableName("lock_stock")
public class LockStock {

    @TableId(type = IdType.ASSIGN_UUID)
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("锁库数量")
    @ConversionNumber
    private Long lockStockNumber;

    @ApiModelProperty("已领数量")
    @ConversionNumber
    private Long pickedQuantity;

    @ApiModelProperty("采购计划明细id")
    private String purchaseDemandPlanDetailId;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("锁库类型")
    private String stockType;


}
