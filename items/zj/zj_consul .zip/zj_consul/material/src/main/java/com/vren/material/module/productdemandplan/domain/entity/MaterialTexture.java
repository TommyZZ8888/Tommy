package com.vren.material.module.productdemandplan.domain.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 * 材质表
 */
@Data
@Api
@TableName("material_texture")
public class MaterialTexture {

    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("代号")
    private String code;

    @ApiModelProperty("材料")
    private String material;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;



}