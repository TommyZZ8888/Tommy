package com.vren.material.module.purchaseplan.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ContentRowHeight;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
@ContentRowHeight(25)
public class PurchasePlanBoardExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("id")
    private Integer serialNo;

    @ExcelProperty("材料名称")
    @ApiModelProperty("材料名称")
    private String materialName;

    @ExcelProperty("件号")
    @ApiModelProperty("件号")
    private String partNo;

    @ExcelProperty("规格")
    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("厚度")
    @ConversionNumber
    @ExcelIgnore
    private Long firstSize;

    @ApiModelProperty("厚度")
    @ExcelProperty(value = "厚度")
    private String firstSizeString;

    @ExcelProperty(value = "宽度", converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("宽度")
    @ConversionNumber
    private Long secondSize;

    @ExcelProperty(value = "长度", converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("长度")
    @ConversionNumber
    private Long thirdSize;

    @ExcelProperty("材质")
    @ApiModelProperty("材质")
    private String texture;

    @ExcelProperty("执行标准")
    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ExcelProperty("单位")
    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ExcelProperty(value = "数量", converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;

    @ExcelIgnore
    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    @ExcelProperty(value = "标书/认价价格", converter = EasyExcelToLongConverter.class)
    @ApiModelProperty(value = "标书/认价价格")
    @ConversionNumber
    private Long proposalPrice;

    @ExcelProperty(value = "含税金额", converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long amountIncludingTax;

    @ExcelProperty(value = "市场含税单价",converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("市场含税单价")
    @ConversionNumber(value = 10000)
    private Long marketUnitPriceTax;

    @ExcelProperty(value = "含税金额",converter = EasyExcelToLongConverter.class)
    @ApiModelProperty("含税金额")
    @ConversionNumber
    private Long priceInTax;

    @ExcelProperty("标书品牌")
    @ApiModelProperty("标书品牌")
    private String bidBrand;

    @ExcelProperty("付款条件")
    @ApiModelProperty("付款条件")
    private String paymentTerms;

    @ExcelProperty(value = "到货时间",converter = DateConverter.class)
    @ApiModelProperty("到货时间")
    private Date deliveryTime;

    @ExcelProperty("备注")
    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("导出采购重量")
    @ExcelProperty("导出采购重量")
    private String purchaseWeightExport;

    @ApiModelProperty("id")
    @ExcelProperty(value = "id")
    private String id;

    @ApiModelProperty("序号")
    @ExcelIgnore
    private Integer serialNumber;

    @ApiModelProperty("面积")
    @ConversionNumber
    @ExcelIgnore
    private Long purchaseArea;

    @ApiModelProperty("是否合并 0否 1是")
    @ExcelIgnore
    private Integer isMerge;

    @ExcelProperty("是否合并")
    @ApiModelProperty("是否合并")
    private String isMergeString;

}
