package com.vren.material.module.materialcheckout;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.materialcheckout.domain.dto.*;
import com.vren.material.module.materialcheckout.domain.vo.*;
import com.vren.material.module.purchasecontract.domain.dto.StartContractListWorkFlow;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/materialcheckout")
@Api(tags = {"材料出库记录"})
@OperateLog
public class MaterialCheckoutController {
    @Autowired
    private MaterialCheckoutService materialCheckoutService;

    @RequestMapping(value = "/addMaterialCheckout", method = RequestMethod.POST)
    @ApiOperation("新增或修改领料单")
    public ResponseResult<Boolean> addOrEditMaterialCheckout(@RequestBody @Valid MaterialCheckoutRecordAddDTO dto) {
        materialCheckoutService.addOrEditMaterialCheckout(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialCheckoutById", method = RequestMethod.POST)
    @ApiOperation("获取单个领料单")
    public ResponseResult<MaterialCheckoutRecordVO> getMaterialCheckoutById(@RequestBody @Valid MaterialCheckoutQuerySingleDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutById(dto));
    }

    @RequestMapping(value = "/getTaxMethodVOList", method = RequestMethod.POST)
    @ApiOperation("获得计税方法下拉框")
    public ResponseResult<List<TaxMethodVO>> getTaxMethodVOList() {
        return ResponseResult.success("操作成功", materialCheckoutService.getTaxMethodVOList());
    }

    @RequestMapping(value = "/getMaterialCheckoutList", method = RequestMethod.POST)
    @ApiOperation("获得领料单列表数据")
    public ResponseResult<PageResult<MaterialCheckoutRecordVO>> getMaterialCheckoutList(@RequestBody @Valid MaterialCheckoutRecordQueryDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutList(dto));
    }

    @RequestMapping(value = "/deleteMaterialCheckout", method = RequestMethod.POST)
    @ApiOperation("删除领料单")
    public ResponseResult<Boolean> deleteMaterialCheckout(@RequestBody @Valid MaterialCheckoutRecordDeleteDTO dto) {
        materialCheckoutService.deleteMaterialCheckout(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialCheckoutDataList", method = RequestMethod.POST)
    @ApiOperation("获得库存回显数据")
    public ResponseResult<MaterialCheckoutDataVO> getMaterialCheckoutDataList(@RequestBody @Valid MaterialCheckoutDataDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutDataList(dto));
    }

    @RequestMapping(value = "/materialCheckout", method = RequestMethod.POST)
    @ApiOperation("领料单点出库(按钮)")
    public ResponseResult<Boolean> materialCheckout(@RequestBody @Valid MaterialCheckoutDTO dto) {
        materialCheckoutService.materialCheckout(dto);
        return ResponseResult.success("出库成功");
    }

    /***************************************************************************************************************************/
    @RequestMapping(value = "/getMaterialNameList", method = RequestMethod.POST)
    @ApiOperation("获得物资编号下拉框")
    public ResponseResult<List<MaterialNumberVO>> getMaterialNameList(@RequestBody @Valid MaterialCheckoutRecordQueryDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialNameList(dto));
    }

    @RequestMapping(value = "/getMaterialCheckoutDetailList", method = RequestMethod.POST)
    @ApiOperation("获得领料单列表明细数据")
    public ResponseResult<PageResult<MaterialCheckoutDetailVO>> getMaterialCheckoutDetailList(@RequestBody @Valid MaterialCheckoutDetailQueryDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutDetailList(dto));
    }

    @RequestMapping(value = "/getMaterialCheckoutDetailById", method = RequestMethod.POST)
    @ApiOperation("获得单个领料单明细数据")
    public ResponseResult<MaterialCheckoutDetailVO> getMaterialCheckoutDetailById(@RequestBody @Valid MaterialCheckoutDetailDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialCheckoutDetailById(dto));
    }


    @RequestMapping(value = "/addMaterialCheckoutDetail", method = RequestMethod.POST)
    @ApiOperation("新增或修改领料单明细")
    public ResponseResult<Boolean> generateMaterialCheckoutDetail(@RequestBody @Valid MaterialCheckoutDetailAddDTO dto) {
        materialCheckoutService.addMaterialCheckoutDetail(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/deleteMaterialCheckoutDetail", method = RequestMethod.POST)
    @ApiOperation("删除领料单明细")
    public ResponseResult<Boolean> deleteMaterialCheckoutDetail(@RequestBody @Valid MaterialCheckoutDetailDeleteDTO dto) {
        materialCheckoutService.deleteMaterialCheckoutDetail(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialOutboundList", method = RequestMethod.POST)
    @ApiOperation("获得出库管理列出库的数据")
    public ResponseResult<PageResult<MaterialCheckoutRecordVO>> getMaterialOutboundList(@RequestBody @Valid MaterialCheckoutRecordQueryDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.getMaterialOutboundList(dto));
    }

    /***********************领料单审核********************************/
    @RequestMapping(value = "/startCheckoutWorkFlow", method = RequestMethod.POST)
    @ApiOperation("开始领料单的审核")
    public ResponseResult<Boolean> startCheckoutWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", materialCheckoutService.startCheckoutWorkFlow(dto));
    }

    @RequestMapping(value = "/updateCheckoutWorkFlow", method = RequestMethod.POST)
    @ApiOperation("领料单的审批")
    public ResponseResult<Boolean> updateCheckoutWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", materialCheckoutService.updateCheckoutWorkFlow(dto));
    }

    @RequestMapping(value = "/reviewCheckoutWorkFlow", method = RequestMethod.POST)
    @ApiOperation("领料单的审核")
    public ResponseResult<Boolean> reviewCheckoutWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", materialCheckoutService.reviewCheckoutWorkFlow(dto));
    }

    @RequestMapping(value = "/endCheckoutWorkFlow", method = RequestMethod.POST)
    @ApiOperation("结束领料单的审核")
    public ResponseResult<Boolean> endCheckoutWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", materialCheckoutService.endCheckoutWorkFlow(dto));
    }

    @RequestMapping(value = "/materialCheckoutIsCheck", method = RequestMethod.POST)
    @ApiOperation("领料单是否送审")
    public ResponseResult<Boolean> materialCheckoutIsCheck(@RequestBody @Valid MaterialCheckoutDTO dto) {
        return ResponseResult.success("操作成功", materialCheckoutService.materialCheckoutIsCheck(dto));
    }


    @RequestMapping(value = "/materialCheckoutWordExport", method = RequestMethod.POST)
    @ApiOperation("物资限额领料单")
    public void materialCheckoutWordExport(HttpServletResponse response, @RequestBody MaterialCheckoutQuerySingleDTO dto) {
        materialCheckoutService.exportMaterialCheckoutWord(response, dto);
    }


    @RequestMapping(value = "/engineeringMaterialConsumptionExport", method = RequestMethod.POST)
    @ApiOperation("工程材料耗用导出")
    public void exportEngineeringMaterialConsumption(HttpServletResponse response, @RequestBody MaterialCheckoutRecordWordExportDTO dto) {
        materialCheckoutService.exportEngineeringMaterialConsumption(response, dto);
    }
}
