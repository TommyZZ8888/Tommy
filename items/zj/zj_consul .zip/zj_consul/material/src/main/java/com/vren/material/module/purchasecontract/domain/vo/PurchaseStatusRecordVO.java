package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
public class PurchaseStatusRecordVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("操作者")
    private String operator;

    @ApiModelProperty("操作者名称")
    private String operatorName;

    @ApiModelProperty("操作时间")
    private Date operationTime;

    @ApiModelProperty("操作前的状态")
    private Integer beforeChange;

    @ApiModelProperty("操作前状态")
    private String beforeChangeText;

    @ApiModelProperty("操作后的状态")
    private Integer afterChange;

    @ApiModelProperty("操作后的状态")
    private String afterChangeText;

}
