package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class MaterialTypeQueryDTO {
    @NotBlank(message = "项目id不能为空")
    @ApiModelProperty("项目id")
    private String projectId;
    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;
}
