package com.vren.material.module.order.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Author GR
 * @Time 2023-04-12-09-14
 **/
@Data
public class DeleteOrderDetailDTO {

    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("采购计划详情id")
    @NotBlank(message = "采购计划详情id不能为空")
    private String purchasePlanDetailId;

    @ApiModelProperty("订单数量")
    @ConversionNumber
    @NotNull(message = "订单数量不能为空")
    private Long orderQuantity;


}
