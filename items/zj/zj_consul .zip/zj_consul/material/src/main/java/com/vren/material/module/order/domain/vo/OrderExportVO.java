package com.vren.material.module.order.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import com.vren.material.common.converter.DateConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author gr
 */
@Data
public class OrderExportVO {

    @ExcelProperty("序号")
    @ApiModelProperty("自增序号")
    private Long autoincrementId;

    @ApiModelProperty("物资名称")
    @ExcelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格型号")
    @ExcelProperty("规格型号")
    private String size;

    @ApiModelProperty("材质、执行标准")
    @ExcelProperty("材质、执行标准")
    private String textureAndStandards;

    @ApiModelProperty("单位")
    @ExcelProperty("单位")
    private String useMaterialUnit;

    @ApiModelProperty("合同数量")
    @ConversionNumber
    @ExcelProperty(value = "合同数量", converter = EasyExcelToLongConverter.class)
    private Long purchaseAmount;

    @ApiModelProperty("累计已供货数量")
    @ExcelProperty(value = "累计已供货数量",converter = EasyExcelToLongConverter.class)
    private Long generatedOrderQuantity;

    @ApiModelProperty("本次订单数量")
    @ExcelProperty(value = "本次订单数量",converter = EasyExcelToLongConverter.class)
    private Long orderQuantity;

    @ApiModelProperty("税前单价")
    @ConversionNumber(value = 10000)
    private Long preTaxPrice;

    @ApiModelProperty("不含税单价（元/*）")
    @ExcelProperty("不含税单价（元/*）")
    private Double preTaxPriceExport;

    @ApiModelProperty("不含税总价")
    @ConversionNumber
    private Long totalPriceExcludingTax;

    @ApiModelProperty("不含税总价（元）")
    @ExcelProperty("不含税总价（元）")
    private Double totalPriceExcludingTaxExport;

    @ApiModelProperty("要求进场日期")
    @ExcelProperty(value = "要求进场日期",converter = DateConverter.class)
    private Date deliveryTime;

    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;

    @ApiModelProperty("材质")
    @ExcelIgnore
    private String texture;

    @ApiModelProperty("技术标准")
    @ExcelIgnore
    private String executiveStandards;


}
