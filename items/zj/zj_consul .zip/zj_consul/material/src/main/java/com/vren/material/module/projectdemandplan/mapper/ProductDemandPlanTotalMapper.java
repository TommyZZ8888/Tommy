package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.projectdemandplan.domain.entity.ProductDemandPlanTotal;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


@Mapper
public interface ProductDemandPlanTotalMapper extends MPJBaseMapper<ProductDemandPlanTotal> {

    /**
     *  批量新增
     * @param entities
     * @return
     */
    Integer insertBatchSomeColumn(List<ProductDemandPlanTotal> entities);

}
