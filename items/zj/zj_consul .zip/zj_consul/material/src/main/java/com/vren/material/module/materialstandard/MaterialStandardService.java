package com.vren.material.module.materialstandard;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.common.common.utils.PageUtil;
import com.vren.material.module.materialrenturn.domain.dto.QueryOneDTO;
import com.vren.material.module.materialstandard.domain.dto.GetMaterialStandardDTO;
import com.vren.material.module.materialstandard.domain.dto.MaterialStandardDTO;
import com.vren.material.module.materialstandard.domain.entity.MaterialStandard;
import com.vren.material.module.materialstandard.domain.vo.MaterialStandardSelectVO;
import com.vren.material.module.materialstandard.domain.vo.MaterialStandardVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author GR
 * time 2023-07-10-10-06
 **/
@Service
public class MaterialStandardService {

    @Autowired
    private MaterialStandardMapper materialStandardMapper;


    public boolean addOrEditMaterialStandard(MaterialStandardDTO dto) {
        MaterialStandard materialStandard = BeanUtil.copy(dto, MaterialStandard.class);
        materialStandard.setIsDelete(false);
        if (CommonUtil.isNull(materialStandard.getId())) {
            //新增
            return materialStandardMapper.insert(materialStandard) > 0;
        } else {
            //编辑
            return materialStandardMapper.updateById(materialStandard) > 0;

        }

    }

    public PageResult<MaterialStandardVO> getMaterialStandard(GetMaterialStandardDTO dto) {
        Page<MaterialStandardVO> page = PageUtil.convert2QueryPage(dto);
        MPJLambdaWrapper<MaterialStandard> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStandard.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialStandard::getMaterialType, dto.getMaterialType())
                .like(!CommonUtil.isNull(dto.getTexture()), MaterialStandard::getTexture, dto.getTexture())
                .eq(MaterialStandard::getIsDelete, false);
        IPage<MaterialStandardVO> materialStandardVOIPage = materialStandardMapper.selectJoinPage(page, MaterialStandardVO.class, wrapper);
        return PageUtil.convert2PageResult(materialStandardVOIPage);
    }

    public MaterialStandardVO getMaterialStandardById(QueryOneDTO dto) {
        MaterialStandard materialStandard = materialStandardMapper.selectById(dto.getId());
        return BeanUtil.copy(materialStandard, MaterialStandardVO.class);
    }

    public boolean delMaterialStandardById(QueryOneDTO dto) {
        UpdateWrapper<MaterialStandard> updateWrapper = new UpdateWrapper<>();
        updateWrapper.set("is_delete", 1)
                .eq("id", dto.getId());
        return materialStandardMapper.update(new MaterialStandard(), updateWrapper) > 0;
    }

    public List<MaterialStandardSelectVO> getMaterialStandardSelect(GetMaterialStandardDTO dto) {
        MPJLambdaWrapper<MaterialStandard> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialStandard.class)
                .eq(!CommonUtil.isNull(dto.getMaterialType()), MaterialStandard::getMaterialType, dto.getMaterialType())
                .like(!CommonUtil.isNull(dto.getTexture()), MaterialStandard::getTexture, dto.getTexture())
                .eq(MaterialStandard::getIsDelete, false);
        List<MaterialStandard> materialStandards = materialStandardMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(materialStandards)) {
            return BeanUtil.copyList(materialStandards, MaterialStandardSelectVO.class);
        } else {
            return new ArrayList<>();
        }
    }
}
