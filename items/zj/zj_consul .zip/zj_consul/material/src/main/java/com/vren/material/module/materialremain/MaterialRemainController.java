package com.vren.material.module.materialremain;

import com.vren.common.common.anno.NoNeedLogin;
import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.materialremain.domain.dto.EditMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.GetMaterialRemainDTO;
import com.vren.material.module.materialremain.domain.dto.QueryOneDTO;
import com.vren.material.module.materialremain.domain.vo.MaterialRemainVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/materialRemain")
@Api(tags = {"余料管理"})
@OperateLog
public class MaterialRemainController {

    @Autowired
    private MaterialRemainService materialRemainService;


    @RequestMapping(value = "/selectMaterialRemain", method = RequestMethod.POST)
    @ApiOperation("查询余料记录")
    public ResponseResult<PageResult<MaterialRemainVO>> getMaterialRemain(@RequestBody @Valid GetMaterialRemainDTO dto) {
        return ResponseResult.success("操作成功",materialRemainService.getMaterialRemain(dto));
    }

    @RequestMapping(value = "/selectMaterialRemainById", method = RequestMethod.POST)
    @ApiOperation("根据id查询余料记录")
    public ResponseResult<MaterialRemainVO> getMaterialRemainById(@RequestBody @Valid QueryOneDTO dto) {
        return ResponseResult.success("操作成功",materialRemainService.getMaterialRemainById(dto));
    }


    @RequestMapping(value = "/editMaterialRemain", method = RequestMethod.POST)
    @ApiOperation("编辑余料记录")
    public ResponseResult<Boolean> editMaterialRemain(@RequestBody @Valid EditMaterialRemainDTO dto) {
        materialRemainService.editMaterialRemain(dto);
        return ResponseResult.success("操作成功",true);
    }


    @RequestMapping(value = "/selectAttachment", method = RequestMethod.POST)
    @ApiOperation("查看附件")
    public ResponseResult<String> getAttachment(@RequestBody @Valid QueryOneDTO dto) {
        return ResponseResult.success("操作成功",materialRemainService.getAttachment(dto));
    }


}
