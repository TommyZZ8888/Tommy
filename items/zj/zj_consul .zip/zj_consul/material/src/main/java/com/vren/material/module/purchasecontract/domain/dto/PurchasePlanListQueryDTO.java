package com.vren.material.module.purchasecontract.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Description PurchasePlanListQueryDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class PurchasePlanListQueryDTO extends PageParam {

    @ApiModelProperty("项目需求计划编号")
    private String projectDemandPlanNo;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

}
