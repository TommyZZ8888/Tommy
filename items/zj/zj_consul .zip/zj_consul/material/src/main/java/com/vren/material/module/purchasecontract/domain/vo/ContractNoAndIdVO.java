package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ContractNoAndIdVO {

    @ApiModelProperty("合同清单Id")
    private String id;

    @ApiModelProperty("合同")
    private String contractNo;
}
