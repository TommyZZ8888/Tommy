package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @Description DeleteContractInfoDTO
 * @Author 张卫刚
 * @Date Created on 2023/9/5
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DeleteContractInfoDTO {

    @ApiModelProperty("采购合同详细id")
    private String id;

    @ApiModelProperty("物资类型")
    private Integer materialType;
}
