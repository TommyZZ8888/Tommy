package com.vren.material.module.materialremain.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GetMaterialRemainDTO extends PageParam {

    @ApiModelProperty("余料名称")
    private String remainingMaterialName;

    @ApiModelProperty("余料编号")
    private String remainingMaterialNo;

    @ApiModelProperty("库存状态")
    private Integer stockStatus;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("厚度")
    @ConversionNumber
    private Long firstSize;

}
