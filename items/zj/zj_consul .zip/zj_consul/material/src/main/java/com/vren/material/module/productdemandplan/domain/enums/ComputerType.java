package com.vren.material.module.productdemandplan.domain.enums;

import com.vren.material.module.productdemandplan.handler.*;

/**
 * @author vren
 */
public enum ComputerType {

    STICK_SHAPE("棒形", StickShape.class),
    TUBULAR_SHAPE("管形", TubularShape.class),

    TUBE("管", TubularShape.class),
    ANNULAR("环形", Annular.class),
    SQUARE("方形",Square.class),
    CIRCULAR("圆形",Circular.class),
    RECTANGLE("矩形",Rectangle.class),
    DRUM("卷筒",Drum.class),
    DEFAULT("默认处理", Default.class),
    ;

    private Class<? extends ComputerHandler> clazz;

    private String code;

    ComputerType(String code, Class<? extends ComputerHandler> clazz) {
        this.code = code;
        this.clazz = clazz;
    }

    public Class<? extends ComputerHandler> getClazz() {
        return clazz;
    }

    public String getCode() {
        return code;
    }
}
