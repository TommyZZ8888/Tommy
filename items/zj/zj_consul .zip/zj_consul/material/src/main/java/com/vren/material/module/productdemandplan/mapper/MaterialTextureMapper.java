package com.vren.material.module.productdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.productdemandplan.domain.entity.MaterialTexture;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 * 材质表
 */
@Mapper
public interface MaterialTextureMapper extends MPJBaseMapper<MaterialTexture> {
}
