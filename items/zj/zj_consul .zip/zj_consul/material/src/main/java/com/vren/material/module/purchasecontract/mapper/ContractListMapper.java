package com.vren.material.module.purchasecontract.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.purchasecontract.domain.entity.ContractList;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 */
@Mapper
public interface ContractListMapper extends MPJBaseMapper<ContractList> {

}
