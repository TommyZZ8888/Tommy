package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class UpdateMaterialTypeDTO {
    @ApiModelProperty("产品信息id")
    private String productInformationId;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("批次")
    private String batch;
}
