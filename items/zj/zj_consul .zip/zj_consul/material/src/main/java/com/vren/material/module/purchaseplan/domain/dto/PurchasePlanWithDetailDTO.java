package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author GR
 * @Time 2023-04-12-13-38
 **/
@Data
public class PurchasePlanWithDetailDTO {

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("合同清单编号")
    @NotBlank(message = "合同清单编号不能为空")
    private String contractListNo;

    @ApiModelProperty("订单id")
    private String orderId;

}
