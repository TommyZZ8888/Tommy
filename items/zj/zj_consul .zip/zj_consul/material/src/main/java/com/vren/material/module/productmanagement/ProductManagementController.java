package com.vren.material.module.productmanagement;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.productmanagement.domain.dto.*;
import com.vren.material.module.productmanagement.domain.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/productManagement")
@Api(tags = {"产品管理"})
@OperateLog
public class ProductManagementController {

    @Autowired
    private ProductManageService productManageService;

    @RequestMapping(value = "/getContainerType", method = RequestMethod.POST)
    @ApiOperation("获取容器类别下拉框")
    public ResponseResult<List<String>> getContainerType(){
        return  ResponseResult.success("获取成功",productManageService.getContainerType());
    }

    
    @RequestMapping(value = "/getProjectOutline", method = RequestMethod.POST)
    @ApiOperation("获取项目id和项目名称，用于下新增产品的拉框和查询产品的查询条件")
    public ResponseResult<List<ProjectVO>> getProjectOutline(){
        return  ResponseResult.success("获取成功",productManageService.getProjectOutline());
    }

    
    @RequestMapping(value = "/getProductOutline", method = RequestMethod.POST)
    @ApiOperation("获取产品id和产品名称，用于前端查询条件的模糊")
    public ResponseResult<List<ProductOutlineVO>> getProductOutline(){
        return  ResponseResult.success("获取成功",productManageService.getProductOutline());
    }

    @RequestMapping(value = "/getProductOutlineWithDemand", method = RequestMethod.POST)
    @ApiOperation("获取产品id和产品名称（产品还有数量没有 关联产品需求计划的）")
    public ResponseResult<List<ProductAndDemandVO>> getProductOutlineWithDemand(){
        return  ResponseResult.success("获取成功",productManageService.getProductOutlineWithDemand());
    }



    @RequestMapping(value = "/select", method = RequestMethod.POST)
    @ApiOperation("查询产品信息")
    public ResponseResult<PageResult<ProductInformationVO>> getProductInformation(@RequestBody ProductInformationDTO dto){
        return  ResponseResult.success("获取成功",productManageService.getProductInformation(dto));
    }

    
    @RequestMapping(value = "/batchDeleteProduct", method = RequestMethod.POST)
    @ApiOperation("删除单个/多个产品信息")
    public ResponseResult<Boolean> batchDeleteProduct(@RequestBody @Valid BatchDeleteDTO dto){
        productManageService.batchDeleteProduct(dto);
        return  ResponseResult.success("删除成功",true);
    }

    @RequestMapping(value = "/addOrEdit", method = RequestMethod.POST)
    @ApiOperation("新增或编辑产品信息")
    public ResponseResult<Boolean> addOrEditProduct(@RequestBody @Valid UpdateProductDTO dto){
        productManageService.addOrEditProduct(dto);
        return  ResponseResult.success("操作成功",true);
    }

    
    @RequestMapping(value = "/getProductInformationDetail", method = RequestMethod.POST)
    @ApiOperation("根据id查询产品信息")
    public ResponseResult<ProductInformationVO> getProductInformationDetail(@RequestBody @Valid DeleteOrGetOneDTO dto){
        return  ResponseResult.success("操作成功",productManageService.getProductInformationDetail(dto.getId()));
    }

    @RequestMapping(value = "/getProductInformationByName", method = RequestMethod.POST)
    @ApiOperation("根据条件查询产品信息")
    public ResponseResult<ProductInformationVO> getProductInformationByName(@RequestBody @Valid com.vren.common.module.material.dto.QueryProductDTO dto){
        return  ResponseResult.success("操作成功",productManageService.getProductInformationByName(dto));
    }


    @RequestMapping(value = "/selectByKeyIds", method = RequestMethod.POST)
    @ApiOperation("多个id查询产品信息")
    public ResponseResult<List<ProductInformationVO>> selectByKeyIds(@RequestBody @Valid IdsDTO dto){
        return  ResponseResult.success("获取成功",productManageService.selectByKeyIds(dto));
    }

    @RequestMapping(value = "/getProductNotProductionPlan", method = RequestMethod.POST)
    @ApiOperation("未处于生产计划的产品信息")
    public ResponseResult<List<ProductInformationVO>> getProductNotProductionPlan(){
        return  ResponseResult.success("获取成功",productManageService.getProductNotProductionPlan());
    }

    @RequestMapping(value = "/createProductPlan", method = RequestMethod.POST)
    @ApiOperation("创建生产计划并更改生产计划状态")
    public ResponseResult<Boolean> createProductPlan(@RequestBody @Valid  CreateProductPlanDTO dto){
        return  productManageService.createProductPlan(dto);
    }

    @RequestMapping(value = "/changeProductScheduling", method = RequestMethod.POST)
    @ApiOperation("根据产品id更新排产状态")
    public ResponseResult<Boolean> changeProductScheduling(@RequestBody  ProductSchedulingDTO dto){
        return  ResponseResult.success("获取成功",productManageService.changeProductScheduling(dto));
    }


    @RequestMapping(value = "/changeProductPlan", method = RequestMethod.POST)
    @ApiOperation("删除生产计划时，改变产品生产状态(调用)")
    public ResponseResult<Boolean> changeProductPlan(@RequestBody  DeleteOrGetOneDTO dto){
        return  ResponseResult.success("获取成功",productManageService.changeProductPlan(dto));
    }


    @RequestMapping(value = "/getProductInProductionScheduling", method = RequestMethod.POST)
    @ApiOperation("查询处于排产状态的产品信息")
    public ResponseResult<List<ProductInformationVO>> getProductInProductionScheduling(){
        return  ResponseResult.success("获取成功",productManageService.getProductInProductionScheduling());
    }


    @RequestMapping(value = "/getProductByProjectId", method = RequestMethod.POST)
    @ApiOperation("根据项目id查询产品信息(调用)")
    public ResponseResult<List<ProductByProjectIdVO>> getProductByProjectId(@RequestBody ProjectIdDTO dto){
        return  ResponseResult.success("获取成功",productManageService.getProductByProjectId(dto));
    }


    @RequestMapping(value = "/canDeleteProject", method = RequestMethod.POST)
    @ApiOperation("根据项目id判断这个项目是否能够删除（项目下存在产品，则不能删除）(调用)")
    public ResponseResult<Boolean> canDeleteProject(@RequestParam(value = "id") String id) {
        return ResponseResult.success("获取成功", productManageService.canDeleteProject(id));
    }

    @RequestMapping(value = "/exportProduct", method = RequestMethod.POST)
    @ApiOperation("基于项目导出产品信息")
    public void exportProduct(HttpServletResponse response, @RequestBody @Valid ExportProductDTO dto) throws IOException {
        productManageService.exportProduct(response, dto);
    }

    @RequestMapping(value = "/importProduct", method = RequestMethod.POST)
    @ApiOperation("基于项目导入产品信息")
    public ResponseResult<Boolean> importProduct(MultipartFile file, ExportProductDTO dto) {
        try {
            boolean result = productManageService.importProduct(file, dto);
            if (result) {
                return ResponseResult.success("导入成功", true);
            }
            return ResponseResult.error("导入失败，制造编号重复", false);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ResponseResult.error("导入失败", false);
    }

}
