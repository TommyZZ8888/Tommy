package com.vren.material.module.purchaseplan.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@TableName("purchase_plan_details_welding_materials")
@Data
public class PurchasePlanDetailsWeldingMaterials {
    @ApiModelProperty("id")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("采购计划表ID")
    private String purchasePlanId;

    @ApiModelProperty("油漆需求计划表ID")
    private String weldingMaterialDemandPlanId;

    @ApiModelProperty("图号")
    private String figureNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;

    @ApiModelProperty("用料单位")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    @ApiModelProperty("技术标准")
    private String technicalStandard;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long proposalPrice;

    @ApiModelProperty("税前单价")
    @ConversionNumber(value = 10000)
    private Long preTaxPrice;

    @ApiModelProperty("税额")
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("市场最高价")
    @ConversionNumber
    private Long highestMarketPrice;

    @ApiModelProperty("市场最低价")
    @ConversionNumber
    private Long lowestMarketPrice;

    @ApiModelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("市场含税单价")
    @ConversionNumber(value = 10000)
    private Long marketUnitPriceTax;

    @ApiModelProperty("市场加权均价")
    @ConversionNumber
    private Long marketWeightedAverage;

    @ApiModelProperty("建议控制价")
    @ConversionNumber
    private Long proposedControlPrice;

    @ApiModelProperty("商务核准价格")
    @ConversionNumber
    private Long businessApprovedPrice;

    @ApiModelProperty("最终批准价格")
    @ConversionNumber
    private Long finalApprovalPriceField;

    @ApiModelProperty("标书加权均价")
    @ConversionNumber
    private Long weightedAverageBidPrice;

    @ApiModelProperty("含税单价")
    @ConversionNumber
    private Long unitPriceWithTax;

    @ApiModelProperty("不含税总价")
    @ConversionNumber
    private Long totalPriceExcludingTax;

    @ApiModelProperty("含税总价")
    @ConversionNumber
    private Long totalPriceIncludingTax;

    @ApiModelProperty("单位2")
    private String unitTwo;

    @ApiModelProperty("单位3")
    private String unitThree;

    @ApiModelProperty("税率")
    @ConversionNumber
    private Long taxRate;

    @ApiModelProperty("是否删除")
    @TableField(fill = FieldFill.INSERT)
    private Boolean isDeleted;


    @ApiModelProperty("已生成订单数量")
    @ConversionNumber
    private Long generatedOrderQuantity;

    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long bidPrice;

    @ApiModelProperty("标书最低价")
    @ConversionNumber
    private Long lowestBidPrice;

    @ApiModelProperty("标书最高价")
    @ConversionNumber
    private Long highestBidPrice;

    @ApiModelProperty("标书品牌")
    private String bidBrand;

    @ApiModelProperty("付款条件")
    private String paymentTerms;

    @ApiModelProperty("序号")
    private Integer serialNumber;

    private String contractListId;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;
}