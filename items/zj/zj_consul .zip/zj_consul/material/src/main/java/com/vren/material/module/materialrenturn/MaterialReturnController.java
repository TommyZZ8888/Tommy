package com.vren.material.module.materialrenturn;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.materialcheckout.domain.vo.MaterialCheckoutDetailVO;
import com.vren.material.module.materialrenturn.domain.dto.*;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNameInCheckoutVO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialNumberSelectVO;
import com.vren.material.module.materialrenturn.domain.vo.MaterialReturnVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author 耿让
 * 回库
 */
@RestController
@RequestMapping("/materialReturn")
@Api(tags = {"材料退库"})
@OperateLog
public class MaterialReturnController {

    @Autowired
    private MaterialReturnService materialReturnService;

    @RequestMapping(value = "/selectCheckoutByProjectIdAndNo", method = RequestMethod.POST)
    @ApiOperation("根据项目id和出库编号查询出库记录(名称、规格)")
    public ResponseResult<List<MaterialCheckoutDetailVO>> selectCheckoutByProjectIdAndNo(@RequestBody @Valid SelectCheckoutDTO dto) {
        return ResponseResult.success("操作成功",materialReturnService.selectCheckoutByProjectIdAndNo(dto));
    }

    @RequestMapping(value = "/selectCheckoutByMaterialNumber", method = RequestMethod.POST)
    @ApiOperation("根据物资编号查询出库记录")
    public ResponseResult<MaterialCheckoutDetailVO> selectCheckoutByMaterialNumber(@RequestBody @Valid MaterialNumberDTO dto) {
        return ResponseResult.success("操作成功", materialReturnService.selectCheckoutByMaterialNumber(dto));
    }


    @RequestMapping(value = "/generateReturnRecord", method = RequestMethod.POST)
    @ApiOperation("生成回库记录")
    public ResponseResult<Boolean> generateReturnRecord(@RequestBody @Valid GenerateReturnRecordDTO dto) {
        materialReturnService.generateReturnRecord(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialNumberSelect", method = RequestMethod.POST)
    @ApiOperation("在出库记录中，根据项目名称和物资类型获取物资编号下拉框")
    public ResponseResult<List<MaterialNumberSelectVO>> getMaterialNumberSelect(@RequestBody MaterialNumberSelectDTO dto) {
        return ResponseResult.success("操作成功", materialReturnService.getMaterialNumberSelect(dto));
    }

    @RequestMapping(value = "/generateSpareRecord", method = RequestMethod.POST)
    @ApiOperation("生成余料记录")
    public ResponseResult<Boolean> generateSpareRecord(@RequestBody @Valid GenerateSpareRecordDTO dto) {
        materialReturnService.generateSpareRecord(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/selectReturnRecord", method = RequestMethod.POST)
    @ApiOperation("查询回库记录")
    public ResponseResult<PageResult<MaterialReturnVO>> getReturnRecord(@RequestBody @Valid GetReturnRecordDTO dto) {
        return ResponseResult.success("操作成功",materialReturnService.getReturnRecord(dto));
    }

    @RequestMapping(value = "/selectReturnRecordById", method = RequestMethod.POST)
    @ApiOperation("根据id查询回库记录")
    public ResponseResult<MaterialReturnVO> getReturnRecordById(@RequestBody @Valid QueryOneDTO dto) {
        return ResponseResult.success("操作成功",materialReturnService.getReturnRecordById(dto));
    }


    @RequestMapping(value = "/editReturnRecord", method = RequestMethod.POST)
    @ApiOperation("编辑回库记录")
    public ResponseResult<Boolean> editReturnRecord(@RequestBody @Valid EditReturnRecordDTO dto) {
        materialReturnService.editReturnRecord(dto);
        return ResponseResult.success("操作成功",true);
    }

    @RequestMapping(value = "/getMaterialNameInCheckout", method = RequestMethod.POST)
    @ApiOperation("新增余料，回显出库数据")
    public ResponseResult<List<MaterialNameInCheckoutVO>> getMaterialNameInCheckout(@RequestBody @Valid MaterialNameInCheckoutDTO dto) {
        return ResponseResult.success("获取成功",materialReturnService.getMaterialNameInCheckout(dto));
    }

}
