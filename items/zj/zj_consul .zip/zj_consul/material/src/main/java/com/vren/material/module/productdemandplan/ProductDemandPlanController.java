package com.vren.material.module.productdemandplan;

import com.vren.common.common.anno.NoNeedLogin;
import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.common.module.material.dto.QueryProductDTO;
import com.vren.common.module.material.entity.ProductInformationVO;
import com.vren.common.module.product.domain.entity.ProdutPlanProgressList;
import com.vren.material.module.productdemandplan.domain.dto.*;
import com.vren.material.module.productdemandplan.domain.vo.*;
import com.vren.material.module.productmanagement.domain.dto.BatchDeleteDTO;
import com.vren.material.module.productmanagement.domain.dto.CreateProductPlanDTO;
import com.vren.material.module.productmanagement.domain.dto.DeleteOrGetOneDTO;
import com.vren.material.module.productmanagement.domain.dto.ProductSchedulingDTO;
import com.vren.material.module.productmanagement.domain.vo.ProductDemandVO;
import com.vren.material.module.purchasecontract.domain.dto.StartContractListWorkFlow;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/productDemandPlan")
@Api(tags = {"产品需求计划"})
@OperateLog
public class ProductDemandPlanController {

    @Autowired
    private ProductDemandPlanService productDemandPlanService;


    @RequestMapping(value = "/select", method = RequestMethod.POST)
    @ApiOperation("查询产品需求计划")
    public ResponseResult<PageResult<ProductDemandPlanVO>> getProductDemandPlan(@RequestBody QueryDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductDemandPlan(dto));
    }


    @RequestMapping(value = "/addOrEdit", method = RequestMethod.POST)
    @ApiOperation("新增或编辑产品需求信息")
    public ResponseResult<Boolean> addOrEditProductDemandPlan(@RequestBody @Valid UpdateProductDemanPlanDTO dto) {
        productDemandPlanService.addOrEditProductDemandPlan(dto);
        return ResponseResult.success("操作成功", true);
    }


    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ApiOperation("删除产品需求计划")
    public ResponseResult<Boolean> deleteProductDemandPlan(@RequestBody @Valid DeleteProductDemandPlanDTO dto) {
        productDemandPlanService.deleteProductDemandPlan(dto.getId(), dto.getBatch());
        return ResponseResult.success("删除成功", true);
    }


    @RequestMapping(value = "/getProductDemandPlanDetail", method = RequestMethod.POST)
    @ApiOperation("根据id查询产品需求计划")
    public ResponseResult<ProductDemandPlanVO> getProductDemandPlanDetail(@RequestBody @Valid DeleteOrGetOneDTO dto) {
        return ResponseResult.success("操作成功", productDemandPlanService.getProductDemandPlanDetail(dto.getId()));
    }


    @RequestMapping(value = "/export", method = RequestMethod.POST)
    @ApiOperation("导出产品对应的产品需求明细（传产品需求计划id）")
    public void export(HttpServletResponse response, @RequestBody @Valid DeleteOrGetOneDTO dto) throws IOException {
        productDemandPlanService.export(response, dto);
    }

    //************************************产品需求计划明细***************************************************


    @RequestMapping(value = "/selectDetails", method = RequestMethod.POST)
    @ApiOperation("（子界面）查询产品需求计划详情，每个产品对应的子表（通过产品需求计划id和查询条件查询）")
    public ResponseResult<PageResult<ProductDemandPlanDetailsWithTotalFigureNoVO>> selectProductDemandPlanDetails(@RequestBody @Valid QueryDetailsDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectProductDemandPlanDetails(dto));
    }


    @RequestMapping(value = "/batchAddProductDemandPlanDetails", method = RequestMethod.POST)
    @ApiOperation("（子界面）批量新增产品需求计划详情")
    public ResponseResult<Boolean> batchAddProductDemandPlanDetails(@RequestBody @Valid BatchInsertDetailDTO dto) {
        productDemandPlanService.batchAddProductDemandPlanDetails(dto);
        return ResponseResult.success("操作成功", true);
    }


    @RequestMapping(value = "/selectDetailsOne", method = RequestMethod.POST)
    @ApiOperation("（子界面）根据id查询产品需求详情（编辑时/查看时使用）")
    public ResponseResult<ProductDemandPlanDetailVO> selectDetailsOne(@RequestBody @Valid DeleteOrGetOneDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectDetailsOne(dto));
    }


    @RequestMapping(value = "/editDetails", method = RequestMethod.POST)
    @ApiOperation("（子界面）编辑产品需求详情")
    public ResponseResult<Boolean> editDetails(@RequestBody InsertDetailDTO dto) {
        productDemandPlanService.editDetails(dto);
        return ResponseResult.success("操作成功", true);
    }


    @RequestMapping(value = "/deleteDetails", method = RequestMethod.POST)
    @ApiOperation("（子界面）根据id删除产品需求详情")
    public ResponseResult<Boolean> deleteDetails(@RequestBody @Valid DeleteOrGetOneDTO dto) {
        productDemandPlanService.deleteDetails(dto);
        return ResponseResult.success("获取成功", true);
    }


    @RequestMapping(value = "/editTimeAndLocation", method = RequestMethod.POST)
    @ApiOperation("（子界面）批量更新交货时间和交货地点")
    public ResponseResult<Boolean> editTimeAndLocation(@RequestBody @Valid EditTimeAndLocationDTO dto) {
        productDemandPlanService.editTimeAndLocation(dto);
        return ResponseResult.success("操作成功", true);
    }


    //************************************材质管理*******************************************************

    @RequestMapping(value = "/getMaterialTexture", method = RequestMethod.POST)
    @ApiOperation("（材质管理）根据id查询材质")
    public ResponseResult<MaterialTextureVO> getMaterialTexture(@RequestBody @Valid DeleteOrGetOneDTO dto) {
        return ResponseResult.success("操作成功", productDemandPlanService.getMaterialTexture(dto.getId()));
    }


    @RequestMapping(value = "/selectAllMaterialTexture", method = RequestMethod.POST)
    @ApiOperation("（材质管理）查询材质，带有分页")
    public ResponseResult<PageResult<MaterialTextureVO>> selectAllMaterialTexture(@RequestBody QueryMaterialTextureDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectAllMaterialTexture(dto));
    }


    @RequestMapping(value = "/selectAllMaterialTextureWithoutPage", method = RequestMethod.POST)
    @ApiOperation("（材质管理）查询所有材质，没有分页（新增产品需求计划详情时代号模糊 和 前端自动填充材质和用料类型）")
    public ResponseResult<List<MaterialTextureVO>> selectAllMaterialTextureWithoutPage() {
        return ResponseResult.success("获取成功", productDemandPlanService.selectAllMaterialTextureWithoutPage());
    }


    @RequestMapping(value = "/addMaterialTexture", method = RequestMethod.POST)
    @ApiOperation("（材质管理）新增/编辑材质")
    public ResponseResult<Boolean> addMaterialTexture(@RequestBody InsertOrUpdateMaterialTextureDTO dto) {
        productDemandPlanService.addMaterialTexture(dto);
        return ResponseResult.success("操作成功", true);
    }


    @RequestMapping(value = "/batchDeleteMaterialTexture", method = RequestMethod.POST)
    @ApiOperation("(材质管理)删除单个/多个材质")
    public ResponseResult<Boolean> batchDeleteMaterialTexture(@RequestBody @Valid BatchDeleteDTO dto) {
        productDemandPlanService.batchDeleteMaterialTexture(dto);
        return ResponseResult.success("删除成功", true);
    }


    /**
     * 新增产品需求详情的时候，需要下拉选择材质
     * 用料类型是材质表里面的用料类型字段
     */


    @RequestMapping(value = "/getMaterialTypeList", method = RequestMethod.POST)
    @ApiOperation("获取用料类型下拉框，材质管理里面的（往后端直接传用料类型的名称）")
    public ResponseResult<List<String>> getMaterialTypeList() {
        ArrayList<String> list = new ArrayList<>();
        list.add("卷筒");
        list.add("圆形");
        list.add("方形");
        list.add("矩形");
        list.add("环形");
        list.add("棒形");
        list.add("管形");
        list.add("外购");
        list.add("管");
        return ResponseResult.success("获取成功", list);
    }


    //******************************************物资类型表:只针对备注的更新和删除*************************************

    @RequestMapping(value = "/getMaterialTypeSelect", method = RequestMethod.POST)
    @ApiOperation("产品需求模块，查询所有的物资类型")
    public ResponseResult<List<SelectVO>> getMaterialTypeSelect() {
        return ResponseResult.success("获取成功", productDemandPlanService.getMaterialTypeSelect());
    }

    @RequestMapping(value = "/getMaterialType", method = RequestMethod.POST)
    @ApiOperation("产品需求模块，查询所有的物资类型")
    public ResponseResult<List<SelectVO>> getMaterialType(@RequestBody GetMaterialTypeDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getMaterialType(dto));
    }


    @RequestMapping(value = "/getMaterialTypeBatch", method = RequestMethod.POST)
    @ApiOperation("（材料说明）查询所有的物资类型")
    public ResponseResult<List<MaterialTypeVO>> getMaterialTypeBatch(@RequestBody @Valid GetMaterialTypeDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getMaterialTypeByProductIdAndBatch(dto));
    }

    @RequestMapping(value = "/getMaterialTypeByDemandId", method = RequestMethod.POST)
    @ApiOperation("（材料说明）查询所有的物资类型（工艺卡部分调用）")
    public ResponseResult<List<MaterialTypeAndRemarkVO>> getMaterialTypeByDemandId(@RequestBody @Valid KeyIdDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getMaterialTypeByDemandId(dto));
    }


    @RequestMapping(value = "/getMaterialTypeById", method = RequestMethod.POST)
    @ApiOperation("（材料说明）根据产品id和物资类型查询物资类型（批量新增明细时，从此获得自动填充的备注）")
    public ResponseResult<MaterialTypeVO> getMaterialTypeById(@RequestBody GetMaterialTypeByProductId dto) {
        return ResponseResult.success("查询成功", productDemandPlanService.getMaterialTypeById(dto));
    }


    @RequestMapping(value = "/editMaterialType", method = RequestMethod.POST)
    @ApiOperation("（材料说明）修改/清空备注（不传备注即为清空操作）/ 根据批次")
    public ResponseResult<Boolean> editMaterialType(@RequestBody UpdateMaterialTypeDTO dto) {
        productDemandPlanService.editMaterialType(dto);
        return ResponseResult.success("操作成功", true);
    }


    @RequestMapping(value = "/selectDetailsByProductId", method = RequestMethod.POST)
    @ApiOperation("根据产品id查询产品需求详情(调用)")
    public ResponseResult<List<ProductDemandPlanDetailsVO>> selectDetailsByProductId(@RequestBody @Valid GetManyById dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectDetailsByProductId(dto));
    }


    @RequestMapping(value = "/getProductDemandSelect", method = RequestMethod.POST)
    @ApiOperation("项目需求计划生成，选择产品需求计划下拉框")
    public ResponseResult<List<ProductDemandSelectVO>> getProductDemandSelect(@RequestBody @Valid DeleteOrGetOneDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductDemandSelect(dto));
    }

    //2023/03/03  工艺部分接口调整，工艺根据产品获取需求详情 改为 根据产品需求获取需求详情

    @RequestMapping(value = "/getProductDemandPlanSelect", method = RequestMethod.POST)
    @ApiOperation("工艺获取产品需求信息下拉框")
    public ResponseResult<List<ProductDemandPlanSelectVO>> getProductDemandPlanSelect() {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductDemandPlanSelect());
    }


    @RequestMapping(value = "/selectDetailsByProductDemandPlanId", method = RequestMethod.POST)
    @ApiOperation("根据产品需求计划id查询产品需求详情(调用)")
    public ResponseResult<List<ProductDemandPlanDetailsForProcessVO>> selectDetailsByProductDemandPlanId(@RequestBody @Valid GetManyById dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectDetailsByProductDemandPlanId(dto));
    }


    @RequestMapping(value = "/selectByKeyId", method = RequestMethod.POST)
    @ApiOperation("根据产品需求计划id查询（调用）")
    public ResponseResult<ProductDemandVO> selectByKeyId(@RequestBody @Valid KeyIdDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.selectByKeyId(dto));
    }


    //2023/03/03  生产模块 将根据产品创建生产  改为  根据产品需求计划创建生产

    @RequestMapping(value = "/getProductDemandPlanNotProductionPlan", method = RequestMethod.POST)
    @ApiOperation("未处于生产计划的产品需求计划")
    public ResponseResult<PageResult<ProductDemandPlanNotProductionPlanVO>> getProductDemandPlanNotProductionPlan(@RequestBody QueryProductDemandDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductDemandPlanNotProductionPlan(dto));
    }

    @RequestMapping(value = "/createProductPlan", method = RequestMethod.POST)
    @ApiOperation("创建生产计划并更改生产计划状态")
    public ResponseResult<Boolean> createProductPlan(@RequestBody @Valid CreateProductPlanDTO dto) {
        return productDemandPlanService.createProductPlan(dto);
    }

    @RequestMapping(value = "/changeProductScheduling", method = RequestMethod.POST)
    @ApiOperation("根据产品需求id更新排产状态")
    public ResponseResult<Boolean> changeProductScheduling(@RequestBody ProductSchedulingDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.changeProductScheduling(dto));
    }

    @RequestMapping(value = "/changeProductPlan", method = RequestMethod.POST)
    @ApiOperation("删除生产计划时，改变产品需求计划的生产状态(调用)")
    public ResponseResult<Boolean> changeProductPlan(@RequestBody DeleteOrGetOneDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.changeProductPlan(dto));
    }

    @RequestMapping(value = "/getProductDemandInProductionScheduling", method = RequestMethod.POST)
    @ApiOperation("查询处于排产状态的产品需求信息")
    public ResponseResult<List<ProductDemandInProductionSchedulingVO>> getProductDemandInProductionScheduling() {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductDemandInProductionScheduling());
    }

    //2023/03/10 质量模块，需要产品信息接口

    //    produces = {"application/json;charset=utf-8"}
    @RequestMapping(value = "/getProductInformationByName", method = RequestMethod.POST)
    @ApiOperation("根据产品需求计划id查询")
    public ResponseResult<ProductInformationVO> getProductInformationByName(@RequestBody @Valid QueryProductDTO dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.getProductInformationByName(dto));
    }

    //2023/03/17  获取项目进度，免token调用

    @RequestMapping(value = "/getProcess", method = RequestMethod.POST)
    @NoNeedLogin
    ResponseResult<String> getProcess(@RequestBody List<ProdutPlanProgressList> productPlanProgressList) {
        return ResponseResult.success("获取成功", productDemandPlanService.getProcess(productPlanProgressList));
    }

    @RequestMapping(value = "/updateSpecifications", method = RequestMethod.POST)
    @ApiOperation("更新规格")
    @NoNeedLogin
    public void updateSpecifications() {
        productDemandPlanService.updateSpecifications();
    }

    /***********************产品需求计划审批********************************/
    @RequestMapping(value = "/startProductDemandPlanWorkFlow", method = RequestMethod.POST)
    @ApiOperation("开始产品需求计划的审核")
    public ResponseResult<Boolean> startProductDemandPlanWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.startProductDemandPlanWorkFlow(dto));
    }

    @RequestMapping(value = "/updateProductDemandPlanWorkFlow", method = RequestMethod.POST)
    @ApiOperation("产品需求计划的审核")
    public ResponseResult<Boolean> updateProductDemandPlanWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.updateProductDemandPlanWorkFlow(dto));
    }

    @RequestMapping(value = "/endProductDemandPlanWorkFlow", method = RequestMethod.POST)
    @ApiOperation("结束产品需求计划的审核")
    public ResponseResult<Boolean> endProductDemandPlanWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", productDemandPlanService.endProductDemandPlanWorkFlow(dto));
    }


    @ApiOperation("复制产品需求计划")
    @RequestMapping(value = "/copy", method = RequestMethod.POST)
    public ResponseResult<Boolean> copy(@RequestBody UpdateProductDemanPlanDTO dto) {
        productDemandPlanService.copy(dto);
        return ResponseResult.success("操作成功");
    }


    @ApiOperation("更新重量")
    @RequestMapping(value = "/updateWeight", method = RequestMethod.POST)
    public ResponseResult<Boolean> updateWeight() {
        productDemandPlanService.update();
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/updateSpecificationX", method = RequestMethod.POST)
    @ApiOperation("更新板材型材规格的X为*--产品详细")
    public ResponseResult<Boolean> updateSpecificationX() {
        productDemandPlanService.updateSpecificationX();
        return ResponseResult.success("操作成功");
    }
}
