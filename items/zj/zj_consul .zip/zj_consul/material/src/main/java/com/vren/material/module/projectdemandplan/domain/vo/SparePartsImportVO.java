package com.vren.material.module.projectdemandplan.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;


@Data
public class SparePartsImportVO {

    @ApiModelProperty("序号")
    @ExcelProperty(value = "序号", index = 0)
    private Integer serialNumber;

    @ApiModelProperty("物资名称")
    @ExcelProperty(value = "物资名称", index = 1)
    private String materialName;

    @ApiModelProperty("规格型号")
    @ExcelProperty(value = "规格型号", index = 2)
    private String specification;

    @ApiModelProperty("材质")
    @ExcelProperty(value = "材质", index = 3)
    private String texture;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量", index = 4, converter = EasyExcelToLongConverter.class)
    @ConversionNumber
    private Long count;

    @ApiModelProperty("单位")
    @ExcelProperty(value = "单位", index = 5)
    private String unit;

    @ApiModelProperty("技术标准")
    @ExcelProperty(value = "技术标准", index = 6)
    private String enforceStandards;

    @ApiModelProperty("到货时间")
    @ExcelProperty(value = "到货时间", index = 7)
    private Date deliveryTime;

    @ApiModelProperty("备注")
    @ExcelProperty(value = "备注", index = 8)
    private String remarks;

}
