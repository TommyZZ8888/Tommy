package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@Data
public class ProductTotalVO {


    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型描述")
    private String materialTypeText;

    @ApiModelProperty("单位")
    private String unit;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("规格")
    private String specification;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("备注")
    private String remarks;
    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;

    @ApiModelProperty("产品需求计划idList")
    private String[] idList;

    @ApiModelProperty("制造编号&件号")
    private String manufacturingNumberPartNo;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;

    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ConversionNumber
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("采购到货数量")
    @ConversionNumber
    private Integer arrivalAmount;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Integer purchaseNum;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    private Long purchaseWeight;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;

    @ApiModelProperty("序号")
    private Integer serialNumber;

    @ApiModelProperty("产品需求计划详情id")
    private String productDemandPlanDetailsId;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;

    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("可锁库存数")
    @ConversionNumber
    private Long canLockMaterialStockNum;

    @ApiModelProperty("可锁余料数")
    @ConversionNumber
    private Long canLockMaterialRemainNum;

    @ApiModelProperty("宽度")
    @ConversionNumber
    private Long width;

    @ApiModelProperty("长度")
    @ConversionNumber
    private Long length;

    @ApiModelProperty("厚度")
    @ConversionNumber
    private Long thickness;
}
