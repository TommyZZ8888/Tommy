package com.vren.material.module.order;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.order.domain.dto.*;
import com.vren.material.module.order.domain.vo.OrderDetailVO;
import com.vren.material.module.order.domain.vo.OrderInProcessVO;
import com.vren.material.module.order.domain.vo.OrderVO;
import com.vren.material.module.purchasecontract.domain.dto.GetOneOrDeleteDTO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;

/**
 * @author 耿让
 */
@RestController
@RequestMapping(value = "/order")
@Api(tags = {"采购订单"})
@OperateLog
public class OrderController {

    private final OrderService orderService;


    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @RequestMapping(value = "/queryOrder", method = RequestMethod.POST)
    @ApiOperation("查询订单列表")
    public ResponseResult<PageResult<OrderVO>> queryOrder(@RequestBody QueryOrderDTO dto) {
        return ResponseResult.success("获取成功", orderService.queryOrder(dto));
    }

    @RequestMapping(value = "/addOrder", method = RequestMethod.POST)
    @ApiOperation("新增订单")
    public ResponseResult<Boolean> addOrder(@Valid @RequestBody AddOrderDTO dto) {
        return ResponseResult.success("获取成功", orderService.addOrder(dto));
    }

    @RequestMapping(value = "/queryOrderById", method = RequestMethod.POST)
    @ApiOperation("根据id查询订单")
    public ResponseResult<OrderVO> queryOrderById(@Valid @RequestBody GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", orderService.queryOrderById(dto));
    }

    @RequestMapping(value = "/editOrder", method = RequestMethod.POST)
    @ApiOperation("编辑订单")
    public ResponseResult<Boolean> editOrder(@RequestBody EditOrderDTO dto) {
        return ResponseResult.success("获取成功", orderService.editOrder(dto));
    }

    @RequestMapping(value = "/deleteOrder", method = RequestMethod.POST)
    @ApiOperation("删除订单")
    public ResponseResult<Boolean> deleteOrder(@RequestBody GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", orderService.deleteOrder(dto));
    }

    @RequestMapping(value = "/queryOrderDetail", method = RequestMethod.POST)
    @ApiOperation("查询订单详情")
    public ResponseResult<PageResult<OrderDetailVO>> queryOrderDetail(@Valid @RequestBody QueryOrderDetailDTO dto) {
        return ResponseResult.success("获取成功", orderService.queryOrderDetail(dto));
    }

    @RequestMapping(value = "/queryOrderDetailById", method = RequestMethod.POST)
    @ApiOperation("根据id查询订单详情")
    public ResponseResult<OrderDetailVO> queryOrderDetailById(@Valid @RequestBody QueryDTO dto) {
        return ResponseResult.success("获取成功", orderService.queryOrderDetailById(dto));
    }

    @RequestMapping(value = "/editOrderDetail", method = RequestMethod.POST)
    @ApiOperation("编辑订单详情")
    public ResponseResult<Boolean> editOrderDetail(@RequestBody EditOrderDetailDTO dto) {
        return ResponseResult.success("获取成功", orderService.editOrderDetail(dto));
    }

    @RequestMapping(value = "/deleteOrderDetail", method = RequestMethod.POST)
    @ApiOperation("删除订单详情")
    public ResponseResult<Boolean> deleteOrderDetail(@Valid @RequestBody DeleteOrderDetailDTO dto) {
        return ResponseResult.success("获取成功", orderService.deleteOrderDetail(dto));
    }

    @RequestMapping(value = "/addOrderDetail", method = RequestMethod.POST)
    @ApiOperation("批量新增订单详情")
    public ResponseResult<Boolean> addOrderDetail(@Valid @RequestBody AddOrderDetailDTO dto) {
        return ResponseResult.success("获取成功", orderService.addOrderDetail(dto));
    }

    @RequestMapping(value = "/exportOrder", method = RequestMethod.POST)
    @ApiOperation("导出订单信息")
    public void exportOrder(HttpServletResponse response, @Valid @RequestBody QueryDTO dto) {
        try {
            orderService.exportOrder(response, dto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /***********************订单审核********************************/
    @RequestMapping(value = "/startOrderWorkFlow", method = RequestMethod.POST)
    @ApiOperation("开始订单的审核")
    public ResponseResult<Boolean> startOrderWorkFlow(@RequestBody @Valid StartOrderWorkFlowDTO dto) {
        return ResponseResult.success("获取成功", orderService.startOrderWorkFlow(dto));
    }

    @RequestMapping(value = "/updateOrderWorkFlow", method = RequestMethod.POST)
    @ApiOperation("订单的审核")
    public ResponseResult<Boolean> updateOrderWorkFlow(@RequestBody @Valid StartOrderWorkFlowDTO dto) {
        return ResponseResult.success("获取成功", orderService.updateOrderWorkFlow(dto));
    }

    @RequestMapping(value = "/endOrderWorkFlow", method = RequestMethod.POST)
    @ApiOperation("结束订单的审核")
    public ResponseResult<Boolean> endOrderWorkFlow(@RequestBody @Valid StartOrderWorkFlowDTO dto) {
        return ResponseResult.success("获取成功", orderService.endOrderWorkFlow(dto));
    }

    @RequestMapping(value = "/getOrderInProcess", method = RequestMethod.POST)
    @ApiOperation("获取正在审核的数据")
    public ResponseResult<OrderInProcessVO> getOrderInProcess(@RequestBody @Valid GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", orderService.getOrderInProcess(dto));
    }


    @RequestMapping(value = "/exportOrderWord", method = RequestMethod.POST)
    @ApiOperation("导出采购订单信息--Word")
    public void exportOrderWord(HttpServletResponse response, @Valid @RequestBody QueryDTO dto) {
        orderService.exportOrderWord(response, dto);
    }
}
