package com.vren.material.module.order.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Author GR
 * @Time 2023-04-11-16-58
 **/
@Data
public class EditOrderDetailDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("订单数量")
    @ConversionNumber
    private Long orderQuantity;

    @ApiModelProperty("已生成订单数量")
    @ConversionNumber
    private Long generatedOrderQuantity;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;

    @ApiModelProperty("订单限额")
    @ConversionNumber
    private Long orderLimit;

}
