package com.vren.material.module.projectdemandplan.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class MaterialRemainData {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("余料名称")
    private String remainingMaterialName;

    @ApiModelProperty("余料编号")
    private String remainingMaterialNo;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("余料数量")
    @ConversionNumber
    private Long remainingMaterialCount;

    @ApiModelProperty("附件")
    private String attachmentPath;
}
