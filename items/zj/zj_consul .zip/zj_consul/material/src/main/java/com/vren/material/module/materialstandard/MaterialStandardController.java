package com.vren.material.module.materialstandard;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.materialrenturn.domain.dto.QueryOneDTO;
import com.vren.material.module.materialstandard.domain.dto.GetMaterialStandardDTO;
import com.vren.material.module.materialstandard.domain.dto.MaterialStandardDTO;
import com.vren.material.module.materialstandard.domain.vo.MaterialStandardSelectVO;
import com.vren.material.module.materialstandard.domain.vo.MaterialStandardVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * @author GR
 * time 2023-07-10-10-05
 **/
@RestController
@RequestMapping("/materialStandard")
@Api(tags = {"材料标准件"})
@OperateLog
public class MaterialStandardController {

    @Autowired
    private MaterialStandardService materialStandardService;


    @RequestMapping(value = "/addOrEditMaterialStandard", method = RequestMethod.POST)
    @ApiOperation("新增或编辑材料标准")
    public ResponseResult<Boolean> addOrEditMaterialStandard(@RequestBody @Valid MaterialStandardDTO dto) {
        materialStandardService.addOrEditMaterialStandard(dto);
        return ResponseResult.success("操作成功");
    }

    @RequestMapping(value = "/getMaterialStandard", method = RequestMethod.POST)
    @ApiOperation("查询材料标准列表")
    public ResponseResult<PageResult<MaterialStandardVO>> getMaterialStandard(@RequestBody @Valid GetMaterialStandardDTO dto) {
        return ResponseResult.success("操作成功", materialStandardService.getMaterialStandard(dto));
    }

    @RequestMapping(value = "/getMaterialStandardById", method = RequestMethod.POST)
    @ApiOperation("根据id查询材料标准")
    public ResponseResult<MaterialStandardVO> getMaterialStanardById(@RequestBody @Valid QueryOneDTO dto) {
        return ResponseResult.success("操作成功", materialStandardService.getMaterialStandardById(dto));
    }

    @RequestMapping(value = "/delMaterialStandardById", method = RequestMethod.POST)
    @ApiOperation("删除材料标准")
    public ResponseResult<Boolean> delMaterialStandardById(@RequestBody @Valid QueryOneDTO dto) {
        return ResponseResult.success("操作成功", materialStandardService.delMaterialStandardById(dto));
    }

    @RequestMapping(value = "/getMaterialStandardSelect", method = RequestMethod.POST)
    @ApiOperation("材料标准")
    public ResponseResult<List<MaterialStandardSelectVO>> getMaterialStandardSelect(@RequestBody @Valid GetMaterialStandardDTO dto) {
        return ResponseResult.success("操作成功", materialStandardService.getMaterialStandardSelect(dto));
    }


}
