package com.vren.material.module.materialrenturn.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class QueryOneDTO {

    @NotBlank(message = "id不能为空")
    @ApiModelProperty("id")
    private String id;
}
