package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class WeldingMaterialDemandPlanDelteDTO {
    @ApiModelProperty("焊材需求计划id")
    private String id;
}
