package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import com.vren.common.common.converter.EasyExcelToLongConverter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ContractProductDetailsImportVO {

    @ApiModelProperty("重量")
    @ExcelIgnore
    private Long purchaseWeight;


    @ApiModelProperty("材料名称")
    @ExcelProperty(index = 1)
    private String materialName;


    @ApiModelProperty("厚度")
    @ExcelProperty(index = 2)
    private String thickness;

    @ApiModelProperty("宽度")
    @ExcelProperty(index = 3)
    private String width;

    @ApiModelProperty("长度")
    @ExcelProperty(index = 4)
    private String length;

    @ApiModelProperty("规格")
    @ExcelProperty(index = 5)
    private String size;

    @ApiModelProperty("材质")
    @ExcelProperty(index = 6)
    private String texture;

    @ApiModelProperty("执行标准")
    @ExcelProperty(index = 7)
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    @ExcelProperty(index = 8, value = "单位1")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ExcelProperty(index = 9, value = "数量", converter = EasyExcelToLongConverter.class)
    @ConversionNumber
    private Long purchaseAmountExport;

    @ApiModelProperty("不含税单价")
    @ConversionNumber(value = 10000)
    @ExcelProperty(index = 10, value = "不含税单价", converter = EasyExcelToLongConverter.class)
    private Long preTaxPrice;

    @ApiModelProperty("含税单价")
    @ConversionNumber(value = 10000)
    @ExcelProperty(index = 11, value = "含税单价", converter = EasyExcelToLongConverter.class)
    private Long unitPriceWithTax;


    @ApiModelProperty("单位2")
    @ExcelProperty(index = 12, value = "单位2")
    private String unitTwo;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    @ExcelIgnore
    private Long purchaseAmount;

    @ApiModelProperty("采购重量")
    @ExcelProperty(index = 13, converter = EasyExcelToLongConverter.class)
    @ConversionNumber
    private Long purchaseAmountExportTwo;


    @ApiModelProperty("不含税总价")
    @ConversionNumber
    @ExcelProperty(index = 14, value = "不含税总价", converter = EasyExcelToLongConverter.class)
    private Long totalPriceExcludingTax;

    @ApiModelProperty("含税总价")
    @ConversionNumber
    @ExcelProperty(index = 15, value = "含税总价", converter = EasyExcelToLongConverter.class)
    private Long totalPriceIncludingTax;


    @ApiModelProperty("税额")
    @ExcelIgnore
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("税率")
    @ExcelProperty(index = 16, value = "税率", converter = EasyExcelToLongConverter.class)
    @ConversionNumber
    private Long taxRate;

    @ApiModelProperty("牌号")
    @ExcelProperty(index = 17)
    private String brand;


    @ApiModelProperty("备注")
    @ExcelProperty(index = 18)
    private String remarks;

    @ApiModelProperty("用料类型")
    @ExcelIgnore
    private String ingredientsType;

    @ApiModelProperty("入库编号")
    @ExcelProperty(index = 19)
    private String warehousingNo;


}
