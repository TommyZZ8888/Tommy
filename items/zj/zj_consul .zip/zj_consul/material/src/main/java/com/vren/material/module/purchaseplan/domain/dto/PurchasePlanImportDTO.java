package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author GR
 * time 2023-05-17-13-52
 **/
@Data
public class PurchasePlanImportDTO {

    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;
}
