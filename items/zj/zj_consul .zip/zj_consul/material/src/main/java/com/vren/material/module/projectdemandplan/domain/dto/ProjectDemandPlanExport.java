package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ProjectDemandPlanExport {
    @ApiModelProperty("项目id")
    private String id;
    @ApiModelProperty("计划批次")
    private String projectDemandPlanBatch;
}
