package com.vren.material.module.order.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author GR
 * @time 2023-04-14-10-17
 **/
@Data
public class QueryPurchaseDetailDTO {

    @ApiModelProperty("订单id")
    @NotBlank(message = "订单id不能为空")
    private String id;

    @ApiModelProperty("项目id")
    @NotBlank(message = "项目id不能为空")
    private String projectId;
}
