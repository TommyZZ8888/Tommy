package com.vren.material.module.materialstandard.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-10-10-07
 **/
@Data
@TableName("material_standard")
public class MaterialStandard {

    @ApiModelProperty("材料标准表")
    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    @ApiModelProperty("是否删除")
    @TableField(fill = FieldFill.INSERT)
    private Boolean isDelete;


}
