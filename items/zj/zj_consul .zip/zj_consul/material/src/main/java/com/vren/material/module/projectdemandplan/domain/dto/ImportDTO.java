package com.vren.material.module.projectdemandplan.domain.dto;

import com.alibaba.excel.annotation.ExcelProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-05-11-15-11
 **/
@Data
public class ImportDTO {

    @ApiModelProperty("序号")
    @ExcelProperty(value = "序号", index = 0)
    private String orderNumber;

//    @ApiModelProperty("件号")
//    @ExcelProperty(value = "件号",index = 1)
//    private String partNo;

    @ApiModelProperty("制造编号&件号")
    @ExcelProperty(value = "制造编号&件号", index = 1)
    private String manufacturingNumberPartNo;

    @ApiModelProperty("材料名称")
    @ExcelProperty(value = "材料名称", index = 2)
    private String materialName;

    @ApiModelProperty("规格")
    @ExcelProperty(value = "规格", index = 3)
    private String specification;

    @ApiModelProperty("材质")
    @ExcelProperty(value = "材质", index = 4)
    private String texture;

    @ApiModelProperty("数量")
    @ExcelProperty(value = "数量", index = 5)
    private String count;

    @ApiModelProperty("重量")
    @ExcelProperty(value = "重量", index = 6)
    private String weight;

    @ApiModelProperty("执行标准")
    @ExcelProperty(value = "执行标准", index = 7)
    private String enforceStandards;

    @ApiModelProperty("交货时间")
    @ExcelProperty(value = "交货时间", index = 8)
    private String deliveryTime;

    @ApiModelProperty("交货地点")
    @ExcelProperty(value = "交货地点", index = 9)
    private String deliveryLocation;

    @ApiModelProperty("备件数量")
    @ExcelProperty(value = "备件数量", index = 10)
    private String sparePartsQuantity;

    @ApiModelProperty("备注")
    @ExcelProperty(value = "备注", index = 11)
    private String remarks;

}
