package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @Author GR
 * @Time 2023-04-10-13-50
 **/
@Data
public class OrderVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("订单编号")
    private String orderNumber;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("供应商名称")
    private String supplierName;

    @ApiModelProperty("供应商联系人")
    private String contacts;

    @ApiModelProperty("供应商联系电话")
    private String supplierContactNumber;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资类型")
    private String materialTypeText;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("合同编号")
    private String contractNo;

    @ApiModelProperty("需方")
    private String demander;

    @ApiModelProperty("送货地址")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    private String contactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

    @ApiModelProperty("到货日期")
    private Date arrivalTime;

    @ApiModelProperty("状态（0：正在审核，1：成功，3：失败）")
    private Integer state;

    @ApiModelProperty("状态（0：正在审核，1：通过审核，3：未通过审核）")
    private String stateText;
}
