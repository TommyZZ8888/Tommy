package com.vren.material.module.productmanagement.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author GR
 * time 2023-07-21-14-24
 **/
@Data
public class ExportProductDTO {

    @ApiModelProperty("项目id")
    @NotBlank(message = "项目id不能为空")
    private String projectId;

}
