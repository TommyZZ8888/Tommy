package com.vren.material.module.materialrenturn.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class GenerateReturnRecordDetailDTO {

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("生产公司")
    private String productionCompany;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("退库重量")
    private Long returnWeight;

    @ConversionNumber
    @ApiModelProperty("实领数量")
    private Long actualPickedQuantity;

    @ApiModelProperty("退库数量（编辑项）")
    @ConversionNumber
    private Long returnCount;

    @ApiModelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("颜色")
    private String colour;

    @ApiModelProperty("面积")
    @ConversionNumber
    private Long area;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("型号")
    private String model;

    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;


    @ApiModelProperty("备注（编辑项）")
    private String remarks;

//    @ApiModelProperty("创建时间")
//    private Date createTime;
//
//    @ApiModelProperty("更新时间")
//    private Date updateTime;
//
//    @ApiModelProperty("退库类型")
//    private String returnType;

}
