package com.vren.material.module.purchasecontract.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class StartContractListWorkFlow {

    @ApiModelProperty("keyId")
    private String keyId;

    @ApiModelProperty("结果")
    private String result;

    @ApiModelProperty("是否撤销")
    private String isRevoke;

    @ApiModelProperty("流程code")
    private String instanceCode;

}
