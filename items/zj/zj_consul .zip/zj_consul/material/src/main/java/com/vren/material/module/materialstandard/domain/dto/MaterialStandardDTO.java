package com.vren.material.module.materialstandard.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-10-10-38
 **/
@Data
public class MaterialStandardDTO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

}
