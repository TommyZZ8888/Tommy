package com.vren.material.module.purchasecontract.domain.vo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Description ContractInfoListVO
 * @Author 张卫刚
 * @Date Created on 2023/9/4
 */
@Data
public class ContractInfoListVO {

    private String purchaseContractProjectInfoId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目需求计划编号")
    private String projectDemandPlanNo;

    @ApiModelProperty("采购计划编号")
    private String purchasePlanNo;

    @ApiModelProperty("采购状态（1招标公告、2投标、3定标、4合同签订）")
    private Integer purchaseStatus;

    @ApiModelProperty("采购状态描述")
    private String purchaseStatusText;

    @ApiModelProperty("合同id列表")
    private List<String> contractListIds;

    @ApiModelProperty("项目id列表")
    private List<String> projectIdList;

    private List<ContractInfoVO> contractInfoVOList;

}
