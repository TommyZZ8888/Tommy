package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.projectdemandplan.domain.entity.ProjectDemandPlan;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;


@Mapper
public interface ProjectDemandPlanMapper extends MPJBaseMapper<ProjectDemandPlan> {
    @Select("SELECT id,demand_type FROM  `project_demand_plan`where project_id = #{projectId} and project_demand_plan_batch=#{projectDemandPlanBatch};")
    List<ProjectDemandPlan> getProjectDemandPlanIdList(@Param("projectId") String projectId, @Param("projectDemandPlanBatch") String projectDemandPlanBatch);
}
