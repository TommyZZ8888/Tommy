package com.vren.material.module.purchasecontract;

import com.vren.common.common.anno.OperateLog;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.domain.ResponseResult;
import com.vren.material.module.projectdemandplan.domain.dto.IdDTO;
import com.vren.material.module.purchasecontract.domain.dto.*;
import com.vren.material.module.purchasecontract.domain.vo.*;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.vo.PurchasePlanDetailVO;
import com.vren.material.module.storage.domain.vo.WarehousingMaterialTypeVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

/**
 * @author 耿让
 */
@RestController
@RequestMapping("/purchaseContract")
@Api(tags = {"采购合同清单"})
@OperateLog
public class PurchaseContractController {

    @Autowired
    private PurchaseContractService purchaseContractService;


    @Autowired
    private PurchasePlanService purchasePlanService;


    @RequestMapping(value = "/getProjectInPurchasePlan", method = RequestMethod.POST)
    @ApiOperation("查询采购计划里面所有的项目")
    public ResponseResult<List<ProjectInPurchasePlanVO>> getProjectInPurchasePlan() {
        return ResponseResult.success("操作成功", purchaseContractService.getProjectInPurchasePlan());
    }


    @RequestMapping(value = "/selectPurchaseStatesRecord", method = RequestMethod.POST)
    @ApiOperation("查询合同清单的采购状态变化情况")
    public ResponseResult<List<PurchaseStatusRecordVO>> getPurchaseStatesRecord(@RequestBody GetPurchaseStatusRecordDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getPurchaseStatesRecord(dto));
    }

    /*****************************************项目需求计划需要的接口*************************************************/

    /*************************************入库管理*********************/
    @RequestMapping(value = "/getContractNoAndId", method = RequestMethod.POST)
    @ApiOperation("查询所有的合同编号和id")
    public ResponseResult<List<ContractNoAndIdVO>> getContractNoAndId() {
        return ResponseResult.success("获取成功", purchaseContractService.getContractNoAndId());
    }

    @RequestMapping(value = "/getSupplierAndProject", method = RequestMethod.POST)
    @ApiOperation("根据合同查询供应商和项目信息")
    public ResponseResult<SupplierAndProjectVO> getSupplierAndProject(@RequestBody @Valid GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getSupplierAndProject(dto));
    }

    @RequestMapping(value = "/getPurchasePlanDetail", method = RequestMethod.POST)
    @ApiOperation("选择采购合同，采购计划后后，查询所有的物资详情")
    public ResponseResult<List<PurchasePlanDetailVO>> getPurchasePlanDetail(@RequestBody PurchasePlanDetailDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getPurchasePlanDetail(dto));
    }

    /***************************************入库管理***************************************/

    @RequestMapping(value = "/getPurchasePlanNumberInSelect", method = RequestMethod.POST)
    @ApiOperation("根据选择的项目和物资类型和物资类型回显")
    public ResponseResult<List<PurchasePlanNumberInSelectVO>> getPurchasePlanNumberInSelect(@RequestBody PurchasePlanNumberInSelectDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getPurchasePlanNumberInSelect(dto));
    }

    @RequestMapping(value = "/export", method = RequestMethod.POST)
    @ApiOperation("导出")
    public void export(HttpServletResponse response, @RequestBody ExportDTO dto) throws IOException {
        purchaseContractService.export(response, dto);
    }


    @RequestMapping(value = "/importPurchaseContractDetail", method = RequestMethod.POST)
    @ApiOperation("导入")
    public ResponseResult<Boolean> importPurchaseContractDetail(MultipartFile file, ImportPurchaseContractDetailDTO dto) {
        try {
            purchaseContractService.importPurchaseContractDetail(file, dto);
            return ResponseResult.success("导入成功", true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    /*******************************************供应商管理****************************************/

    @RequestMapping(value = "/getSupplierList", method = RequestMethod.POST)
    @ApiOperation("获取供应商列表数据")
    public ResponseResult<PageResult<SupplierVO>> getSupplierList(@RequestBody SupplierListDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getSupplierList(dto));
    }


    @RequestMapping(value = "/addOrEditSupplier", method = RequestMethod.POST)
    @ApiOperation("新增或编辑供应商")
    public ResponseResult<Boolean> addOrEditSupplier(@RequestBody @Valid UpdateSupplierDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.addOrEditSupplier(dto));
    }

    @RequestMapping(value = "/getSupplierById", method = RequestMethod.POST)
    @ApiOperation("根据id查询供应商信息")
    public ResponseResult<SupplierVO> getSupplierList(@RequestBody @Valid GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getSupplierById(dto));
    }

    @RequestMapping(value = "/deleteSupplier", method = RequestMethod.POST)
    @ApiOperation("删除供应商")
    public ResponseResult<Boolean> deleteSupplier(@RequestBody @Valid GetOneOrDeleteDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.deleteSupplier(dto));
    }


    @RequestMapping(value = "/getSupplierSelectVO", method = RequestMethod.POST)
    @ApiOperation("供应商信息下拉框")
    public ResponseResult<List<SupplierSelectVO>> getSupplierSelectVO() {
        return ResponseResult.success("获取成功", purchaseContractService.getSupplierSelectVO());
    }

    @RequestMapping(value = "/importSupplier", method = RequestMethod.POST)
    @ApiOperation("供应商模板导入")
    public ResponseResult<String> importSupplier(MultipartFile file) {
        try {
            return purchaseContractService.importSupplier(file);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    @RequestMapping(value = "/downloadTemplateFile", method = RequestMethod.POST)
    @ApiOperation("下载模板文件")
    public void downloadTemplateFile(HttpServletResponse response) {
        purchaseContractService.downloadTemplateFile(response);
    }


    /***********************采购合同审核********************************/
    @RequestMapping(value = "/startContractListWorkFlow", method = RequestMethod.POST)
    @ApiOperation("开始合同清单的审核")
    public ResponseResult<Boolean> startContractListWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", purchaseContractService.startContractListWorkFlow(dto));
    }

    @RequestMapping(value = "/updateContractListWorkFlow", method = RequestMethod.POST)
    @ApiOperation("合同清单的审核")
    public ResponseResult<Boolean> updateContractListWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", purchaseContractService.updateContractListWorkFlow(dto));
    }

    @RequestMapping(value = "/endContractListWorkFlow", method = RequestMethod.POST)
    @ApiOperation("结束合同清单的审核")
    public ResponseResult<Boolean> endContractListWorkFlow(@RequestBody @Valid StartContractListWorkFlow dto) {
        return ResponseResult.success("获取成功", purchaseContractService.endContractListWorkFlow(dto));
    }


    @RequestMapping(value = "/getPurchaseContractListDetail", method = RequestMethod.POST)
    @ApiOperation("获取合同详情")
    public ResponseResult<PageResult<ContractProductDetailsExportVO>> getPurchaseContractListDetail(@RequestBody ContractListDetailDTO dto) {
        return ResponseResult.success("获取成功", purchaseContractService.getPurchaseContractListDetail(dto));
    }

    @RequestMapping(value = "/getPaintPurchaseContractListDetail", method = RequestMethod.POST)
    @ApiOperation("获取合同详情--油漆")
    public ResponseResult<PageResult<ContractProductPaintDetailVO>> getPaintPurchasePlanDetails(@RequestBody ContractListDetailDTO dto) {
        return ResponseResult.success("获取成功", purchasePlanService.getPaintPurchaseContractListDetail(dto));
    }


    @RequestMapping(value = "/generateContract", method = RequestMethod.POST)
    @ApiOperation("生成采购合同")
    public ResponseResult<Boolean> generateContract(@RequestBody @Valid GenerateContractDTO dto) {
        purchaseContractService.generateContract(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/deleteContract", method = RequestMethod.POST)
    @ApiOperation("删除采购合同")
    public ResponseResult<Boolean> deleteContract(@RequestBody DeleteContractListDTO dto) {
        purchaseContractService.deleteContract(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiOperation("采购合同列表")
    public ResponseResult<PageResult<ContractInfoListVO>> list(@RequestBody QueryContractListDTO dto) {
        return ResponseResult.success("操作成功", purchaseContractService.list(dto));
    }


    @RequestMapping(value = "/insertContractInfo", method = RequestMethod.POST)
    @ApiOperation("新增或修改采购合同详细")
    public ResponseResult<Boolean> insertContractInfo(@RequestBody @Valid InsertContractInfoDTO dto) {
        purchaseContractService.insertOrUpdateContractInfo(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/getContractInfo", method = RequestMethod.POST)
    @ApiOperation("获取合同信息")
    public ResponseResult<ContractInfoVO> getContractInfo(@RequestBody @Valid IdDTO dto) {
        return ResponseResult.success("操作成功", purchaseContractService.selectContractInfo(dto));
    }


    @RequestMapping(value = "/deleteContractInfo", method = RequestMethod.POST)
    @ApiOperation("删除采购合同详细")
    public ResponseResult<Boolean> deleteContractInfo(@RequestBody @Valid DeleteContractInfoDTO dto) {
        purchaseContractService.deleteContractInfo(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/deleteContractProductInfo", method = RequestMethod.POST)
    @ApiOperation("删除采购合同详细--采购计划明细")
    public ResponseResult<Boolean> deleteContractProductInfo(@RequestBody @Valid DeleteContractProductInfoDTO dto) {
        purchasePlanService.deleteContractProductInfo(dto);
        return ResponseResult.success("操作成功");
    }


    @RequestMapping(value = "/getContractMaterialType", method = RequestMethod.POST)
    @ApiOperation("获取合同物资类型下拉框")
    public ResponseResult<List<WarehousingMaterialTypeVO>> getContractMaterialType() {
        return ResponseResult.success("获取成功", purchaseContractService.getContractMaterialType());
    }
}
