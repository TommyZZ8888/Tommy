package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

@Data
public class ProjectDataVO {
    @ApiModelProperty("id")
    private String id;
    @ApiModelProperty("查询项目id")
    private String searchId;
    @ApiModelProperty("项目编号")
    private String projectNo;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("项目类型")
    private String projectType;

    @ApiModelProperty("客户名称")
    private String customerName;

    @ApiModelProperty("项目需求计划批次,例如 第一批次")
    private String projectDemandPlanBatch;
   private List<ProjectDemandPlanVO> list;

    @ApiModelProperty("产品需求计划编号")
    private String productDemandScheduleNo;
}
