package com.vren.material.module.productdemandplan.handler;

import com.vren.common.common.utils.BeanUtil;
import com.vren.common.common.utils.CommonUtil;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @author 耿让
 */
@Component
public class Drum implements ComputerHandler {
    @Override
    public ProductDemandPlanDetails execution(InsertDetailDTO data) {
        DecimalFormat decimalFormat = new DecimalFormat("###################.###########");
        if (CommonUtil.isNull(data.getFirstSize()) || CommonUtil.isNull(data.getSecondSize()) || CommonUtil.isNull(data.getThirdSize())) {
            throw new RuntimeException(data.getMaterialName() + "的第一尺寸、第二尺寸和第三尺寸不能为空");
        }
        //IF(E28="卷筒",PI()*((F28+2*G28)^2-F28^2)/4*H28*J28/1000000*C28,
        double result = Math.PI * (Math.pow((data.getFirstSize().doubleValue() / 100) + (2 * data.getSecondSize().doubleValue() / 100), 2) - Math.pow(data.getFirstSize().doubleValue() / 100, 2)) / 4 * (data.getThirdSize().doubleValue() / 100) * (data.getProportion().doubleValue() / 100) / 1000000 * data.getCount().doubleValue() / 100;
        String specification = "δ" + decimalFormat.format(data.getSecondSize().doubleValue() / 100) + "X" + decimalFormat.format(data.getThirdSize().doubleValue() / 100) + "X" + decimalFormat.format((int) Math.floor(data.getFirstSize().doubleValue() / 100 * 3.1416 + data.getSecondSize().doubleValue() / 100 * 3.1416 + 1));

        ProductDemandPlanDetails productDemandPlanDetails = BeanUtil.copy(data, ProductDemandPlanDetails.class);
        productDemandPlanDetails.setSpecification(specification);
        if (result < 0) {
            throw new RuntimeException("您输入的尺寸有误！");
        }
        productDemandPlanDetails.setWeight((long) (result * 100));
        return productDemandPlanDetails;
    }

    @Override
    public void analysis(ProductDemandPlanTotalExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("X"));
            String thirdSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            String firstSize = specification.substring(specification.lastIndexOf("X") + 1);
            vo.setFirstSize(String.valueOf((Double.parseDouble(firstSize) - 1 - Double.parseDouble(secondSize) * 3.1416) / 3.1416));
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void analysis(ProfileExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("X"));
            String thirdSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            String firstSize = specification.substring(specification.lastIndexOf("X") + 1);
            vo.setFirstSize(String.valueOf((Double.parseDouble(firstSize) - 1 - Double.parseDouble(secondSize) * 3.1416) / 3.1416));
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void analysis(ProjectDemandPlanExportVO vo) {
        String specification = vo.getSpecification();
        if (specification != null && !vo.getIsCalculate()) {
            String secondSize = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("X"));
            String thirdSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            String firstSize = specification.substring(specification.lastIndexOf("X") + 1);
            vo.setFirstSize(String.valueOf((Double.parseDouble(firstSize) - 1 - Double.parseDouble(secondSize) * 3.1416) / 3.1416));
            vo.setSecondSize(secondSize);
            vo.setThirdSize(thirdSize);
        }
    }

    @Override
    public void execution(BoardImportDTO data) {
        //厚度是规格中的  第二尺寸   宽度是规格中的  第三尺寸   长度是规格中的  第一尺寸*3.1416+第二尺寸*3.1416+1（结果向下取整）
        //第一尺寸=（长度-1-厚度*3.1416）/3.1416

        //卷筒的计算    圆周率*（（第一尺寸+2*第二尺寸）^2-第一尺寸^2）/4*第三尺寸*比重/1000000*数量
        // 规格为：δ第二尺寸X第三尺寸X第一尺寸*3.1416+第二尺寸*3.1416+1（结果向下取整）
        //重量计算： 圆周率*（（（长度-1-厚度*3.1416）/3.1416 + 2*厚度）^2-（长度-1-厚度*3.1416）/3.1416 ^2）/4*宽度*比重/1000000*数量
        //规格   δ厚度X宽度X长度

        //将厚度、长度、宽度、数量和比重都转为Double，没有倍数转换 ;  没有数据的就按照0.0算呗
        double thickness = !CommonUtil.isNull(data.getThickness()) ? Double.parseDouble(data.getThickness()) : 0.0;
        double length = !CommonUtil.isNull(data.getLength()) ? Double.parseDouble(data.getLength()) : 0.0;
        double width = !CommonUtil.isNull(data.getWidth()) ? Double.parseDouble(data.getWidth()) : 0.0;
        double proportion = !CommonUtil.isNull(data.getProportion()) ? Double.parseDouble(data.getProportion()) : 0.0;
        double count = !CommonUtil.isNull(data.getCount()) ? Double.parseDouble(data.getCount()) : 0.0;

        //第一尺寸
        double firstSize = (length - 1 - thickness * 3.1416) / 3.1416;
        //计算重量
        double weight = (Math.pow(firstSize + 2 * thickness, 2) - Math.pow(firstSize, 2)) / 4 * width * proportion / 1000000 * count;
        String specification = "δ" + NumberConvertUtil.doubleToString(thickness) + "X" + NumberConvertUtil.doubleToString(width) + "X" + NumberConvertUtil.doubleToString(length);

        //设置重量和规格
        data.setWeight((long) (weight * 100));
        data.setSpecification(specification);
    }

    @Override
    public Map<String, String> analysis(String specification, String ingredientsType) {
        HashMap<String, String> map = new HashMap<>();
        if (specification != null) {
            String thickness = specification.substring(specification.indexOf("δ") + 1, specification.indexOf("X"));
            String length = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
            String width = specification.substring(specification.lastIndexOf("X") + 1);
            map.put("width", width);
            map.put("length", length);
            map.put("thickness", thickness);
        }
        return map;
    }
}
