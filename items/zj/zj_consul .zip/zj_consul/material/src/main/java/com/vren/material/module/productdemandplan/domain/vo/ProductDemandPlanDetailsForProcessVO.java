package com.vren.material.module.productdemandplan.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 *  有接口调用
 */
@Data
public class ProductDemandPlanDetailsForProcessVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("产品需求计划id")
    private String productDemandPlanId;


    @ApiModelProperty("产品ID")
    private String productInformationId;

    @ApiModelProperty("图号")
    private String figureNo;


    @ApiModelProperty("件号")
    private String partNo;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("物资类型")
    private String materialType;

    @ApiModelProperty("用料单位（就是单位）：从物资类型表中查询获得")
    private String useMaterialUnit;


    @ApiModelProperty("材质")
    private String material;

    @ApiModelProperty("比重")
    @ConversionNumber
    private Long proportion;

    @ApiModelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;

    @ApiModelProperty("第一尺寸String")
    private String firstSizeString;

    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("第四尺寸/外购标准")
    private String fourthSizeOutsourcingStandards;

    @ApiModelProperty("规格：(由第一、第二、第三、第四尺寸计算而来)")
    private String specification;

    @ApiModelProperty("执行标准")
    private String enforceStandards;

    /**
     * 不能小于0
     */
    @ApiModelProperty("备件数量")
    private Long sparePartsQuantity;



    @ApiModelProperty("重量")
    @ConversionNumber
    private Long weight;

    @ApiModelProperty("数量")
    @ConversionNumber
    private Long count;


    @ApiModelProperty("标书价")
    @ConversionNumber
    private Long demandProposalPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("规格：工艺导出")
    private String specificationText;

    @ApiModelProperty("备注，工艺导出使用")
    private String remarkText;

    @ApiModelProperty("是否需要进行计算")
    private Boolean isCalculate;

}
