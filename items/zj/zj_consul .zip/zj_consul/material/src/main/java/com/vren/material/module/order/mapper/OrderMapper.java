package com.vren.material.module.order.mapper;

import com.github.yulichang.base.MPJBaseMapper;
import com.vren.material.module.order.domain.entity.Order;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 耿让
 */
@Mapper
public interface OrderMapper extends MPJBaseMapper<Order> {

}
