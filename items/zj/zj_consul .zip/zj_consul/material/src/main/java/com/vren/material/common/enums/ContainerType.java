package com.vren.material.common.enums;

/**
 * @author 耿让
 * 容器类别
 */

public enum ContainerType {
    TYPE_ONE(1, "Ⅰ类"),
    TYPE_TWO(2, "Ⅱ类"),
    TYPE_THREE(3, "Ⅲ类"),
    ASME(4, "ASME"),
    ASME_U(5, "ASME U"),
    CONSTANT_PRESSURE(6, "常压"),
    EXTRACLASS(7, "类外"),
    INTERNAL_PRESSURE(8, "内压"),
    EXTERNA_PRESSURE(9, "外压");

    ContainerType(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
