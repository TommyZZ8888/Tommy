package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class WarehousingNoDTO {

    @ApiModelProperty("入库编号")
    @NotBlank(message = "入库编号不能为空")
    private String warehousingNo;

}
