package com.vren.material.module.order.domain.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @author 耿让
 */
@Data
@TableName("t_order")
public class Order {

    @TableId(type = IdType.ASSIGN_UUID)
    private String id;

    @ApiModelProperty("订单编号")
    private String orderNumber;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("合同清单id")
    private String contractListId;

    @ApiModelProperty("需方")
    private String demander;

    @ApiModelProperty("送货地址")
    private String deliveryAddress;

    @ApiModelProperty("收货联系人")
    private String receivingContact;

    @ApiModelProperty("联系电话")
    private String contactNumber;

    @ApiModelProperty("订单内容")
    private String orderContent;

    @ApiModelProperty("附件")
    private String attachment;

    @ApiModelProperty("状态（0：正在审核，1：成功，2：失败）")
    private Integer state;

    @ApiModelProperty("流程code")
    private String instanceCode;

    @ApiModelProperty("创建时间")
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;

    @ApiModelProperty("更新时间")
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    @ApiModelProperty("到货日期")
    private Date arrivalTime;

    @ApiModelProperty("合同编号")
    private String contractNo;

}
