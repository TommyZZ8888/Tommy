package com.vren.material.module.order.domain.dto;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @Author GR
 * @Time 2023-04-10-14-44
 **/
@Data
public class OrderDetailDTO {

    @ApiModelProperty("采购计划详情id")
    @NotBlank(message = "采购计划详情id不能为空")
    private String purchasePlanDetailId;

    @ApiModelProperty("订单数量")
    @ConversionNumber
    private Long orderQuantity;

    @ApiModelProperty("已生成订单数量")
    @ConversionNumber
    private Long generatedOrderQuantity;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    private Long purchaseAmount;

    @ApiModelProperty("订单限额")
    @ConversionNumber
    private Long orderLimit;

    @ApiModelProperty("批次")
    private String batch;

    @ApiModelProperty("项目id")
    private String projectId;

}
