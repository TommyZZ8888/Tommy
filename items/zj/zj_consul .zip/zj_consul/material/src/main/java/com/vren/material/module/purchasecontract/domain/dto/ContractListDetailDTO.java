package com.vren.material.module.purchasecontract.domain.dto;

import com.vren.common.common.domain.PageParam;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author GR
 * time 2023-07-31-15-12
 **/
@Data
public class ContractListDetailDTO extends PageParam {

    @ApiModelProperty("合同id")
    private String contractListId;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    private String materialName;

}
