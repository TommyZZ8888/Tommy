package com.vren.material.module.projectdemandplan;

import com.alibaba.excel.write.handler.WriteHandler;
import com.alibaba.excel.write.metadata.fill.FillWrapper;
import com.alibaba.excel.write.metadata.style.WriteCellStyle;
import com.alibaba.excel.write.style.HorizontalCellStyleStrategy;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.github.yulichang.wrapper.MPJLambdaWrapper;
import com.vren.common.common.domain.PageResult;
import com.vren.common.common.exception.ErrorException;
import com.vren.common.common.utils.*;
import com.vren.common.common.utils.easyexcel.CustomSheetWriteHandler;
import com.vren.common.common.utils.easyexcel.ExcelExportService;
import com.vren.common.common.utils.easyexcel.ExcelUtil;
import com.vren.common.common.utils.easyexcel.MyMergeHandler;
import com.vren.common.module.identity.user.UserService;
import com.vren.common.module.identity.user.domain.entity.UserInfoEntity;
import com.vren.common.module.project.ProjectService;
import com.vren.common.module.project.domain.dto.ProjectDemandQueryDTO;
import com.vren.common.module.project.domain.entity.ProjectVO;
import com.vren.common.module.project.domain.entity.ProjectViewVO;
import com.vren.material.common.converter.ChineseComparator;
import com.vren.material.common.utils.NumberConvertUtil;
import com.vren.material.module.materialremain.MaterialRemainService;
import com.vren.material.module.productdemandplan.ProductDemandPlanDetailsMapper;
import com.vren.material.module.productdemandplan.ProductDemandPlanService;
import com.vren.material.module.productdemandplan.domain.dto.EditTimeAndLocationDTO;
import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlan;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.productdemandplan.domain.enums.ComputerType;
import com.vren.material.module.productdemandplan.domain.vo.ProductDemandSelectVO;
import com.vren.material.module.productdemandplan.domain.vo.RemarkVO;
import com.vren.material.module.productdemandplan.handler.ComputerHandler;
import com.vren.material.module.productdemandplan.mapper.ProductDemandPlanMapper;
import com.vren.material.module.productmanagement.ProductManageService;
import com.vren.material.module.productmanagement.domain.dto.DeleteOrGetOneDTO;
import com.vren.material.module.productmanagement.domain.entity.ProductInformation;
import com.vren.material.module.projectdemandplan.domain.dto.*;
import com.vren.material.module.projectdemandplan.domain.entity.*;
import com.vren.material.module.projectdemandplan.domain.enums.DemandType;
import com.vren.material.module.projectdemandplan.domain.enums.MaterialType;
import com.vren.material.module.projectdemandplan.domain.vo.*;
import com.vren.material.module.projectdemandplan.mapper.*;
import com.vren.material.module.purchaseplan.PurchasePlanService;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlan;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsPaint;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsProductTotal;
import com.vren.material.module.purchaseplan.domain.entity.PurchasePlanDetailsWeldingMaterials;
import com.vren.material.module.purchaseplan.domain.vo.ProjectNameInDemandPlanVO;
import com.vren.material.module.purchaseplan.mapper.PurchasePlanMapper;
import com.vren.material.module.stockmanagement.StockManagementService;
import com.vren.material.module.stockmanagement.domian.entity.MaterialStock;
import com.vren.material.module.stockmanagement.domian.vo.MaterialStockVO;
import com.vren.material.module.stocktransfer.StockTransferService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * @author 耿让
 */
@Slf4j
@Service
public class ProjectDemandPlanService {

    @Autowired
    private StockTransferService stockTransferService;

    @Autowired
    private ProjectService projectService;

    @Autowired
    private ProjectDemandPlanMapper projectDemandPlanMapper;

    @Autowired
    private MaterialTypeDescriptionMapper materialTypeDescriptionMapper;

    @Autowired
    private ProductDemandPlanService productDemandPlanService;

    @Autowired
    private ProductDemandPlanTotalMapper productDemandPlanTotalMapper;

    @Autowired
    private ProductManageService productManageService;

    @Autowired
    private ProductDemandPlanDetailsMapper productDemandPlanDetailsMapper;

    @Autowired
    private PaintDemandPlanMapper paintDemandPlanMapper;

    @Autowired
    private WeldingMaterialsDemandPlanMapper weldingMaterialsDemandPlanMapper;

    @Autowired
    private ProductDemandPlanMapper productDemandPlanMapper;

    @Autowired
    private StockManagementService stockManagementService;

    @Autowired
    private LockStockMapper lockStockMapper;

    @Autowired
    private MaterialRemainService materialRemainService;

    @Autowired
    private UserService userService;

    @Autowired
    private PurchasePlanMapper purchasePlanMapper;

    @Autowired
    private ChineseComparator chineseComparator;

    @Autowired
    private PurchasePlanService purchasePlanService;


    public void updateByProjectDemandPlan(ProjectDemandPlan projectDemandPlan) {
        projectDemandPlanMapper.updateById(projectDemandPlan);
    }


    /**
     * 根据项目id和物资类型查询项目需求计划
     * @param projectId
     * @param demandType
     * @return
     */
    public ProjectDemandPlan selectByProjectIdAndDemandType(String projectId, Integer demandType, String batch) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, projectId)
                .eq(ProjectDemandPlan::getDemandType, demandType)
                .eq(ProjectDemandPlan::getProjectDemandPlanBatch, batch);
        return projectDemandPlanMapper.selectOne(wrapper);
    }


    /**
     * 根据项目id 查询项目需求计划
     * @param projectId
     * @return
     */
    public List<ProjectDemandPlan> selectByProjectId(String projectId, String batch) {
        //2023/03/02 根据项目id和批次查询项目需求计划 ， projectId 的格式为： projectId-批次
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(!CommonUtil.isNull(projectId), ProjectDemandPlan::getProjectId, projectId)
                .eq(!CommonUtil.isNull(batch), ProjectDemandPlan::getProjectDemandPlanBatch, batch);
        return projectDemandPlanMapper.selectList(wrapper);
    }

    /**
     * 根据项目需求计划查询产品需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<ProductDemandPlanTotal> selectProductDemandByProjectDemandPlanId(String projectDemandPlanId) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId), ProductDemandPlanTotal::getProjectDemandPlanId, projectDemandPlanId);
        return productDemandPlanTotalMapper.selectList(wrapper);
    }

    /**
     * 根据项目需求计划id查询焊材需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<WeldingMaterialDemandPlan> selectWeldByProjectDemandPlanId(String projectDemandPlanId) {
        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId), PaintDemandPlan::getProjectDemandPlanId, projectDemandPlanId);
        return weldingMaterialsDemandPlanMapper.selectList(wrapper);
    }

    /**
     * 根据项目需求计划id查询油漆需求计划
     * @param projectDemandPlanId
     * @return
     */
    public List<PaintDemandPlan> selectPaintByProjectDemandPlanId(String projectDemandPlanId) {
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(!CommonUtil.isNull(projectDemandPlanId), PaintDemandPlan::getProjectDemandPlanId, projectDemandPlanId);
        return paintDemandPlanMapper.selectList(wrapper);
    }

    /**
     * 根据id查询项目需求计划
     * @param id
     * @return
     */
    public ProjectDemandPlan selectOneById(String id) {
        return projectDemandPlanMapper.selectById(id);
    }

    /**
     * 计算采购总数
     * @param ids
     * @return
     */
    public HashMap<String, PurchaseCount> purchaseCount(List<String> ids) {
        HashMap<String, PurchaseCount> map = new HashMap<>();

        //产品采购总数、焊材采购总数、油漆采购总数
        //查询产品计划汇总表：库存数量、数量、重量、物资类型
        //计算结果新增到对应的子表中
        /**
         * 采购汇总
         *  采购数量累加起来
         *  采购重量累加起来
         * 对于焊材，只有重量，没有数量这一说法
         */
        MPJLambdaWrapper<ProductDemandPlanTotal> totalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        totalMPJLambdaWrapper.select(ProductDemandPlanTotal::getStockAmount, ProductDemandPlanTotal::getCount, ProductDemandPlanTotal::getWeight, ProductDemandPlanTotal::getMaterialType, ProductDemandPlanTotal::getBidPrice)
                .in(ProductDemandPlanTotal::getProjectDemandPlanId, ids);
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(totalMPJLambdaWrapper);

        //根据物资类型，计算采购数量和重量   采购数量=需求数量-锁库数量
        //根据物资类型分类
        Map<Integer, List<ProductDemandPlanTotal>> collect = productDemandPlanTotals.stream().collect(Collectors.groupingBy(ProductDemandPlanTotal::getMaterialType));
        for (Integer item : collect.keySet()) {
            Integer purchaseNum = 0;
            Long purchaseWeight = 0L;
            List<ProductDemandPlanTotal> planTotals = collect.get(item);
            for (ProductDemandPlanTotal i : planTotals) {
                //数量减去库存数量  =   采购数量
                if (!CommonUtil.isNull(i.getCount()) && !CommonUtil.isNull(i.getStockAmount())) {
                    purchaseNum += Math.toIntExact((i.getCount() - i.getStockAmount()));
                    if (i.getCount() > 0) {
                        purchaseWeight += i.getWeight() * (purchaseNum / i.getCount());
                    }
                }
            }
            //根据类型存放到map中
            if (purchaseNum > 0) {
                PurchaseCount purchaseCount = PurchaseCount.builder().purchaseNum(purchaseNum).purchaseWeight(purchaseWeight).build();
                map.put(EnumUtil.getValue(MaterialType.class, item), purchaseCount);
            } else {
                //如果采购数量小于0，不需要采购
                map.put(EnumUtil.getValue(MaterialType.class, item), PurchaseCount.builder().purchaseNum(0).purchaseWeight(0L).build());
            }
        }
        //查询焊材需求计划，计算采购重量
        MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingWrapper = new MPJLambdaWrapper<>();
        weldingWrapper.select(WeldingMaterialDemandPlan::getStockAmount, WeldingMaterialDemandPlan::getCount, WeldingMaterialDemandPlan::getWeight, WeldingMaterialDemandPlan::getBidPrice)
                .in(WeldingMaterialDemandPlan::getProjectDemandPlanId, ids);
        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(weldingWrapper);
        Long weldPurchaseWeight = 0L;
        for (WeldingMaterialDemandPlan item : weldingMaterialDemandPlans) {
            //数量减去库存数量  =   采购数量
            weldPurchaseWeight += item.getWeight() - item.getStockAmount();
        }
        if (weldPurchaseWeight > 0) {
            PurchaseCount weldPurchaseCount = PurchaseCount.builder().purchaseWeight(weldPurchaseWeight).build();
            map.put("焊材", weldPurchaseCount);
        } else {
            map.put("焊材", PurchaseCount.builder().purchaseWeight(0L).build());
        }

        //查询油漆需求计划，计算采购数量和采购重量;数量单位是桶
        MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
        paintWrapper.select(PaintDemandPlan::getStockAmount, PaintDemandPlan::getCount, PaintDemandPlan::getBidPrice)
                .in(PaintDemandPlan::getProjectDemandPlanId, ids);
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
        Integer paintPurchaseNum = 0;
        for (PaintDemandPlan item : paintDemandPlans) {
            //数量减去库存数量  =   采购数量
            if (!CommonUtil.isNull(item.getCount()) && !CommonUtil.isNull(item.getStockAmount())) {
                paintPurchaseNum += Math.toIntExact((item.getCount() - item.getStockAmount()));
            }
        }
        if (paintPurchaseNum > 0) {
            PurchaseCount paintPurchaseCount = PurchaseCount.builder().purchaseNum(paintPurchaseNum).build();
            map.put("油漆", paintPurchaseCount);
        } else {
            PurchaseCount paintPurchaseCount = PurchaseCount.builder().purchaseNum(0).build();
            map.put("油漆", paintPurchaseCount);
        }
        return map;
    }

    /**
     * 根据项目需求id 查询项目名称
     * @param id
     * @return
     */
    public String selectProjectNameByDemandPlanId(String id) {
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(id);
        return projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
    }


    public PageResult<ProjectDataVO> getDataList(ProjectDemandQueryDTO dto) {
        List<ProjectViewVO> projectViewVOS = projectService.queryDataList(dto);
        List<ProjectDataVO> projectDataVOS = BeanUtil.copyList(projectViewVOS, ProjectDataVO.class);
        List<ProjectDataVO> projectDatalist = new ArrayList<>();
        Map<String, List<ProjectDemandPlan>> listMap = projectDemandPlanMapper.selectList(null).stream().collect(Collectors.groupingBy(ProjectDemandPlan::getProjectId));

        for (ProjectDataVO projectDataVO : projectDataVOS) {
            List<ProjectDemandPlan> projectDemandPlans = listMap.get(projectDataVO.getId());
            List<ProjectDemandPlanVO> projectDemandPlanVOS = BeanUtil.copyList(projectDemandPlans, ProjectDemandPlanVO.class);

            DeleteOrGetOneDTO deleteOrGetOneDTO = new DeleteOrGetOneDTO();
            deleteOrGetOneDTO.setId(projectDataVO.getId());
            List<ProductDemandSelectVO> productDemandSelect = productDemandPlanService.getProductDemandSelect(deleteOrGetOneDTO);
            Map<String, String> idStringMap = productDemandSelect.stream().collect(Collectors.toMap(ProductDemandSelectVO::getId, ProductDemandSelectVO::getValue));
            List<ProjectDemandPlanVO> collect = projectDemandPlanVOS.stream().peek(item -> {
                item.setDemandTypeText(EnumUtil.getValue(DemandType.class, item.getDemandType()));
                if (!CommonUtil.isNull(item.getCompiler())) {
                    item.setCompiler(userService.getUserInfoByID(item.getCompiler()).getCHName());
                }
                if (StringUtils.isNotBlank(item.getIdListString())) {
                    String replace = item.getIdListString().replace("[", "").replace("]", "");
                    String[] idStringList = replace.split(",");
                    item.setIdList(idStringList);
                    String[] idList = new String[idStringList.length];
                    for (int i = 0; i < idStringList.length; i++) {
                        String productNo = idStringMap.get(idStringList[i]);
                        if (StringUtils.isNotBlank(productNo)) {
                            idList[i] = productNo;
                        }
                    }
                    List<String> collect1 = Arrays.stream(idList).filter(StringUtils::isNotBlank).collect(Collectors.toList());
                    String[] strings = collect1.toArray(new String[0]);
                    item.setIdListArr(strings);
                }
            }).collect(Collectors.toList());
            Map<String, List<ProjectDemandPlanVO>> map = collect.stream().collect(Collectors.groupingBy(ProjectDemandPlanVO::getProjectDemandPlanBatch));
            for (String s : map.keySet()) {
                //list循环add注意事项
                ProjectDataVO result = new ProjectDataVO();
                projectDataVO.setProjectDemandPlanBatch(s);
                List<ProjectDemandPlan> demandList = listMap.get(projectDataVO.getId()).stream().filter(item -> s.equals(item.getProjectDemandPlanBatch())).collect(Collectors.toList());
                if (CommonUtil.listIsNotEmpty(demandList)) {
                    List<ProjectDemandPlan> demandPlans = demandList.stream().filter(item -> !CommonUtil.isNull(item.getIdListString())).collect(Collectors.toList());
                    if (CommonUtil.listIsNotEmpty(demandPlans)) {
                        String idListString = demandPlans.get(0).getIdListString();

                        ArrayList<String> arrayList = new ArrayList<>();
                        if (idListString.length() > 45) {
                            String[] split = idListString.substring(1, idListString.length() - 1).split(",");
                            arrayList.addAll(List.of(split));
                        } else {
                            arrayList.add(idListString.substring(1, idListString.length() - 1));
                        }

                        List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectBatchIds(arrayList);
                        //获得制造编号+在件号上面
                        String scheduleNo = "";
                        for (ProductDemandPlan productDemandPlan : productDemandPlans) {
                            scheduleNo = scheduleNo + productDemandPlan.getScheduleNo() + ",";
                        }
                        if (scheduleNo.length() > 0) {
                            projectDataVO.setProductDemandScheduleNo(scheduleNo.substring(0, scheduleNo.length() - 1));
                        }
                    } else {
                        projectDataVO.setProductDemandScheduleNo("");
                    }
                }
                List<ProjectDemandPlanVO> demandPlanVOS = map.get(s);
                demandPlanVOS.forEach(item -> {
                    String[] arr = CommonUtil.isNull(item.getIdList()) ? new String[0] : item.getIdList();
                    List<String> idArr = new ArrayList<>();
                    for (String id : arr) {
                        ProductDemandPlan productDemandPlan = productDemandPlanService.selectById(id);
                        if (CommonUtil.isNull(productDemandPlan)) {
                            continue;
                        }
                        ProductInformation productInformation = productManageService.selectById(Optional.ofNullable(productDemandPlan).orElse(new ProductDemandPlan()).getProductInformationId());
                        String s1 = productInformation.getProductName() + "_" + productDemandPlan.getBatch() + "_" + (productDemandPlan.getNumber() / 100);
                        idArr.add(s1);
                    }
                    String[] objects = idArr.toArray(new String[0]);
                    item.setIdListArr(objects);
                });
                projectDataVO.setList(map.get(s));
                projectDataVO.setSearchId(s + projectDataVO.getId());
                BeanUtils.copyProperties(projectDataVO, result);
                projectDatalist.add(result);
            }
        }
        List<ProjectDataVO> collect = projectDatalist.stream().filter(projectDataVO -> projectDataVO.getList().size() > 0).collect(Collectors.toList());

        collect.sort(((o1, o2) -> {
            if (!CommonUtil.isNull(o1.getProjectName()) && !CommonUtil.isNull(o2.getProjectName())) {
                if (o1.getProjectName().equals(o2.getProjectName())) {
                    //材质的原先位置
                    /**/
                    if (!CommonUtil.isNull(o1.getProjectDemandPlanBatch()) && !CommonUtil.isNull(o2.getProjectDemandPlanBatch())) {
                        int a = Integer.parseInt(o1.getProjectDemandPlanBatch().substring(1, o1.getProjectDemandPlanBatch().length() - 2));
                        int b = Integer.parseInt(o2.getProjectDemandPlanBatch().substring(1, o2.getProjectDemandPlanBatch().length() - 2));
                        return a - b;
                    }
                    if (!CommonUtil.isNull(o1.getProjectDemandPlanBatch())) {
                        return 1;
                    }
                    if (!CommonUtil.isNull(o2.getProjectDemandPlanBatch())) {
                        return -1;
                    }
                    return 0;
                } else {
                    return o1.getProjectName().compareTo(o2.getProjectName());
                }
            }
            if (CommonUtil.isNull(o1.getProjectName())) {
                return 1;
            }
            if (CommonUtil.isNull(o2.getProjectName())) {
                return -1;
            }
            return 0;
        }));
        return PageUtil.convert2PageResult(collect, dto);
    }


    public List<ProjectNameDataVO> getProjectName(ProjectDemandQueryDTO dto) {
        List<ProjectViewVO> projectViewVOS = projectService.queryDataList(dto);
        ArrayList<ProjectNameDataVO> list = new ArrayList<>();
        for (ProjectViewVO projectViewVO : projectViewVOS) {
            ProjectNameDataVO projectNameDataVO = new ProjectNameDataVO();
            projectNameDataVO.setProjectId(projectViewVO.getId());
            projectNameDataVO.setProjectName(projectViewVO.getProjectName());
            list.add(projectNameDataVO);
        }
        return list;
    }


    public List<DemandTypeVO> getDemandType() {
        ArrayList<DemandTypeVO> list = new ArrayList<>();
        for (DemandType statue : DemandType.values()) {
            DemandTypeVO responsibilityTypeVO = new DemandTypeVO();
            responsibilityTypeVO.setCode(statue.getCode());
            responsibilityTypeVO.setValue(statue.getName());
            list.add(responsibilityTypeVO);
        }
        return list;
    }


    @Transactional(rollbackFor = Exception.class)
    public void addOrEditProjectDemandPlan(ProjectDemandPlanUpdateDTO dto) {
        if (CommonUtil.isNull(dto.getId())) {
            MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(ProjectDemandPlan.class)
                    .eq(!CommonUtil.isNull(dto.getProjectId()), ProjectDemandPlan::getProjectId, dto.getProjectId())
                    .eq(ProjectDemandPlan::getDemandType, dto.getDemandType())
                    .eq(ProjectDemandPlan::getProjectDemandPlanBatch, dto.getProjectDemandPlanBatch());
            List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);

            if (CommonUtil.listIsNotEmpty(projectDemandPlans)) {
                throw new ErrorException("需求类型已存在,不能新增");
            }
            switch (dto.getDemandType()) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    QueryWrapper<ProjectDemandPlan> totalWrapper = new QueryWrapper<>();
                    totalWrapper.select("1").eq(!CommonUtil.isNull(dto.getPlanNo()), "plan_no", dto.getPlanNo()).last("limit 1");
                    if (projectDemandPlanMapper.selectCount(totalWrapper) > 0) {
                        throw new ErrorException("计划编号已存在");
                    }
                    break;

                default:
                    break;
            }
            String materialTypeValue = EnumUtil.getValue(DemandType.class, dto.getDemandType());
            if (!CommonUtil.isNull(dto.getIdList()) && dto.getIdList().length > 0) {
                String materialTypeText = EnumUtil.getValue(DemandType.class, dto.getDemandType());
                QueryWrapper<ProductDemandPlanDetails> mpjLambdaWrapper = new QueryWrapper<>();
                mpjLambdaWrapper.in("product_demand_plan_id", dto.getIdList())
                        .eq("material_type", materialTypeText);
                List<ProductDemandPlanDetails> productDemandPlanDetailsList = productDemandPlanDetailsMapper.selectList(mpjLambdaWrapper);

                List<ProductDemandPlanDetails> demandPlanDetailsList = productDemandPlanDetailsList.stream().filter(item -> CommonUtil.isNull(item.getProjectDemandPlanId())).collect(Collectors.toList());
                List<ProjectDemandPlanGenerateVO> generateVOList = BeanUtil.copyList(demandPlanDetailsList, ProjectDemandPlanGenerateVO.class);
                List<ProjectDemandPlanGenerateVO> projectDemandPlanGenerateVOS = generateVOList.stream().filter(item -> !"组合件".equals(item.getMaterial())).peek(item -> {
                    String manufacturingNumber = productDemandPlanMapper.selectById(item.getProductDemandPlanId()).getManufacturingNumber();
                    item.setManufacturingNumberPartNo(manufacturingNumber + "/" + item.getPartNo());
                }).collect(Collectors.toList());

                MPJLambdaWrapper<ProductDemandPlanDetails> lambdaWrapper = new MPJLambdaWrapper<>();
                lambdaWrapper.selectAll(ProductDemandPlanDetails.class)
                        .selectAll(ProductDemandPlan.class)
                        .leftJoin(ProductDemandPlan.class, ProductDemandPlan::getId, ProductDemandPlanDetails::getProductDemandPlanId)
                        .in(ProductDemandPlan::getId, dto.getIdList())
                        .eq(ProductDemandPlanDetails::getMaterialType, materialTypeText);
                List<ProductDemandPlanDetails> details = productDemandPlanDetailsMapper.selectList(lambdaWrapper);
                String[] arr = details.stream().map(ProductDemandPlanDetails::getProductDemandPlanId).distinct().toArray(String[]::new);
                String idListString = Arrays.toString(arr).replace(" ", "");

                ProjectDemandPlan copy = BeanUtil.copy(dto, ProjectDemandPlan.class);

                copy.setIdListString(idListString);
                copy.setCompiler(ThreadLocalUser.get().getUserId());
                projectDemandPlanMapper.insert(copy);

                this.changeId(1, projectDemandPlanGenerateVOS, copy.getId());

                List<ProjectDemandPlanGenerateVO> boardCollect = projectDemandPlanGenerateVOS.stream().filter(item -> materialTypeText.equals(item.getMaterialType())).collect(Collectors.toList());
                for (ProjectDemandPlanGenerateVO vo : boardCollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(copy.getId());
                    Integer materialType = null;
                    MaterialType[] values = MaterialType.values();
                    for (MaterialType value : values) {
                        if (value.getName().equals(materialTypeText)) {
                            materialType = value.getCode();
                        }
                    }
                    productDemandPlanTotal.setMaterialType(materialType);
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    Map<String, Long> specificationMap = analysisSpecification(vo.getIngredientsType(), vo.getSpecification());
                    if (specificationMap.size() > 0) {
                        productDemandPlanTotal.setWidth(specificationMap.get("width"));
                        productDemandPlanTotal.setThickness(specificationMap.get("thickness"));
                        productDemandPlanTotal.setLength(specificationMap.get("length"));
                        productDemandPlanTotal.setTexture(vo.getMaterial());
                        productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                    }
                }
                insertMaterialTypeDescription(dto.getProjectId(), materialTypeValue, dto.getProjectDemandPlanBatch());
                return;
            }

            ProjectDemandPlan copy = BeanUtil.copy(dto, ProjectDemandPlan.class);
            copy.setCompiler(ThreadLocalUser.get().getUserId());
            projectDemandPlanMapper.insert(copy);
            insertMaterialTypeDescription(dto.getProjectId(), materialTypeValue, dto.getProjectDemandPlanBatch());
            return;
        }
        ProjectDemandPlan copy = BeanUtil.copy(dto, ProjectDemandPlan.class);
        projectDemandPlanMapper.updateById(copy);
    }


    @Transactional(rollbackFor = Exception.class)
    public void deleteProjectDemandPlan(ProjectDemandPlanDeleteDTO dto) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId())
                .eq(ProjectDemandPlan::getProjectDemandPlanBatch, dto.getProjectDemandPlanBatch());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        //如果有采购计划 不能删除
        MPJLambdaWrapper<PurchasePlan> purchasePlanMPJLambdaWrapper = new MPJLambdaWrapper<>();
        purchasePlanMPJLambdaWrapper.selectAll(PurchasePlan.class)
                .eq(PurchasePlan::getProjectId, dto.getProjectId())
                .eq(PurchasePlan::getBatch, dto.getProjectDemandPlanBatch());
        List<PurchasePlan> purchasePlans = purchasePlanMapper.selectList(purchasePlanMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(purchasePlans)) {
            throw new ErrorException("该项目需求计划有关联的采购计划不能删除");
        }
        for (ProjectDemandPlan projectDemandPlan : projectDemandPlans) {
            projectDemandPlanMapper.deleteById(projectDemandPlan.getId());

            MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingMaterialWrapper = new MPJLambdaWrapper<>();
            weldingMaterialWrapper.selectAll(WeldingMaterialDemandPlan.class)
                    .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId, projectDemandPlan.getId());
            List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(weldingMaterialWrapper);
            if (CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)) {
                List<String> collect = weldingMaterialDemandPlans.stream().map(WeldingMaterialDemandPlan::getId).collect(Collectors.toList());
                weldingMaterialsDemandPlanMapper.deleteBatchIds(collect);
            }

            MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
            paintWrapper.selectAll(PaintDemandPlan.class)
                    .eq(PaintDemandPlan::getProjectDemandPlanId, projectDemandPlan.getId());
            List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
            if (CommonUtil.listIsNotEmpty(paintDemandPlans)) {
                List<String> collect = paintDemandPlans.stream().map(PaintDemandPlan::getId).collect(Collectors.toList());
                paintDemandPlanMapper.deleteBatchIds(collect);
            }

            MPJLambdaWrapper<ProductDemandPlanTotal> planTotalLambdaWrapper = new MPJLambdaWrapper<>();
            planTotalLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                    .eq(ProductDemandPlanTotal::getProjectDemandPlanId, projectDemandPlan.getId());
            List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalLambdaWrapper);
            if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
                List<String> collect = productDemandPlanTotals.stream().map(ProductDemandPlanTotal::getId).collect(Collectors.toList());
                productDemandPlanTotalMapper.deleteBatchIds(collect);
                //更新产品(需求计划id) 和状态
                List<String> xcollect = productDemandPlanTotals.stream().map(ProductDemandPlanTotal::getProjectDemandPlanId).collect(Collectors.toList());
                UpdateWrapper<ProductDemandPlanDetails> updateWrapper = new UpdateWrapper();
                updateWrapper.set("project_demand_plan_id", null).in("project_demand_plan_id", xcollect);
                productDemandPlanDetailsMapper.update(new ProductDemandPlanDetails(), updateWrapper);

                if (!CommonUtil.isNull(projectDemandPlan.getIdListString())) {
                    String str = projectDemandPlan.getIdListString().substring(1, projectDemandPlan.getIdListString().length() - 1);
                    ArrayList<String> strings = new ArrayList<String>();
                    //如果是单个id 不用分割
                    if (str.length() > 45) {
                        String[] split = str.split(",");
                        for (String s : split) {
                            strings.add(s);
                        }
                    } else {
                        strings.add(str);
                    }
                    UpdateWrapper<ProductDemandPlan> planUpdateWrapper = new UpdateWrapper();
                    planUpdateWrapper.set("flag_project_demand_plan", false).in("id", strings);
                    productDemandPlanMapper.update(new ProductDemandPlan(), planUpdateWrapper);
                }
            }
            MPJLambdaWrapper<MaterialTypeDescription> materialTypeDescriptionLambdaWrapper = new MPJLambdaWrapper<>();
            materialTypeDescriptionLambdaWrapper.selectAll(MaterialTypeDescription.class)
                    .eq(MaterialTypeDescription::getProjectId, dto.getProjectId())
                    .eq(MaterialTypeDescription::getProjectDemandPlanBatch, dto.getProjectDemandPlanBatch());
            List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(materialTypeDescriptionLambdaWrapper);
            for (MaterialTypeDescription materialTypeDescription : materialTypeDescriptions) {
                materialTypeDescriptionMapper.deleteById(materialTypeDescription);
            }
        }
    }


    public List<MaterialTypeVO> getMaterialType() {
        ArrayList<MaterialTypeVO> list = new ArrayList<>();
        for (MaterialType statue : MaterialType.values()) {
            MaterialTypeVO materialTypeVO = new MaterialTypeVO();
            materialTypeVO.setCode(statue.getCode());
            materialTypeVO.setValue(statue.getName());
            list.add(materialTypeVO);
        }
        return list;
    }


    public void editWeldingMaterial(WeldingMaterialUpdateDTO dto) {
        WeldingMaterialDemandPlan copy = BeanUtil.copy(dto, WeldingMaterialDemandPlan.class);
        weldingMaterialsDemandPlanMapper.updateById(copy);
    }

    public void editPaint(PaintUpdateDTO dto) {
        PaintDemandPlan copy = BeanUtil.copy(dto, PaintDemandPlan.class);
        paintDemandPlanMapper.updateById(copy);
    }


    public void deleteProductDemandPlanTotal(ProductDemandPlanTotalDeleteDTO dto) {
        productDemandPlanTotalMapper.deleteById(dto.getId());

    }


    public void addPaintDemandPlan(BatchInsertOrUpdatePaintDemandPlanDTO dto) {
        List<PaintDemandPlanDTO> list = dto.getList();
        for (PaintDemandPlanDTO pdto : list) {
            PaintDemandPlan copy = BeanUtil.copy(pdto, PaintDemandPlan.class);
            paintDemandPlanMapper.insert(copy);
        }
    }


    public void addWeldingMaterialDemandPlan(BatchInsertOrUpdateWeldingMaterialDemandPlanDTO dto) {
        List<WeldingMaterialDemandPlanDTO> list = dto.getList();
        for (WeldingMaterialDemandPlanDTO wdto : list) {
            WeldingMaterialDemandPlan copy = BeanUtil.copy(wdto, WeldingMaterialDemandPlan.class);
            weldingMaterialsDemandPlanMapper.insert(copy);
        }
    }


    public PageResult<WeldingMaterialsVO> getWeldingDemandPlanList(WeldingMaterialDemandQueryPlanDTO dto) {

        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, WeldingMaterialDemandPlan::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .like(!CommonUtil.isNull(dto.getMaterialName()), WeldingMaterialDemandPlan::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getBrand()), WeldingMaterialDemandPlan::getBrand, dto.getBrand())
                .like(!CommonUtil.isNull(dto.getModel()), WeldingMaterialDemandPlan::getModel, dto.getModel());

        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        List<WeldingMaterialsVO> weldingMaterialsVOS = BeanUtil.copyList(weldingMaterialDemandPlans, WeldingMaterialsVO.class);
        List<WeldingMaterialsVO> collect = weldingMaterialsVOS.stream().peek(item -> {
            if (!CommonUtil.isNull(item.getCount()) && !CommonUtil.isNull(item.getBidPrice()) && item.getCount() != 0) {
                double v = Math.round(item.getBidPrice() * 100 / item.getCount()) / 100.0;
                item.setBidUnitPrice((long) (v * 100));
            }
            item.setMaterialType(MaterialType.WELDING_MATERIALS.getCode());
            item.setMaterialTypeText("焊材");
        }).collect(Collectors.toList());

        collect = collect.stream().sorted(Comparator.nullsLast(Comparator.comparing(WeldingMaterialsVO::getSerialNumber, Comparator.nullsLast(Integer::compareTo)))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }


    public PageResult<PaintVO> getPaintDemandPlanList(PaintDemandPlanQueryDTO dto) {
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, PaintDemandPlan::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .like(!CommonUtil.isNull(dto.getColour()), PaintDemandPlan::getColour, dto.getColour())
                .like(!CommonUtil.isNull(dto.getMaterialName()), PaintDemandPlan::getMaterialName, dto.getMaterialName());

        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        List<PaintVO> paintVOS = BeanUtil.copyList(paintDemandPlans, PaintVO.class);
        List<PaintVO> collect = paintVOS.stream().peek(item -> {
            if (!CommonUtil.isNull(item.getCount()) && !CommonUtil.isNull(item.getBidPrice()) && item.getCount() != 0) {
                double v = Math.round(item.getBidPrice() * 100 / item.getCount()) / 100.0;
                item.setBidUnitPrice((long) (v * 100));
            }
            item.setMaterialType(MaterialType.PAINT.getCode());
            item.setMaterialTypeText("油漆");
        }).collect(Collectors.toList());

        collect = collect.stream().sorted(Comparator.nullsLast(Comparator.comparing(PaintVO::getSerialNumber, Comparator.nullsLast(Integer::compareTo)))).collect(Collectors.toList());

        return PageUtil.convert2PageResult(collect, dto);
    }


    public void insertMaterialTypeDescription(String projectId, String materoalType, String projectDemandPlanBatch) {
        MaterialTypeDescription materialTypeDescription = new MaterialTypeDescription();
        materialTypeDescription.setProjectDemandPlanBatch(projectDemandPlanBatch);
        materialTypeDescription.setRemarks("");
        materialTypeDescription.setMaterialType(materoalType);
        materialTypeDescription.setProjectId(projectId);
        materialTypeDescriptionMapper.insert(materialTypeDescription);
    }


    @Transactional(rollbackFor = Exception.class)
    public void generateProjectDemandPlan(ProjectGenerateDemandQueryDTO dto) {
        QueryWrapper<ProductDemandPlanDetails> mpjLambdaWrapper = new QueryWrapper<>();
        mpjLambdaWrapper.in("product_demand_plan_id", dto.getIdList())
                .in("material_type", dto.getMaterialTypeList());
        List<ProductDemandPlanDetails> productDemandPlanDetailsList = productDemandPlanDetailsMapper.selectList(mpjLambdaWrapper);
        MPJLambdaWrapper<ProductDemandPlanDetails> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.selectAll(ProductDemandPlanDetails.class)
                .selectAll(ProductDemandPlan.class)
                .leftJoin(ProductDemandPlan.class, ProductDemandPlan::getId, ProductDemandPlanDetails::getProductDemandPlanId)
                .in(ProductDemandPlan::getId, dto.getIdList())
                .in(ProductDemandPlanDetails::getMaterialType, dto.getMaterialTypeList());
        List<ProductDemandPlanDetails> details = productDemandPlanDetailsMapper.selectList(lambdaWrapper);
        List<String> strings = details.stream().map(ProductDemandPlanDetails::getProductDemandPlanId).distinct().collect(Collectors.toList());
        List<String> typeList = details.stream().map(ProductDemandPlanDetails::getMaterialType).distinct().collect(Collectors.toList());
        List<String> totalStrings = new ArrayList<>();
        //查询项目需求计划表 中包含id的需求类型
        for (String string : strings) {
            MPJLambdaWrapper<ProjectDemandPlan> planWrapper = new MPJLambdaWrapper<>();
            planWrapper.selectAll(ProjectDemandPlan.class)
                    .eq(!CommonUtil.isNull(dto.getProjectId()), ProjectDemandPlan::getProjectId, dto.getProjectId());
            List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(planWrapper);
            if (CommonUtil.listIsNotEmpty(projectDemandPlans)) {
                List<String> typeCollect = projectDemandPlans.stream()
                        .filter(item -> {
                            if (CommonUtil.isNull(item.getIdListString())) {
                                return false;
                            }
                            return item.getIdListString().contains(string);
                        })
                        .map(item -> EnumUtil.getValue(DemandType.class, item.getDemandType()))
                        .distinct().collect(Collectors.toList());
                if (CommonUtil.listIsNotEmpty(typeCollect)) {
                    typeList.addAll(typeCollect);
                    if (typeList.size() >= 5) {
                        totalStrings.add(string);
                    }
                } else if (typeList.size() == 5) {
                    totalStrings.add(string);
                }
            } else if (typeList.size() == 5) {
                totalStrings.add(string);
            }
        }

        if (CommonUtil.isNull(productDemandPlanDetailsList)) {
            throw new ErrorException("该产品下没数据无法生成");
        }
        //过滤没有项目需求计划的id的产品
        List<ProductDemandPlanDetails> demandPlanDetailsList = productDemandPlanDetailsList.stream().filter(item -> CommonUtil.isNull(item.getProjectDemandPlanId())).collect(Collectors.toList());
        List<ProjectDemandPlanGenerateVO> generateVOList = BeanUtil.copyList(demandPlanDetailsList, ProjectDemandPlanGenerateVO.class);
        List<ProjectDemandPlanGenerateVO> projectDemandPlanGenerateVOS = generateVOList.stream().filter(item -> !"组合件".equals(item.getMaterial())).peek(item -> {
            String manufacturingNumber = productDemandPlanMapper.selectById(item.getProductDemandPlanId()).getManufacturingNumber();
            item.setManufacturingNumberPartNo(manufacturingNumber + "/" + item.getPartNo());

        }).collect(Collectors.toList());
        Set<Integer> collectInteger = projectDemandPlanGenerateVOS.stream().map(item -> {
            String code = EnumUtil.getCode(DemandType.class, item.getMaterialType());
            Integer integer = Integer.valueOf(code);
            return integer;
        }).collect(Collectors.toSet());

        //新增批次
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        Integer max;

        Set<Integer> integerSet = projectDemandPlans.stream().map(item -> {
            Integer integer;
            if (CommonUtil.isNull(item.getProjectDemandPlanBatch())) {
                integer = 0;
            } else {
                integer = Integer.valueOf(item.getProjectDemandPlanBatch().substring(1, item.getProjectDemandPlanBatch().length() - 2));
            }
            return integer;
        }).collect(Collectors.toSet());
        //已有批次最大值
        if (!CommonUtil.listIsNotEmpty(projectDemandPlans)) {
            max = 0;
        } else {
            max = Collections.max(integerSet);
        }

        //id 字符串
        String[] arr = strings.toArray(new String[0]);
        String idListString = Arrays.toString(arr).replace(" ", "");
        for (Integer integer : collectInteger) {
            if (DemandType.BOARD.getCode().equals(integer)) {
                ProjectDemandPlan bprojectDemandPlan = new ProjectDemandPlan();
                bprojectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt = new Random().nextInt(10000) + 10000;
                bprojectDemandPlan.setPlanNo("计划编号" + randomInt);
                bprojectDemandPlan.setCompiler(ThreadLocalUser.get().getUserId());
                bprojectDemandPlan.setDemandType(DemandType.BOARD.getCode());
                bprojectDemandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
                bprojectDemandPlan.setIdListString(idListString);
                projectDemandPlanMapper.insert(bprojectDemandPlan);
                //更新产品(需求计划id) id
                this.changeId(1, projectDemandPlanGenerateVOS, bprojectDemandPlan.getId());

                List<ProjectDemandPlanGenerateVO> boardCollect = projectDemandPlanGenerateVOS.stream().filter(item -> "板材".equals(item.getMaterialType())).collect(Collectors.toList());
                for (ProjectDemandPlanGenerateVO vo : boardCollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(bprojectDemandPlan.getId());
                    productDemandPlanTotal.setMaterialType(MaterialType.BOARD.getCode());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    //增加比重
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    Map<String, Long> specificationMap = analysisSpecification(vo.getIngredientsType(), vo.getSpecification());
                    if (specificationMap.size() > 0) {
                        productDemandPlanTotal.setWidth(specificationMap.get("width"));
                        productDemandPlanTotal.setThickness(specificationMap.get("thickness"));
                        productDemandPlanTotal.setLength(specificationMap.get("length"));
                        productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                    }
                }
            } else if (DemandType.PROFILE.getCode().equals(integer)) {
                ProjectDemandPlan xprojectDemandPlan = new ProjectDemandPlan();
                xprojectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt = new Random().nextInt(10000) + 10000;
                xprojectDemandPlan.setPlanNo("计划编号" + randomInt);
                xprojectDemandPlan.setCompiler(ThreadLocalUser.get().getUserId());
                xprojectDemandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
                xprojectDemandPlan.setIdListString(idListString);
                xprojectDemandPlan.setDemandType(DemandType.PROFILE.getCode());
                projectDemandPlanMapper.insert(xprojectDemandPlan);
                //合并型材
                //更新产品(需求计划id) id
                this.changeId(2, projectDemandPlanGenerateVOS, xprojectDemandPlan.getId());
                List<ProjectDemandPlanGenerateVO> collect = projectDemandPlanGenerateVOS.stream().filter(item -> "型材".equals(item.getMaterialType())).collect(Collectors.toList());
                for (ProjectDemandPlanGenerateVO vo : collect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(xprojectDemandPlan.getId());
                    productDemandPlanTotal.setMaterialType(MaterialType.PROFILE.getCode());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    productDemandPlanTotal.setTexture(vo.getMaterial());
//                    Map<String, Long> specificationMap = analysisSpecification(vo.getIngredientsType(), vo.getSpecification());
                    productDemandPlanTotal.setWidth(vo.getSecondSize());
                    productDemandPlanTotal.setThickness(vo.getFirstSize());
                    productDemandPlanTotal.setLength(vo.getThirdSize());
                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }
            } else if (DemandType.FORGE_PIECE.getCode().equals(integer)) {
                List<ProjectDemandPlanGenerateVO> forgecollect = projectDemandPlanGenerateVOS.stream().filter(item -> "锻件".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt = new Random().nextInt(10000) + 10000;
                projectDemandPlan.setPlanNo("计划编号" + randomInt);
                projectDemandPlan.setCompiler(ThreadLocalUser.get().getUserId());
                projectDemandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
                projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(DemandType.FORGE_PIECE.getCode());
                projectDemandPlanMapper.insert(projectDemandPlan);
                //更新产品(需求计划id) id
                this.changeId(3, projectDemandPlanGenerateVOS, projectDemandPlan.getId());
                for (ProjectDemandPlanGenerateVO vo : forgecollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());
                    productDemandPlanTotal.setMaterialType(MaterialType.FORGE_PIECE.getCode());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    //增加比重
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }
            } else if (DemandType.PURCHASED_PARTS.getCode().equals(integer)) {
                List<ProjectDemandPlanGenerateVO> purcollect = projectDemandPlanGenerateVOS.stream().filter(item -> "外购件".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt = new Random().nextInt(10000) + 10000;
                projectDemandPlan.setPlanNo("计划编号" + randomInt);
                projectDemandPlan.setCompiler(ThreadLocalUser.get().getUserId());
                projectDemandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
                projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(DemandType.PURCHASED_PARTS.getCode());
                projectDemandPlanMapper.insert(projectDemandPlan);
                //更新产品(需求计划id) id
                //更新产品(需求计划id) id
                this.changeId(4, projectDemandPlanGenerateVOS, projectDemandPlan.getId());
                for (ProjectDemandPlanGenerateVO vo : purcollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());
                    productDemandPlanTotal.setMaterialType(MaterialType.PURCHASED_PARTS.getCode());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    //增加比重
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }
            } else if (DemandType.AUXILIARY_MATERIALS.getCode().equals(integer)) {
                List<ProjectDemandPlanGenerateVO> auxcollect = projectDemandPlanGenerateVOS.stream().filter(item -> "辅材".equals(item.getMaterialType())).collect(Collectors.toList());
                ProjectDemandPlan projectDemandPlan = new ProjectDemandPlan();
                projectDemandPlan.setProjectId(dto.getProjectId());
                int randomInt = new Random().nextInt(10000) + 10000;
                projectDemandPlan.setPlanNo("计划编号" + randomInt);
                projectDemandPlan.setCompiler(ThreadLocalUser.get().getUserId());
                projectDemandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
                projectDemandPlan.setIdListString(idListString);
                projectDemandPlan.setDemandType(DemandType.AUXILIARY_MATERIALS.getCode());
                projectDemandPlanMapper.insert(projectDemandPlan);
                //更新产品(需求计划id) id
                this.changeId(5, projectDemandPlanGenerateVOS, projectDemandPlan.getId());
                for (ProjectDemandPlanGenerateVO vo : auxcollect) {
                    ProductDemandPlanTotal productDemandPlanTotal = new ProductDemandPlanTotal();
                    BeanUtil.copyProperties(vo, productDemandPlanTotal);
                    productDemandPlanTotal.setId(null);
                    productDemandPlanTotal.setProjectDemandPlanId(projectDemandPlan.getId());
                    productDemandPlanTotal.setMaterialType(MaterialType.AUXILIARY_MATERIALS.getCode());
                    productDemandPlanTotal.setUnit(vo.getUseMaterialUnit());
                    productDemandPlanTotal.setBidPrice(vo.getDemandProposalPrice());
                    //增加用料类型
                    //增加比重
                    //后加的字段属性
                    productDemandPlanTotal.setTexture(vo.getMaterial());
                    productDemandPlanTotalMapper.insert(productDemandPlanTotal);
                }
            }
            String value = EnumUtil.getValue(DemandType.class, integer);
            insertMaterialTypeDescription(dto.getProjectId(), value, "第" + (max + 1) + "批次");
        }
        if (CommonUtil.listIsNotEmpty(totalStrings)) {
            UpdateWrapper<ProductDemandPlan> planUpdateWrapper = new UpdateWrapper();
            planUpdateWrapper.set("flag_project_demand_plan", true).in("id", totalStrings);
            productDemandPlanMapper.update(new ProductDemandPlan(), planUpdateWrapper);
        }
    }


    @Transactional(rollbackFor = Exception.class)
    public void generateBlankProjectDemandPlan(ProjectGenerateDemandQueryDTO dto) {
        //新增批次
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        Integer max;

        Set<Integer> integerSet = projectDemandPlans.stream().map(item -> {
            Integer integer;
            if (CommonUtil.isNull(item.getProjectDemandPlanBatch())) {
                integer = 0;
            } else {
                integer = Integer.valueOf(item.getProjectDemandPlanBatch().substring(1, item.getProjectDemandPlanBatch().length() - 2));
            }
            return integer;
        }).collect(Collectors.toSet());
        //已有批次最大值
        if (!CommonUtil.listIsNotEmpty(projectDemandPlans)) {
            max = 0;
        } else {
            max = Collections.max(integerSet);
        }

        for (String materialName : dto.getMaterialTypeList()) {
            String code = EnumUtil.getCode(DemandType.class, materialName);
            ProjectDemandPlan demandPlan = new ProjectDemandPlan();
            demandPlan.setProjectId(dto.getProjectId());
            int randomInt = new Random().nextInt(10000) + 10000;
            demandPlan.setPlanNo("计划编号" + randomInt);
            demandPlan.setCompiler(ThreadLocalUser.get().getUserId());
            demandPlan.setDemandType(Integer.valueOf(code));
            demandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
            projectDemandPlanMapper.insert(demandPlan);
            insertMaterialTypeDescription(dto.getProjectId(), materialName, "第" + (max + 1) + "批次");
        }
    }


    /***
     * @description
     * @author szp
     * @date 2023/5/19
     * @version 1.0.0
     */
    private void changeId(Integer materialType, List<ProjectDemandPlanGenerateVO> list, String id) {
        Map<String, List<ProjectDemandPlanGenerateVO>> collect = list.stream().collect(Collectors.groupingBy(ProjectDemandPlanGenerateVO::getMaterialType));
        String value = EnumUtil.getValue(MaterialType.class, materialType);
        if (collect.keySet().contains(value)) {
            List<String> xcollect = collect.get(value).stream().map(item -> item.getId()).collect(Collectors.toList());
            List<ProductDemandPlanDetails> details = productDemandPlanDetailsMapper.selectBatchIds(xcollect);
            List<String> stringList = details.stream().filter(item -> CommonUtil.isNull(item.getProjectDemandPlanId())).map(item -> item.getId()).collect(Collectors.toList());
            if (CommonUtil.listIsNotEmpty(stringList)) {
                UpdateWrapper<ProductDemandPlanDetails> updateWrapper = new UpdateWrapper();
                updateWrapper.set("project_demand_plan_id", id).in("id", stringList);
                productDemandPlanDetailsMapper.update(new ProductDemandPlanDetails(), updateWrapper);
            }
        }
    }

    /**
     * @author szp
     * @date 2022/11/16
     * 计算合并后的规则
     */
    private ProductDemandPlanDetails getProductDemandPlanDetails(List<ProjectDemandPlanGenerateVO> productDemandPlanDetails1, ProjectDemandPlanGenerateVO generateVO) {
        List<ProjectDemandPlanGenerateVO> collect = productDemandPlanDetails1.stream().peek(item -> {
            if (CommonUtil.isNull(item.getThirdSize())) {
                item.setThirdSize(0L);
            }
        }).collect(Collectors.toList());
        Long sumThirdSize = collect.stream().mapToLong(ProjectDemandPlanGenerateVO::getThirdSize).sum();
        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, generateVO.getIngredientsType());
        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
        Class<? extends ComputerHandler> clazz = computerType.getClazz();
        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
        generateVO.setThirdSize(sumThirdSize);
        InsertDetailDTO copy = BeanUtil.copy(generateVO, InsertDetailDTO.class);
        copy.setProportion(generateVO.getProportion());
        ProductDemandPlanDetails execution = bean.execution(copy);
        return execution;
    }

    public void paintEditTimeAndLocation(EditTimeAndLocationDTO dto) {
        paintDemandPlanMapper.paintEditTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }

    public void deletePaintDemandPlan(PaintDemandPlanDeleteDTO dto) {
        paintDemandPlanMapper.deleteById(dto.getId());
    }

    public void deleteWeldingMaterialDemandPlan(WeldingMaterialDemandPlanDelteDTO dto) {
        weldingMaterialsDemandPlanMapper.deleteById(dto.getId());
    }

    public void weldingMaterialEditTimeAndLocation(EditTimeAndLocationDTO dto) {
        weldingMaterialsDemandPlanMapper.weldingMaterialEditTimeAndLocation(dto.getIds(), dto.getDeliveryTime(), dto.getDeliveryLocation());
    }


    public PaintDemandPlanViewVO getPaintDemandPlanVO(PaintDemandPlanQueryOneDTO dto) {
        PaintDemandPlan paintDemandPlan = paintDemandPlanMapper.selectById(dto.getId());
        if (!CommonUtil.isNull(paintDemandPlan.getCount()) && !CommonUtil.isNull(paintDemandPlan.getBidPrice()) && paintDemandPlan.getCount() != 0) {
            paintDemandPlan.setBidUnitPrice(100 * (paintDemandPlan.getBidPrice() / paintDemandPlan.getCount()));
        }
        return BeanUtil.copy(paintDemandPlan, PaintDemandPlanViewVO.class);
    }


    public WeldingMaterialDemandPlanViewVO getWeldingMaterialDemandPlanVO(WeldingMaterialDemandPlanQueryOneDTO dto) {
        WeldingMaterialDemandPlan weldingMaterialDemandPlan = weldingMaterialsDemandPlanMapper.selectById(dto.getId());
        if (!CommonUtil.isNull(weldingMaterialDemandPlan.getCount()) && !CommonUtil.isNull(weldingMaterialDemandPlan.getBidPrice()) && weldingMaterialDemandPlan.getCount() != 0) {
            weldingMaterialDemandPlan.setBidUnitPrice(100 * (weldingMaterialDemandPlan.getBidPrice() / weldingMaterialDemandPlan.getCount()));
        }
        return BeanUtil.copy(weldingMaterialDemandPlan, WeldingMaterialDemandPlanViewVO.class);
    }


    public void productDemandPlanTotalRead(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<BoardImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), BoardImportVO.class, MaterialType.BOARD.getName());
        file.getInputStream().close();
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.BOARD.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                copy.setMaterialType(MaterialType.BOARD.getCode());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (item.getDeliveryTime().contains("-")) {
                        parse = sdf.parse(item.getDeliveryTime());
                    } else if (item.getDeliveryTime().contains("/")) {
                        parse = format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                productDemandPlanTotalMapper.insert(copy);
            }
        });
    }

    /**
     * @author szp
     * @date 2023/3/8 17:35
     */
    public List<MaterialTypeDescriptionViewVO> getMaterialEntityViewVOList(MaterialTypeQueryDTO dto) {
        MPJLambdaWrapper<MaterialTypeDescription> materialWrapper = new MPJLambdaWrapper<>();
        materialWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, dto.getProjectId())
                .eq(MaterialTypeDescription::getProjectDemandPlanBatch, dto.getProjectDemandPlanBatch());
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(materialWrapper);
        List<MaterialTypeDescriptionViewVO> materialTypeDescriptionViewVOS = BeanUtil.copyList(materialTypeDescriptions, MaterialTypeDescriptionViewVO.class);
        return materialTypeDescriptionViewVOS.stream().peek(item -> {
            if (StringUtils.isBlank(item.getRemarks())) {
                item.setRemarks("");
            }
        }).collect(Collectors.toList());
    }


    public void editMaterialType(MaterialTypeEditDTO dto) {
        MaterialTypeDescription copy = BeanUtil.copy(dto, MaterialTypeDescription.class);
        materialTypeDescriptionMapper.updateById(copy);
    }


    public void exportBoard(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.BOARD.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {
            this.sortBySerialNumber(productDemandPlanTotals);
        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);
        }
        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ProductDemandPlanTotalExportVO> list = productDemandPlanTotals.stream().map(product -> {
            ProductDemandPlanTotalExportVO totalExportVO = BeanUtil.copy(product, ProductDemandPlanTotalExportVO.class);
            totalExportVO.setFirstSizeExport(NumberConvertUtil.longConvertToString(product.getWidth(), 100));
            totalExportVO.setSecondSizeExport(NumberConvertUtil.longConvertToString(product.getThickness(), 100));
            totalExportVO.setThirdSizeExport(NumberConvertUtil.longConvertToString(product.getLength(), 100));
            return totalExportVO;
        }).collect(Collectors.toList());

        AtomicInteger atomicInteger = new AtomicInteger();
        //件号加入 制造编号前缀 2023.04.19
        list.forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //根据材质解析
            /**
             * 根据材质表id获取用料类型
             *  根据用料类型，解析出尺寸
             */
            ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
            ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
            Class<? extends ComputerHandler> clazz = computerType.getClazz();
            ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
            bean.analysis(item);

            if ("复合板".equals(item.getMaterialName())) {
                String specification = item.getSpecification();
                item.setFirstSizeExport("");
                //规格第一列是second
                item.setSecondSizeExport(specification);
                item.setThirdSizeExport("");
            }
            /**/
            String sparePartsQuantity = "";
            if (!CommonUtil.isNull(item.getSparePartsQuantity()) && item.getSparePartsQuantity() != 0) {
                sparePartsQuantity = "备件数量" + item.getSparePartsQuantity().doubleValue() / 100 + "件";
            }
            //设置备件数量
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantityExport(item.getSparePartsQuantity().doubleValue() / 100);
            }
            //设置比重和标书价
            if (!CommonUtil.isNull(item.getBidPrice())) {
                item.setBidPriceExport(item.getBidPrice().doubleValue() / 100);
            }
            if (!CommonUtil.isNull(item.getProportion())) {
                item.setProportionExport(item.getProportion().doubleValue() / 100);
            }
            //设置是否计算
            item.setIsCalculateText(item.getIsCalculate() ? "是" : "否");
            //备注加上备件数量{}               {list.sparePartsQuantity}
            item.setRemarks(item.getRemarks() == null ? "" : item.getRemarks() + sparePartsQuantity);

            //设置数量(数量+备件数量)
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setCountExport(item.getCount().doubleValue() / 100 + item.getSparePartsQuantity().doubleValue() / 100);
            } else {
                item.setCountExport(item.getCount().doubleValue() / 100);
            }
            if (item.getWeight() != null) {
                item.setWeightExport(item.getWeight().doubleValue() / 100);
            } else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        writeHandlers.add(new MyMergeHandler(List.of("板材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 18))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/template2.xlsx");
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "板材导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "板材");

        //计算列总和
        double total = list.stream().mapToDouble(ProductDemandPlanTotalExportVO::getWeightExport).sum();

        String param1 = projectDemandPlan.getManufacturingNumber() != null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1", param1);
        data.put("param2", param2);
        data.put("total", total);
        excelExportService.fill(data, "板材");

        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "板材")
                .eq(StringUtils.isNotBlank(projectDemandPlan.getProjectDemandPlanBatch()), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlan.getProjectDemandPlanBatch())
                .last("limit 1");
        MaterialTypeDescription materialTypeDescriptions = materialTypeDescriptionMapper.selectOne(descriptionMPJLambdaWrapper);
        //备注数据
        List<RemarkVO> remarkVOS = new ArrayList<>();
        RemarkVO remarkVO1 = new RemarkVO();
        remarkVO1.setSeq(1);
        remarkVO1.setContent(Optional.ofNullable(materialTypeDescriptions).orElse(new MaterialTypeDescription()).getRemarks());
        remarkVOS.add(remarkVO1);
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "板材");

        excelExportService.export();
    }

    public void weldingExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        /**
         * 焊材导出
         *  根据项目需求计划表id查询焊材需求计划
         */
        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(!CommonUtil.isNull(dto.getProjectDemandPlanId()), WeldingMaterialDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());
        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        if (!CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<WeldingMaterialsExportVO> list = BeanUtil.copyList(weldingMaterialDemandPlans, WeldingMaterialsExportVO.class);
        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setIdExport((long) atomicInteger.incrementAndGet());
            //计算总重
            if (CommonUtil.isNull(item.getCount())) {
                item.setCount(1);
            }
            item.setTotalWeight(item.getWeight().doubleValue() / 100 * item.getCount());
        });
        //计算重量总和
        double total = list.stream().mapToDouble(WeldingMaterialsExportVO::getTotalWeight).sum();
        List<WriteHandler> writeHandlers = new ArrayList<>();
        writeHandlers.add(new MyMergeHandler(List.of("焊材"), 4 + list.size(), List.of(new CellRangeAddress(4 + list.size(), 4 + list.size(), 1, 10))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/weldTemplate.xlsx");

        //工程名称:项目需求计划表关联id，查询获得项目id
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        ProjectVO projectVO = projectService.getById(projectDemandPlan.getProjectId());
        String param1 = projectVO.getProjectName();

        ExcelExportService excelExportService = new ExcelExportService(param1 + projectDemandPlan.getProjectDemandPlanBatch() + "焊材", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //计划编号
        String param2 = projectDemandPlan.getPlanNo();

        HashMap<String, Object> data = new HashMap<>();
        //自定义参数数据
        //焊材列表页面
        data.put("param1", param1);
        data.put("param2", projectDemandPlan.getPlanNo());
        data.put("total", total);
        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "焊材")
                .eq(StringUtils.isNotBlank(projectDemandPlan.getProjectDemandPlanBatch()), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlan.getProjectDemandPlanBatch())
                .last("limit 1");
        MaterialTypeDescription materialTypeDescriptions = materialTypeDescriptionMapper.selectOne(descriptionMPJLambdaWrapper);
        //备注数据
        List<RemarkVO> remarkVOS = new ArrayList<>();
        RemarkVO remarkVO1 = new RemarkVO();
        remarkVO1.setSeq(1);
        remarkVO1.setContent(Optional.ofNullable(materialTypeDescriptions).orElse(new MaterialTypeDescription()).getRemarks());
        remarkVOS.add(remarkVO1);
        excelExportService.fill(new FillWrapper("list", list), "焊材");
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "焊材");
        excelExportService.fill(data, "焊材");
        //封面
        HashMap<String, Object> map = new HashMap<>();
        map.put("param2", param2);
        UserInfoEntity userInfoByID = userService.getUserInfoByID(projectDemandPlan.getCompiler());
        map.put("organization", Optional.ofNullable(userInfoByID).orElse(new UserInfoEntity()).getCHName());
        map.put("organizationTime", projectDemandPlan.getCompileTime());
        map.put("engineer", projectDemandPlan.getProofreader());
        map.put("process", projectDemandPlan.getProofreadingTime());
        map.put("manager", projectDemandPlan.getReviewer());
        map.put("reviewTime", projectDemandPlan.getReviewTime());
        map.put("approval", projectDemandPlan.getChecker());
        map.put("approvalTime", projectDemandPlan.getCheckTime());
        map.put("projectNo", projectVO.getProjectNo());
        map.put("projectName", projectVO.getProjectName());
        excelExportService.fill(map, "封面");
        //编制说明
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("explain", projectDemandPlan.getPreparationDescription());
        excelExportService.fill(hashMap, "编制说明");
        excelExportService.export();
    }


    public void paintExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        /**
         * 油漆导出
         *
         *
         */
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(!CommonUtil.isNull(dto.getProjectDemandPlanId()), PaintDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        if (!CommonUtil.listIsNotEmpty(paintDemandPlans)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<PaintExportVO> list = BeanUtil.copyList(paintDemandPlans, PaintExportVO.class);
        AtomicInteger atomicInteger = new AtomicInteger();
        list.stream().forEach(item -> {
            //自增序号
            item.setEnforceStandards(item.getExecutiveStandards());
            item.setAutoincrementId(Integer.valueOf(atomicInteger.incrementAndGet()));

            item.setCount(item.getCount() / 100);
            item.setArea(item.getArea() / 100);
            //计算总面积
            item.setTotalArea(item.getArea().doubleValue() * item.getCount());
        });

        //计算面积总和
        double total = list.stream().mapToDouble(PaintExportVO::getTotalArea).sum();
        log.info("导出的数据：{}", list);
        List<WriteHandler> writeHandlers = new ArrayList<>();
        /* writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("油漆"), 4, List.of(9, 11)));*/
        writeHandlers.add(new MyMergeHandler(List.of("油漆"), 4 + list.size(), List.of(new CellRangeAddress(4 + list.size(), 4 + list.size(), 1, 10))));

        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/paintTemplate.xlsx");

        //工程名称:项目需求计划表关联id，查询获得项目id
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        ProjectVO projectVO = projectService.getById(projectDemandPlan.getProjectId());
        String param1 = projectVO.getProjectName();

        ExcelExportService excelExportService = new ExcelExportService(param1 + projectDemandPlan.getProjectDemandPlanBatch() + "油漆", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //计划编号

        String param2 = projectDemandPlan.getPlanNo();
        //编号
        String param3 = projectVO.getProjectNo();

        HashMap<String, Object> data = new HashMap<>();
        //自定义参数数据
        //焊材列表页面
        data.put("param1", param1);
        data.put("param2", projectDemandPlan.getPlanNo());
        data.put("param3", param3);
        data.put("total", total);
        //备注
        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "油漆")
                .eq(StringUtils.isNotBlank(projectDemandPlan.getProjectDemandPlanBatch()), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlan.getProjectDemandPlanBatch())
                .last("limit 1");
        MaterialTypeDescription materialTypeDescriptions = materialTypeDescriptionMapper.selectOne(descriptionMPJLambdaWrapper);
        //备注数据
        List<RemarkVO> remarkVOS = new ArrayList<>();
        RemarkVO remarkVO1 = new RemarkVO();
        remarkVO1.setSeq(1);
        remarkVO1.setContent(Optional.ofNullable(materialTypeDescriptions).orElse(new MaterialTypeDescription()).getRemarks());
        remarkVOS.add(remarkVO1);
//        List<PaintExportVO> collect = list.stream().peek(item -> item.setMaterialNameAndSize(item.getMaterialName() + item.getSize())).collect(Collectors.toList());
//        excelExportService.fill(new FillWrapper("list", collect), "油漆");
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "油漆");
        excelExportService.fill(new FillWrapper("list", list), "油漆");
        excelExportService.fill(data, "油漆");
        //封面
        HashMap<String, Object> map = new HashMap<>();
        map.put("param1", param1);
        map.put("param2", param2);
        map.put("param3", param3);
        map.put("organization", projectDemandPlan.getCompiler());
        map.put("organizationTime", projectDemandPlan.getCompileTime());
        map.put("engineer", projectDemandPlan.getProofreader());
        map.put("process", projectDemandPlan.getProofreadingTime());
        map.put("manager", projectDemandPlan.getReviewer());
        map.put("reviewTime", projectDemandPlan.getReviewTime());
        map.put("approval", projectDemandPlan.getChecker());
        map.put("approvalTime", projectDemandPlan.getCheckTime());
        map.put("projectNo", projectVO.getProjectNo());
        map.put("projectName", projectVO.getProjectName());
        excelExportService.fill(map, "封面展示");
         /*
          导出编制说明
         */
        ArrayList<RemarkVO> exRemarkVOS = new ArrayList<>();
        if (!CommonUtil.isNull(projectDemandPlan.getPreparationDescription())) {

            String[] split = projectDemandPlan.getPreparationDescription().split("\n");
            for (int i = 0; i < split.length; i++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(i + 1);
                remarkVO.setContent(split[i]);
                exRemarkVOS.add(remarkVO);
            }
            excelExportService.fill(new FillWrapper("explain", exRemarkVOS), "编制说明");
        } else {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("explain.content", "");
            excelExportService.fill(hashMap, "编制说明");
        }
        excelExportService.export();
    }

    /**
     * 根据项目id和物资类型查询计划编号
     * @param projectId
     * @param materialType
     * @return
     */
    public String selectPlanNoByProjectId(String projectId, Integer materialType) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProjectDemandPlan::getPlanNo)
                .eq(!CommonUtil.isNull(projectId), ProjectDemandPlan::getProjectId, projectId);
        if (materialType.equals(MaterialType.WELDING_MATERIALS.getCode())) {
            //焊材
            wrapper.eq(ProjectDemandPlan::getDemandType, 1);
        } else if (materialType.equals(MaterialType.PAINT.getCode())) {
            wrapper.eq(ProjectDemandPlan::getDemandType, 2);
        } else {
            wrapper.eq(ProjectDemandPlan::getDemandType, 3);
        }
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectOne(wrapper);
        return CommonUtil.isNull(projectDemandPlan) ? "" : projectDemandPlan.getPlanNo();
    }

    public List<LockStockData> getLockStockData(QueryLockStockDataDTO dto) {
        /**
         *  在物资表中查询没有关联项目的物资
         *      如果是产品类型，根据材料名称、材质和规格，在库存表里面匹配
         *      如果时油漆类型，根据颜色在库存表里面匹配
         *      如果是焊材类型，根据名称、型号和规格匹配
         *   将匹配结果返回（包含库存id，库存数量（填写锁库数量要比较））
         *   锁库时，将项目需求明细id、库存id、锁库数量传到后台，在锁库表进行批量新增
         *   锁库完成，更新项目需求数量中的锁库数量，减少库存表里面的库存数量
         *   //2023/02/13 锁库数据：从该项目下的调拨记录中的数据中锁库
         */
        List<LockStockData> lockStockData = stockManagementService.selectByColorAndMaterialType(dto, null);
        List<LockStockData> data = stockTransferService.getTransferByProject(dto);
        if (CommonUtil.listIsNotEmpty(lockStockData)) {
            lockStockData.addAll(data);
            return lockStockData.stream().filter(item -> item.getStockBalance() > 0).collect(Collectors.toList());
        } else if (CommonUtil.listIsNotEmpty(data)) {
            data.addAll(lockStockData);
            return data.stream().filter(item -> item.getStockBalance() > 0).collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }
    }


    public void lockStock(LockStockMoreDTO dto) {
        //填写的锁库数量  <=需求数量-锁库数量     <=库存数量
        //多个锁库，将锁库数量累加起来，就是这个材料被锁库的数量
        List<LockStockDTO> list = dto.getList();
        Long stockNUmber = list.stream().mapToLong(LockStockDTO::getLockStockNumber).sum();
        if (MaterialType.PAINT.getCode().equals(list.get(0).getMaterialType())) {
            //油漆
            PurchasePlanDetailsPaint paintDemandPlan = purchasePlanService.selectPaintByPurchasePlanPaintId(list.get(0).getPurchaseDemandPlanDetailId());
            if (paintDemandPlan.getPurchaseAmount() < stockNUmber - paintDemandPlan.getStockAmount()) {
                throw new RuntimeException("锁库数量需小于等于需求数量！");
            }
        } else if (MaterialType.WELDING_MATERIALS.getCode().equals(list.get(0).getMaterialType())) {
            PurchasePlanDetailsWeldingMaterials weldingMaterialDemandPlan = purchasePlanService.selectByPurchasePlanWeldId(list.get(0).getPurchaseDemandPlanDetailId());
            if (weldingMaterialDemandPlan.getPurchaseWeight() < stockNUmber - weldingMaterialDemandPlan.getStockAmount()) {
                throw new RuntimeException("锁库重量需小于等于需求数量！");
            }
        } else {
            PurchasePlanDetailsProductTotal productDemandPlanTotal = purchasePlanService.selectByPurchasePlanTotalId(list.get(0).getPurchaseDemandPlanDetailId());
            if (productDemandPlanTotal.getPurchaseAmount() < stockNUmber - productDemandPlanTotal.getStockAmount()) {
                throw new RuntimeException("锁库数量需小于等于需求数量！");
            }
        }
        list.forEach(item -> {
            //锁库数量 <= 库存数量
            MaterialStockVO materialStockVO = stockManagementService.getMaterialStockById(item.getMaterialStockId());
            if (materialStockVO.getStockBalance() < item.getLockStockNumber()) {
                throw new RuntimeException("锁库数量不能大于库存余量");
            }
        });

        List<LockStock> lockStocks = BeanUtil.copyList(list, LockStock.class);
        lockStocks.forEach(item -> {
            item.setStockType("锁库存");
        });
        Integer integer = lockStockMapper.insertBatchSomeColumn(lockStocks);
        if (integer > 0) {
            //新增锁库，，
            //更新项目需求数量中的锁库数量
            /**
             * 根据物资类型确定更新哪张表中的锁库数量
             */
            if (list.get(0).getMaterialType().equals(MaterialType.PAINT.getCode())) {
                //油漆
                purchasePlanService.updatePaintStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), stockNUmber, 1);
            } else if (list.get(0).getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                //焊材
                purchasePlanService.updateWeldStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), stockNUmber, 1);
            } else {
                //产品
                purchasePlanService.updateDetailStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), stockNUmber, 1);
            }
            //减少库存表里面的库存数量
            list.forEach(item -> {
                //根据物资表id，更新库存数量和锁库数量
                stockManagementService.updateStockAndLockNumber(item.getMaterialStockId(), item.getLockStockNumber());
            });
        }
    }

    /**
     * 项目需求计划汇总表  更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updateDetailStockAmount(String projectDemandDetailId, Long stockNUmber, Integer stockType) {
        UpdateWrapper<ProductDemandPlanTotal> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", projectDemandDetailId)
                .set("stock_type", stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = productDemandPlanTotalMapper.update(new ProductDemandPlanTotal(), wrapper);
        if (update > 0) {
            log.info("产品的锁库数量更新了：{}", stockNUmber);
        }
    }

    /**
     * 焊材表 更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updateWeldStockAmount(String projectDemandDetailId, Long stockNUmber, Integer stockType) {
        UpdateWrapper<WeldingMaterialDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", projectDemandDetailId)
                .set("stock_type", stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = weldingMaterialsDemandPlanMapper.update(new WeldingMaterialDemandPlan(), wrapper);
        if (update > 0) {
            log.info("焊材的锁库数量更新了：{}", stockNUmber);
        }

    }

    /**
     * 油漆表  更新锁库数量
     * @param projectDemandDetailId
     * @param stockNUmber
     */
    private void updatePaintStockAmount(String projectDemandDetailId, Long stockNUmber, Integer stockType) {
        UpdateWrapper<PaintDemandPlan> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", projectDemandDetailId)
                .set("stock_type", stockType)
                .setSql("stock_amount = stock_amount +" + stockNUmber);
        int update = paintDemandPlanMapper.update(new PaintDemandPlan(), wrapper);
        if (update > 0) {
            log.info("油漆的锁库数量更新了：{}", stockNUmber);
        }
    }

    /**
     * 在余料表中，根据余料名称、规格和材质匹配符合锁余料的数据
     * @param dto
     * @return
     */
    public List<MaterialRemainData> getMaterialRemainData(QueryMaterialRemainDataDTO dto) {
        return materialRemainService.getByNameAndSpecification(dto.getMaterialName(), dto.getTexture(), dto.getSpecification());
    }

    public void lockRemain(LockRemainMoreDTO dto) {
        /**
         *  锁余料数量  <= 需求数量 - 锁余料数量    <=  余料数量（前端传过来）
         */
        List<MaterialRemainDTO> list = dto.getList();
        long sum = list.stream().mapToLong(MaterialRemainDTO::getLockStockNumber).sum();
        list.forEach(item -> {
            if (item.getLockStockNumber() > item.getRemainingMaterialCount()) {
                throw new RuntimeException("锁余料数量应该小于等于余料数量");
            }
        });
        if (sum > list.get(0).getCount() - list.get(0).getStockAmount()) {
            throw new RuntimeException("锁余料数量应该小于需求数量");
        }
        List<LockStock> lockStocks = BeanUtil.copyList(list, LockStock.class);
        lockStocks.forEach(item -> {
            item.setStockType("锁余料");
        });
        Integer integer = lockStockMapper.insertBatchSomeColumn(lockStocks);
        if (integer > 0) {
            //新增锁库，，
            //更新项目需求数量中的锁库数量
            /**
             * 根据物资类型确定更新哪张表中的锁库数量
             */

            if (list.get(0).getMaterialType().equals(MaterialType.PAINT.getCode())) {
                //油漆
                this.updatePaintStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), sum, 2);
            } else if (list.get(0).getMaterialType().equals(MaterialType.WELDING_MATERIALS.getCode())) {
                //焊材
                this.updateWeldStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), sum, 2);
            } else {
                //产品
                this.updateDetailStockAmount(list.get(0).getPurchaseDemandPlanDetailId(), sum, 2);
            }
            //减少库存表里面的库存数量
            list.forEach(item -> {
                //根据余料表id，更新库存数量和锁库数量
                materialRemainService.updateStockAndLockNumber(item.getMaterialStockId(), item.getLockStockNumber());
            });
        }
    }

    public List<LockStockVO> getLockStock(QueryLockStockDTO dto) {

        /**
         * 根据项目需求计划详情id，在锁库表中查询
         *  返回的VO展示库存表的主要信息 和 锁库数量  已领数量  锁库类型
         *  关联查询
         */
        MPJLambdaWrapper<LockStock> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(LockStock.class)
                .selectAll(MaterialStock.class)
                .eq(!CommonUtil.isNull(dto.getId()), LockStock::getPurchaseDemandPlanDetailId, dto.getId())
                .leftJoin(MaterialStock.class, MaterialStock::getId, LockStock::getMaterialStockId);
        return lockStockMapper.selectJoinList(LockStockVO.class, wrapper);
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteOneProjectDemandPlan(ProjectDemandPlanDeleteOneDTO dto) {
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getId());
        String materialName = EnumUtil.getValue(DemandType.class, dto.getDemandType());
        if (CommonUtil.isNotNull(projectDemandPlan)) {
            String projectDemandPlanBatch = projectDemandPlan.getProjectDemandPlanBatch();
            MPJLambdaWrapper<MaterialTypeDescription> lambdaWrapper = new MPJLambdaWrapper<>();
            lambdaWrapper.selectAll(MaterialTypeDescription.class)
                    .eq(MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlanBatch)
                    .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                    .eq(MaterialTypeDescription::getMaterialType, materialName);
            MaterialTypeDescription materialTypeDescription = materialTypeDescriptionMapper.selectOne(lambdaWrapper);
            materialTypeDescriptionMapper.deleteById(materialTypeDescription);
        }

        int i = projectDemandPlanMapper.deleteById(dto.getId());
        if (i > 0) {
            switch (dto.getDemandType()) {
                case 1:
                    MPJLambdaWrapper<WeldingMaterialDemandPlan> weldingMaterialWrapper = new MPJLambdaWrapper<>();
                    weldingMaterialWrapper.selectAll(WeldingMaterialDemandPlan.class)
                            .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId, dto.getId());
                    List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(weldingMaterialWrapper);
                    for (WeldingMaterialDemandPlan weldingMaterialDemandPlan : weldingMaterialDemandPlans) {
                        weldingMaterialsDemandPlanMapper.deleteById(weldingMaterialDemandPlan);
                    }
                    break;
                case 2:
                    MPJLambdaWrapper<PaintDemandPlan> paintWrapper = new MPJLambdaWrapper<>();
                    paintWrapper.selectAll(PaintDemandPlan.class)
                            .eq(PaintDemandPlan::getProjectDemandPlanId, dto.getId());
                    List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);
                    for (PaintDemandPlan paintDemandPlan : paintDemandPlans) {
                        paintDemandPlanMapper.deleteById(paintDemandPlan);
                    }
                    break;
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    MPJLambdaWrapper<ProductDemandPlanTotal> planTotalLambdaWrapper = new MPJLambdaWrapper<>();
                    planTotalLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                            .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getId());
                    List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalLambdaWrapper);
                    if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
                        List<String> collect = productDemandPlanTotals.stream().map(item -> item.getId()).collect(Collectors.toList());
                        productDemandPlanTotalMapper.deleteBatchIds(collect);
                        //更改状态
                        QueryWrapper<ProductDemandPlanDetails> mpjLambdaWrapper = new QueryWrapper<>();
                        mpjLambdaWrapper.eq("project_demand_plan_id", dto.getId());
                        List<ProductDemandPlanDetails> productDemandPlanDetailsList = productDemandPlanDetailsMapper.selectList(mpjLambdaWrapper);
                        List<String> stringList = productDemandPlanDetailsList.stream().map(item -> item.getProductDemandPlanId()).collect(Collectors.toList());
                        if (CommonUtil.listIsNotEmpty(stringList)) {
                            UpdateWrapper<ProductDemandPlan> planUpdateWrapper = new UpdateWrapper();
                            planUpdateWrapper.set("flag_project_demand_plan", false).in("id", stringList);
                            productDemandPlanMapper.update(new ProductDemandPlan(), planUpdateWrapper);
                        }

                        //更改id
                        UpdateWrapper<ProductDemandPlanDetails> updateWrapper = new UpdateWrapper();
                        updateWrapper.set("project_demand_plan_id", null).eq("project_demand_plan_id", dto.getId());
                        productDemandPlanDetailsMapper.update(new ProductDemandPlanDetails(), updateWrapper);
                    }
                    break;
                default:
                    break;
            }
        }
    }


    public PageResult<ProductTotalVO> getProductDataList(ProductDemandPlanTotalQueryDTO dto) {
        String value = EnumUtil.getValue(DemandType.class, dto.getDemandType());
        String code = EnumUtil.getCode(MaterialType.class, value);
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq(ProductDemandPlanTotal::getMaterialType, Integer.valueOf(code))
                .like(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .like(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getManufacturingNumberPartNo, dto.getPartNo());
        List<ProductDemandPlanTotal> productTotals = productDemandPlanTotalMapper.selectList(wrapper);
        List<ProductDemandPlanTotal> list = productTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(list) && list.size() > 2) {
            this.sortBySerialNumber(productTotals);
        } else {
            this.sortByManufacturingNumberPartNo(productTotals);
        }
        List<ProductTotalVO> productTotalVOS = BeanUtil.copyList(productTotals, ProductTotalVO.class);
        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> {
                    if (!CommonUtil.isNull(item.getCount()) && !CommonUtil.isNull(item.getBidPrice()) && item.getCount() != 0) {
                        double v = Math.round(item.getBidPrice() * 100 / item.getCount()) / 100.0;
                        item.setBidUnitPrice((long) (v * 100));
                    }
                    if (!CommonUtil.isNull(item.getManufacturingNumberPartNo())) {
                        item.setPartNo(item.getManufacturingNumberPartNo());
                    }
                    item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()));
                    QueryLockStockDataDTO queryLockStockDataDTO = new QueryLockStockDataDTO();
                    queryLockStockDataDTO.setMaterialType(item.getMaterialType());
                    queryLockStockDataDTO.setTexture(item.getTexture());
                    queryLockStockDataDTO.setMaterialName(item.getMaterialName());
                    queryLockStockDataDTO.setSpecification(item.getSpecification());
                    queryLockStockDataDTO.setSize(item.getSpecification());
                    List<LockStockData> lockStockData = getLockStockData(queryLockStockDataDTO);
                    long sum = Optional.ofNullable(lockStockData).orElse(new ArrayList<>()).stream().mapToLong(LockStockData::getStockBalance).sum();
                    item.setCanLockMaterialStockNum(sum);

                    long remainingMaterialCount = 0;
                    List<MaterialRemainData> materialRemainData = materialRemainService.getByNameAndSpecification(dto.getMaterialName(), item.getTexture(), item.getSpecification());
                    if (CommonUtil.listIsNotEmpty(materialRemainData)) {
                        remainingMaterialCount = materialRemainData.get(0).getRemainingMaterialCount();
                    }
                    item.setCanLockMaterialRemainNum(remainingMaterialCount);
                    item.setFirstSize(item.getThickness());
                    item.setSecondSize(item.getWidth());
                    item.setThirdSize(item.getLength());
                }
        ).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }


    /**
     * 按序号排序
     * @author szp
     * @date 2023/7/14 15:58
     */
    private void sortBySerialNumber(List<ProductDemandPlanTotal> list) {

        list.sort(((x1, x2) -> {
            if (!CommonUtil.isNull(x1.getSerialNumber()) && !CommonUtil.isNull(x2.getSerialNumber())) {

                return x1.getSerialNumber().compareTo(x2.getSerialNumber());
            }
            if (CommonUtil.isNull(x1.getSerialNumber())) {
                if (CommonUtil.isNull(x2.getSerialNumber())) {
                    return 0;
                }
                return 1;
            }
            if (CommonUtil.isNull(x2.getSerialNumber())) {
                return -1;
            }

            return 0;
        }));
    }

    /**
     * 按制造编号 材质排序
     * @author szp
     * @date 2023/7/14 15:58
     */

    private void sortByManufacturingNumberPartNo(List<ProductDemandPlanTotal> list) {
        list.sort(((o1, o2) -> {
            if (!CommonUtil.isNull(o1.getManufacturingNumberPartNo()) && !CommonUtil.isNull(o2.getManufacturingNumberPartNo())) {
                if (o1.getManufacturingNumberPartNo().substring(0, o1.getManufacturingNumberPartNo().indexOf("/")).equals(o2.getManufacturingNumberPartNo().substring(0, o2.getManufacturingNumberPartNo().indexOf("/")))) {
                    //材质的原先位置
                    /**/
                    if (!CommonUtil.isNull(o1.getTexture()) && !CommonUtil.isNull(o2.getTexture())) {
                        return chineseComparator.compare(o1.getTexture(), o2.getTexture());
                    }
                    if (CommonUtil.isNull(o1.getTexture())) {
                        return 1;
                    }
                    if (CommonUtil.isNull(o2.getTexture())) {
                        return -1;
                    }
                    /**/
                } else {
                    return chineseComparator.compare(o1.getManufacturingNumberPartNo(), o2.getManufacturingNumberPartNo());
                }

            }
            if (CommonUtil.isNull(o1.getManufacturingNumberPartNo())) {
                return 1;
            }
            if (CommonUtil.isNull(o2.getManufacturingNumberPartNo())) {
                return -1;
            }
            return 0;
        }));

    }

    public PageResult<ProductTotalVO> getProfileList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getForgePieceList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getPurchasedPartsList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public PageResult<ProductTotalVO> getAuxiliaryMaterialsList(ProductDemandPlanTotalQueryDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProductDemandPlanTotal.class)
                .selectAll(ProjectDemandPlan.class)
                .leftJoin(ProjectDemandPlan.class, ProjectDemandPlan::getId, ProductDemandPlanTotal::getProjectDemandPlanId)
                .eq(ProjectDemandPlan::getPlanNo, dto.getPlanNo())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode())
                .eq(!CommonUtil.isNull(dto.getMaterialName()), ProductDemandPlanTotal::getMaterialName, dto.getMaterialName())
                .eq(!CommonUtil.isNull(dto.getPartNo()), ProductDemandPlanTotal::getPartNo, dto.getPartNo());

        List<ProductTotalVO> productTotalVOS = productDemandPlanTotalMapper.selectJoinList(ProductTotalVO.class, wrapper);

        List<ProductTotalVO> collect = productTotalVOS.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        return PageUtil.convert2PageResult(collect, dto);
    }

    public void profileExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {

            // 2023.07.14 如果 没有序号 就按照 制造编号材质 排序
            this.sortBySerialNumber(productDemandPlanTotals);

        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);

        }
        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ProfileExportVO> list = productDemandPlanTotals.stream().map(product -> {
            ProfileExportVO profileExportVO = BeanUtil.copy(product, ProfileExportVO.class);
            profileExportVO.setFirstSizeExport(NumberConvertUtil.longConvertToString(product.getWidth(), 100));
            profileExportVO.setSecondSizeExport(NumberConvertUtil.longConvertToString(product.getThickness(), 100));
            profileExportVO.setThirdSizeExport(NumberConvertUtil.longConvertToString(product.getLength(), 100));
            return profileExportVO;
        }).collect(Collectors.toList());
        AtomicInteger atomicInteger = new AtomicInteger();
        //2023.04.19 制造编号加在加在件号前面

        list.forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //根据材质解析
            /**
             * 根据材质表id获取用料类型
             *  根据用料类型，解析出尺寸
             */
            ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
            ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
            Class<? extends ComputerHandler> clazz = computerType.getClazz();
            ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
            bean.analysis(item);
            /*设置判断*/
            //根据用料类型来设置厚度、宽度和长度
            if (item.getIsCalculate()) {
                try {
                    String specification = item.getSpecification();
                    item.setSecondSizeExport(specification);
                } catch (Exception e) {
                    throw new RuntimeException("角钢的规格不符合规范");
                }
            }
            //设置备件数量
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantityExport(item.getSparePartsQuantity().doubleValue() / 100);
            }
            //设置比重和标书价
            if (!CommonUtil.isNull(item.getBidPrice())) {
                item.setBidPriceExport(item.getBidPrice().doubleValue() / 100);
            }
            if (!CommonUtil.isNull(item.getProportion())) {
                item.setProportionExport(item.getProportion().doubleValue() / 100);
            }
            //设置是否计算
            item.setIsCalculateText(item.getIsCalculate() ? "是" : "否");
            //备注加上备件数量{}
            String sparePartsQuantity = "";
            if (!CommonUtil.isNull(item.getSparePartsQuantity()) && item.getSparePartsQuantity() != 0) {
                sparePartsQuantity = "备件数量" + item.getSparePartsQuantity().doubleValue() / 100 + "件";
            }
            item.setRemarks(item.getRemarks() == null ? "" : item.getRemarks() + sparePartsQuantity);

            //设置数量(数量+备件数量)
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setCountExport(item.getCount().doubleValue() / 100 + item.getSparePartsQuantity().doubleValue() / 100);
            } else {
                item.setCountExport(item.getCount().doubleValue() / 100);
            }
            if (item.getWeight() != null) {
                item.setWeightExport(item.getWeight().doubleValue() / 100);
            } else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        /*writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("一台管材型材"), 5, List.of(10, 11)));*/
        writeHandlers.add(new MyMergeHandler(List.of("一台管材型材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 18))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/profile.xlsx");
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "一台管材型材导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));

        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "一台管材型材");

        //计算列总和
        double total = list.stream().mapToDouble(ProfileExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */

        String param1 = projectDemandPlan.getManufacturingNumber() != null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1", param1);
        data.put("param2", param2);
        data.put("total", total);
        excelExportService.fill(data, "一台管材型材");

        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(StringUtils.isNotBlank(projectDemandPlan.getProjectDemandPlanBatch()), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlan.getProjectDemandPlanBatch())
                .eq(MaterialTypeDescription::getMaterialType, "型材")
                .last("limit 1");
        MaterialTypeDescription materialTypeDescriptions = materialTypeDescriptionMapper.selectOne(descriptionMPJLambdaWrapper);
        //备注数据
        List<RemarkVO> remarkVOS = new ArrayList<>();
        RemarkVO remarkVO = new RemarkVO();
        remarkVO.setSeq(1);
        remarkVO.setContent(Optional.ofNullable(materialTypeDescriptions).orElse(new MaterialTypeDescription()).getRemarks());
        remarkVOS.add(remarkVO);

        excelExportService.fill(new FillWrapper("remark", remarkVOS), "一台管材型材");
        excelExportService.export();
    }

    public void forgePieceExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {

            // 2023.07.14 如果 没有序号 就按照 制造编号材质 排序
            this.sortBySerialNumber(productDemandPlanTotals);

        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);

        }
        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<ForgePieceExportVO> list = BeanUtil.copyList(productDemandPlanTotals, ForgePieceExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        //2023.04.19 制造编号加在加在件号前面

        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            String sparePartsQuantity = "";
            if (!CommonUtil.isNull(item.getSparePartsQuantity()) && item.getSparePartsQuantity() != 0) {
                sparePartsQuantity = "备件数量" + item.getSparePartsQuantity().doubleValue() / 100 + "件";
            }
            item.setRemarks(item.getRemarks() == null ? "" : item.getRemarks() + sparePartsQuantity);
            //设置备件数量
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantityExport(item.getSparePartsQuantity().doubleValue() / 100);
            }
            //设置数量(数量+备件数量)
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setCountExport(item.getCount().doubleValue() / 100 + item.getSparePartsQuantity().doubleValue() / 100);
            } else {
                item.setCountExport(item.getCount().doubleValue() / 100);
            }
            if (item.getWeight() != null) {
                item.setWeightExport(item.getWeight().doubleValue() / 100);
            } else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        /*writeHandlers.add(new ExcelFillCellMergeStrategy(List.of("锻件"), 5, List.of(7, 8)));*/
        writeHandlers.add(new MyMergeHandler(List.of("锻件"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 11))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/forgepiece.xlsx");
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "锻件导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));

        //填充数据
        excelExportService.fill(new FillWrapper("list", list), "锻件");

        //计算列总和
        double total = list.stream().mapToDouble(ForgePieceExportVO::getWeightExport).sum();

        /**
         * 制造编号  和  计划编号
         */

        String param1 = projectDemandPlan.getManufacturingNumber() != null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1", param1);
        data.put("param2", param2);
        data.put("total", total);
        excelExportService.fill(data, "锻件");

        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "锻件")
                .eq(StringUtils.isNotBlank(projectDemandPlan.getProjectDemandPlanBatch()), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlan.getProjectDemandPlanBatch())
                .last("limit 1");
        MaterialTypeDescription materialTypeDescriptions = materialTypeDescriptionMapper.selectOne(descriptionMPJLambdaWrapper);
        //备注数据
        List<RemarkVO> remarkVOS = new ArrayList<>();
        RemarkVO remarkVO1 = new RemarkVO();
        remarkVO1.setSeq(1);
        remarkVO1.setContent(Optional.ofNullable(materialTypeDescriptions).orElse(new MaterialTypeDescription()).getRemarks());
        remarkVOS.add(remarkVO1);
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "锻件");

        excelExportService.export();
    }

    public void purchasedPartsExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {

        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {

            // 2023.07.14 如果 没有序号 就按照 制造编号材质 排序
            this.sortBySerialNumber(productDemandPlanTotals);

        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);

        }
        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<PurchasedPartsExportVO> list = BeanUtil.copyList(productDemandPlanTotals, PurchasedPartsExportVO.class);

        AtomicInteger atomicInteger = new AtomicInteger();
        //2023.04.19 制造编号加在加在件号前面
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            String sparePartsQuantity = "";
            if (!CommonUtil.isNull(item.getSparePartsQuantity()) && item.getSparePartsQuantity() != 0) {
                sparePartsQuantity = "备件数量" + item.getSparePartsQuantity().doubleValue() / 100 + "件";
            }
            item.setRemarks(item.getRemarks() == null ? "" : item.getRemarks() + sparePartsQuantity);
            //设置备件数量
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantityExport(item.getSparePartsQuantity().doubleValue() / 100);
            }
            //设置数量(数量+备件数量)
            //设置数量(数量+备件数量)
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setCountExport(item.getCount().doubleValue() / 100 + item.getSparePartsQuantity().doubleValue() / 100);
            } else {
                item.setCountExport(item.getCount().doubleValue() / 100);
            }
            if (item.getWeight() != null) {
                item.setWeightExport(item.getWeight().doubleValue() / 100);
            } else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        writeHandlers.add(new MyMergeHandler(List.of("外购件"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 9))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/purchasedparts.xlsx");
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "外购件导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        //比较 材质
        excelExportService.fill(new FillWrapper("list", list), "外购件");

        double total = list.stream().mapToDouble(PurchasedPartsExportVO::getWeightExport).sum();

        String param1 = projectDemandPlan.getManufacturingNumber() != null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1", param1);
        data.put("param2", param2);
        data.put("total", total);
        excelExportService.fill(data, "外购件");


        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "外购件");
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);
        //备注数据
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
        if (CommonUtil.listIsNotEmpty(materialTypeDescriptions)) {
            String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
            remarkVOS = new ArrayList<>();
            for (int i = 0; i < split.length; i++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(i + 1);
                remarkVO.setContent(split[i]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "外购件");

        excelExportService.export();
    }

    public void auxiliaryMaterialsExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {
            this.sortBySerialNumber(productDemandPlanTotals);
        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);
        }

        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<AuxiliaryMaterialsExportVO> list = BeanUtil.copyList(productDemandPlanTotals, AuxiliaryMaterialsExportVO.class);
        //比较 材质
        AtomicInteger atomicInteger = new AtomicInteger();
        //2023.04.19 制造编号加在加在件号前面
        list.stream().forEach(item -> {
            //自增序号
            item.setAutoincrementId(atomicInteger.incrementAndGet());
            //备注加上备件数量{}
            String sparePartsQuantity = "";
            if (!CommonUtil.isNull(item.getSparePartsQuantity()) && item.getSparePartsQuantity() != 0) {
                sparePartsQuantity = "备件数量" + item.getSparePartsQuantity().doubleValue() / 100 + "件";
            }
            item.setRemarks(item.getRemarks() == null ? "" : item.getRemarks());
            //设置备件数量
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setSparePartsQuantityExport(item.getSparePartsQuantity().doubleValue() / 100);
            }
            //设置数量(数量+备件数量)
            if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                item.setCountExport(item.getCount().doubleValue() / 100 + item.getSparePartsQuantity().doubleValue() / 100);
            } else {
                item.setCountExport(item.getCount().doubleValue() / 100);
            }
            if (item.getWeight() != null) {
                item.setWeightExport(item.getWeight().doubleValue() / 100);
            } else {
                item.setWeightExport(0.0);
            }
        });

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        writeHandlers.add(new MyMergeHandler(List.of("辅材"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 11))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/auxiliarymaterials.xlsx");
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "辅材导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));

        excelExportService.fill(new FillWrapper("list", list), "辅材");
        double total = list.stream().mapToDouble(AuxiliaryMaterialsExportVO::getWeightExport).sum();

        String param1 = projectDemandPlan.getManufacturingNumber() != null ? projectDemandPlan.getManufacturingNumber() : "";
        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param1", param1);
        data.put("param2", param2);
        data.put("total", total);
        excelExportService.fill(data, "辅材");

        MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
        descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                .eq(MaterialTypeDescription::getMaterialType, "辅材");
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);
        //备注数据
        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
        if (CommonUtil.listIsNotEmpty(materialTypeDescriptions)) {
            String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
            remarkVOS = new ArrayList<>();
            for (int i = 0; i < split.length; i++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(i + 1);
                remarkVO.setContent(split[i]);
                remarkVOS.add(remarkVO);
            }
        }
        excelExportService.fill(new FillWrapper("remark", remarkVOS), "辅材");

        excelExportService.export();
    }

    public void sparePartsExport(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.SPARE_PARTS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        List<ProductDemandPlanTotal> sortList = productDemandPlanTotals.stream().filter(item -> !CommonUtil.isNull(item.getSerialNumber())).collect(Collectors.toList());
        if (CommonUtil.listIsNotEmpty(sortList) && sortList.size() > 2) {
            this.sortBySerialNumber(productDemandPlanTotals);
        } else {
            this.sortByManufacturingNumberPartNo(productDemandPlanTotals);
        }
        if (!CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            throw new ErrorException("该类型下没有数据无需导出");
        }
        List<SparePartsImportVO> list = BeanUtil.copyList(productDemandPlanTotals, SparePartsImportVO.class);

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);

        writeHandlers.add(horizontalCellStyleStrategy);
        writeHandlers.add(new MyMergeHandler(List.of("备件"), 5 + list.size(), List.of(new CellRangeAddress(5 + list.size(), 5 + list.size(), 1, 11))));
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        String projectName = projectService.getById(projectDemandPlan.getProjectId()).getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/projectDemandPlanSpareParts.xlsx");
        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch() + "备件导出", response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        excelExportService.fill(new FillWrapper("list", list), "备件");

        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";
        HashMap<String, Object> data = new HashMap<>();
        data.put("param2", param2);
        excelExportService.fill(data, "备件");

        excelExportService.export();
    }


    public List<ProjectNameInDemandPlanVO> getProject() {
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(null);
        ArrayList<ProjectNameInDemandPlanVO> list = new ArrayList<>();
        ArrayList<ProjectDemandPlan> collect = projectDemandPlans.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() ->
                new TreeSet<>(Comparator.comparing(o -> o.getProjectId() + ";" + o.getProjectDemandPlanBatch()))
        ), ArrayList::new));
        log.info("去重后的集合：{}", collect);
        collect.forEach(
                item -> {
                    ProjectNameInDemandPlanVO build = ProjectNameInDemandPlanVO.builder().projectId(item.getProjectId() + "-" + item.getProjectDemandPlanBatch())
                            .projectName(projectService.getById(item.getProjectId()).getProjectName() + "-" + item.getProjectDemandPlanBatch()).build();
                    list.add(build);
                }
        );
        return list;
    }


    public void profileUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<BoardImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), BoardImportVO.class, MaterialType.PROFILE.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PROFILE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (item.getDeliveryTime().contains("-")) {
                        parse = sdf.parse(item.getDeliveryTime());
                    } else if (item.getDeliveryTime().contains("/")) {
                        parse = format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setMaterialType(MaterialType.PROFILE.getCode());
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                productDemandPlanTotalMapper.insert(copy);
            }
        });
    }

    public List<String> getPlanNo(String projectId, String materialTypeText) {
        String code = EnumUtil.getCode(DemandType.class, materialTypeText);
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProjectDemandPlan::getPlanNo)
                .eq(!CommonUtil.isNull(projectId), ProjectDemandPlan::getProjectId, projectId)
                .eq(!CommonUtil.isNull(materialTypeText), ProjectDemandPlan::getDemandType, code);
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        return projectDemandPlans.stream().map(ProjectDemandPlan::getPlanNo).collect(Collectors.toList());
    }

    public void forgePieceUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<ForgePieceImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), ForgePieceImportVO.class, MaterialType.FORGE_PIECE.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.FORGE_PIECE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(), ""));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (item.getDeliveryTime().contains("-")) {
                        parse = sdf.parse(item.getDeliveryTime());
                    } else if (item.getDeliveryTime().contains("/")) {
                        parse = format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setMaterialType(MaterialType.FORGE_PIECE.getCode());
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                productDemandPlanTotalMapper.insert(copy);
            }
        });
    }

    public void purchasedPartsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<PurchasedPartsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), PurchasedPartsImportVO.class, MaterialType.PURCHASED_PARTS.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.PURCHASED_PARTS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(), ""));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (item.getDeliveryTime().contains("-")) {
                        parse = sdf.parse(item.getDeliveryTime());
                    } else if (item.getDeliveryTime().contains("/")) {
                        parse = format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setMaterialType(MaterialType.PURCHASED_PARTS.getCode());
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                productDemandPlanTotalMapper.insert(copy);
            }
        });


    }

    public void auxiliaryMaterialsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<AuxiliaryMaterialsImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), AuxiliaryMaterialsImportVO.class, MaterialType.AUXILIARY_MATERIALS.getName());
        MPJLambdaWrapper<ProductDemandPlanTotal> planTotalMPJLambdaWrapper = new MPJLambdaWrapper<>();
        planTotalMPJLambdaWrapper.selectAll(ProductDemandPlanTotal.class)
                .eq(ProductDemandPlanTotal::getProjectDemandPlanId, dto.getProjectDemandPlanId())
                .eq(ProductDemandPlanTotal::getMaterialType, MaterialType.AUXILIARY_MATERIALS.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(planTotalMPJLambdaWrapper);
        if (CommonUtil.listIsNotEmpty(productDemandPlanTotals)) {
            for (ProductDemandPlanTotal productDemandPlanTotal : productDemandPlanTotals) {
                productDemandPlanTotalMapper.deleteById(productDemandPlanTotal);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                ProductDemandPlanTotal copy = BeanUtil.copy(item, ProductDemandPlanTotal.class);
                copy.setMaterialName(item.getMaterialName().replace(item.getSpecification(), ""));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (item.getDeliveryTime().contains("-")) {
                        parse = sdf.parse(item.getDeliveryTime());
                    } else if (item.getDeliveryTime().contains("/")) {
                        parse = format.parse(item.getDeliveryTime());
                    }

                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setDeliveryTime(parse);
                copy.setMaterialType(MaterialType.AUXILIARY_MATERIALS.getCode());
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                productDemandPlanTotalMapper.insert(copy);
            }
        });
    }

    public void export(HttpServletResponse response, ProductDemandPlanTotalImportDTO dto) {
        switch (dto.getDemandType()) {
            case 1:
                this.weldingExport(response, dto);
                break;
            case 2:
                this.paintExport(response, dto);
                break;

            case 3:
                this.exportBoard(response, dto);
                break;

            case 4:
                this.profileExport(response, dto);
                break;

            case 5:
                this.forgePieceExport(response, dto);
                break;
            case 6:
                this.purchasedPartsExport(response, dto);
                break;
            case 7:
                this.auxiliaryMaterialsExport(response, dto);
                break;
            case 8:
                sparePartsExport(response, dto);
                break;
            default:
                break;

        }

    }


    @Transactional(rollbackFor = Exception.class)
    public void weldingMaterialsUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<WeldingMaterialsImportVO> list = ExcelUtil.readSheet(file.getInputStream(), WeldingMaterialsImportVO.class, MaterialType.WELDING_MATERIALS.getName());
        if (!CommonUtil.listIsNotEmpty(list)) {
            throw new ErrorException("无数据");
        }

        MPJLambdaWrapper<WeldingMaterialDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(WeldingMaterialDemandPlan.class)
                .eq(WeldingMaterialDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());

        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)) {
            for (WeldingMaterialDemandPlan weldingMaterialDemandPlan : weldingMaterialDemandPlans) {
                weldingMaterialsDemandPlanMapper.deleteById(weldingMaterialDemandPlan);
            }
        }
        for (int i = 0; i < 2; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                WeldingMaterialDemandPlan copy = BeanUtil.copy(item, WeldingMaterialDemandPlan.class);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (StringUtils.isNotBlank(item.getDeliveryTime())) {
                        if (item.getDeliveryTime().contains("-")) {
                            parse = sdf.parse(item.getDeliveryTime());
                        } else if (item.getDeliveryTime().contains("/")) {
                            parse = format.parse(item.getDeliveryTime());
                        }
                        copy.setDeliveryTime(parse);
                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());
                copy.setSerialNumber(item.getId().intValue() / 100);
                weldingMaterialsDemandPlanMapper.insert(copy);
            }
        });

        //备注更新
        String partNo = list.get(list.size() - 1).getMaterialName();
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        if (CommonUtil.isNull(projectDemandPlan)) {
            return;
        }
        //根据项目id、物资类型和项目需求计划批次  更新说明
        UpdateWrapper<MaterialTypeDescription> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("project_id", projectDemandPlan.getProjectId())
                .eq("project_demand_plan_batch", projectDemandPlan.getProjectDemandPlanBatch())
                .eq("material_type", MaterialType.WELDING_MATERIALS.getName())
                .set("remarks", partNo);
        materialTypeDescriptionMapper.update(new MaterialTypeDescription(), updateWrapper);
    }


    @Transactional(rollbackFor = Exception.class)
    public void paintUpload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        LinkedList<PaintMaterialImportVO> list = ExcelUtil.
                readSheet(file.getInputStream(), PaintMaterialImportVO.class, MaterialType.PAINT.getName());
        MPJLambdaWrapper<PaintDemandPlan> wrapper = new MPJLambdaWrapper<PaintDemandPlan>();
        wrapper.selectAll(PaintDemandPlan.class)
                .eq(PaintDemandPlan::getProjectDemandPlanId, dto.getProjectDemandPlanId());
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(paintDemandPlans)) {
            for (PaintDemandPlan paintDemandPlan : paintDemandPlans) {
                paintDemandPlanMapper.deleteById(paintDemandPlan);
            }
        }
        for (int i = 0; i < 3; i++) {
            list.poll();
        }
        list.stream().forEach(item -> {
            if (!CommonUtil.isNull(item.getId())) {
                PaintDemandPlan copy = BeanUtil.copy(item, PaintDemandPlan.class);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

                Date parse = new Date();
                try {
                    if (StringUtils.isNotBlank(item.getDeliveryTime())) {
                        if (item.getDeliveryTime().contains("-")) {
                            parse = sdf.parse(item.getDeliveryTime());
                        } else if (item.getDeliveryTime().contains("/")) {
                            parse = format.parse(item.getDeliveryTime());
                        }
                        copy.setDeliveryTime(parse);
                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

                copy.setProjectDemandPlanId(dto.getProjectDemandPlanId());

                copy.setSerialNumber(item.getId().intValue());
                paintDemandPlanMapper.insert(copy);
            }
        });

        //导入数据最后几行
        int size = 0;
        for (int i = 0; i < list.size(); i++) {
            if (CommonUtil.isNull(list.get(i).getId())) {
                size = i;
                break;
            }
        }
        //备注更新
        StringBuilder remarks = new StringBuilder();
        for (int i = size + 1; i < list.size() - 1; i++) {
            String partNo = list.get(i).getPartNo();
            remarks.append(partNo).append("\n");
        }
        ProjectDemandPlan projectDemandPlan = projectDemandPlanMapper.selectById(dto.getProjectDemandPlanId());
        if (CommonUtil.isNull(projectDemandPlan)) {
            return;
        }
        //根据项目id、物资类型和项目需求计划批次  更新说明
        UpdateWrapper<MaterialTypeDescription> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("project_id", projectDemandPlan.getProjectId())
                .eq("project_demand_plan_batch", projectDemandPlan.getProjectDemandPlanBatch())
                .eq("material_type", MaterialType.PAINT.getName())
                .set("remarks", remarks.toString());
        materialTypeDescriptionMapper.update(new MaterialTypeDescription(), updateWrapper);
    }


    public void productDemandPlanTotalupload(MultipartFile file, ProductDemandPlanTotalImportDTO dto) throws IOException {
        switch (dto.getDemandType()) {


            case 3:
                this.productDemandPlanTotalRead(file, dto);
                break;

            case 4:
                this.profileUpload(file, dto);
                break;

            case 5:
                this.forgePieceUpload(file, dto);
                break;
            case 6:
                this.purchasedPartsUpload(file, dto);
                break;
            case 7:
                this.auxiliaryMaterialsUpload(file, dto);
                break;
            default:
                break;
        }
    }

    public List<ProjectDemandPlan> getProjectDemandPlanByProject(String projectId) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, projectId);
        return projectDemandPlanMapper.selectList(wrapper);
    }

    public List<ProjectDemandPlan> getProjectAndDemandType(String demandPlanNumber) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .like(ProjectDemandPlan::getPlanNo, demandPlanNumber);
        return projectDemandPlanMapper.selectList(wrapper);
    }

    private List<MaterialTypeDescriptionVO> getMaterialTypeByProductId(String projectId, String projectDemandPlanBatch) {
        MPJLambdaWrapper<MaterialTypeDescription> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(MaterialTypeDescription.class)
                .eq(!CommonUtil.isNull(projectId), MaterialTypeDescription::getProjectId, projectId)
                .eq(!CommonUtil.isNull(projectDemandPlanBatch), MaterialTypeDescription::getProjectDemandPlanBatch, projectDemandPlanBatch);
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(wrapper);
        return BeanUtil.copyList(materialTypeDescriptions, MaterialTypeDescriptionVO.class);
    }


    public void projectDemandPlanExport(HttpServletResponse response, ProjectDemandPlanExport dto) {
        //根据所有产品id所有的产品需求计划明细（pass）
        //根据项目id 和批次查询项目需求计划id
        List<ProjectDemandPlan> list = projectDemandPlanMapper.getProjectDemandPlanIdList(dto.getId(), dto.getProjectDemandPlanBatch());
        List<String> projectDemandPlanIds = list.stream().map(ProjectDemandPlan::getId).collect(Collectors.toList());
        List<String> projectDemandPlanDemandNames = list.stream().map(projectDemandPlan -> EnumUtil.getValue(DemandType.class, projectDemandPlan.getDemandType())).collect(Collectors.toList());

        List<String> demandTypeNameList = Arrays.stream(DemandType.values()).map(DemandType::getName).collect(Collectors.toList());
        demandTypeNameList.removeAll(projectDemandPlanDemandNames);
        //通过产品信息表id获取制造编号和计划编号
        ProjectDemandPlan projectDemandPlan = list.get(0);
        //这里的物资类型根据产品id和对应批次,   里面的备注是需要的材料说明

        ProjectVO projectVO = projectService.getById(dto.getId());
        String projectName = projectVO.getProjectName();
        InputStream resourceAsStream = this.getClass().getResourceAsStream("/static/template/projectTemplate.xlsx");

        List<WriteHandler> writeHandlers = new ArrayList<>();
        //设置内容样式
        WriteCellStyle contentWriteCellStyle = new WriteCellStyle();
        contentWriteCellStyle.setHorizontalAlignment(HorizontalAlignment.LEFT);
        HorizontalCellStyleStrategy horizontalCellStyleStrategy = new HorizontalCellStyleStrategy(null, contentWriteCellStyle);
        CustomSheetWriteHandler customSheetWriteHandler = new CustomSheetWriteHandler(demandTypeNameList);
        writeHandlers.add(customSheetWriteHandler);
        writeHandlers.add(horizontalCellStyleStrategy);

        String param2 = projectDemandPlan.getPlanNo() != null ? projectDemandPlan.getPlanNo() : "";

        ExcelExportService excelExportService = new ExcelExportService(projectName + projectDemandPlan.getProjectDemandPlanBatch(), response, resourceAsStream, writeHandlers.toArray(new WriteHandler[0]));
        for (String demandPlanTypeName : projectDemandPlanDemandNames) {
            if (DemandType.WELDING_MATERIALS.getName().equals(demandPlanTypeName)) {
                projectDemandPlanWeldExport(projectDemandPlanIds, projectVO, writeHandlers, projectDemandPlan, excelExportService);
            } else if (DemandType.PAINT.getName().equals(demandPlanTypeName)) {
                projectDemandPlanPaintExport(projectDemandPlanIds, projectVO, writeHandlers, projectDemandPlan, excelExportService);
            } else {
                projectDemandPlanTotalExport(projectDemandPlanIds, param2, writeHandlers, projectDemandPlan, excelExportService);
            }
        }
        //项目编号:根据产品需求计划id查询产品信息表，在产品信息表中获取项目id，获得项目信息
        String projectNo = projectVO.getProjectNo();
        //项目名称
        HashMap<String, Object> data = new HashMap<>();
        data.put("param2", param2);
        if (CommonUtil.isNull(projectDemandPlan.getCompiler())) {
            data.put("organization", "");
        } else {
            data.put("organization", userService.getUserInfoByID(projectDemandPlan.getCompiler()).getCHName());
        }

        data.put("organizationTime", projectDemandPlan.getCompileTime());
        data.put("engineer", projectDemandPlan.getProofreader());
        data.put("process", projectDemandPlan.getProofreadingTime());
        data.put("manager", projectDemandPlan.getReviewer());
        data.put("reviewTime", projectDemandPlan.getReviewTime());
        data.put("approval", projectDemandPlan.getChecker());
        data.put("approvalTime", projectDemandPlan.getCheckTime());
        data.put("projectNo", projectNo);
        data.put("projectName", projectName);
        excelExportService.fill(data, "封面");

        ArrayList<RemarkVO> remarkVOS = new ArrayList<>();
        if (!CommonUtil.isNull(projectDemandPlan.getPreparationDescription())) {

            String[] split = projectDemandPlan.getPreparationDescription().split("\n");
            for (int i = 0; i < split.length; i++) {
                RemarkVO remarkVO = new RemarkVO();
                remarkVO.setSeq(i + 1);
                remarkVO.setContent(split[i]);
                remarkVOS.add(remarkVO);
            }
            excelExportService.fill(new FillWrapper("explain", remarkVOS), "编制说明");
        } else {
            HashMap<String, Object> hashMap = new HashMap<>();
            hashMap.put("explain.content", "");
            excelExportService.fill(hashMap, "编制说明");
        }
        excelExportService.export();
    }

    public void projectDemandPlanTotalExport(List<String> list, String param2, List<WriteHandler> writeHandlers, ProjectDemandPlan projectDemandPlan, ExcelExportService excelExportService) {
        List<ProductDemandPlanTotal> totals = new ArrayList<>();
        for (String s : list) {
            MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
            wrapper.selectAll(ProductDemandPlanTotal.class)
                    .eq(ProductDemandPlanTotal::getProjectDemandPlanId, s)
                    .orderByAsc(ProductDemandPlanDetails::getPartNo);
            List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(wrapper);
            totals.addAll(productDemandPlanTotals);
        }

        List<ProjectDemandPlanExportVO> vos = BeanUtil.copyList(totals, ProjectDemandPlanExportVO.class);
        List<ProjectDemandPlanExportVO> vocollect = vos.stream().peek(item -> item.setMaterialTypeText(EnumUtil.getValue(MaterialType.class, item.getMaterialType()))).collect(Collectors.toList());
        //根据件号排序
        PartNoSortUtil.sort(vocollect);
        List<MaterialTypeDescriptionVO> materialTypes = this.getMaterialTypeByProductId(projectDemandPlan.getProjectId(), projectDemandPlan.getProjectDemandPlanBatch());

        //将数据按照物资类型分组
        Map<String, List<ProjectDemandPlanExportVO>> map = vocollect.stream().collect(Collectors.groupingBy(ProjectDemandPlanExportVO::getMaterialTypeText));
        for (MaterialTypeDescriptionVO type : materialTypes) {
            String materialType = type.getMaterialType();
            if (map.get(materialType) != null) {
                //该类型存在数据不存,map获取结果可能为null
                if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 12))));
                } else if (materialType.equals(MaterialType.AUXILIARY_MATERIALS.getName()) || materialType.equals(MaterialType.PURCHASED_PARTS.getName())) {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 9))));
                } else {
                    writeHandlers.add(new MyMergeHandler(List.of(materialType), 5 + map.get(materialType).size(), List.of(new CellRangeAddress(5 + map.get(materialType).size(), 5 + map.get(materialType).size(), 1, 9))));
                }
            }
        }

        String manufacturingNumber = "";
        if (!CommonUtil.isNull(projectDemandPlan.getIdListString())) {
            String idListString = projectDemandPlan.getIdListString();
            ArrayList<String> arrayList = new ArrayList<>();

            String[] splitPart = idListString.substring(1, idListString.length() - 1).split(",");
            for (int i = 0; i < splitPart.length; i++) {
                splitPart[i] = splitPart[i].trim();
            }
            arrayList.addAll(List.of(splitPart));

            List<ProductDemandPlan> productDemandPlans = productDemandPlanMapper.selectBatchIds(arrayList);
            //获得制造编号+在件号上面

            for (ProductDemandPlan productDemandPlan : productDemandPlans) {
                manufacturingNumber = manufacturingNumber + productDemandPlan.getManufacturingNumber() + "&";
            }
        }

        //制造编号
        String param1 = manufacturingNumber;
        for (MaterialTypeDescriptionVO type : materialTypes) {
            String materialType = type.getMaterialType();
            //自增序号，列表数据
            List<ProjectDemandPlanExportVO> szpExportVOS = map.get(materialType);
            if (CommonUtil.isNull(szpExportVOS)) {
                continue;
            }
            List<ProjectDemandPlanExportVO> voList = szpExportVOS.stream().peek(item -> {
                if (item.getMaterialType() == 4) {
                    item.setIngredientsType("");
                }
            }).collect(Collectors.toList());

            List<RemarkVO> remarkVOS = new ArrayList<>();
            HashMap<String, Object> data = new HashMap<>();
            data.put("param3", materialType);
            if (CommonUtil.listIsNotEmpty(voList)) {
                AtomicInteger num = new AtomicInteger();
                for (ProjectDemandPlanExportVO vo : voList) {
                    vo.setAutoincrementId(num.incrementAndGet());
                }
                for (ProjectDemandPlanExportVO item : voList) {
                    ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, item.getIngredientsType());
                    ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
                    Class<? extends ComputerHandler> clazz = computerType.getClazz();
                    ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
                    bean.analysis(item);
                    //根据用料类型来设置厚度、宽度和长度

                    String ingredientsType = item.getIngredientsType();
                    if (!CommonUtil.isNull(ingredientsType)) {
                        //第三尺寸是长度
                        //第二尺寸是厚度
                        //第一尺寸是直径
                        if (ingredientsType.equals(ComputerType.TUBULAR_SHAPE.getCode())) {
                            //管形
                            item.setThirdSizeExport(item.getThirdSize());
                            item.setSecondSizeExport(item.getSecondSize());
                            item.setFirstSizeExport(item.getFirstSize());
                        } else if (ingredientsType.equals(ComputerType.SQUARE.getCode())) {
                            //方形 2023.0509
                            item.setThirdSizeExport(item.getFirstSize());
                            item.setFirstSizeExport(item.getFirstSize());
                            item.setSecondSizeExport(item.getSecondSize());
                        } else if (ingredientsType.equals(ComputerType.RECTANGLE.getCode())) {
                            //矩形
                            item.setThirdSizeExport(item.getFirstSize());
                            item.setSecondSizeExport(item.getThirdSize());
                            item.setFirstSizeExport(item.getSecondSize());
                        } else if (ingredientsType.equals(ComputerType.STICK_SHAPE.getCode())) {
                            //棒形
                            item.setThirdSizeExport(item.getSecondSize());
                            item.setFirstSizeExport(item.getFirstSize());
                        } else if (ingredientsType.equals(ComputerType.ANNULAR.getCode())) {
                            //环形：从规格中解析出来
                            String specification = item.getSpecification();
                            //长度
                            String firstSize = specification.substring(specification.indexOf("X") + 1, specification.lastIndexOf("X"));
                            //宽度
                            String secondSize = specification.substring(specification.lastIndexOf("X") + 1);
                            //厚度
                            String thirdSize = specification.substring(1, specification.indexOf("X"));
                            //厚度
                            item.setSecondSizeExport(thirdSize);
                            //长度
                            item.setThirdSizeExport(firstSize);
                            //宽度
                            item.setFirstSizeExport(secondSize);

                        } else if (ingredientsType.equals(ComputerType.CIRCULAR.getCode())) {
                            //圆形
                            item.setSecondSizeExport(item.getSecondSize());
                            item.setFirstSizeExport(item.getFirstSize());
                        } else if (ingredientsType.equals(ComputerType.DRUM.getCode())) {
                            //根据规格拆分
                            String specification = item.getSpecification();
                            //δ48X350X175   拆分规则如下
                            //厚度   直径  长度
                            int lastIndexOf = specification.lastIndexOf("X");
                            int indexOf = specification.indexOf("X");
                            item.setThirdSizeExport(specification.substring(lastIndexOf + 1));
                            item.setFirstSizeExport(specification.substring(indexOf + 1, lastIndexOf));
                            item.setSecondSizeExport(specification.substring(1, indexOf));
                        } else {
                            item.setThirdSizeExport(item.getThirdSize());
                            item.setSecondSizeExport(item.getSecondSize());
                            item.setFirstSizeExport(item.getFirstSize());
                        }
                    }
                    if (item.getIsCalculate()) {
                        try {
                            String specification = item.getSpecification();
                            item.setSecondSizeExport(specification);
                        } catch (Exception e) {
                            throw new RuntimeException("角钢的规格不符合规范");
                        }
                    }
                    if (!CommonUtil.isNull(item.getManufacturingNumberPartNo())) {
                        item.setPartNo(item.getManufacturingNumberPartNo());
                    }

                    //2023/02/01  如果有备件，导出就在备注里面加上：备件+数量
                    if (!CommonUtil.isNull(item.getSparePartsQuantity())) {
                        if (item.getSparePartsQuantity() > 0) {
                            item.setRemarks(item.getRemarks() + "备件" + item.getSparePartsQuantity() / 100 + "件");
                        }
                        item.setCountExport((item.getCount().doubleValue() + item.getSparePartsQuantity().doubleValue()) / 100);
                    } else {
                        item.setCountExport(item.getCount().doubleValue() / 100);
                    }
                    if (!CommonUtil.isNull(item.getWeight())) {
                        item.setWeightExport(item.getWeight().doubleValue() / 100);
                    }
                }
                //计算列总和
                double total = voList.stream().filter(item -> !CommonUtil.isNull(item.getWeightExport())).mapToDouble(ProjectDemandPlanExportVO::getWeightExport).sum();
                //数据库尺寸是扩大一百倍的，这里需要缩小
                //自定义参数数据
                data.put("param1", param1);
                data.put("param2", param2);
                data.put("total", total);
                //备注数据:根据产品id查询
                String remarks = type.getRemarks();
                if (CommonUtil.isNull(remarks)) {
                    RemarkVO remarkVO = new RemarkVO();
                    remarkVOS.add(remarkVO);
                } else {
                    String[] split = remarks.split("\n");
                    for (int j = 0; j < split.length; j++) {
                        RemarkVO remarkVO = new RemarkVO();
                        remarkVO.setSeq(j + 1);
                        remarkVO.setContent(split[j]);
                        remarkVOS.add(remarkVO);
                    }
                }
            }
            voList.forEach(item -> {
                if (CommonUtil.isNull(item.getSerialNumber())) {
                    item.setAutoincrementId(item.getSerialNumber());
                }
            });
            if (materialType.equals(MaterialType.BOARD.getName()) || materialType.equals(MaterialType.PROFILE.getName())) {
                excelExportService.fill(new FillWrapper("list", voList), materialType);
            } else if (materialType.equals(MaterialType.AUXILIARY_MATERIALS.getName()) || materialType.equals(MaterialType.PURCHASED_PARTS.getName())) {
                List<ProjectAuxiliaryExportVO> exportVOS = BeanUtil.copyList(voList, ProjectAuxiliaryExportVO.class);
                exportVOS.forEach(item -> item.setMaterialNameAndSpecification(item.getMaterialName() + "-" + item.getSpecification()));
                excelExportService.fill(new FillWrapper("list", exportVOS), materialType);
            } else {
                List<ProjectCopyExportVO> copyVOS = BeanUtil.copyList(voList, ProjectCopyExportVO.class);
                copyVOS.forEach(item -> item.setMaterialNameAndSpecification(item.getMaterialName() + "-" + item.getSpecification()));
                excelExportService.fill(new FillWrapper("list", copyVOS), materialType);
            }
            //备注
            excelExportService.fill(new FillWrapper("remark", remarkVOS), materialType);
            //表头
            excelExportService.fill(data, materialType);
        }
    }


    public void projectDemandPlanPaintExport(List<String> list, ProjectVO projectVO, List<WriteHandler> writeHandlers, ProjectDemandPlan projectDemandPlan, ExcelExportService excelExportService) {
        QueryWrapper<PaintDemandPlan> paintWrapper = new QueryWrapper<>();
        paintWrapper.in("project_demand_plan_id", list);
        List<PaintDemandPlan> paintDemandPlans = paintDemandPlanMapper.selectList(paintWrapper);

        List<PaintExportVO> paintList = BeanUtil.copyList(paintDemandPlans, PaintExportVO.class);
        ArrayList<RemarkVO> remarkPaintVOS = new ArrayList<>();
        HashMap<String, Object> dataPaint = new HashMap<>();
        List<PaintExportVO> collect = new ArrayList<>();
        if (CommonUtil.listIsNotEmpty(paintDemandPlans)) {
            AtomicInteger atomicInteger = new AtomicInteger();
            paintList.forEach(item -> {
                //自增序号
                item.setAutoincrementId(atomicInteger.incrementAndGet());
                item.setCount(item.getCount() / 100);
                item.setArea(item.getArea() / 100);
                //计算总面积
                item.setTotalArea(item.getArea().doubleValue() * item.getCount());
            });

            //计算面积总和
            double total = paintList.stream().mapToDouble(PaintExportVO::getTotalArea).sum();
            writeHandlers.add(new MyMergeHandler(List.of("油漆"), 4 + paintList.size(), List.of(new CellRangeAddress(4 + paintList.size(), 4 + paintList.size(), 1, 10))));

            //工程名称:项目需求计划表关联id，查询获得项目id
            String param1 = projectVO.getProjectName();
            //计划编号
            String param2 = projectDemandPlan.getPlanNo();
            //编号
            String param3 = projectVO.getProjectNo();

            dataPaint.put("param1", param1);
            dataPaint.put("param2", projectDemandPlan.getPlanNo());
            dataPaint.put("param3", param3);
            dataPaint.put("total", total);

            MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
            descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                    .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                    .eq(MaterialTypeDescription::getMaterialType, "油漆");
            List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);

            if (CommonUtil.listIsNotEmpty(materialTypeDescriptions)) {
                String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
                log.info("备注：{}", split[0]);
                remarkPaintVOS = new ArrayList<>();
                for (int i = 0; i < split.length; i++) {
                    RemarkVO remarkVO = new RemarkVO();
                    remarkVO.setSeq(i + 1);
                    remarkVO.setContent(split[i]);
                    remarkPaintVOS.add(remarkVO);
                }
            }
            collect = paintList.stream().peek(item -> item.setMaterialNameAndSize(item.getMaterialName() + item.getSize())).collect(Collectors.toList());
        }
        collect.forEach(item -> {
            if (CommonUtil.isNull(item.getSerialNumber())) {
                item.setAutoincrementId(item.getSerialNumber());
            }
        });
        excelExportService.fill(new FillWrapper("list", collect), "油漆");
        excelExportService.fill(new FillWrapper("remark", remarkPaintVOS), "油漆");
        excelExportService.fill(dataPaint, "油漆");
    }

    public void projectDemandPlanWeldExport(List<String> list, ProjectVO projectVO, List<WriteHandler> writeHandlers, ProjectDemandPlan projectDemandPlan, ExcelExportService excelExportService) {
        QueryWrapper<WeldingMaterialDemandPlan> weldWrapper = new QueryWrapper<>();
        weldWrapper.in("project_demand_plan_id", list);
        List<WeldingMaterialDemandPlan> weldingMaterialDemandPlans = weldingMaterialsDemandPlanMapper.selectList(weldWrapper);

        List<WeldingMaterialsExportVO> weldlist = BeanUtil.copyList(weldingMaterialDemandPlans, WeldingMaterialsExportVO.class);
        ArrayList<RemarkVO> remarkWeldVOS = new ArrayList<>();
        HashMap<String, Object> dataWeld = new HashMap<>();
        if (CommonUtil.listIsNotEmpty(weldingMaterialDemandPlans)) {
            AtomicInteger atomicInteger = new AtomicInteger();
            weldlist.forEach(item -> {
                //自增序号
                item.setId(String.valueOf(atomicInteger.incrementAndGet()));
                //计算总重
                if (CommonUtil.isNull(item.getCount())) {
                    item.setCount(1);
                }
                item.setTotalWeight(item.getWeight().doubleValue() / 100 * item.getCount());
            });
            //计算重量总和
            double total = weldlist.stream().mapToDouble(WeldingMaterialsExportVO::getTotalWeight).sum();
            writeHandlers.add(new MyMergeHandler(List.of("焊材"), 4 + weldlist.size(), List.of(new CellRangeAddress(4 + weldlist.size(), 4 + weldlist.size(), 1, 10))));
            //工程名称:项目需求计划表关联id，查询获得项目id
            String param1 = projectVO.getProjectName();
            //计划编号
            String param2 = projectDemandPlan.getPlanNo();
            //焊材列表页面
            dataWeld.put("param1", param1);
            dataWeld.put("param2", projectDemandPlan.getPlanNo());
            dataWeld.put("total", total);
            //备注
            MPJLambdaWrapper<MaterialTypeDescription> descriptionMPJLambdaWrapper = new MPJLambdaWrapper<>();
            descriptionMPJLambdaWrapper.selectAll(MaterialTypeDescription.class)
                    .eq(MaterialTypeDescription::getProjectId, projectDemandPlan.getProjectId())
                    .eq(MaterialTypeDescription::getMaterialType, "焊材");
            List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(descriptionMPJLambdaWrapper);

            if (CommonUtil.listIsNotEmpty(materialTypeDescriptions)) {
                String[] split = materialTypeDescriptions.get(0).getRemarks().split("\n");
                remarkWeldVOS = new ArrayList<>();
                for (int i = 0; i < split.length; i++) {
                    RemarkVO remarkVO = new RemarkVO();
                    remarkVO.setSeq(i + 1);
                    remarkVO.setContent(split[i]);
                    remarkWeldVOS.add(remarkVO);
                }
            }
        }
        weldlist.forEach(item -> {
            if (CommonUtil.isNull(item.getSerialNumber())) {
                item.setIdExport((long) item.getSerialNumber());
            }
        });
        excelExportService.fill(new FillWrapper("list", weldlist), "焊材");
        excelExportService.fill(new FillWrapper("remark", remarkWeldVOS), "焊材");
        excelExportService.fill(dataWeld, "焊材");
    }


    public void generateMaterialEntityViewVOList(String projectId, String projectDemandPlanBatch, List<String> typeList, Set<Integer> collectInteger) {

        for (String s : typeList) {
            MaterialTypeDescription materialTypeDescription = new MaterialTypeDescription();
            materialTypeDescription.setRemarks("");
            materialTypeDescription.setProjectDemandPlanBatch(projectDemandPlanBatch);
            materialTypeDescription.setMaterialType(s);
            materialTypeDescription.setProjectId(projectId);
            materialTypeDescriptionMapper.insert(materialTypeDescription);
        }


    }

    /**
     * 根据项目id、批次和物资类型查询材料说明
     * @param projectId
     * @param batch
     * @param name
     * @return
     */
    public String getMaterialDescription(String projectId, String batch, String name) {
        MPJLambdaWrapper<MaterialTypeDescription> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(MaterialTypeDescription::getRemarks)
                .eq(!CommonUtil.isNull(projectId), MaterialTypeDescription::getProjectId, projectId)
                .eq(!CommonUtil.isNull(batch), MaterialTypeDescription::getProjectDemandPlanBatch, batch)
                .eq(!CommonUtil.isNull(name), MaterialTypeDescription::getMaterialType, name);
        List<MaterialTypeDescription> materialTypeDescriptions = materialTypeDescriptionMapper.selectList(wrapper);
        if (CommonUtil.listIsNotEmpty(materialTypeDescriptions)) {
            return materialTypeDescriptions.get(0).getRemarks();
        } else {
            return "";
        }
    }

    /**
     * 不依赖产品需求计划生成项目需求计划
     * @author szp
     * @date 2023/7/28 15:11
     */
    @Transactional(rollbackFor = Exception.class)
    public void easyGenerateProjectDemandPlan(EasyGenerateProjectDemandPlanDTO dto) {
        MPJLambdaWrapper<ProjectDemandPlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(ProjectDemandPlan.class)
                .eq(ProjectDemandPlan::getProjectId, dto.getProjectId());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(wrapper);
        Integer max;

        Set<Integer> integerSet = projectDemandPlans.stream().map(item -> {
            Integer integer;
            if (CommonUtil.isNull(item.getProjectDemandPlanBatch())) {
                integer = 0;
            } else {
                integer = Integer.valueOf(item.getProjectDemandPlanBatch().substring(1, item.getProjectDemandPlanBatch().length() - 2));
            }
            return integer;
        }).collect(Collectors.toSet());
        //已有批次最大值
        if (!CommonUtil.listIsNotEmpty(projectDemandPlans)) {
            max = 0;
        } else {
            max = Collections.max(integerSet);
        }
        List<String> collect = Arrays.stream(dto.getMaterialTypeList()).collect(Collectors.toList());
        Set<Integer> set = collect.stream().map(item -> {
            return Integer.valueOf(EnumUtil.getCode(DemandType.class, item));
        }).collect(Collectors.toSet());

        //生成材料说明
        this.generateMaterialEntityViewVOList(dto.getProjectId(), "第" + (max + 1) + "批次", collect, set);
        for (Integer integer : set) {
            /*                                                                        */
            ProjectDemandPlan projectDemandPlan = this.returnProjectDemandPlan(dto.getProjectId(), max, integer);
            projectDemandPlanMapper.insert(projectDemandPlan);
        }
    }

    /**
     * @param id   项目id
     * @param max  已有的最大批次
     * @param code 需求计划类型 code
     * @author szp
     * @date 2023/7/28 8:48
     */
    public ProjectDemandPlan returnProjectDemandPlan(String id, Integer max, Integer code) {
        ProjectDemandPlan demandPlan = new ProjectDemandPlan();
        demandPlan.setProjectId(id);
        int randomInt = new Random().nextInt(10000) + 10000;
        demandPlan.setPlanNo("计划编号" + randomInt);
        demandPlan.setCompiler(ThreadLocalUser.get().getUserId());
        demandPlan.setDemandType(code);
        demandPlan.setProjectDemandPlanBatch("第" + (max + 1) + "批次");
        return demandPlan;
    }


    public List<ProjectDemandPlanInfoVO> selectByProjectIds(ProjectDemanPlanInfoQueryDTO dto) {
        MPJLambdaWrapper<ProjectDemandPlan> lambdaWrapper = new MPJLambdaWrapper<>();
        lambdaWrapper.select(ProjectDemandPlan::getProjectId, ProjectDemandPlan::getPlanNo
                , ProjectDemandPlan::getId, ProjectDemandPlan::getProjectDemandPlanBatch, ProjectDemandPlan::getDemandType);
        lambdaWrapper.in(ProjectDemandPlan::getProjectId, dto.getProjectIds());
        List<ProjectDemandPlan> projectDemandPlans = projectDemandPlanMapper.selectList(lambdaWrapper);

        MPJLambdaWrapper<PurchasePlan> wrapper = new MPJLambdaWrapper<>();
        wrapper.selectAll(PurchasePlan.class)
                .in(PurchasePlan::getProjectId, dto.getProjectIds());
        List<PurchasePlan> purchasePlanList = purchasePlanMapper.selectList(wrapper);
        if (!CommonUtil.listIsNotEmpty(purchasePlanList)) {
            throw new ErrorException("所选项目下没有采购计划");
        }

        return projectDemandPlans.stream().map(item -> ProjectDemandPlanInfoVO.builder()
                .projectId(item.getProjectId())
                .projectDemanPlanId(item.getId())
                .projectDemanPlanNo(item.getPlanNo())
                .projectDemandPlanType(item.getDemandType())
                .projectDemandPlanBatch(item.getProjectDemandPlanBatch()).build()).collect(Collectors.toList());
    }


    public Map<String, Long> analysisSpecification(String ingredientsType, String specification) {
        ComputerType enumByCode = EnumUtil.getEnumByCode(ComputerType.class, ingredientsType);
        ComputerType computerType = Optional.ofNullable(enumByCode).orElse(ComputerType.DEFAULT);
        Class<? extends ComputerHandler> clazz = computerType.getClazz();
        ComputerHandler bean = ApplicationContextUtil.getBean(clazz);
        Map<String, String> map = bean.analysis(specification, ingredientsType);
        if (CommonUtil.isNull(map)) {
            return new HashMap<>();
        }

        String width = map.get("width");
        double widthDouble = Double.parseDouble(width) * 100;
        long widthLong = StringUtils.isNotBlank(width) ? Long.parseLong(NumberConvertUtil.doubleToString(widthDouble)) : 0;
        String thickness = StringUtils.isNotBlank(map.get("thickness")) ? map.get("thickness") : "0";
        double thicknessDouble = Double.parseDouble(thickness) * 100;
        long thicknessLong = StringUtils.isNotBlank(thickness) ? Long.parseLong(NumberConvertUtil.doubleToString(thicknessDouble)) : 0;
        String length = map.get("length");
        double lengthDouble = Double.parseDouble(length) * 100;
        long lengthLong = StringUtils.isNotBlank(length) ? Long.parseLong(NumberConvertUtil.doubleToString(lengthDouble)) : 0;

        Map<String, Long> hashMap = new HashMap<>();
        hashMap.put("width", widthLong);
        hashMap.put("thickness", thicknessLong);
        hashMap.put("length", lengthLong);
        return hashMap;
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateSpecificationX() {
        MPJLambdaWrapper<ProductDemandPlanTotal> wrapper = new MPJLambdaWrapper<>();
        wrapper.select(ProductDemandPlanTotal::getId, ProductDemandPlanTotal::getSpecification, ProductDemandPlanTotal::getMaterialType)
                .in(ProductDemandPlanTotal::getMaterialType, MaterialType.BOARD.getCode(), MaterialType.PROFILE.getCode());
        List<ProductDemandPlanTotal> productDemandPlanTotals = productDemandPlanTotalMapper.selectList(wrapper);

        productDemandPlanTotals.forEach(item -> {
            if (StringUtils.isNotBlank(item.getSpecification())) {
                String newSpecification = item.getSpecification().replaceAll("X", "*");
                item.setSpecification(newSpecification);
                productDemandPlanTotalMapper.updateById(item);
            }
        });
    }

}
