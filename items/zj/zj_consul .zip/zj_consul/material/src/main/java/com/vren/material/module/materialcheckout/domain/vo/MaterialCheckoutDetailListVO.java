package com.vren.material.module.materialcheckout.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @Description MaterialCheckoutDetailListVO
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */
@Data
@Builder
@AllArgsConstructor
@Accessors(chain = true)
public class MaterialCheckoutDetailListVO {

    @ApiModelProperty("序号")
    private String serialNum;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("限额数量")
    private String quantityRequired;

    @ApiModelProperty("已领数量")
    private String pickedQuantity;

    @ApiModelProperty("申领数量")
    private String applyQuantity;

    @ApiModelProperty("实领数量")
    private String actualPickedQuantity;

    @ApiModelProperty("税前单价")
    private String preTaxPrice;

    @ApiModelProperty("金额")
    private String money;

    @ApiModelProperty("税率")
    private String taxRate;

    @ApiModelProperty("税额")
    private String tax;

    @ApiModelProperty("价税合计金额")
    private String materialTotalPrice;


}
