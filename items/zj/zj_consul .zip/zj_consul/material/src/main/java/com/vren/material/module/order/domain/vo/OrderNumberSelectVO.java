package com.vren.material.module.order.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * @author GR
 * &#064;time  2023-04-14-08-58
 **/
@Data
@Builder
public class OrderNumberSelectVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("订单编号")
    private String orderNumber;
}
