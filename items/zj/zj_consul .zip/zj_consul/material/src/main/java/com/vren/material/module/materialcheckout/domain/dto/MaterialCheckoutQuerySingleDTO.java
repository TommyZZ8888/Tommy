package com.vren.material.module.materialcheckout.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialCheckoutQuerySingleDTO {
    @ApiModelProperty("领料单id")
    private String id;
}
