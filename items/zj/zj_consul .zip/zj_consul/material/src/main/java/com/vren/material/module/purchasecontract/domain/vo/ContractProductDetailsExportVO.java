package com.vren.material.module.purchasecontract.domain.vo;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import com.alibaba.excel.annotation.write.style.ContentStyle;
import com.alibaba.excel.enums.BooleanEnum;
import com.alibaba.excel.enums.poi.HorizontalAlignmentEnum;
import com.alibaba.excel.enums.poi.VerticalAlignmentEnum;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ContractProductDetailsExportVO {

    @ApiModelProperty("id")
    @ExcelIgnore
    private String id;

    @ApiModelProperty("序号")
    @ExcelProperty("序号")
    private Integer number;

    @ApiModelProperty("入库编号")
    @ExcelProperty("入库编号")
    private String warehousingNo;

    @ApiModelProperty("材料名称")
    @ExcelProperty("物资名称")
    private String materialName;


    @ApiModelProperty("规格")
    @ExcelProperty("规格型号2")
    private String size;

    @ApiModelProperty("厚度")
    @ExcelProperty("厚度")
    private String thickness;

    @ApiModelProperty("宽度")
    @ExcelProperty("宽度")
    private String width;

    @ApiModelProperty("长度")
    @ExcelProperty("长度")
    private String length;

    @ApiModelProperty("材质")
    @ExcelProperty("材质")
    private String texture;

    @ApiModelProperty("执行标准")
    @ExcelProperty("执行标准")
    private String executiveStandards;

    @ApiModelProperty("用料单位")
    @ExcelProperty("单位1")
    private String useMaterialUnit;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelIgnore
    private Long purchaseAmount;

    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelProperty(value = "数量")
    private Double purchaseAmountExportTwo;


    @ApiModelProperty("采购数量")
    @ConversionNumber
    @ExcelProperty("数量")
    private Double purchaseAmountExport;

    @ApiModelProperty("单位2")
    @ExcelProperty("单位2")
    private String unitTwo;

    @ApiModelProperty("采购重量")
    @ConversionNumber
    @ExcelIgnore
    private Long purchaseWeight;

    @ApiModelProperty("单位3")
    @ExcelProperty("单位3")
    private String unitThree;

    @ApiModelProperty("不含税单价")
    @ConversionNumber(value = 10000)
    @ExcelIgnore
    private Long preTaxPrice;

    @ApiModelProperty("不含税单价")
    @ConversionNumber(value = 10000)
    @ExcelProperty("不含税单价")
    private Double preTaxPriceExport;


    @ApiModelProperty("含税单价")
    @ConversionNumber(value = 10000)
    @ExcelIgnore
    private Long unitPriceWithTax;

    @ApiModelProperty("含税单价")
    @ConversionNumber(value = 10000)
    @ExcelProperty("含税单价")
    private Double unitPriceWithTaxExport;

    @ApiModelProperty("不含税总价")
    @ConversionNumber
    @ExcelIgnore
    private Long totalPriceExcludingTax;

    @ApiModelProperty("不含税总价")
    @ConversionNumber
    @ExcelProperty("不含税总价")
    private Double totalPriceExcludingTaxExport;

    @ApiModelProperty("含税总价")
    @ConversionNumber
    @ExcelIgnore
    private Long totalPriceIncludingTax;

    @ApiModelProperty("含税总价")
    @ConversionNumber
    @ExcelProperty("含税总价")
    private Double totalPriceIncludingTaxExport;


    @ApiModelProperty("税额")
    @ExcelIgnore
    @ConversionNumber
    private Long tax;

    @ApiModelProperty("税率")
    @ExcelIgnore
    private Long taxRate;

    @ApiModelProperty("税率")
    @ExcelProperty("税率")
    private Double taxRateExport;

    @ApiModelProperty("牌号")
    @ExcelProperty("品牌")
    private String brand;


    @ApiModelProperty("备注")
    @ExcelProperty("备注")
    private String remarks;

    @ApiModelProperty("用料类型")
    @ExcelProperty("用料类型")
    private String ingredientsType;

    @ApiModelProperty("物资类型")
    @ExcelIgnore
    private Integer materialType;

    @ApiModelProperty("物资类型描述")
    @ExcelIgnore
    private String materialTypeText;

    @ApiModelProperty("序号")
    private Integer serialNumber;

    @ApiModelProperty("采购计划表ID")
    private String purchasePlanId;

    @ApiModelProperty("油漆需求计划表ID")
    private String weldingMaterialDemandPlanId;

    @ApiModelProperty("项目名称")
    private String projectName;


    @ContentStyle(
            horizontalAlignment = HorizontalAlignmentEnum.LEFT, //水平居左
            verticalAlignment = VerticalAlignmentEnum.CENTER, //垂直居中
            wrapped = BooleanEnum.TRUE)//主要是为了导出时直接换行
    @ExcelProperty("条形码")
    @ColumnWidth(60)
    private WriteCellData<Void> barcode;


    @ApiModelProperty("产品需求计划汇总表ID")
    private String productDemandPlanTotalId;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;

    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("件号")
    private String partNo;
}
