package com.vren.material.module.materialremain.domain.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class MaterialRemainVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("项目id")
    private String projectId;

    @ApiModelProperty("项目名称")
    private String projectName;

    @ApiModelProperty("余料名称")
    private String remainingMaterialName;

    @ApiModelProperty("余料编号")
    private String remainingMaterialNo;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("材质")
    private String texture;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("余料重量")
    @ConversionNumber
    private Long remainingMaterialWeight;

    @ApiModelProperty("余料数量")
    @ConversionNumber
    private Long remainingMaterialCount;

    @ApiModelProperty("执行标准")
    private String executiveStandard;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("锁库数量")
    @ConversionNumber
    private Long lockNumber;

    @ApiModelProperty("库存状态")
    private Integer stockStatus;

    @ApiModelProperty("库存状态")
    private String stockStatusText;

    @ApiModelProperty("附件")
    private String attachmentPath;

    @ApiModelProperty("物资类型名称")
    private String materialTypeText;

    @ApiModelProperty("物资类型")
    private Integer materialType;

    @ApiModelProperty("税前单价")
    @ConversionNumber(value = 10000)
    private Long preTaxPrice;

    @ApiModelProperty("含税总额")
    private Long totalAmountIncludingTax;

    @ApiModelProperty("用料单位")
    @ExcelProperty("单位1")
    private String useMaterialUnit;

    @ApiModelProperty("用料单位")
    private String materialStockId;

    @ApiModelProperty("第一尺寸")
    @ConversionNumber
    private Long firstSize;

    @ApiModelProperty("第二尺寸")
    @ConversionNumber
    private Long secondSize;

    @ApiModelProperty("第三尺寸")
    @ConversionNumber
    private Long thirdSize;

    @ApiModelProperty("物资编号")
    private String materialNumber;

    @ApiModelProperty("供应商id")
    private String supplierId;

    @ApiModelProperty("供应商姓名")
    private String supplierName;

}
