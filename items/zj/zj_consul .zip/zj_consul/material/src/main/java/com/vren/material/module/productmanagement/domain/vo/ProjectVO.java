package com.vren.material.module.productmanagement.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 * 项目id和项目名称
 */
@Data
public class ProjectVO {

    @ApiModelProperty("id")
    private String id;

    /**
     * 项目名称
     */
    @ApiModelProperty("项目名称")
    private String projectName;
}
