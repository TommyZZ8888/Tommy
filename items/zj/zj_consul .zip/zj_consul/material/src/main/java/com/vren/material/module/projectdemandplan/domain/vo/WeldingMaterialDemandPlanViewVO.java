package com.vren.material.module.projectdemandplan.domain.vo;


import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * 焊材展示详情VO
 * @author szp
 * @date 2022/10/14 15:39
 */
@Data
public class WeldingMaterialDemandPlanViewVO {
    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("库存表id")
    private String materialStockId;

    @ApiModelProperty("项目需求计划表id")
    private String projectDemandPlanId;

    @ApiModelProperty("材料名称")
    private String materialName;

    @ApiModelProperty("型号")
    private String model;

    @ApiModelProperty("牌号")
    private String brand;

    @ApiModelProperty("规格")
    private String size;
    @ConversionNumber
    @ApiModelProperty("重量")
    private Long weight;

    @ApiModelProperty("单位")
    private String unit;
    @ConversionNumber
    @ApiModelProperty("数量")
    private Long count;

    @ApiModelProperty("技术标准")
    private String technicalStandards;
    @ConversionNumber
    @ApiModelProperty("锁库数量")
    private Long stockAmount;

    @ApiModelProperty("备注")
    private String remarks;

    @ApiModelProperty("库存类型")
    private Integer stockType;

    @ConversionNumber
    @ApiModelProperty("标书价")
    private Long bidPrice;

    @ApiModelProperty("交货时间")
    private Date deliveryTime;

    @ApiModelProperty("交货地点")
    private String deliveryLocation;

    @ConversionNumber
    @ApiModelProperty("标书单价")
    private Long bidUnitPrice;
}
