package com.vren.material.module.productdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.Size;
import java.util.List;

/**
 * @author 耿让
 * 批量新增
 */
@Data
public class BatchInsertDetailDTO {

    @Size(min = 1,message = "参数不能为空")
    @ApiModelProperty("产品需求详情集合（批量新增）")
    private List<InsertDetailDTO> list;

}
