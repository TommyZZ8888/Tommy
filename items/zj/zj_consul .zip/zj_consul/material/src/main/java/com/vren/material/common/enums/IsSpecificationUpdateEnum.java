package com.vren.material.common.enums;

/**
 * @Description IsSpecificationUpdateEnum
 * @Author 张卫刚
 * @Date Created on 2023/9/12
 */
public enum IsSpecificationUpdateEnum {

    NOT_UPDATE(0, "未更新"),
    UPDATED(1, "更新"),
    ;

    private Integer code;

    private String name;

    IsSpecificationUpdateEnum (Integer code, String name) {
        this.name = name;
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public void setCode(Integer code){
        this.code = code;
    }

    public void setName(String name){
        this.name = name;
    }
 }
