package com.vren.material.module.purchaseplan.domain.dto;

import com.vren.common.common.domain.PageParam;
import com.vren.material.module.projectdemandplan.domain.dto.IdDTO;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @author 耿让
 */
@Data
public class QueryDTO extends PageParam {
    @ApiModelProperty("采购合同项目需求绑定id")
    @NotBlank(message = "id不能为空")
    private String purchaseContractProjectInfoId;

    @ApiModelProperty("物资类型")
    private Integer materialType;
}
