package com.vren.material.module.order.domain.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
@TableName("order_detail")
public class OrderDetail {

  @TableId(type = IdType.ASSIGN_UUID)
  private String id;

  @ApiModelProperty("订单id")
  private String orderId;

  @ApiModelProperty("采购计划详情id")
  private String purchasePlanDetailId;

  @ApiModelProperty("订单数量")
  @ConversionNumber
  private Long orderQuantity;

  @ApiModelProperty("批次")
  private String batch;

  @ApiModelProperty("项目id")
  private String projectId;


}
