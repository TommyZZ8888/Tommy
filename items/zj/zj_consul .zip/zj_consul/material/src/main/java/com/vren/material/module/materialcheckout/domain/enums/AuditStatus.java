package com.vren.material.module.materialcheckout.domain.enums;

public enum AuditStatus {
    UNAUDITED(0,"未审核"),
    APPROVALED(1,"审核通过"),
    APPROVALING(2,"审核失败"),
    UNAPPROVALED(3,"待审核")
    ;
    AuditStatus(Integer code, String name){
        this.code = code;
        this.name = name;
    }
    public Integer getCode() {
        return code;
    }
    public String getName() {
        return name;
    }
    private Integer code;
    private String  name;
}
