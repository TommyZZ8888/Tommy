package com.vren.material.module.materialcheckout.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * @Description MaterialCheckoutDetailListVO
 * @Author 张卫刚
 * @Date Created on 2023/9/22
 */
@Data
@Builder
@AllArgsConstructor
@Accessors(chain = true)
@NoArgsConstructor
public class MaterialCheckoutDetailWordExportVO {

    @ApiModelProperty("序号")
    private String serialNum;

    @ApiModelProperty("物资名称")
    private String materialName;

    @ApiModelProperty("规格")
    private String specification;

    @ApiModelProperty("计量单位")
    private String measuringUnit;

    @ApiModelProperty("已领数量")
    private String pickedQuantity;

    @ApiModelProperty("税前单价")
    private String preTaxPrice;

    @ApiModelProperty("金额")
    private String money;

    @ApiModelProperty("甲供")
    private String ownerSupply;

    @ApiModelProperty("自购")
    private String selfPurchase;

    @ApiModelProperty("调剂")
    private String adjust;

    @ApiModelProperty("分包一数量")
    private String subPackageOneCount;

    @ApiModelProperty("分包一金额")
    private String subPackageOneMoney;

    @ApiModelProperty("分包二数量")
    private String subPackageTwoCount;

    @ApiModelProperty("分包二金额")
    private String subPackageTwoMoney;

    @ApiModelProperty("分包三数量")
    private String subPackageThreeCount;

    @ApiModelProperty("分包三金额")
    private String subPackageThreeMoney;

    @ApiModelProperty("分包四数量")
    private String subPackageFourCount;

    @ApiModelProperty("分包四金额")
    private String subPackageFourMoney;

    @ApiModelProperty("库存数量")
    private String stockCount;

    @ApiModelProperty("库存金额")
    private String stockMoney;

    @ApiModelProperty("票据号")
    private String billNum;


}
