package com.vren.material.module.projectdemandplan.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 项目名称和对应id 返回添加 VO
 * @author szp
 * @date 2022/10/13 13:12
 */
@Data
public class ProjectNameDataVO {
    @ApiModelProperty("项目名称")
    private String projectName;
    @ApiModelProperty("项目id")
    private String projectId;
}
