package com.vren.material.module.productmanagement.domain.vo;

import com.vren.common.common.anno.ConversionNumber;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author 耿让
 */
@Data
public class ProductByProjectIdVO {

    @ApiModelProperty("id")
    private String id;

    @ApiModelProperty("产品名称")
    private String productName;

    @ApiModelProperty("制造编号(生产编号)")
    private String manufacturingNumber;

    @ApiModelProperty("重量/吨")
    @ConversionNumber
    private Long weight;
}
