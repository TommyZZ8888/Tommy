package com.vren.material.module.projectdemandplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class ProductDemandPlanTotalImportDTO {
    @ApiModelProperty("项目需求计划Id")
    @NotBlank(message = "项目需求计划Id不能为空")
    private String projectDemandPlanId;

    @ApiModelProperty("需求类型")
    @NotNull(message = "需求类型不能为空")
    private  Integer demandType;
}
