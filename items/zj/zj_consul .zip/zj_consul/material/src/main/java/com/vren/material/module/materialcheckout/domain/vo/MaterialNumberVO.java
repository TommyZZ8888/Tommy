package com.vren.material.module.materialcheckout.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class MaterialNumberVO {
    @ApiModelProperty("材料编号")
    private String materialNumber;
}
