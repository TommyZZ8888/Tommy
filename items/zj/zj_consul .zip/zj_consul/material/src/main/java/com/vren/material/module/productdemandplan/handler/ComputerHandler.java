package com.vren.material.module.productdemandplan.handler;

import com.vren.material.module.productdemandplan.domain.dto.InsertDetailDTO;
import com.vren.material.module.productdemandplan.domain.entity.ProductDemandPlanDetails;
import com.vren.material.module.projectdemandplan.domain.dto.BoardImportDTO;
import com.vren.material.module.projectdemandplan.domain.vo.ProductDemandPlanTotalExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProfileExportVO;
import com.vren.material.module.projectdemandplan.domain.vo.ProjectDemandPlanExportVO;

import java.io.Serializable;
import java.util.Map;

/**
 * @author vren
 */
public interface ComputerHandler extends Serializable {

    ProductDemandPlanDetails execution(InsertDetailDTO data);


    /**
     *  根据规格解析出尺寸
     * @param vo
     */
    void analysis(ProductDemandPlanTotalExportVO vo);
    /**
     *  根据规格解析出尺寸
     * @param vo
     */
    void analysis(ProfileExportVO vo);

    /**
     *  根据用料类型和规格计算厚度、宽度和长度
     * @param specification
     * @param ingredientsType
     * @return
     */
    Map<String,String> analysis(String specification,String ingredientsType);


    void analysis(ProjectDemandPlanExportVO item);


    /**
     *  项目需求计划导入，根据厚度、宽度和长度计算重量，生成规格
     * @param data
     */
    void execution(BoardImportDTO data);

}
