package com.vren.material.module.purchaseplan.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author 耿让
 */
@Data
public class DeletePurchasePlanDTO {

    @ApiModelProperty("项目id（删除该项目下所有的采购计划）")
    @NotBlank(message = "项目id不能为空")
    private String projectId;

    @ApiModelProperty("批次")
    private String batch;

}
