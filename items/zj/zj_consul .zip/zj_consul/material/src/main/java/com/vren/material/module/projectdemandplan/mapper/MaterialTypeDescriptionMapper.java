package com.vren.material.module.projectdemandplan.mapper;

import com.github.yulichang.base.MPJBaseMapper;

import com.vren.material.module.projectdemandplan.domain.entity.MaterialTypeDescription;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MaterialTypeDescriptionMapper extends MPJBaseMapper<MaterialTypeDescription> {
}
